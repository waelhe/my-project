/**
 * In-Memory Rate Limiter
 * نظام تحديد معدل الطلبات في الذاكرة
 * 
 * يستخدم لتقييد عدد الطلبات لكل IP خلال فترة زمنية محددة
 */

interface RateLimitEntry {
  count: number;
  resetTime: number;
}

interface RateLimitResult {
  success: boolean;
  limit: number;
  remaining: number;
  resetTime: number;
  retryAfter?: number;
}

// In-memory storage for rate limits
// Map<key, RateLimitEntry>
const rateLimitStore = new Map<string, RateLimitEntry>();

// Cleanup interval to prevent memory leaks
// تنظيف دوري لمنع تسرب الذاكرة
setInterval(() => {
  const now = Date.now();
  for (const [key, entry] of rateLimitStore.entries()) {
    if (now > entry.resetTime) {
      rateLimitStore.delete(key);
    }
  }
}, 60 * 1000); // Every minute

/**
 * Rate Limiter Class
 * فئة تحديد معدل الطلبات
 */
export class RateLimiter {
  private windowMs: number;
  private maxRequests: number;
  private prefix: string;

  constructor(options: { windowMs: number; maxRequests: number; prefix?: string }) {
    this.windowMs = options.windowMs;
    this.maxRequests = options.maxRequests;
    this.prefix = options.prefix || 'rl';
  }

  /**
   * Check rate limit for a given key (usually IP address)
   * التحقق من حد الطلبات لمفتاح معين (عادة عنوان IP)
   */
  check(key: string): RateLimitResult {
    const fullKey = `${this.prefix}:${key}`;
    const now = Date.now();
    
    const entry = rateLimitStore.get(fullKey);

    if (!entry || now > entry.resetTime) {
      // Create new entry
      const newEntry: RateLimitEntry = {
        count: 1,
        resetTime: now + this.windowMs
      };
      rateLimitStore.set(fullKey, newEntry);

      return {
        success: true,
        limit: this.maxRequests,
        remaining: this.maxRequests - 1,
        resetTime: newEntry.resetTime
      };
    }

    // Entry exists and within window
    if (entry.count >= this.maxRequests) {
      return {
        success: false,
        limit: this.maxRequests,
        remaining: 0,
        resetTime: entry.resetTime,
        retryAfter: Math.ceil((entry.resetTime - now) / 1000)
      };
    }

    // Increment count
    entry.count++;
    rateLimitStore.set(fullKey, entry);

    return {
      success: true,
      limit: this.maxRequests,
      remaining: this.maxRequests - entry.count,
      resetTime: entry.resetTime
    };
  }

  /**
   * Reset rate limit for a given key
   * إعادة تعيين حد الطلبات لمفتاح معين
   */
  reset(key: string): void {
    const fullKey = `${this.prefix}:${key}`;
    rateLimitStore.delete(fullKey);
  }
}

/**
 * Get client IP from request
 * الحصول على عنوان IP للعميل من الطلب
 */
export function getClientIP(request: Request): string {
  // Check various headers for real IP (behind proxy/CDN)
  const forwarded = request.headers.get('x-forwarded-for');
  if (forwarded) {
    // Take first IP in the chain
    return forwarded.split(',')[0].trim();
  }

  const realIP = request.headers.get('x-real-ip');
  if (realIP) {
    return realIP;
  }

  // Fallback to a default (for development)
  return 'unknown';
}

/**
 * Create rate limit headers for response
 * إنشاء headers تحديد الطلبات للاستجابة
 */
export function createRateLimitHeaders(result: RateLimitResult): HeadersInit {
  return {
    'X-RateLimit-Limit': result.limit.toString(),
    'X-RateLimit-Remaining': result.remaining.toString(),
    'X-RateLimit-Reset': Math.ceil(result.resetTime / 1000).toString(),
    ...(result.retryAfter && { 'Retry-After': result.retryAfter.toString() })
  };
}

// Pre-configured rate limiters for different endpoints
// تحديدات معدل مُعدّة مسبقاً لنقاط نهاية مختلفة

/**
 * Rate limiter for tourism agent API
 * 10 requests per minute per IP
 */
export const tourismAgentLimiter = new RateLimiter({
  windowMs: 60 * 1000, // 1 minute
  maxRequests: 10,
  prefix: 'tourism-agent'
});

/**
 * Rate limiter for chat API
 * 10 requests per minute per IP
 */
export const chatLimiter = new RateLimiter({
  windowMs: 60 * 1000, // 1 minute
  maxRequests: 10,
  prefix: 'chat'
});

/**
 * Rate limiter for OTP API
 * 3 requests per minute per IP (for additional protection)
 */
export const otpLimiter = new RateLimiter({
  windowMs: 60 * 1000, // 1 minute
  maxRequests: 3,
  prefix: 'otp'
});
