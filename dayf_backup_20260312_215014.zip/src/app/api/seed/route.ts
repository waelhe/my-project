import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

// POST /api/seed - Seed initial data
// ⚠️ This endpoint is only available in development mode
export async function POST() {
  // Security: Only allow in development
  if (process.env.NODE_ENV === 'production') {
    return NextResponse.json(
      { error: 'هذا الإجراء غير متاح في بيئة الإنتاج' },
      { status: 403 }
    );
  }

  try {
    // Check if already seeded
    const existingCities = await db.city.count();
    if (existingCities > 0) {
      return NextResponse.json({ 
        message: 'Database already seeded',
        cities: existingCities 
      });
    }

    // Create cities
    const cities = await db.city.createMany({
      data: [
        { nameAr: 'دمشق', nameEn: 'Damascus', governorate: 'دمشق', isPopular: true },
        { nameAr: 'حلب', nameEn: 'Aleppo', governorate: 'حلب', isPopular: true },
        { nameAr: 'اللاذقية', nameEn: 'Lattakia', governorate: 'اللاذقية', isPopular: true },
        { nameAr: 'طرطوس', nameEn: 'Tartus', governorate: 'طرطوس', isPopular: true },
        { nameAr: 'حمص', nameEn: 'Homs', governorate: 'حمص', isPopular: true },
        { nameAr: 'حماة', nameEn: 'Hama', governorate: 'حماة', isPopular: false },
        { nameAr: 'تدمر', nameEn: 'Palmyra', governorate: 'حمص', isPopular: true },
        { nameAr: 'معلولا', nameEn: 'Maaloula', governorate: 'ريف دمشق', isPopular: true },
        { nameAr: 'صافيتا', nameEn: 'Safita', governorate: 'طرطوس', isPopular: false },
        { nameAr: 'السويداء', nameEn: 'Suwayda', governorate: 'السويداء', isPopular: false },
        { nameAr: 'درعا', nameEn: 'Daraa', governorate: 'درعا', isPopular: false },
        { nameAr: 'القامشلي', nameEn: 'Qamishli', governorate: 'الحسكة', isPopular: false },
        { nameAr: 'دير الزور', nameEn: 'Deir ez-Zor', governorate: 'دير الزور', isPopular: false },
        { nameAr: 'إدلب', nameEn: 'Idlib', governorate: 'إدلب', isPopular: false },
        { nameAr: 'الرقة', nameEn: 'Raqqa', governorate: 'الرقة', isPopular: false },
      ]
    });

    // Create a demo host user
    const host = await db.user.create({
      data: {
        phone: '+963999999999',
        name: 'مضيف تجريبي',
        nameAr: 'مضيف تجريبي',
        role: 'HOST',
        status: 'ACTIVE',
        isVerified: true
      }
    });

    // Get Damascus city
    const damascus = await db.city.findFirst({
      where: { nameEn: 'Damascus' }
    });

    const aleppo = await db.city.findFirst({
      where: { nameEn: 'Aleppo' }
    });

    const lattakia = await db.city.findFirst({
      where: { nameEn: 'Lattakia' }
    });

    // Create sample accommodations
    if (damascus && aleppo && lattakia) {
      await db.accommodation.createMany({
        data: [
          {
            titleAr: 'شقة فاخرة في قلب دمشق',
            titleEn: 'Luxury Apartment in Heart of Damascus',
            descriptionAr: 'شقة مفروشة بالكامل مع إطلالة رائعة على المدينة القديمة',
            descriptionEn: 'Fully furnished apartment with stunning view of the Old City',
            type: 'APARTMENT',
            status: 'ACTIVE',
            addressAr: 'الشعلان، دمشق',
            cityId: damascus.id,
            bedrooms: 2,
            bathrooms: 1,
            maxGuests: 4,
            beds: 2,
            basePrice: 150000,
            amenities: JSON.stringify(['wifi', 'ac', 'parking', 'kitchen', 'tv']),
            hostId: host.id,
            images: JSON.stringify([
              'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?q=80&w=800',
              'https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?q=80&w=800'
            ]),
            coverImage: 'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?q=80&w=800',
            rating: 4.9,
            reviewCount: 128
          },
          {
            titleAr: 'غرفة في فندق تاريخي',
            titleEn: 'Room in Historic Hotel',
            descriptionAr: 'فندق بارون التاريخي - تجربة فريدة في قلب حلب القديمة',
            descriptionEn: 'Historic Baron Hotel - Unique experience in Old Aleppo',
            type: 'HOTEL',
            status: 'ACTIVE',
            addressAr: 'الجميلية، حلب',
            cityId: aleppo.id,
            bedrooms: 1,
            bathrooms: 1,
            maxGuests: 2,
            beds: 1,
            basePrice: 280000,
            amenities: JSON.stringify(['wifi', 'breakfast', 'restaurant', 'room-service']),
            hostId: host.id,
            images: JSON.stringify([
              'https://images.unsplash.com/photo-1566073771259-6a8506099945?q=80&w=800'
            ]),
            coverImage: 'https://images.unsplash.com/photo-1566073771259-6a8506099945?q=80&w=800',
            rating: 4.7,
            reviewCount: 89
          },
          {
            titleAr: 'شاليه على شاطئ اللاذقية',
            titleEn: 'Chalet on Lattakia Beach',
            descriptionAr: 'شاليه مباشر على البحر مع خاصية خروج للشاطئ',
            descriptionEn: 'Beachfront chalet with direct beach access',
            type: 'CHALET',
            status: 'ACTIVE',
            addressAr: 'شاطئ السيادر، اللاذقية',
            cityId: lattakia.id,
            bedrooms: 3,
            bathrooms: 2,
            maxGuests: 6,
            beds: 4,
            basePrice: 200000,
            amenities: JSON.stringify(['wifi', 'ac', 'parking', 'kitchen', 'sea-view', 'bbq']),
            hostId: host.id,
            images: JSON.stringify([
              'https://images.unsplash.com/photo-1587061949409-02df41d5e562?q=80&w=800'
            ]),
            coverImage: 'https://images.unsplash.com/photo-1587061949409-02df41d5e562?q=80&w=800',
            rating: 4.8,
            reviewCount: 156
          },
          {
            titleAr: 'فيلا عصرية في المزة',
            titleEn: 'Modern Villa in Mezzeh',
            descriptionAr: 'فيلا فاخرة مع حديقة ومسبح خاص',
            descriptionEn: 'Luxury villa with garden and private pool',
            type: 'VILLA',
            status: 'ACTIVE',
            addressAr: 'المزة، دمشق',
            cityId: damascus.id,
            bedrooms: 4,
            bathrooms: 3,
            maxGuests: 8,
            beds: 5,
            basePrice: 350000,
            amenities: JSON.stringify(['wifi', 'ac', 'parking', 'kitchen', 'pool', 'garden']),
            hostId: host.id,
            images: JSON.stringify([
              'https://images.unsplash.com/photo-1631049307264-da0ec9d70304?q=80&w=800'
            ]),
            coverImage: 'https://images.unsplash.com/photo-1631049307264-da0ec9d70304?q=80&w=800',
            rating: 4.9,
            reviewCount: 234
          }
        ]
      });
    }

    return NextResponse.json({
      success: true,
      message: 'Database seeded successfully',
      data: {
        cities: cities.count
      }
    });

  } catch (error) {
    console.error('Seed error:', error);
    return NextResponse.json(
      { error: 'حدث خطأ في تهيئة البيانات' },
      { status: 500 }
    );
  }
}
