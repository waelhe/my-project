import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET /api/cities - List cities
export async function GET(request: NextRequest) {
  try {
    const cities = await db.city.findMany({
      orderBy: [
        { isPopular: 'desc' },
        { nameAr: 'asc' }
      ],
      include: {
        _count: {
          select: {
            accommodations: {
              where: { status: 'ACTIVE' }
            }
          }
        }
      }
    });

    return NextResponse.json({ cities });

  } catch (error) {
    console.error('Get cities error:', error);
    return NextResponse.json(
      { error: 'حدث خطأ في جلب البيانات' },
      { status: 500 }
    );
  }
}
