'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import {
  Search,
  MapPin,
  Bell,
  ChevronLeft,
  ChevronRight,
  Flame,
} from 'lucide-react';
import { Carousel, CarouselContent, CarouselItem } from '@/components/ui/carousel';

const heroSlides = [
  {
    title: 'سوق المستعمل',
    description: 'بع واشترِ بأمان في ضاحيتك',
    image: '/images/marketplace-hero.jpg',
    color: 'from-orange-500/20 to-yellow-500/20',
  },
  {
    title: 'عقارات الضاحية',
    description: 'شقق، محلات، وأراضٍ للبيع والإيجار',
    image: '/images/realestate-hero.jpg',
    color: 'from-emerald-500/20 to-teal-500/20',
  },
  {
    title: 'دليل الفعاليات',
    description: 'اكتشف المحلات والخدمات حولك',
    image: '/images/directory-hero.jpg',
    color: 'from-purple-500/20 to-pink-500/20',
  },
];

const popularSearches = [
  'شقة للإيجار',
  'سيارة مستعملة',
  'صيدلية مناوبة',
  'طبيب أسنان',
  'أثاث منزلية',
];

export function HeroSection() {
  const router = useRouter();
  const [searchQuery, setSearchQuery] = useState('');
  const [currentSlide, setCurrentSlide] = useState(0);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      router.push(`/search?q=${encodeURIComponent(searchQuery)}`);
    }
  };

  return (
    <section className="relative overflow-hidden">
      {/* Background Gradient */}
      <div className="absolute inset-0 bg-gradient-to-b from-primary/5 via-transparent to-transparent" />

      {/* Animated Background Elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-primary/10 rounded-full blur-3xl animate-pulse" />
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-emerald-500/10 rounded-full blur-3xl animate-pulse delay-1000" />
      </div>

      <div className="container relative px-4 py-8">
        {/* Location Badge */}
        <div className="flex items-center justify-center gap-2 mb-6">
          <div className="flex items-center gap-2 px-4 py-2 bg-primary/10 rounded-full text-sm">
            <MapPin className="h-4 w-4 text-primary" />
            <span className="font-medium">ضاحية قدسيا</span>
          </div>
        </div>

        {/* Hero Card */}
        <Card className="max-w-2xl mx-auto overflow-hidden border-0 shadow-xl">
          <CardContent className="p-0">
            {/* Slides */}
            <div className="relative h-48 overflow-hidden">
              {heroSlides.map((slide, index) => (
                <div
                  key={index}
                  className={`absolute inset-0 transition-all duration-500 ${
                    index === currentSlide
                      ? 'opacity-100 translate-x-0'
                      : 'opacity-0 translate-x-full'
                  }`}
                >
                  <div className={`absolute inset-0 bg-gradient-to-br ${slide.color}`} />
                  <div className="absolute inset-0 flex flex-col items-center justify-center p-6 text-center">
                    <h2 className="text-2xl font-bold mb-2">{slide.title}</h2>
                    <p className="text-muted-foreground">{slide.description}</p>
                  </div>
                </div>
              ))}

              {/* Navigation Arrows */}
              <button
                onClick={() =>
                  setCurrentSlide((prev) =>
                    prev === 0 ? heroSlides.length - 1 : prev - 1
                  )
                }
                className="absolute left-2 top-1/2 -translate-y-1/2 h-8 w-8 rounded-full bg-background/80 flex items-center justify-center hover:bg-background transition-colors"
              >
                <ChevronLeft className="h-4 w-4" />
              </button>
              <button
                onClick={() =>
                  setCurrentSlide((prev) =>
                    prev === heroSlides.length - 1 ? 0 : prev + 1
                  )
                }
                className="absolute right-2 top-1/2 -translate-y-1/2 h-8 w-8 rounded-full bg-background/80 flex items-center justify-center hover:bg-background transition-colors"
              >
                <ChevronRight className="h-4 w-4" />
              </button>

              {/* Dots */}
              <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex gap-2">
                {heroSlides.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => setCurrentSlide(index)}
                    className={`h-2 rounded-full transition-all ${
                      index === currentSlide
                        ? 'w-6 bg-primary'
                        : 'w-2 bg-primary/30'
                    }`}
                  />
                ))}
              </div>
            </div>

            {/* Search Bar */}
            <div className="p-4 bg-card">
              <form onSubmit={handleSearch} className="flex gap-2">
                <div className="relative flex-1">
                  <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="ابحث في المنصة..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pr-10"
                  />
                </div>
                <Button type="submit">بحث</Button>
              </form>

              {/* Popular Searches */}
              <div className="mt-3">
                <p className="text-xs text-muted-foreground mb-2">بحث شائع:</p>
                <div className="flex flex-wrap gap-2">
                  {popularSearches.map((term) => (
                    <button
                      key={term}
                      onClick={() => setSearchQuery(term)}
                      className="text-xs px-3 py-1 bg-muted rounded-full hover:bg-muted/80 transition-colors"
                    >
                      {term}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Quick Add Button */}
        <div className="flex justify-center mt-6">
          <Button size="lg" className="gap-2 shadow-lg">
            <Flame className="h-5 w-5" />
            أضف إعلانك مجاناً
          </Button>
        </div>
      </div>
    </section>
  );
}
