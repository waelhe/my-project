'use client';

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Moon, Clock, MapPin } from 'lucide-react';

// Prayer times for Qudsaya - would normally come from an API
const prayerTimes = [
  { name: 'الفجر', time: '04:52', icon: '🌙' },
  { name: 'الشروق', time: '06:17', icon: '🌅' },
  { name: 'الظهر', time: '12:42', icon: '☀️' },
  { name: 'العصر', time: '16:27', icon: '🌤️' },
  { name: 'المغرب', time: '19:07', icon: '🌅' },
  { name: 'العشاء', time: '20:32', icon: '🌙' },
];

const getNextPrayer = () => {
  const now = new Date();
  const currentHour = now.getHours();
  const currentMinute = now.getMinutes();
  const currentTime = currentHour * 60 + currentMinute;

  for (const prayer of prayerTimes) {
    const [hours, minutes] = prayer.time.split(':').map(Number);
    const prayerTime = hours * 60 + minutes;
    if (prayerTime > currentTime) {
      return prayer;
    }
  }
  return prayerTimes[0]; // Return Fajr for next day
};

export function PrayerTimesCard() {
  const nextPrayer = getNextPrayer();

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-base flex items-center gap-2">
          <Moon className="h-4 w-4 text-primary" />
          مواقيت الصلاة
        </CardTitle>
      </CardHeader>
      <CardContent>
        {/* Next Prayer Highlight */}
        <div className="bg-primary/10 rounded-xl p-4 mb-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs text-muted-foreground">الصلاة القادمة</p>
              <p className="text-lg font-bold">{nextPrayer.name}</p>
            </div>
            <div className="text-left">
              <p className="text-2xl font-bold text-primary">{nextPrayer.time}</p>
              <div className="flex items-center gap-1 text-xs text-muted-foreground">
                <MapPin className="h-3 w-3" />
                ضاحية قدسيا
              </div>
            </div>
          </div>
        </div>

        {/* All Prayer Times */}
        <div className="grid grid-cols-3 gap-2">
          {prayerTimes.map((prayer) => (
            <div
              key={prayer.name}
              className={`text-center p-2 rounded-lg ${
                prayer.name === nextPrayer.name
                  ? 'bg-primary text-primary-foreground'
                  : 'bg-muted'
              }`}
            >
              <span className="text-lg">{prayer.icon}</span>
              <p className="text-xs font-medium mt-1">{prayer.name}</p>
              <p
                className={`text-xs ${
                  prayer.name === nextPrayer.name
                    ? 'text-primary-foreground'
                    : 'text-muted-foreground'
                }`}
              >
                {prayer.time}
              </p>
            </div>
          ))}
        </div>

        {/* Date */}
        <div className="mt-4 text-center text-xs text-muted-foreground">
          <p>الأحد 15 رمضان 1446</p>
          <p>15 آذار 2025</p>
        </div>
      </CardContent>
    </Card>
  );
}
