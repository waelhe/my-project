'use client';

import Link from 'next/link';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  ShoppingCart,
  Building2,
  BookOpen,
  Users,
  TrendingUp,
  Moon,
  Pill,
  Car,
  Phone,
  Utensils,
} from 'lucide-react';

const quickAccessItems = [
  {
    title: 'سوق المستعمل',
    description: 'بع واشترِ',
    icon: ShoppingCart,
    href: '/marketplace',
    color: 'bg-orange-500',
    count: 156,
  },
  {
    title: 'العقارات',
    description: 'بيع وإيجار',
    icon: Building2,
    href: '/real-estate',
    color: 'bg-emerald-500',
    count: 89,
  },
  {
    title: 'دليل الفعاليات',
    description: 'محلات وخدمات',
    icon: BookOpen,
    href: '/directory',
    color: 'bg-purple-500',
    count: 234,
  },
  {
    title: 'المجتمع',
    description: 'تواصل مع الجيران',
    icon: Users,
    href: '/community',
    color: 'bg-pink-500',
    count: null,
  },
  {
    title: 'أسعار السوق',
    description: 'أسعار اليوم',
    icon: TrendingUp,
    href: '/market-prices',
    color: 'bg-cyan-500',
    count: null,
  },
  {
    title: 'إسلامي',
    description: 'مواقيت الصلاة',
    icon: Moon,
    href: '/islamic',
    color: 'bg-indigo-500',
    count: null,
  },
  {
    title: 'صيدليات مناوبة',
    description: 'متاحة الآن',
    icon: Pill,
    href: '/pharmacies',
    color: 'bg-red-500',
    count: 3,
  },
  {
    title: 'مواصلات',
    description: 'سيارات وسرافيس',
    icon: Car,
    href: '/transport',
    color: 'bg-amber-500',
    count: null,
  },
  {
    title: 'مطاعم',
    description: 'توصيل وجبات',
    icon: Utensils,
    href: '/directory?category=restaurants',
    color: 'bg-rose-500',
    count: null,
  },
  {
    title: 'طوارئ',
    description: 'أرقام هامة',
    icon: Phone,
    href: '/emergency',
    color: 'bg-red-600',
    count: null,
  },
];

export function QuickAccess() {
  return (
    <section className="container px-4 py-4">
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base">الوصول السريع</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3">
            {quickAccessItems.map((item) => {
              const Icon = item.icon;
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className="group relative p-4 rounded-xl bg-muted/50 hover:bg-muted transition-all hover:shadow-md"
                >
                  <div className="flex flex-col items-center text-center">
                    <div
                      className={`h-12 w-12 rounded-xl ${item.color} flex items-center justify-center mb-3 shadow-lg transform group-hover:scale-110 transition-transform`}
                    >
                      <Icon className="h-6 w-6 text-white" />
                    </div>
                    <h3 className="font-semibold text-sm mb-1">{item.title}</h3>
                    <p className="text-xs text-muted-foreground">
                      {item.description}
                    </p>
                    {item.count && (
                      <span className="absolute top-2 left-2 min-w-[20px] h-5 px-1.5 rounded-full bg-primary text-primary-foreground text-xs flex items-center justify-center">
                        {item.count}
                      </span>
                    )}
                  </div>
                </Link>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </section>
  );
}
