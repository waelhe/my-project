'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Moon,
  Sun,
  MapPin,
  Clock,
  BookOpen,
  Volume2,
  Navigation,
  Phone,
} from 'lucide-react';

// Prayer times for Qudsaya
const prayerTimes = [
  { name: 'الفجر', nameEn: 'Fajr', time: '04:52', icon: Moon },
  { name: 'الشروق', nameEn: 'Sunrise', time: '06:17', icon: Sun },
  { name: 'الظهر', nameEn: 'Dhuhr', time: '12:42', icon: Sun },
  { name: 'العصر', nameEn: 'Asr', time: '16:27', icon: Sun },
  { name: 'المغرب', nameEn: 'Maghrib', time: '19:07', icon: Moon },
  { name: 'العشاء', nameEn: 'Isha', time: '20:32', icon: Moon },
];

// Sample mosques
const mosques = [
  {
    id: '1',
    name: 'الجامع الكبير',
    neighborhood: 'الجزيرة الأولى',
    imamName: 'الشيخ محمد الأحمد',
    capacity: 500,
    hasWomenSection: true,
    lessons: ['درس تفسير - الثلاثاء بعد العصر', 'حلقة تحفيظ - الجمعة بعد العصر'],
  },
  {
    id: '2',
    name: 'جامع النور',
    neighborhood: 'الجزيرة الثانية',
    imamName: 'الشيخ أحمد الخطيب',
    capacity: 300,
    hasWomenSection: false,
    lessons: ['درس فقه - الأحد بعد المغرب'],
  },
  {
    id: '3',
    name: 'جامع التقوى',
    neighborhood: 'شارع النخيل',
    imamName: 'الشيخ خالد المصري',
    capacity: 400,
    hasWomenSection: true,
    lessons: ['حلقة تحفيظ للأطفال - السبت والأربعاء'],
  },
];

export default function IslamicPage() {
  const [currentTime, setCurrentTime] = useState(new Date());
  const [nextPrayer, setNextPrayer] = useState(prayerTimes[0]);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    const now = currentTime.getHours() * 60 + currentTime.getMinutes();
    for (const prayer of prayerTimes) {
      const [hours, minutes] = prayer.time.split(':').map(Number);
      const prayerMinutes = hours * 60 + minutes;
      if (prayerMinutes > now) {
        setNextPrayer(prayer);
        break;
      }
    }
  }, [currentTime]);

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('ar-SY', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
    });
  };

  const getTimeRemaining = (prayerTime: string) => {
    const [hours, minutes] = prayerTime.split(':').map(Number);
    const now = currentTime.getHours() * 60 + currentTime.getMinutes();
    const prayer = hours * 60 + minutes;
    const diff = prayer - now;
    if (diff <= 0) return null;
    const h = Math.floor(diff / 60);
    const m = diff % 60;
    return `${h} ساعة و ${m} دقيقة`;
  };

  // Hijri date (approximate)
  const hijriDate = '15 رمضان 1446';
  const gregorianDate = new Date().toLocaleDateString('ar-SY', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  return (
    <div className="container px-4 py-6">
      {/* Header */}
      <div className="text-center mb-6">
        <h1 className="text-2xl font-bold mb-2">القسم الإسلامي</h1>
        <p className="text-muted-foreground">مواقيت الصلاة ودليل المساجد</p>
      </div>

      <Tabs defaultValue="prayer-times" className="w-full">
        <TabsList className="grid w-full grid-cols-2 mb-6">
          <TabsTrigger value="prayer-times">مواقيت الصلاة</TabsTrigger>
          <TabsTrigger value="mosques">دليل المساجد</TabsTrigger>
        </TabsList>

        {/* Prayer Times Tab */}
        <TabsContent value="prayer-times">
          {/* Current Time Card */}
          <Card className="mb-6 bg-gradient-to-br from-primary/10 to-primary/5">
            <CardContent className="p-6">
              <div className="text-center">
                <p className="text-sm text-muted-foreground mb-1">الوقت الحالي</p>
                <p className="text-4xl font-bold mb-4">{formatTime(currentTime)}</p>
                <div className="flex justify-center gap-4 text-sm">
                  <span>{hijriDate}</span>
                  <span className="text-muted-foreground">|</span>
                  <span>{gregorianDate}</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Next Prayer Card */}
          <Card className="mb-6 border-primary">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg flex items-center gap-2">
                <Clock className="h-5 w-5 text-primary" />
                الصلاة القادمة
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-2xl font-bold">{nextPrayer.name}</h3>
                  <p className="text-muted-foreground">{nextPrayer.nameEn}</p>
                </div>
                <div className="text-left">
                  <p className="text-3xl font-bold text-primary">{nextPrayer.time}</p>
                  {getTimeRemaining(nextPrayer.time) && (
                    <p className="text-sm text-muted-foreground">
                      متبقي {getTimeRemaining(nextPrayer.time)}
                    </p>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* All Prayer Times */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Moon className="h-5 w-5" />
                مواقيت الصلاة - ضاحية قدسيا
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                {prayerTimes.map((prayer) => {
                  const Icon = prayer.icon;
                  const isNext = prayer.name === nextPrayer.name;

                  return (
                    <div
                      key={prayer.name}
                      className={`p-4 rounded-xl text-center ${
                        isNext ? 'bg-primary text-primary-foreground' : 'bg-muted'
                      }`}
                    >
                      <Icon className={`h-6 w-6 mx-auto mb-2 ${isNext ? '' : 'text-primary'}`} />
                      <p className="font-semibold">{prayer.name}</p>
                      <p className={`text-lg font-bold ${isNext ? '' : 'text-primary'}`}>
                        {prayer.time}
                      </p>
                    </div>
                  );
                })}
              </div>

              <div className="mt-4 p-3 bg-muted/50 rounded-lg text-sm text-center">
                <p className="flex items-center justify-center gap-1">
                  <MapPin className="h-4 w-4" />
                  موقعك: ضاحية قدسيا، ريف دمشق، سوريا
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Mosques Tab */}
        <TabsContent value="mosques">
          <div className="space-y-4">
            {mosques.map((mosque) => (
              <Card key={mosque.id}>
                <CardContent className="p-4">
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <h3 className="font-semibold text-lg">{mosque.name}</h3>
                      <p className="text-sm text-muted-foreground flex items-center gap-1">
                        <MapPin className="h-3 w-3" />
                        {mosque.neighborhood}
                      </p>
                    </div>
                    <div className="flex gap-2">
                      <Button size="icon" variant="outline">
                        <Navigation className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4 text-sm mb-3">
                    <div>
                      <p className="text-muted-foreground">الإمام</p>
                      <p className="font-medium">{mosque.imamName}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">السعة</p>
                      <p className="font-medium">{mosque.capacity} مصلي</p>
                    </div>
                  </div>

                  {mosque.hasWomenSection && (
                    <Badge variant="secondary" className="mb-3">
                      مصلى نسائي
                    </Badge>
                  )}

                  {mosque.lessons.length > 0 && (
                    <div className="mt-3">
                      <p className="text-sm font-medium mb-2 flex items-center gap-1">
                        <BookOpen className="h-4 w-4" />
                        الدروس والأنشطة
                      </p>
                      <ul className="text-sm text-muted-foreground space-y-1">
                        {mosque.lessons.map((lesson, index) => (
                          <li key={index} className="flex items-center gap-2">
                            <span className="h-1.5 w-1.5 rounded-full bg-primary" />
                            {lesson}
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
