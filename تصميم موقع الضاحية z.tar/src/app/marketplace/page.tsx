'use client';

import { useState } from 'react';
import Link from 'next/link';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Search,
  Filter,
  Grid,
  List,
  MapPin,
  Clock,
  Eye,
  Heart,
  Plus,
  Phone,
  MessageCircle,
} from 'lucide-react';

const categories = [
  { id: 'electronics', name: 'إلكترونيات', icon: '📱' },
  { id: 'cars', name: 'سيارات', icon: '🚗' },
  { id: 'furniture', name: 'أثاث', icon: '🛋️' },
  { id: 'appliances', name: 'أجهزة منزلية', icon: '📺' },
  { id: 'clothes', name: 'ملابس', icon: '👕' },
  { id: 'books', name: 'كتب', icon: '📚' },
  { id: 'sports', name: 'رياضة', icon: '⚽' },
  { id: 'kids', name: 'أطفال', icon: '🧸' },
  { id: 'other', name: 'أخرى', icon: '📦' },
];

const neighborhoods = [
  'الجزيرة الأولى',
  'الجزيرة الثانية',
  'الجزيرة الثالثة',
  'شارع النخيل',
  'الشارع الرئيسي',
];

// Sample items
const sampleItems = [
  {
    id: '1',
    title: 'iPhone 13 Pro Max - ممتاز',
    price: 8500000,
    currency: 'ل.س',
    neighborhood: 'الجزيرة الأولى',
    timeAgo: 'منذ ساعتين',
    views: 124,
    condition: 'like_new',
    category: 'electronics',
    isNegotiable: true,
    image: null,
  },
  {
    id: '2',
    title: 'غسالة سامسونج 8 كيلو',
    price: 2800000,
    currency: 'ل.س',
    neighborhood: 'شارع النخيل',
    timeAgo: 'منذ 3 ساعات',
    views: 56,
    condition: 'good',
    category: 'appliances',
    isNegotiable: true,
    image: null,
  },
  {
    id: '3',
    title: 'أثاث غرفة نوم كاملة',
    price: 4200000,
    currency: 'ل.س',
    neighborhood: 'الجزيرة الثانية',
    timeAgo: 'منذ 5 ساعات',
    views: 78,
    condition: 'good',
    category: 'furniture',
    isNegotiable: true,
    image: null,
  },
  {
    id: '4',
    title: 'سيارة هيونداي النترا 2020',
    price: 85000000,
    currency: 'ل.س',
    neighborhood: 'الشارع الرئيسي',
    timeAgo: 'منذ يوم',
    views: 234,
    condition: 'excellent',
    category: 'cars',
    isNegotiable: true,
    image: null,
  },
  {
    id: '5',
    title: 'لابتوب HP Core i7',
    price: 12000000,
    currency: 'ل.س',
    neighborhood: 'الجزيرة الثالثة',
    timeAgo: 'منذ يومين',
    views: 189,
    condition: 'good',
    category: 'electronics',
    isNegotiable: false,
    image: null,
  },
  {
    id: '6',
    title: 'دراجة نارية هوندا 125',
    price: 15000000,
    currency: 'ل.س',
    neighborhood: 'الجزيرة الأولى',
    timeAgo: 'منذ 3 أيام',
    views: 145,
    condition: 'good',
    category: 'cars',
    isNegotiable: true,
    image: null,
  },
];

const conditionLabels: Record<string, string> = {
  new: 'جديد',
  like_new: 'مثل جديد',
  good: 'جيد',
  fair: 'مقبول',
  needs_repair: 'يحتاج إصلاح',
};

export default function MarketplacePage() {
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [selectedNeighborhood, setSelectedNeighborhood] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('ar-SY').format(price);
  };

  const filteredItems = sampleItems.filter((item) => {
    if (selectedCategory && item.category !== selectedCategory) return false;
    if (selectedNeighborhood && item.neighborhood !== selectedNeighborhood) return false;
    if (searchQuery && !item.title.includes(searchQuery)) return false;
    return true;
  });

  return (
    <div className="container px-4 py-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold">سوق المستعمل</h1>
          <p className="text-muted-foreground">بع واشترِ بأمان في ضاحيتك</p>
        </div>
        <Button className="gap-2">
          <Plus className="h-4 w-4" />
          أضف إعلان
        </Button>
      </div>

      {/* Categories */}
      <div className="flex gap-2 overflow-x-auto pb-4 scrollbar-hide">
        <Button
          variant={selectedCategory === null ? 'default' : 'outline'}
          size="sm"
          onClick={() => setSelectedCategory(null)}
          className="shrink-0"
        >
          الكل
        </Button>
        {categories.map((cat) => (
          <Button
            key={cat.id}
            variant={selectedCategory === cat.id ? 'default' : 'outline'}
            size="sm"
            onClick={() => setSelectedCategory(cat.id)}
            className="shrink-0 gap-2"
          >
            <span>{cat.icon}</span>
            {cat.name}
          </Button>
        ))}
      </div>

      {/* Filters */}
      <Card className="mb-6">
        <CardContent className="p-4">
          <div className="flex flex-wrap gap-4">
            <div className="flex-1 min-w-[200px]">
              <div className="relative">
                <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="ابحث عن منتج..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pr-10"
                />
              </div>
            </div>
            <Select value={selectedNeighborhood || ''} onValueChange={(v) => setSelectedNeighborhood(v || null)}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="المنطقة" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="">كل المناطق</SelectItem>
                {neighborhoods.map((n) => (
                  <SelectItem key={n} value={n}>
                    {n}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <div className="flex gap-1">
              <Button
                variant={viewMode === 'grid' ? 'default' : 'outline'}
                size="icon"
                onClick={() => setViewMode('grid')}
              >
                <Grid className="h-4 w-4" />
              </Button>
              <Button
                variant={viewMode === 'list' ? 'default' : 'outline'}
                size="icon"
                onClick={() => setViewMode('list')}
              >
                <List className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Items Grid/List */}
      {viewMode === 'grid' ? (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {filteredItems.map((item) => (
            <Link key={item.id} href={`/marketplace/${item.id}`}>
              <Card className="overflow-hidden hover:shadow-lg transition-shadow">
                <div className="relative h-40 bg-muted">
                  <div className="absolute inset-0 flex items-center justify-center">
                    <span className="text-4xl opacity-20">📦</span>
                  </div>
                  <Badge className="absolute top-2 right-2" variant="secondary">
                    {conditionLabels[item.condition]}
                  </Badge>
                </div>
                <CardContent className="p-3">
                  <h3 className="font-medium text-sm line-clamp-2 mb-2">{item.title}</h3>
                  <p className="text-primary font-bold">
                    {formatPrice(item.price)} {item.currency}
                  </p>
                  {item.isNegotiable && (
                    <p className="text-xs text-muted-foreground">قابل للتفاوض</p>
                  )}
                  <div className="flex items-center justify-between mt-2 text-xs text-muted-foreground">
                    <span className="flex items-center gap-1">
                      <MapPin className="h-3 w-3" />
                      {item.neighborhood}
                    </span>
                    <span className="flex items-center gap-1">
                      <Eye className="h-3 w-3" />
                      {item.views}
                    </span>
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      ) : (
        <div className="space-y-3">
          {filteredItems.map((item) => (
            <Link key={item.id} href={`/marketplace/${item.id}`}>
              <Card className="overflow-hidden hover:shadow-lg transition-shadow">
                <CardContent className="p-4">
                  <div className="flex gap-4">
                    <div className="w-24 h-24 bg-muted rounded-lg shrink-0 flex items-center justify-center">
                      <span className="text-3xl opacity-20">📦</span>
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between">
                        <div>
                          <h3 className="font-medium">{item.title}</h3>
                          <p className="text-primary font-bold text-lg">
                            {formatPrice(item.price)} {item.currency}
                            {item.isNegotiable && (
                              <span className="text-xs text-muted-foreground font-normal mr-2">
                                (قابل للتفاوض)
                              </span>
                            )}
                          </p>
                        </div>
                        <Badge variant="secondary">{conditionLabels[item.condition]}</Badge>
                      </div>
                      <div className="flex items-center gap-4 mt-2 text-sm text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <MapPin className="h-3 w-3" />
                          {item.neighborhood}
                        </span>
                        <span className="flex items-center gap-1">
                          <Clock className="h-3 w-3" />
                          {item.timeAgo}
                        </span>
                        <span className="flex items-center gap-1">
                          <Eye className="h-3 w-3" />
                          {item.views}
                        </span>
                      </div>
                      <div className="flex gap-2 mt-3">
                        <Button size="sm" variant="outline" className="gap-1">
                          <Phone className="h-3 w-3" />
                          اتصال
                        </Button>
                        <Button size="sm" variant="outline" className="gap-1">
                          <MessageCircle className="h-3 w-3" />
                          واتساب
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      )}

      {filteredItems.length === 0 && (
        <div className="text-center py-12">
          <p className="text-muted-foreground">لا توجد نتائج</p>
        </div>
      )}
    </div>
  );
}
