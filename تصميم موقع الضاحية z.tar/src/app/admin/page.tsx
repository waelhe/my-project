'use client';

import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import {
  Users,
  ShoppingCart,
  Building2,
  BookOpen,
  TrendingUp,
  AlertCircle,
  Settings,
  Bell,
  Plus,
  Edit,
  Trash2,
  Check,
  X,
  Zap,
  Droplets,
} from 'lucide-react';

// Sample stats
const stats = [
  { title: 'المستخدمين', value: '1,234', icon: Users, change: '+12%' },
  { title: 'إعلانات السوق', value: '456', icon: ShoppingCart, change: '+8%' },
  { title: 'العقارات', value: '89', icon: Building2, change: '+3%' },
  { title: 'الفعاليات', value: '234', icon: BookOpen, change: '+15%' },
];

// Sample pending items
const pendingItems = [
  { id: 1, type: 'marketplace', title: 'سيارة تويوتا كورولا 2019', user: 'أحمد محمد', date: '2024-03-15' },
  { id: 2, type: 'real_estate', title: 'شقة 120م للبيع', user: 'سارة علي', date: '2024-03-15' },
  { id: 3, type: 'directory', title: 'مطعم الوفاء', user: 'محمد خالد', date: '2024-03-14' },
];

export default function AdminPage() {
  const [electricityStatus, setElectricityStatus] = useState('partial');
  const [waterStatus, setWaterStatus] = useState('available');
  const [breakingNews, setBreakingNews] = useState('');

  const handleAddBreakingNews = () => {
    if (breakingNews.trim()) {
      console.log('Adding breaking news:', breakingNews);
      setBreakingNews('');
    }
  };

  return (
    <div className="container px-4 py-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold">لوحة التحكم</h1>
          <p className="text-muted-foreground">إدارة وتنظيم منصة قدسيا بلس</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="icon">
            <Bell className="h-4 w-4" />
          </Button>
          <Button variant="outline" size="icon">
            <Settings className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        {stats.map((stat) => {
          const Icon = stat.icon;
          return (
            <Card key={stat.title}>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">{stat.title}</p>
                    <p className="text-2xl font-bold">{stat.value}</p>
                    <p className="text-xs text-green-600">{stat.change}</p>
                  </div>
                  <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
                    <Icon className="h-5 w-5 text-primary" />
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <Tabs defaultValue="services" className="w-full">
        <TabsList className="grid w-full grid-cols-4 mb-6">
          <TabsTrigger value="services">الخدمات</TabsTrigger>
          <TabsTrigger value="news">الأخبار</TabsTrigger>
          <TabsTrigger value="pending">المراجعة</TabsTrigger>
          <TabsTrigger value="prices">الأسعار</TabsTrigger>
        </TabsList>

        {/* Services Status Tab */}
        <TabsContent value="services">
          <div className="grid md:grid-cols-2 gap-6">
            {/* Electricity Status */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Zap className="h-5 w-5 text-yellow-500" />
                  حالة الكهرباء
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Select value={electricityStatus} onValueChange={setElectricityStatus}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="available">متوفرة</SelectItem>
                    <SelectItem value="unavailable">مقطوعة</SelectItem>
                    <SelectItem value="partial">مقطوعة جزئياً</SelectItem>
                    <SelectItem value="maintenance">صيانة</SelectItem>
                  </SelectContent>
                </Select>

                <div className="space-y-2">
                  <label className="text-sm font-medium">المناطق المتأثرة</label>
                  <div className="flex flex-wrap gap-2">
                    {['الجزيرة الأولى', 'الجزيرة الثانية', 'الجزيرة الثالثة', 'شارع النخيل'].map((area) => (
                      <label key={area} className="flex items-center gap-2 text-sm">
                        <input type="checkbox" className="rounded" />
                        {area}
                      </label>
                    ))}
                  </div>
                </div>

                <Textarea placeholder="رسالة إضافية..." rows={2} />

                <Button className="w-full">
                  <Check className="h-4 w-4 ml-2" />
                  حفظ التغييرات
                </Button>
              </CardContent>
            </Card>

            {/* Water Status */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Droplets className="h-5 w-5 text-blue-500" />
                  حالة المياه
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Select value={waterStatus} onValueChange={setWaterStatus}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="available">متوفرة</SelectItem>
                    <SelectItem value="unavailable">مقطوعة</SelectItem>
                    <SelectItem value="partial">مقطوعة جزئياً</SelectItem>
                    <SelectItem value="maintenance">صيانة</SelectItem>
                  </SelectContent>
                </Select>

                <div className="space-y-2">
                  <label className="text-sm font-medium">المناطق المتأثرة</label>
                  <div className="flex flex-wrap gap-2">
                    {['الجزيرة الأولى', 'الجزيرة الثانية', 'الجزيرة الثالثة', 'شارع النخيل'].map((area) => (
                      <label key={area} className="flex items-center gap-2 text-sm">
                        <input type="checkbox" className="rounded" />
                        {area}
                      </label>
                    ))}
                  </div>
                </div>

                <Textarea placeholder="رسالة إضافية..." rows={2} />

                <Button className="w-full">
                  <Check className="h-4 w-4 ml-2" />
                  حفظ التغييرات
                </Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* News Tab */}
        <TabsContent value="news">
          <Card>
            <CardHeader>
              <CardTitle>إضافة خبر عاجل</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <Select defaultValue="news">
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="news">خبر</SelectItem>
                    <SelectItem value="announcement">إعلان</SelectItem>
                    <SelectItem value="alert">تنبيه</SelectItem>
                    <SelectItem value="event">فعالية</SelectItem>
                  </SelectContent>
                </Select>
                <Select defaultValue="normal">
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="normal">عادي</SelectItem>
                    <SelectItem value="breaking">عاجل</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <Input
                placeholder="عنوان الخبر..."
                value={breakingNews}
                onChange={(e) => setBreakingNews(e.target.value)}
              />

              <Textarea placeholder="تفاصيل الخبر..." rows={4} />

              <div className="flex gap-2">
                <Button className="flex-1">
                  <Plus className="h-4 w-4 ml-2" />
                  نشر الخبر
                </Button>
                <Button variant="outline">
                  معاينة
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Pending Items Tab */}
        <TabsContent value="pending">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <AlertCircle className="h-5 w-5 text-amber-500" />
                عناصر بانتظار المراجعة ({pendingItems.length})
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {pendingItems.map((item) => (
                  <div
                    key={item.id}
                    className="flex items-center justify-between p-4 rounded-lg border"
                  >
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <Badge variant="outline">
                          {item.type === 'marketplace' ? 'سوق' : 
                           item.type === 'real_estate' ? 'عقار' : 'دليل'}
                        </Badge>
                        <span className="font-medium">{item.title}</span>
                      </div>
                      <p className="text-sm text-muted-foreground">
                        {item.user} • {item.date}
                      </p>
                    </div>
                    <div className="flex gap-2">
                      <Button size="sm" variant="outline" className="text-green-600">
                        <Check className="h-4 w-4" />
                      </Button>
                      <Button size="sm" variant="outline" className="text-red-600">
                        <X className="h-4 w-4" />
                      </Button>
                      <Button size="sm" variant="outline">
                        <Edit className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Prices Tab */}
        <TabsContent value="prices">
          <Card>
            <CardHeader>
              <CardTitle>تحديث أسعار السوق</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground mb-4">
                اختر الفئة لتحديث الأسعار
              </p>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {['خضروات', 'فواكه', 'لحوم', 'ألبان'].map((category) => (
                  <Button key={category} variant="outline" className="h-auto py-4">
                    <div className="text-center">
                      <TrendingUp className="h-6 w-6 mx-auto mb-2" />
                      <span>{category}</span>
                    </div>
                  </Button>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
