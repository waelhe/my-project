import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const category = searchParams.get('category');
    const neighborhood = searchParams.get('neighborhood');
    const minPrice = searchParams.get('minPrice');
    const maxPrice = searchParams.get('maxPrice');
    const condition = searchParams.get('condition');
    const limit = parseInt(searchParams.get('limit') || '20');
    const offset = parseInt(searchParams.get('offset') || '0');

    const where: Record<string, unknown> = {
      status: 'active',
      deletedAt: null,
    };

    if (category) {
      where.categoryId = category;
    }
    if (neighborhood) {
      where.neighborhood = neighborhood;
    }
    if (condition) {
      where.condition = condition;
    }
    if (minPrice || maxPrice) {
      where.price = {};
      if (minPrice) {
        where.price = { ...where.price, gte: parseFloat(minPrice) };
      }
      if (maxPrice) {
        where.price = { ...where.price, lte: parseFloat(maxPrice) };
      }
    }

    const items = await db.marketplaceItem.findMany({
      where,
      include: {
        seller: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            phone: true,
            avatar: true,
          },
        },
        category: true,
      },
      orderBy: [
        { publishedAt: 'desc' },
        { createdAt: 'desc' },
      ],
      take: limit,
      skip: offset,
    });

    const total = await db.marketplaceItem.count({ where });

    // If no items exist, return sample data
    if (items.length === 0 && offset === 0) {
      return NextResponse.json({
        items: [
          {
            id: '1',
            title: 'iPhone 13 Pro Max - ممتاز',
            description: 'جهاز ايفون 13 برو ماكس بحالة ممتازة، بطارية 95%، مع الصندوق والشاحن',
            price: 8500000,
            currency: 'SYP',
            condition: 'like_new',
            images: '[]',
            neighborhood: 'الجزيرة الأولى',
            status: 'active',
            viewCount: 124,
            createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000),
            seller: { id: '1', firstName: 'محمد', lastName: 'أحمد', phone: '963911234567' },
            category: { id: 'phones', name: 'هواتف', nameAr: 'هواتف' },
          },
          {
            id: '2',
            title: 'غسالة سامسونج 8 كيلو',
            description: 'غسالة أوتوماتيك بالكامل، قلابة، بحالة جيدة جداً',
            price: 2800000,
            currency: 'SYP',
            condition: 'good',
            images: '[]',
            neighborhood: 'شارع النخيل',
            status: 'active',
            viewCount: 56,
            createdAt: new Date(Date.now() - 3 * 60 * 60 * 1000),
            seller: { id: '2', firstName: 'أحمد', lastName: 'محمود', phone: '963912345678' },
            category: { id: 'appliances', name: 'أجهزة كهربائية', nameAr: 'أجهزة كهربائية' },
          },
          {
            id: '3',
            title: 'أثاث غرفة نوم كاملة',
            description: 'سرير كينج + خزانة + كمودين + طاولة زينة، خشب زان',
            price: 4200000,
            currency: 'SYP',
            condition: 'good',
            images: '[]',
            neighborhood: 'الجزيرة الأولى',
            status: 'active',
            viewCount: 78,
            createdAt: new Date(Date.now() - 5 * 60 * 60 * 1000),
            seller: { id: '3', firstName: 'فاطمة', lastName: 'علي', phone: '963913456789' },
            category: { id: 'furniture', name: 'أثاث', nameAr: 'أثاث' },
          },
        ],
        total: 3,
        hasMore: false,
      });
    }

    return NextResponse.json({
      items,
      total,
      hasMore: offset + limit < total,
    });
  } catch (error) {
    console.error('Error fetching marketplace items:', error);
    return NextResponse.json(
      { error: 'Failed to fetch marketplace items' },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const {
      title,
      description,
      price,
      categoryId,
      condition,
      images,
      neighborhood,
      contactPhone,
      whatsappNumber,
    } = body;

    // For now, create without authentication
    const item = await db.marketplaceItem.create({
      data: {
        title,
        description,
        price: price ? parseFloat(price) : null,
        categoryId,
        condition: condition || 'used',
        images: JSON.stringify(images || []),
        neighborhood,
        contactPhone,
        whatsappNumber,
        sellerId: 'temp-user', // Will be replaced with actual user ID when auth is implemented
        status: 'active',
        publishedAt: new Date(),
      },
    });

    return NextResponse.json(item, { status: 201 });
  } catch (error) {
    console.error('Error creating marketplace item:', error);
    return NextResponse.json(
      { error: 'Failed to create marketplace item' },
      { status: 500 }
    );
  }
}
