'use client';

import { useState } from 'react';
import Link from 'next/link';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Search,
  MapPin,
  Clock,
  Eye,
  Heart,
  Plus,
  Phone,
  MessageCircle,
  BedDouble,
  Bath,
  Maximize,
  Building2,
} from 'lucide-react';

const neighborhoods = [
  'الجزيرة الأولى',
  'الجزيرة الثانية',
  'الجزيرة الثالثة',
  'شارع النخيل',
  'الشارع الرئيسي',
];

const propertyTypes = [
  { id: 'apartment', name: 'شقة', icon: '🏢' },
  { id: 'villa', name: 'فيلا', icon: '🏡' },
  { id: 'land', name: 'أرض', icon: '🌐' },
  { id: 'shop', name: 'محل', icon: '🏪' },
  { id: 'office', name: 'مكتب', icon: '🏢' },
];

// Sample properties
const sampleProperties = [
  {
    id: '1',
    title: 'شقة 140م للبيع - الجزيرة الثانية',
    type: 'apartment',
    listingType: 'sale',
    price: 450000000,
    currency: 'ل.س',
    neighborhood: 'الجزيرة الثانية',
    area: 140,
    bedrooms: 3,
    bathrooms: 2,
    floor: '3',
    timeAgo: 'منذ يوم',
    views: 89,
    features: ['موقف سيارات', 'مصعد', 'شرفة'],
    image: null,
  },
  {
    id: '2',
    title: 'محل تجاري للإيجار - موقع ممتاز',
    type: 'shop',
    listingType: 'rent',
    price: 500000,
    currency: 'ل.س/شهر',
    neighborhood: 'الشارع الرئيسي',
    area: 80,
    bedrooms: null,
    bathrooms: 1,
    floor: 'أرضي',
    timeAgo: 'منذ يومين',
    views: 234,
    features: ['واجهة رئيسية', 'موقف'],
    image: null,
  },
  {
    id: '3',
    title: 'فيلا 250م مع حديقة',
    type: 'villa',
    listingType: 'sale',
    price: 850000000,
    currency: 'ل.س',
    neighborhood: 'الجزيرة الأولى',
    area: 250,
    bedrooms: 5,
    bathrooms: 3,
    floor: 'أرضي + طابق',
    timeAgo: 'منذ 3 أيام',
    views: 156,
    features: ['حديقة', 'موقف', 'مسبح'],
    image: null,
  },
  {
    id: '4',
    title: 'شقة 100م للإيجار - جديدة',
    type: 'apartment',
    listingType: 'rent',
    price: 300000,
    currency: 'ل.س/شهر',
    neighborhood: 'شارع النخيل',
    area: 100,
    bedrooms: 2,
    bathrooms: 1,
    floor: '4',
    timeAgo: 'منذ 5 ساعات',
    views: 67,
    features: ['مفروشة جزئياً', 'مصعد'],
    image: null,
  },
  {
    id: '5',
    title: 'أرض 500م للبيع - قابلة للبناء',
    type: 'land',
    listingType: 'sale',
    price: 200000000,
    currency: 'ل.س',
    neighborhood: 'الجزيرة الثالثة',
    area: 500,
    bedrooms: null,
    bathrooms: null,
    floor: null,
    timeAgo: 'منذ أسبوع',
    views: 45,
    features: ['قابلة للبناء', 'إطلالة'],
    image: null,
  },
];

export default function RealEstatePage() {
  const [listingType, setListingType] = useState<'all' | 'sale' | 'rent' | 'wanted'>('all');
  const [selectedType, setSelectedType] = useState<string | null>(null);
  const [selectedNeighborhood, setSelectedNeighborhood] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('ar-SY').format(price);
  };

  const filteredProperties = sampleProperties.filter((property) => {
    if (listingType !== 'all' && property.listingType !== listingType) return false;
    if (selectedType && property.type !== selectedType) return false;
    if (selectedNeighborhood && property.neighborhood !== selectedNeighborhood) return false;
    if (searchQuery && !property.title.includes(searchQuery)) return false;
    return true;
  });

  return (
    <div className="container px-4 py-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold">العقارات</h1>
          <p className="text-muted-foreground">شقق، محلات، أراضي للبيع والإيجار</p>
        </div>
        <Button className="gap-2">
          <Plus className="h-4 w-4" />
          أضف عقار
        </Button>
      </div>

      {/* Listing Type Tabs */}
      <Tabs defaultValue="all" className="mb-6" onValueChange={(v) => setListingType(v as typeof listingType)}>
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="all">الكل</TabsTrigger>
          <TabsTrigger value="sale">للبيع</TabsTrigger>
          <TabsTrigger value="rent">للإيجار</TabsTrigger>
          <TabsTrigger value="wanted">مطلوب</TabsTrigger>
        </TabsList>
      </Tabs>

      {/* Filters */}
      <Card className="mb-6">
        <CardContent className="p-4">
          <div className="flex flex-wrap gap-4">
            <div className="relative flex-1 min-w-[200px]">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="ابحث عن عقار..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pr-10"
              />
            </div>
            <Select value={selectedType || ''} onValueChange={(v) => setSelectedType(v || null)}>
              <SelectTrigger className="w-[150px]">
                <SelectValue placeholder="نوع العقار" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="">الكل</SelectItem>
                {propertyTypes.map((t) => (
                  <SelectItem key={t.id} value={t.id}>
                    {t.icon} {t.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={selectedNeighborhood || ''} onValueChange={(v) => setSelectedNeighborhood(v || null)}>
              <SelectTrigger className="w-[150px]">
                <SelectValue placeholder="المنطقة" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="">كل المناطق</SelectItem>
                {neighborhoods.map((n) => (
                  <SelectItem key={n} value={n}>
                    {n}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Properties Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredProperties.map((property) => (
          <Link key={property.id} href={`/real-estate/${property.id}`}>
            <Card className="overflow-hidden hover:shadow-lg transition-shadow h-full">
              <div className="relative h-48 bg-muted">
                <div className="absolute inset-0 flex items-center justify-center">
                  <Building2 className="h-16 w-16 opacity-20" />
                </div>
                <Badge
                  className="absolute top-2 right-2"
                  variant={property.listingType === 'sale' ? 'default' : 'secondary'}
                >
                  {property.listingType === 'sale' ? 'للبيع' : property.listingType === 'rent' ? 'للإيجار' : 'مطلوب'}
                </Badge>
                <div className="absolute bottom-2 left-2 flex gap-1">
                  {property.features.slice(0, 2).map((f) => (
                    <Badge key={f} variant="outline" className="bg-background/80 text-xs">
                      {f}
                    </Badge>
                  ))}
                </div>
              </div>
              <CardContent className="p-4">
                <h3 className="font-medium mb-2">{property.title}</h3>
                <p className="text-primary font-bold text-lg mb-3">
                  {formatPrice(property.price)} {property.currency}
                </p>
                <div className="flex items-center gap-4 text-sm text-muted-foreground mb-3">
                  <span className="flex items-center gap-1">
                    <Maximize className="h-4 w-4" />
                    {property.area} م²
                  </span>
                  {property.bedrooms && (
                    <span className="flex items-center gap-1">
                      <BedDouble className="h-4 w-4" />
                      {property.bedrooms}
                    </span>
                  )}
                  {property.bathrooms && (
                    <span className="flex items-center gap-1">
                      <Bath className="h-4 w-4" />
                      {property.bathrooms}
                    </span>
                  )}
                </div>
                <div className="flex items-center justify-between text-xs text-muted-foreground">
                  <span className="flex items-center gap-1">
                    <MapPin className="h-3 w-3" />
                    {property.neighborhood}
                  </span>
                  <span className="flex items-center gap-1">
                    <Eye className="h-3 w-3" />
                    {property.views}
                  </span>
                </div>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>

      {filteredProperties.length === 0 && (
        <div className="text-center py-12">
          <Building2 className="h-16 w-16 mx-auto opacity-20 mb-4" />
          <p className="text-muted-foreground">لا توجد عقارات تطابق معايير البحث</p>
        </div>
      )}
    </div>
  );
}
