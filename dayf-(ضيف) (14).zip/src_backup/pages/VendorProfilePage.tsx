import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { MapPin, Star, ShoppingCart, ArrowRight } from 'lucide-react';
import { marketplaceService } from '../infrastructure/firebase/marketplaceService';
import { Product } from '../features/marketplace/types';
import toast from 'react-hot-toast';

export default function VendorProfilePage() {
  const { vendorName } = useParams<{ vendorName: string }>();
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchVendorProducts = async () => {
      if (!vendorName) return;
      try {
        const vendorProducts = await marketplaceService.getProductsByVendor(vendorName);
        setProducts(vendorProducts);
      } catch (error) {
        console.error('Error fetching vendor products:', error);
        toast.error('حدث خطأ أثناء تحميل منتجات البائع');
      } finally {
        setLoading(false);
      }
    };
    fetchVendorProducts();
  }, [vendorName]);

  if (loading) return <div className="min-h-screen flex items-center justify-center">جاري التحميل...</div>;

  return (
    <div className="min-h-screen bg-gray-50 pt-24 pb-12">
      <div className="max-w-7xl mx-auto px-4">
        <div className="bg-white rounded-3xl shadow-sm border border-gray-100 p-8 mb-8 flex items-center gap-6">
          <div className="w-24 h-24 bg-emerald-100 rounded-full flex items-center justify-center text-3xl font-bold text-emerald-700">
            {vendorName?.charAt(0)}
          </div>
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">{vendorName}</h1>
            <p className="text-gray-500">حرفي محلي متميز يقدم أفضل المنتجات السورية</p>
          </div>
        </div>

        <h2 className="text-2xl font-bold text-gray-900 mb-6">منتجات {vendorName}</h2>
        
        {products.length === 0 ? (
          <div className="text-center py-12 bg-white rounded-2xl border border-gray-100">
            <p className="text-gray-500">لا توجد منتجات لهذا البائع حالياً</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {products.map(product => (
              <div key={product.id} className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden hover:shadow-xl transition-all">
                <img src={product.image || (product.images && product.images[0])} alt={product.name} className="w-full h-48 object-cover" referrerPolicy="no-referrer" />
                <div className="p-4">
                  <h3 className="font-bold text-gray-900 mb-1">{product.name}</h3>
                  <p className="text-emerald-600 font-bold mb-4">{product.price.toLocaleString('ar-SA')} ل.س</p>
                  <Link 
                    to={`/marketplace/product/${product.id}`}
                    className="block w-full text-center bg-gray-100 text-gray-900 font-bold py-2 rounded-xl hover:bg-emerald-600 hover:text-white transition-colors"
                  >
                    عرض التفاصيل
                  </Link>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
