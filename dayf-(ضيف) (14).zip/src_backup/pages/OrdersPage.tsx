import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { orderService } from '../infrastructure/firebase/orderService';
import { Order } from '../features/orders/types';
import toast from 'react-hot-toast';

export default function OrdersPage() {
  const { user } = useAuth();
  const userId = user?.uid;
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchOrders = async () => {
      if (!userId) return;
      try {
        const data = await orderService.getOrders(userId);
        setOrders(data);
      } catch (error) {
        console.error('Error fetching orders:', error);
        toast.error('حدث خطأ أثناء تحميل الطلبات');
      } finally {
        setLoading(false);
      }
    };
    fetchOrders();
  }, [userId]);

  if (!userId) return <div className="min-h-screen flex items-center justify-center">يرجى تسجيل الدخول لعرض طلباتك</div>;
  if (loading) return <div className="min-h-screen flex items-center justify-center">جاري التحميل...</div>;

  return (
    <div className="min-h-screen bg-gray-50 pt-24 pb-12">
      <div className="max-w-4xl mx-auto px-4">
        <h1 className="text-3xl font-bold text-gray-900 mb-8">طلباتي</h1>
        {orders.length === 0 ? (
          <div className="bg-white p-8 rounded-2xl text-center border border-gray-100">
            <p className="text-gray-500">لا توجد طلبات حالياً</p>
          </div>
        ) : (
          <div className="space-y-6">
            {orders.map(order => (
              <div key={order.id} className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
                <div className="flex justify-between items-center mb-4">
                  <span className="font-bold text-lg">طلب #{order.id.slice(-6)}</span>
                  <span className={`px-3 py-1 rounded-full text-sm font-bold ${order.status === 'pending' ? 'bg-amber-100 text-amber-700' : 'bg-emerald-100 text-emerald-700'}`}>
                    {order.status}
                  </span>
                </div>
                <div className="text-sm text-gray-500 mb-4">
                  {order.createdAt?.seconds 
                    ? new Date(order.createdAt.seconds * 1000).toLocaleDateString('ar-SA')
                    : new Date(order.createdAt).toLocaleDateString('ar-SA')}
                </div>
                <div className="border-t border-gray-100 pt-4">
                  {order.items.map(item => (
                    <div key={item.id} className="flex justify-between mb-2">
                      <span>{item.name} x {item.quantity}</span>
                      <span>{(item.price * item.quantity).toLocaleString('ar-SA')} ل.س</span>
                    </div>
                  ))}
                </div>
                <div className="border-t border-gray-100 pt-4 mt-4 font-bold text-lg flex justify-between">
                  <span>المجموع</span>
                  <span className="text-emerald-600">{order.total.toLocaleString('ar-SA')} ل.س</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
