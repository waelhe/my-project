import { db } from '../../firebase';
import { 
  collection, 
  getDocs, 
  getDoc,
  doc,
  query, 
  where, 
  addDoc, 
  updateDoc,
  serverTimestamp,
  orderBy
} from 'firebase/firestore';
import { handleFirestoreError, OperationType } from '../../utils/firestoreError';

const BOOKINGS_COLLECTION = 'bookings';

export interface Booking {
  id?: string;
  serviceId: string;
  serviceTitle: string;
  userId: string;
  userEmail: string;
  providerId: string;
  checkIn: string;
  checkOut: string;
  guests: number;
  totalPrice: number;
  status: 'pending' | 'confirmed' | 'cancelled' | 'completed';
  createdAt?: any;
}

export const createBooking = async (bookingData: Omit<Booking, 'id' | 'createdAt'>) => {
  try {
    return await addDoc(collection(db, BOOKINGS_COLLECTION), {
      ...bookingData,
      createdAt: serverTimestamp()
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, BOOKINGS_COLLECTION);
  }
};

export const getUserBookings = async (userId: string): Promise<Booking[]> => {
  const q = query(
    collection(db, BOOKINGS_COLLECTION), 
    where('userId', '==', userId),
    orderBy('createdAt', 'desc')
  );
  try {
    const querySnapshot = await getDocs(q);
    return querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Booking));
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, BOOKINGS_COLLECTION);
    return [];
  }
};

export const getProviderBookings = async (providerId: string): Promise<Booking[]> => {
  const q = query(
    collection(db, BOOKINGS_COLLECTION), 
    where('providerId', '==', providerId),
    orderBy('createdAt', 'desc')
  );
  try {
    const querySnapshot = await getDocs(q);
    return querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Booking));
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, BOOKINGS_COLLECTION);
    return [];
  }
};

export const updateBookingStatus = async (bookingId: string, status: Booking['status']) => {
  const docRef = doc(db, BOOKINGS_COLLECTION, bookingId);
  try {
    await updateDoc(docRef, { status });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, BOOKINGS_COLLECTION + '/' + bookingId);
  }
};
