export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  category: string;
  vendorId?: string;
  vendorName?: string;
  vendor?: string;
  images?: string[];
  image?: string;
  stock?: number;
  rating?: number;
  reviewsCount?: number;
  reviews?: number;
  location?: string;
  createdAt?: any;
}

export interface Vendor {
  id: string;
  name: string;
  description: string;
  logo?: string;
  rating: number;
  reviewsCount: number;
  joinedAt: string;
}
