export interface CommunityTopic {
  id?: string;
  title: string;
  content: string;
  authorUid: string;
  authorName: string;
  authorAvatar?: string;
  categoryId: string;
  createdAt: any;
  likesCount: number;
  repliesCount: number;
  isOfficial?: boolean;
}

export interface Reply {
  id?: string;
  topicId: string;
  content: string;
  authorUid: string;
  authorName: string;
  authorAvatar?: string;
  createdAt: any;
  likesCount: number;
}
