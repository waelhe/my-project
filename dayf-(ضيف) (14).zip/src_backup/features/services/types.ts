import { z } from 'zod';

export const ServiceSchema = z.object({
  id: z.string().optional(),
  mainCategoryId: z.string().optional(),
  subCategoryId: z.string().optional(),
  subSubCategoryId: z.string().optional(),
  title: z.string().optional().default("بدون عنوان"),
  location: z.string().optional().default("غير محدد"),
  price: z.coerce.number().optional().default(0),
  originalPrice: z.coerce.number().optional(),
  rating: z.coerce.number().optional().default(0),
  reviews: z.coerce.number().optional().default(0),
  views: z.coerce.number().optional().default(0),
  images: z.array(z.string()).optional().catch([]).default([]),
  type: z.string().optional().default("غير محدد"),
  amenities: z.array(z.string()).optional().catch([]).default([]),
  features: z.array(z.string()).optional().catch([]).default([]),
  isPopular: z.boolean().optional().catch(false).default(false),
  host: z.object({
    name: z.string().optional().default(""),
    isSuperhost: z.boolean().optional().default(false),
    avatar: z.string().optional().default(""),
  }).optional().catch(undefined),
  authorUid: z.string().optional(),
  createdAt: z.any().optional(), // Firestore Timestamp
}).passthrough();

export type Service = z.infer<typeof ServiceSchema>;
