/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BrowserRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import ScrollToTop from './components/ScrollToTop';
import AIAgent from './components/AIAgent';
import Footer from './components/Footer';
import Header from './components/Header';
import BottomNav from './components/BottomNav';
import Home from './pages/Home';
import ListingDetails from './pages/ListingDetails';
import CategoryPage from './pages/CategoryPage';
import MyBookings from './pages/MyBookings';
import ProviderDashboard from './pages/ProviderDashboard';
import AddServicePage from './pages/AddServicePage';
import EditServicePage from './pages/EditServicePage';
import Profile from './pages/Profile';
import ProductDetailsPage from './pages/ProductDetailsPage';
import VendorProfilePage from './pages/VendorProfilePage';
import OrdersPage from './pages/OrdersPage';
import CommunityPage from './pages/CommunityPage';
import TopicDetails from './pages/TopicDetails';
import GuideDetails from './pages/GuideDetails';
import MarketplacePage from './pages/MarketplacePage';
import GuestServiceCenter from './components/GuestServiceCenter';
import { AuthProvider } from './contexts/AuthContext';
import { LanguageProvider } from './contexts/LanguageContext';
import { CartProvider } from './contexts/CartContext';
import CartDrawer from './components/CartDrawer';

function AppContent() {
  const location = useLocation();
  const isHome = location.pathname === '/';

  return (
    <div className="min-h-screen font-sans bg-white flex flex-col">
      <Toaster position="top-center" toastOptions={{ duration: 3000, style: { fontFamily: 'Inter, sans-serif' } }} />
      <Header />
      <CartDrawer />
      <main className={`flex-grow ${isHome ? 'pt-20' : 'pt-16'} pb-16 md:pb-0`}>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/category/:categoryId" element={<CategoryPage />} />
          <Route path="/listing/:id" element={<ListingDetails />} />
          <Route path="/my-bookings" element={<MyBookings />} />
          <Route path="/provider-dashboard" element={<ProviderDashboard />} />
          <Route path="/provider/add-service" element={<AddServicePage />} />
          <Route path="/provider/edit-service/:id" element={<EditServicePage />} />
          <Route path="/profile" element={<Profile />} />
          <Route path="/community" element={<CommunityPage />} />
          <Route path="/community/topic/:id" element={<TopicDetails />} />
          <Route path="/community/guide/:id" element={<GuideDetails />} />
          <Route path="/marketplace" element={<MarketplacePage />} />
          <Route path="/marketplace/product/:id" element={<ProductDetailsPage />} />
          <Route path="/marketplace/vendor/:vendorName" element={<VendorProfilePage />} />
          <Route path="/orders" element={<OrdersPage />} />
        </Routes>
      </main>
      <Footer />
      <BottomNav />
      <GuestServiceCenter />
      <AIAgent />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <LanguageProvider>
        <CartProvider>
          <Router>
            <ScrollToTop />
            <AppContent />
          </Router>
        </CartProvider>
      </LanguageProvider>
    </AuthProvider>
  );
}
