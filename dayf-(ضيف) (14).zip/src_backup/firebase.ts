import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore, getDocFromServer, doc } from 'firebase/firestore';
import firebaseConfig from '../firebase-applet-config.json';
import toast from 'react-hot-toast';

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize Firestore with the specific database ID
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);

// Validate connection to Firestore as suggested in guidelines
async function testConnection() {
  try {
    // Attempt to fetch a non-existent doc just to test connectivity
    await getDocFromServer(doc(db, '_connection_test_', 'ping'));
    console.log("Firestore connection successful");
  } catch (error) {
    if (error instanceof Error && (error.message.includes('offline') || error.message.includes('10 seconds') || error.message.includes('unavailable'))) {
      console.error("Firestore connectivity error: The client is offline or cannot reach the backend.");
      // Show a toast to the user so they know it's a network/adblocker issue
      setTimeout(() => {
        toast.error('تعذر الاتصال بقاعدة البيانات. يرجى التحقق من اتصال الإنترنت، أو إيقاف مانع الإعلانات (Adblocker)، أو استخدام متصفح آخر غير Brave.', {
          duration: 10000,
          icon: '🔌'
        });
      }, 3000);
    }
  }
}

testConnection();

export const auth = getAuth(app);
