import fs from 'fs';
import path from 'path';
import https from 'https';
import { execSync } from 'child_process';

async function main() {
  const zipPath = path.resolve("user_backup.zip");
  const extractPath = path.resolve("user_backup_extracted");

  try {
    execSync(`npx -y extract-zip ${zipPath} ${extractPath}`, { stdio: 'inherit' });
    console.log("Extraction complete.");
  } catch (e) {
    console.error("Extraction failed:", e);
  }
}

main().catch(console.error);
