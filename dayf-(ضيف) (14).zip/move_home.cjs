const fs = require('fs');
const path = require('path');

const moves = [
  ['src/pages/Home.tsx', 'src/features/home/pages/Home.tsx'],
];

const moveMap = new Map(moves.map(([oldPath, newPath]) => [newPath, oldPath]));
const newPathMap = new Map(moves.map(([oldPath, newPath]) => [oldPath, newPath]));

function ensureDir(filePath) {
  const dir = path.dirname(filePath);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
}

// 1. Move files
for (const [src, dest] of moves) {
  if (fs.existsSync(src)) {
    ensureDir(dest);
    fs.renameSync(src, dest);
    console.log(`Moved ${src} to ${dest}`);
  } else {
    console.warn(`File not found: ${src}`);
  }
}

function getAllFiles(dir, fileList = []) {
  if (!fs.existsSync(dir)) return fileList;
  const files = fs.readdirSync(dir);
  for (const file of files) {
    const filePath = path.join(dir, file);
    if (fs.statSync(filePath).isDirectory()) {
      getAllFiles(filePath, fileList);
    } else if (filePath.endsWith('.ts') || filePath.endsWith('.tsx')) {
      fileList.push(filePath);
    }
  }
  return fileList;
}

const allFiles = getAllFiles('src');

for (const file of allFiles) {
  let content = fs.readFileSync(file, 'utf8');
  let changed = false;

  const fileDir = path.dirname(file);
  const importRegex = /(['"])((?:\.\/|\.\.\/)+)(.*?)(['"])/g;
  let match;
  let replacements = [];

  while ((match = importRegex.exec(content)) !== null) {
    const quote = match[1];
    const relPath = match[2];
    const importPath = match[3];
    const fullImport = relPath + importPath;
    
    // Calculate absolute path of the import
    const importedAbsPath = path.resolve(fileDir, fullImport);
    
    // Check if it exists
    const exists = ['.ts', '.tsx', '.js', '.jsx', ''].some(ext => fs.existsSync(importedAbsPath + ext)) ||
                   (fs.existsSync(importedAbsPath) && fs.statSync(importedAbsPath).isDirectory());
                   
    if (!exists) {
      // It doesn't exist. Let's see if it's pointing to an old path that moved.
      let targetOldPath = null;
      for (const ext of ['.ts', '.tsx', '.js', '.jsx', '']) {
        const potentialOldPath = path.relative(process.cwd(), importedAbsPath + ext).replace(/\\/g, '/');
        if (newPathMap.has(potentialOldPath)) {
          targetOldPath = potentialOldPath;
          break;
        }
      }
      
      if (targetOldPath) {
        const targetNewPath = newPathMap.get(targetOldPath);
        const targetNewAbsPath = path.resolve(process.cwd(), targetNewPath.replace(/\.tsx?$/, ''));
        
        // Calculate new relative path
        let newRelPath = path.relative(fileDir, targetNewAbsPath);
        if (!newRelPath.startsWith('.')) {
          newRelPath = './' + newRelPath;
        }
        newRelPath = newRelPath.replace(/\\\\/g, '/');
        
        replacements.push({
          start: match.index,
          end: match.index + match[0].length,
          newStr: quote + newRelPath + quote
        });
      }
    }
  }

  // Apply replacements from back to front
  for (let i = replacements.length - 1; i >= 0; i--) {
    const r = replacements[i];
    content = content.substring(0, r.start) + r.newStr + content.substring(r.end);
    changed = true;
  }

  if (changed) {
    fs.writeFileSync(file, content, 'utf8');
    console.log(`Fixed moved imports in ${file}`);
  }
}
