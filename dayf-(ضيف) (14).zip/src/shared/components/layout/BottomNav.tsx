import { Home, ShoppingBag, Users, User, MessageSquare, LayoutGrid } from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';
import { useLanguage } from '../../../core/contexts/LanguageContext';
import { useScrollDirection } from '../../hooks/useScrollDirection';

export default function BottomNav() {
  const location = useLocation();
  const { t } = useLanguage();
  const { scrollDirection, isScrolled } = useScrollDirection();
  
  const isMinimized = scrollDirection === 'down' && isScrolled;

  const navItems = [
    { name: t('nav.home'), path: '/', icon: Home },
    { name: t('nav.marketplace'), path: '/marketplace', icon: ShoppingBag },
    { name: t('nav.services'), path: '/category/tourism', icon: LayoutGrid },
    { name: t('nav.community'), path: '/community', icon: Users },
    { name: t('nav.my_bookings'), path: '/my-bookings', icon: MessageSquare },
    { name: t('nav.profile'), path: '/profile', icon: User },
  ];

  return (
    <div className={`fixed bottom-0 left-0 right-0 bg-white/95 backdrop-blur-md border-t border-gray-200 z-50 md:hidden pb-safe transition-all duration-300 ease-in-out ${isMinimized ? 'h-10' : 'h-16'}`}>
      <div className="flex justify-around items-center h-full px-2">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = location.pathname === item.path;
          return (
            <Link
              key={item.path}
              to={item.path}
              className={`flex flex-col items-center justify-center w-full h-full gap-1 transition-all duration-300 ${
                isActive ? 'text-emerald-600' : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              <div className={`transition-all duration-300 overflow-hidden flex items-center justify-center ${isMinimized ? 'h-0 opacity-0 mb-0' : 'h-6 opacity-100 mb-0.5'}`}>
                <Icon className={`w-5 h-5 sm:w-6 sm:h-6 ${isActive ? 'stroke-[2.5]' : 'stroke-[2]'}`} />
              </div>
              <span className={`font-bold whitespace-nowrap transition-all duration-300 ${isMinimized ? 'text-[11px] sm:text-[12px]' : 'text-[9px] sm:text-[10px]'}`}>{item.name}</span>
            </Link>
          );
        })}
      </div>
    </div>
  );
}
