import React, { useState, useEffect, useRef } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, Search, User, Globe, LogOut, Compass, Heart, ShoppingBag, Users, Sparkles, Home as HomeIcon, Plane, HeartPulse, GraduationCap, Briefcase, Moon, Sun } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useAuth } from '../../../core/contexts/AuthContext';
import { useLanguage } from '../../../core/contexts/LanguageContext';
import toast from 'react-hot-toast';

export default function Navbar() {
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [isLangOpen, setIsLangOpen] = useState(false);
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(false);
  const { user, logout } = useAuth();
  const { language, setLanguage, t } = useLanguage();
  const location = useLocation();
  const currentPath = location.pathname;
  
  const [isCompact, setIsCompact] = useState(false);
  const lastScrollY = useRef(0);

  useEffect(() => {
    const handleScroll = () => {
      const currentScrollY = window.scrollY;
      if (currentScrollY > 50) {
        setIsCompact(true);
      } else {
        setIsCompact(false);
      }
      lastScrollY.current = currentScrollY;
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const toggleLanguage = (lang: 'ar' | 'en') => {
    setLanguage(lang);
    setIsLangOpen(false);
    toast.success(lang === 'ar' ? 'تم تغيير اللغة إلى العربية' : 'Language changed to English');
  };

  const toggleDarkMode = () => {
    setIsDarkMode(!isDarkMode);
    document.documentElement.classList.toggle('dark');
  };

  const navItems = [
    { to: '/category/tourism', label: language === 'ar' ? 'السياحة' : 'Tourism', icon: Plane },
    { to: '/category/medical', label: language === 'ar' ? 'العلاج' : 'Medical', icon: HeartPulse },
    { to: '/category/education', label: language === 'ar' ? 'الدراسة' : 'Education', icon: GraduationCap },
    { to: '/category/business', label: language === 'ar' ? 'الأعمال' : 'Business', icon: Briefcase },
  ];

  const bottomNavItems = [
    { to: '/category/tourism', label: language === 'ar' ? 'السياحة' : 'Tourism', icon: Compass },
    { to: '/marketplace', label: language === 'ar' ? 'السوق' : 'Market', icon: ShoppingBag },
    { to: '/community', label: language === 'ar' ? 'المجتمع' : 'Community', icon: Users },
    { to: '/profile', label: language === 'ar' ? 'المساعد' : 'AI', icon: Sparkles },
  ];

  return (
    <>
      {/* Desktop & Tablet Top Navbar */}
      <motion.nav 
        initial={false}
        animate={{ 
          height: isCompact ? '70px' : '100px',
          backgroundColor: isCompact ? 'rgba(255, 255, 255, 0.95)' : 'rgba(255, 255, 255, 0.8)',
          boxShadow: isCompact ? '0 10px 40px -10px rgba(16, 185, 129, 0.1)' : '0 0 0 0 rgba(0,0,0,0)',
        }}
        transition={{ type: 'spring', stiffness: 300, damping: 30 }}
        className="fixed top-0 left-0 right-0 z-50 border-b border-emerald-500/10 backdrop-blur-xl"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-full flex items-center justify-between">
          
          {/* Right: Logo */}
          <Link to="/" className="flex-shrink-0 flex items-center gap-3 group z-10">
            <motion.div 
              animate={{ scale: isCompact ? 0.9 : 1 }}
              className="w-10 h-10 bg-gradient-to-tr from-emerald-600 to-teal-400 rounded-xl flex items-center justify-center text-white font-bold text-xl shadow-lg shadow-emerald-500/30 group-hover:rotate-6 transition-transform"
            >
              {language === 'ar' ? 'ض' : 'D'}
            </motion.div>
            <div className="flex flex-col hidden sm:flex">
              <span className="font-black text-gray-900 tracking-tight text-xl leading-none">
                {language === 'ar' ? 'ضيف' : 'Dayf'}
              </span>
              <span className="text-[9px] font-bold text-emerald-600 uppercase tracking-[0.2em] mt-1">
                Premium
              </span>
            </div>
          </Link>

          {/* Center: Navigation Items */}
          <div className="hidden md:flex absolute left-0 right-0 justify-center items-center pointer-events-none">
            <div className="flex items-center gap-2 lg:gap-6 pointer-events-auto bg-white/40 px-6 py-2 rounded-2xl border border-white/60 shadow-sm">
              {navItems.map((item) => {
                const isActive = currentPath.includes(item.to);
                return (
                  <Link 
                    key={item.to}
                    to={item.to} 
                    className={`relative flex flex-col items-center justify-center w-20 h-14 transition-colors group/nav ${
                      isActive ? 'text-emerald-600' : 'text-gray-500 hover:text-emerald-600'
                    }`}
                  >
                    <motion.div
                      initial={false}
                      animate={{ 
                        height: isCompact ? 0 : 24, 
                        opacity: isCompact ? 0 : 1,
                        scale: isCompact ? 0.5 : 1,
                        marginBottom: isCompact ? 0 : 4
                      }}
                      transition={{ type: 'spring', stiffness: 300, damping: 25 }}
                      className="flex items-center justify-center overflow-hidden"
                    >
                      <item.icon className={`w-5 h-5 stroke-[1.5] ${isActive ? 'drop-shadow-md' : ''}`} />
                    </motion.div>
                    <motion.span 
                      animate={{ 
                        fontSize: isCompact ? '14px' : '12px',
                        fontWeight: isCompact ? 700 : 600
                      }}
                      className="whitespace-nowrap"
                    >
                      {item.label}
                    </motion.span>
                    {isActive && (
                      <motion.div 
                        layoutId="navIndicator"
                        className="absolute -bottom-2 left-1/4 right-1/4 h-1 bg-emerald-500 rounded-t-full"
                      />
                    )}
                  </Link>
                );
              })}
            </div>
          </div>

          {/* Left: Actions */}
          <div className="flex items-center gap-2 z-10">
            
            {/* Language Toggle */}
            <div className="relative">
              <button 
                onClick={() => setIsLangOpen(!isLangOpen)} 
                className="p-2 text-gray-500 hover:text-emerald-600 transition-colors flex items-center gap-2 bg-white/50 rounded-xl border border-emerald-50 hover:border-emerald-200"
              >
                <Globe className="w-5 h-5 stroke-[1.5]" />
                <span className="hidden sm:inline-block text-[10px] font-bold uppercase tracking-widest">{language}</span>
              </button>
              
              <AnimatePresence>
                {isLangOpen && (
                  <motion.div 
                    initial={{ opacity: 0, y: 10, scale: 0.95 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: 10, scale: 0.95 }}
                    className="absolute top-full mt-2 bg-white/95 backdrop-blur-xl border border-emerald-100 rounded-2xl shadow-xl overflow-hidden min-w-[120px] right-0 z-50 p-1"
                  >
                    <button onClick={() => toggleLanguage('ar')} className="w-full text-right px-4 py-2 text-xs font-bold hover:bg-emerald-50 text-gray-700 rounded-xl transition-colors">العربية</button>
                    <button onClick={() => toggleLanguage('en')} className="w-full text-right px-4 py-2 text-xs font-bold hover:bg-emerald-50 text-gray-700 rounded-xl transition-colors">English</button>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* General Dropdown Menu */}
            <div className="relative">
              <button 
                onClick={() => setIsDropdownOpen(!isDropdownOpen)}
                className="p-2 text-gray-500 hover:text-emerald-600 transition-colors bg-white/50 rounded-xl border border-emerald-50 hover:border-emerald-200"
              >
                <Menu className="w-5 h-5 stroke-[1.5]" />
              </button>
              <AnimatePresence>
                {isDropdownOpen && (
                  <>
                    <div className="fixed inset-0 z-40" onClick={() => setIsDropdownOpen(false)}></div>
                    <motion.div 
                      initial={{ opacity: 0, scale: 0.95, y: 10 }}
                      animate={{ opacity: 1, scale: 1, y: 0 }}
                      exit={{ opacity: 0, scale: 0.95, y: 10 }}
                      className="absolute top-full mt-2 bg-white/95 backdrop-blur-xl border border-emerald-100 rounded-2xl shadow-xl overflow-hidden min-w-[200px] right-0 z-50 p-2"
                    >
                      <Link to="/marketplace" onClick={() => setIsDropdownOpen(false)} className="flex items-center gap-3 px-4 py-3 text-sm font-bold text-gray-600 hover:text-emerald-600 hover:bg-emerald-50 rounded-xl transition-colors">
                        <ShoppingBag className="w-4 h-4 stroke-[1.5]" />
                        {t('nav.market')}
                      </Link>
                      <Link to="/community" onClick={() => setIsDropdownOpen(false)} className="flex items-center gap-3 px-4 py-3 text-sm font-bold text-gray-600 hover:text-emerald-600 hover:bg-emerald-50 rounded-xl transition-colors">
                        <Users className="w-4 h-4 stroke-[1.5]" />
                        {t('nav.community')}
                      </Link>
                      <Link to="/profile" onClick={() => setIsDropdownOpen(false)} className="flex items-center gap-3 px-4 py-3 text-sm font-bold text-gray-600 hover:text-emerald-600 hover:bg-emerald-50 rounded-xl transition-colors">
                        <Sparkles className="w-4 h-4 stroke-[1.5]" />
                        {t('nav.ai_concierge')}
                      </Link>
                      <Link to="/certified" onClick={() => setIsDropdownOpen(false)} className="flex items-center gap-3 px-4 py-3 text-sm font-bold text-gray-600 hover:text-emerald-600 hover:bg-emerald-50 rounded-xl transition-colors">
                        <Compass className="w-4 h-4 stroke-[1.5]" />
                        {language === 'ar' ? 'المعتمد' : 'Certified'}
                      </Link>
                      
                      <div className="h-px bg-gray-100 my-1"></div>
                      
                      <button onClick={() => { toggleDarkMode(); setIsDropdownOpen(false); }} className="w-full flex items-center gap-3 px-4 py-3 text-sm font-bold text-gray-600 hover:text-emerald-600 hover:bg-emerald-50 rounded-xl transition-colors">
                        {isDarkMode ? <Sun className="w-4 h-4 stroke-[1.5]" /> : <Moon className="w-4 h-4 stroke-[1.5]" />}
                        {isDarkMode ? (language === 'ar' ? 'الوضع النهاري' : 'Light Mode') : (language === 'ar' ? 'الوضع الليلي' : 'Dark Mode')}
                      </button>
                    </motion.div>
                  </>
                )}
              </AnimatePresence>
            </div>

            {user ? (
              <div className="relative">
                <button 
                  onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}
                  className="flex items-center gap-2 p-1 bg-white/50 border border-emerald-50 hover:border-emerald-200 rounded-2xl transition-all"
                >
                  {user.photoURL ? (
                    <img src={user.photoURL} alt="User" className="w-8 h-8 rounded-xl object-cover shadow-sm" referrerPolicy="no-referrer" />
                  ) : (
                    <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-500 flex items-center justify-center text-white font-bold text-xs">
                      {user.displayName?.charAt(0) || 'U'}
                    </div>
                  )}
                </button>

                <AnimatePresence>
                  {isUserMenuOpen && (
                    <>
                      <div className="fixed inset-0 z-40" onClick={() => setIsUserMenuOpen(false)}></div>
                      <motion.div 
                        initial={{ opacity: 0, scale: 0.95, y: 10 }}
                        animate={{ opacity: 1, scale: 1, y: 0 }}
                        exit={{ opacity: 0, scale: 0.95, y: 10 }}
                        className="absolute top-full mt-3 bg-white/95 backdrop-blur-xl border border-emerald-100 rounded-3xl shadow-2xl min-w-[240px] right-0 z-50 p-2"
                      >
                        <div className="px-4 py-3 border-b border-gray-50 mb-1 flex items-center gap-3">
                          <div className="w-10 h-10 rounded-full bg-emerald-50 flex items-center justify-center text-emerald-600">
                            <User className="w-5 h-5" />
                          </div>
                          <div className="flex flex-col min-w-0">
                            <p className="font-bold text-gray-900 text-sm truncate">{user.displayName || 'مستخدم'}</p>
                            <p className="text-[10px] text-gray-500 truncate">{user.email}</p>
                          </div>
                        </div>
                        <Link to="/profile" onClick={() => setIsUserMenuOpen(false)} className="flex items-center gap-3 px-4 py-3 text-sm font-bold text-gray-600 hover:text-emerald-600 hover:bg-emerald-50 rounded-2xl transition-colors">
                          <User className="w-4 h-4 stroke-[1.5]" />
                          الملف الشخصي
                        </Link>
                        <Link to="/my-bookings" onClick={() => setIsUserMenuOpen(false)} className="flex items-center gap-3 px-4 py-3 text-sm font-bold text-gray-600 hover:text-emerald-600 hover:bg-emerald-50 rounded-2xl transition-colors">
                          <Heart className="w-4 h-4 stroke-[1.5]" />
                          حجوزاتي
                        </Link>
                        <button onClick={() => { setIsUserMenuOpen(false); logout(); }} className="w-full flex items-center gap-3 px-4 py-3 text-sm font-bold text-red-500 hover:bg-red-50 rounded-2xl transition-colors mt-1">
                          <LogOut className="w-4 h-4 stroke-[1.5]" />
                          تسجيل الخروج
                        </button>
                      </motion.div>
                    </>
                  )}
                </AnimatePresence>
              </div>
            ) : (
              <button 
                className="bg-emerald-600 text-white px-6 py-2.5 rounded-xl text-sm font-bold hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-200 active:scale-95 ml-2"
              >
                {t('nav.login')}
              </button>
            )}
          </div>
        </div>
      </motion.nav>

      {/* Mobile Bottom Navigation Bar */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white/90 backdrop-blur-xl border-t border-gray-100 z-50 pb-safe shadow-[0_-10px_40px_rgba(0,0,0,0.05)]">
        <div className="flex justify-around items-center h-16 px-2">
          <Link to="/" className={`flex flex-col items-center justify-center w-full h-full gap-1 ${currentPath === '/' ? 'text-emerald-600' : 'text-gray-400'}`}>
            <HomeIcon className={`w-5 h-5 ${currentPath === '/' ? 'fill-emerald-100 stroke-[1.5]' : 'stroke-[1.5]'}`} />
            <span className="text-[10px] font-bold">{language === 'ar' ? 'الرئيسية' : 'Home'}</span>
          </Link>
          {bottomNavItems.map((item) => {
            const isActive = currentPath.includes(item.to);
            return (
              <Link 
                key={item.to}
                to={item.to} 
                className={`flex flex-col items-center justify-center w-full h-full gap-1 ${isActive ? 'text-emerald-600' : 'text-gray-400'}`}
              >
                <item.icon className={`w-5 h-5 ${isActive ? 'fill-emerald-100 stroke-[1.5]' : 'stroke-[1.5]'}`} />
                <span className="text-[10px] font-bold">{item.label}</span>
              </Link>
            );
          })}
        </div>
      </div>
    </>
  );
}
