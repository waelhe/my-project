import React, { useState, useEffect } from 'react';
import { db } from '../../../firebase';
import { collection, query, where, orderBy, onSnapshot, addDoc, serverTimestamp, Timestamp } from 'firebase/firestore';
import { useAuth } from '../../../core/contexts/AuthContext';
import { Star, MessageSquare, Send, Loader2, User as UserIcon } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import toast from 'react-hot-toast';

interface Review {
  id: string;
  userId: string;
  userName: string;
  userPhoto?: string;
  rating: number;
  comment: string;
  createdAt: Timestamp;
}

interface ReviewSectionProps {
  serviceId: string;
}

export default function ReviewSection({ serviceId }: ReviewSectionProps) {
  const { user, signInWithGoogle } = useAuth();
  const [reviews, setReviews] = useState<Review[]>([]);
  const [loading, setLoading] = useState(true);
  const [newComment, setNewComment] = useState('');
  const [newRating, setNewRating] = useState(5);
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    const q = query(
      collection(db, 'reviews'),
      where('serviceId', '==', serviceId),
      orderBy('createdAt', 'desc')
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const reviewsData = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Review[];
      setReviews(reviewsData);
      setLoading(false);
    });

    return () => unsubscribe();
  }, [serviceId]);

  const handleSubmitReview = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      signInWithGoogle();
      return;
    }

    if (!newComment.trim()) return;

    setIsSubmitting(true);
    try {
      await addDoc(collection(db, 'reviews'), {
        serviceId,
        userId: user.uid,
        userName: user.displayName || 'مستخدم ضيف',
        userPhoto: user.photoURL || '',
        rating: newRating,
        comment: newComment,
        createdAt: serverTimestamp()
      });
      setNewComment('');
      setNewRating(5);
      toast.success('تمت إضافة تقييمك بنجاح');
    } catch (error) {
      console.error("Error adding review:", error);
      toast.error('حدث خطأ أثناء إضافة التقييم. يرجى المحاولة مرة أخرى.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="py-12 border-t border-gray-200">
      <div className="flex items-center justify-between mb-8">
        <h3 className="text-2xl font-bold text-gray-900 flex items-center gap-3">
          <MessageSquare className="w-6 h-6 text-emerald-600" />
          آراء الزوار ({reviews.length})
        </h3>
        <div className="flex items-center gap-2 bg-emerald-50 px-4 py-2 rounded-full">
          <Star className="w-5 h-5 text-emerald-600 fill-emerald-600" />
          <span className="font-bold text-emerald-700">
            {reviews.length > 0 
              ? (reviews.reduce((acc, r) => acc + r.rating, 0) / reviews.length).toFixed(1)
              : 'جديد'}
          </span>
        </div>
      </div>

      {/* Add Review Form */}
      <div className="bg-gray-50 rounded-3xl p-6 mb-10">
        <h4 className="font-bold text-gray-900 mb-4">أضف تقييمك</h4>
        <form onSubmit={handleSubmitReview}>
          <div className="flex items-center gap-2 mb-4">
            {[1, 2, 3, 4, 5].map((star) => (
              <button
                key={star}
                type="button"
                onClick={() => setNewRating(star)}
                className="focus:outline-none transition-transform hover:scale-110"
              >
                <Star 
                  className={`w-8 h-8 ${star <= newRating ? 'text-amber-400 fill-amber-400' : 'text-gray-300'}`} 
                />
              </button>
            ))}
          </div>
          <div className="relative">
            <textarea
              value={newComment}
              onChange={(e) => setNewComment(e.target.value)}
              placeholder="شاركنا تجربتك في هذا المكان..."
              className="w-full bg-white border border-gray-200 rounded-2xl p-4 pr-12 min-h-[120px] focus:outline-none focus:ring-2 focus:ring-emerald-500 transition-all"
            />
            <button
              type="submit"
              disabled={isSubmitting || !newComment.trim()}
              className="absolute bottom-4 left-4 bg-emerald-600 text-white p-3 rounded-xl hover:bg-emerald-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isSubmitting ? <Loader2 className="w-5 h-5 animate-spin" /> : <Send className="w-5 h-5 rotate-180" />}
            </button>
          </div>
        </form>
      </div>

      {/* Reviews List */}
      {loading ? (
        <div className="flex justify-center py-10">
          <Loader2 className="w-8 h-8 text-emerald-600 animate-spin" />
        </div>
      ) : reviews.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <AnimatePresence>
            {reviews.map((review) => (
              <motion.div
                key={review.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-white border border-gray-100 rounded-2xl p-6 shadow-sm"
              >
                <div className="flex items-center gap-4 mb-4">
                  {review.userPhoto ? (
                    <img src={review.userPhoto} alt={review.userName} className="w-12 h-12 rounded-full border border-gray-100" referrerPolicy="no-referrer" />
                  ) : (
                    <div className="w-12 h-12 rounded-full bg-gray-100 flex items-center justify-center">
                      <UserIcon className="w-6 h-6 text-gray-400" />
                    </div>
                  )}
                  <div>
                    <h5 className="font-bold text-gray-900">{review.userName}</h5>
                    <div className="flex items-center gap-1">
                      {[...Array(5)].map((_, i) => (
                        <Star 
                          key={i} 
                          className={`w-3 h-3 ${i < review.rating ? 'text-amber-400 fill-amber-400' : 'text-gray-200'}`} 
                        />
                      ))}
                      <span className="text-xs text-gray-400 mr-2">
                        {review.createdAt?.toDate().toLocaleDateString('ar-SA')}
                      </span>
                    </div>
                  </div>
                </div>
                <p className="text-gray-600 leading-relaxed">{review.comment}</p>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      ) : (
        <div className="text-center py-10 bg-gray-50 rounded-3xl border border-dashed border-gray-300">
          <p className="text-gray-500">لا توجد تقييمات بعد. كن أول من يشارك رأيه!</p>
        </div>
      )}
    </div>
  );
}
