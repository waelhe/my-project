import React from 'react';

export default function MyBookings() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">My Bookings</h1>
      <p>You have no bookings yet.</p>
    </div>
  );
}
