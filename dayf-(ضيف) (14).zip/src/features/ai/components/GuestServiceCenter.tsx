import React, { useState } from 'react';
import { HelpCircle, X, Phone, Mail, MessageCircle, ChevronRight, Search, Info, ShieldCheck, CreditCard, MapPin } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useLanguage } from '../../../core/contexts/LanguageContext';

export default function GuestServiceCenter() {
  const { language } = useLanguage();
  const [isOpen, setIsOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const faqs = [
    {
      id: 1,
      question: language === 'ar' ? 'كيف يمكنني حجز خدمة؟' : 'How can I book a service?',
      answer: language === 'ar' ? 'يمكنك تصفح الخدمات واختيار ما يناسبك، ثم الضغط على زر "احجز الآن" واتباع الخطوات.' : 'You can browse services, choose what suits you, then click "Book Now" and follow the steps.'
    },
    {
      id: 2,
      question: language === 'ar' ? 'هل الدفع آمن؟' : 'Is payment secure?',
      answer: language === 'ar' ? 'نعم، نحن نستخدم تقنيات تشفير متقدمة لضمان أمان معلوماتك المالية.' : 'Yes, we use advanced encryption technologies to ensure the security of your financial information.'
    },
    {
      id: 3,
      question: language === 'ar' ? 'كيف يمكنني إلغاء الحجز؟' : 'How can I cancel a booking?',
      answer: language === 'ar' ? 'يمكنك إلغاء الحجز من خلال صفحة "حجوزاتي" في ملفك الشخصي، وفقاً لسياسة الإلغاء الخاصة بالخدمة.' : 'You can cancel a booking through the "My Bookings" page in your profile, according to the service cancellation policy.'
    }
  ];

  const filteredFaqs = faqs.filter(faq => 
    faq.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
    faq.answer.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="fixed bottom-20 md:bottom-6 left-6 z-50">
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9, x: -20 }}
            animate={{ opacity: 1, scale: 1, x: 0 }}
            exit={{ opacity: 0, scale: 0.9, x: -20 }}
            className="absolute bottom-16 left-0 w-[350px] md:w-[400px] bg-white rounded-3xl shadow-2xl border border-gray-100 flex flex-col overflow-hidden max-h-[80vh]"
          >
            {/* Header */}
            <div className="bg-gray-900 p-6 text-white">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-xl font-bold">
                  {language === 'ar' ? 'مركز خدمة ضيف' : 'Dheif Service Center'}
                </h3>
                <button 
                  onClick={() => setIsOpen(false)}
                  className="p-2 hover:bg-white/10 rounded-full transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder={language === 'ar' ? 'كيف يمكننا مساعدتك؟' : 'How can we help?'}
                  className="w-full pl-10 pr-4 py-2 bg-white/10 border border-white/20 rounded-xl text-sm focus:outline-none focus:bg-white/20 transition-all placeholder:text-gray-400"
                />
              </div>
            </div>

            {/* Content */}
            <div className="flex-1 overflow-y-auto p-6 space-y-6">
              {/* Quick Links */}
              <div className="grid grid-cols-2 gap-3">
                <button className="flex flex-col items-center gap-2 p-4 bg-gray-50 rounded-2xl hover:bg-gray-100 transition-colors">
                  <ShieldCheck className="w-6 h-6 text-emerald-600" />
                  <span className="text-xs font-bold">{language === 'ar' ? 'الأمان' : 'Safety'}</span>
                </button>
                <button className="flex flex-col items-center gap-2 p-4 bg-gray-50 rounded-2xl hover:bg-gray-100 transition-colors">
                  <CreditCard className="w-6 h-6 text-blue-600" />
                  <span className="text-xs font-bold">{language === 'ar' ? 'الدفع' : 'Payment'}</span>
                </button>
              </div>

              {/* FAQs */}
              <div>
                <h4 className="text-sm font-bold text-gray-900 mb-4 flex items-center gap-2">
                  <Info className="w-4 h-4 text-gray-400" />
                  {language === 'ar' ? 'الأسئلة الشائعة' : 'Common Questions'}
                </h4>
                <div className="space-y-3">
                  {filteredFaqs.map(faq => (
                    <div key={faq.id} className="p-4 bg-gray-50 rounded-2xl">
                      <p className="text-sm font-bold text-gray-900 mb-1">{faq.question}</p>
                      <p className="text-xs text-gray-600 leading-relaxed">{faq.answer}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Contact */}
              <div className="pt-6 border-t border-gray-100">
                <h4 className="text-sm font-bold text-gray-900 mb-4">
                  {language === 'ar' ? 'تواصل معنا' : 'Contact Us'}
                </h4>
                <div className="space-y-3">
                  <a href="tel:+96311223344" className="flex items-center justify-between p-4 bg-gray-50 rounded-2xl hover:bg-gray-100 transition-colors">
                    <div className="flex items-center gap-3">
                      <Phone className="w-5 h-5 text-gray-400" />
                      <span className="text-sm font-medium">+963 11 223 344</span>
                    </div>
                    <ChevronRight className="w-4 h-4 text-gray-300" />
                  </a>
                  <a href="mailto:support@dheif.com" className="flex items-center justify-between p-4 bg-gray-50 rounded-2xl hover:bg-gray-100 transition-colors">
                    <div className="flex items-center gap-3">
                      <Mail className="w-5 h-5 text-gray-400" />
                      <span className="text-sm font-medium">support@dheif.com</span>
                    </div>
                    <ChevronRight className="w-4 h-4 text-gray-300" />
                  </a>
                </div>
              </div>
            </div>

            {/* Footer */}
            <div className="p-4 bg-gray-50 border-t border-gray-100 text-center">
              <p className="text-[10px] text-gray-400">
                {language === 'ar' ? 'متاحون لخدمتكم 24/7' : 'Available to serve you 24/7'}
              </p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <motion.button
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        onClick={() => setIsOpen(!isOpen)}
        className={`w-14 h-14 rounded-full flex items-center justify-center shadow-2xl transition-all ${
          isOpen ? 'bg-white text-gray-900 border border-gray-100' : 'bg-gray-900 text-white'
        }`}
      >
        {isOpen ? <X className="w-6 h-6" /> : <HelpCircle className="w-6 h-6" />}
      </motion.button>
    </div>
  );
}
