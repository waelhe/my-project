import { collection, addDoc, query, where, getDocs, orderBy } from 'firebase/firestore';
import { db } from '../../../firebase';
import { Order } from '../../features/orders/types';

const ORDERS_COLLECTION = 'orders';

export const orderService = {
  async createOrder(order: Omit<Order, 'id'>): Promise<string> {
    const colRef = collection(db, ORDERS_COLLECTION);
    const docRef = await addDoc(colRef, order);
    return docRef.id;
  },
  async getOrders(userId: string): Promise<Order[]> {
    const q = query(
      collection(db, ORDERS_COLLECTION),
      where('userId', '==', userId),
      orderBy('createdAt', 'desc')
    );
    const snapshot = await getDocs(q);
    return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Order));
  }
};
