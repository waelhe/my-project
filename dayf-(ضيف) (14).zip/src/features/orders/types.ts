import { Product } from '../marketplace/types';

export interface Order {
  id: string;
  userId: string;
  items: (Product & { quantity: number })[];
  total: number;
  status: 'pending' | 'confirmed' | 'shipped' | 'delivered' | 'cancelled';
  createdAt: any;
}
