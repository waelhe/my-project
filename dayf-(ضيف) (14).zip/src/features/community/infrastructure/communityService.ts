import { db } from '../../../firebase';
import { 
  collection, 
  getDocs, 
  getDoc, 
  doc, 
  addDoc, 
  updateDoc, 
  query, 
  where, 
  orderBy, 
  limit, 
  onSnapshot, 
  serverTimestamp, 
  increment,
  Timestamp
} from 'firebase/firestore';
import { CommunityTopic, Reply } from '../../features/community/types';

const TOPICS_COLLECTION = 'community_topics';
const REPLIES_COLLECTION = 'community_replies';

export const communityService = {
  getTopics: async (categoryId?: string, maxLimit: number = 20): Promise<CommunityTopic[]> => {
    let q = query(collection(db, TOPICS_COLLECTION), orderBy('createdAt', 'desc'), limit(maxLimit));
    if (categoryId) {
      q = query(collection(db, TOPICS_COLLECTION), where('categoryId', '==', categoryId), orderBy('createdAt', 'desc'), limit(maxLimit));
    }
    const snapshot = await getDocs(q);
    return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as CommunityTopic));
  },

  subscribeToTopics: (callback: (topics: CommunityTopic[]) => void, categoryId?: string) => {
    let q = query(collection(db, TOPICS_COLLECTION), orderBy('createdAt', 'desc'));
    if (categoryId) {
      q = query(collection(db, TOPICS_COLLECTION), where('categoryId', '==', categoryId), orderBy('createdAt', 'desc'));
    }
    
    return onSnapshot(q, (snapshot) => {
      const topics = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as CommunityTopic));
      callback(topics);
    });
  },

  getTopicById: async (id: string): Promise<CommunityTopic | null> => {
    const docRef = doc(db, TOPICS_COLLECTION, id);
    const docSnap = await getDoc(docRef);
    if (docSnap.exists()) {
      return { id: docSnap.id, ...docSnap.data() } as CommunityTopic;
    }
    return null;
  },

  createTopic: async (topic: Omit<CommunityTopic, 'id' | 'createdAt' | 'likesCount' | 'repliesCount'>): Promise<string> => {
    const docRef = await addDoc(collection(db, TOPICS_COLLECTION), {
      ...topic,
      likesCount: 0,
      repliesCount: 0,
      createdAt: serverTimestamp()
    });
    return docRef.id;
  },

  getReplies: async (topicId: string): Promise<Reply[]> => {
    const q = query(
      collection(db, REPLIES_COLLECTION), 
      where('topicId', '==', topicId), 
      orderBy('createdAt', 'asc')
    );
    const snapshot = await getDocs(q);
    return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Reply));
  },

  subscribeToReplies: (topicId: string, callback: (replies: Reply[]) => void) => {
    const q = query(
      collection(db, REPLIES_COLLECTION), 
      where('topicId', '==', topicId), 
      orderBy('createdAt', 'asc')
    );
    return onSnapshot(q, (snapshot) => {
      const replies = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Reply));
      callback(replies);
    });
  },

  createReply: async (reply: Omit<Reply, 'id' | 'createdAt' | 'likesCount'>): Promise<string> => {
    const docRef = await addDoc(collection(db, REPLIES_COLLECTION), {
      ...reply,
      likesCount: 0,
      createdAt: serverTimestamp()
    });

    // Increment replies count on topic
    const topicRef = doc(db, TOPICS_COLLECTION, reply.topicId);
    await updateDoc(topicRef, {
      repliesCount: increment(1)
    });

    return docRef.id;
  },

  likeTopic: async (topicId: string): Promise<void> => {
    const docRef = doc(db, TOPICS_COLLECTION, topicId);
    await updateDoc(docRef, {
      likesCount: increment(1)
    });
  },

  likeReply: async (replyId: string): Promise<void> => {
    const docRef = doc(db, REPLIES_COLLECTION, replyId);
    await updateDoc(docRef, {
      likesCount: increment(1)
    });
  }
};
