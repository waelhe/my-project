import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { ArrowRight, ShoppingCart, MapPin, Star, Truck, ShieldCheck } from 'lucide-react';
import { marketplaceService } from '../infrastructure/marketplaceService';
import { Product } from '../types';
import { useCart } from '../contexts/CartContext';
import toast from 'react-hot-toast';

export default function ProductDetailsPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [product, setProduct] = useState<Product | null>(null);
  const [loading, setLoading] = useState(true);
  const { addToCart } = useCart();

  useEffect(() => {
    const fetchProduct = async () => {
      if (!id) return;
      try {
        const found = await marketplaceService.getProductById(id);
        setProduct(found);
      } catch (error) {
        console.error('Error fetching product:', error);
        toast.error('حدث خطأ أثناء تحميل تفاصيل المنتج');
      } finally {
        setLoading(false);
      }
    };
    fetchProduct();
  }, [id]);

  if (loading) return <div className="min-h-screen flex items-center justify-center">جاري التحميل...</div>;
  if (!product) return <div className="min-h-screen flex items-center justify-center">المنتج غير موجود</div>;

  return (
    <div className="min-h-screen bg-gray-50 pt-24 pb-12">
      <div className="max-w-4xl mx-auto px-4">
        <button onClick={() => navigate(-1)} className="mb-6 flex items-center gap-2 text-gray-600 hover:text-emerald-600">
          <ArrowRight className="w-5 h-5" />
          العودة للمتجر
        </button>
        
        <div className="bg-white rounded-3xl shadow-sm border border-gray-100 overflow-hidden">
          <img src={product.image || (product.images && product.images[0])} alt={product.name} className="w-full h-96 object-cover" referrerPolicy="no-referrer" />
          
          <div className="p-8">
            <div className="flex justify-between items-start mb-4">
              <h1 className="text-3xl font-bold text-gray-900">{product.name}</h1>
              <span className="text-2xl font-bold text-emerald-600">{product.price.toLocaleString('ar-SA')} ل.س</span>
            </div>
            
            <div className="flex items-center gap-4 mb-6 text-sm text-gray-500">
              <div className="flex items-center gap-1 bg-amber-50 text-amber-600 px-3 py-1 rounded-full font-bold">
                <Star className="w-4 h-4 fill-current" />
                {product.rating} ({product.reviews} تقييم)
              </div>
              <div className="flex items-center gap-1">
                <MapPin className="w-4 h-4 text-emerald-600" />
                {product.location}
              </div>
              <Link to={`/marketplace/vendor/${product.vendor}`} className="text-emerald-600 font-bold hover:underline">
                البائع: {product.vendor}
              </Link>
            </div>

            <p className="text-gray-600 mb-8 leading-relaxed">{product.description}</p>

            <div className="grid grid-cols-2 gap-4 mb-8">
              <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-xl">
                <Truck className="w-6 h-6 text-emerald-600" />
                <div>
                  <p className="font-bold text-sm">شحن سريع</p>
                  <p className="text-xs text-gray-500">توصيل خلال 48 ساعة</p>
                </div>
              </div>
              <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-xl">
                <ShieldCheck className="w-6 h-6 text-emerald-600" />
                <div>
                  <p className="font-bold text-sm">ضمان الجودة</p>
                  <p className="text-xs text-gray-500">منتجات أصلية 100%</p>
                </div>
              </div>
            </div>

            <button 
              onClick={() => {
                addToCart(product);
                toast.success('تمت الإضافة إلى السلة');
              }}
              className="w-full bg-emerald-600 text-white font-bold py-4 rounded-2xl hover:bg-emerald-700 transition-colors flex items-center justify-center gap-2 text-lg"
            >
              <ShoppingCart className="w-6 h-6" />
              إضافة إلى السلة
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
