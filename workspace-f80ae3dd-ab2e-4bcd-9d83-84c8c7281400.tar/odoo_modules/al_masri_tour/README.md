# Al Masri Fahrzeugüberführung - Odoo Module

## 🚗 نظام إدارة نقل المركبات الكامل لـ Odoo 17

---

## 📋 نظرة عامة

هذا الموديول مصمم خصيصاً لشركة **Al Masri Fahrzeugüberführung** لإدارة عمليات نقل المركبات والفوترة.

### الميزات الرئيسية:

- ✅ **إدارة الرحلات (Tours)** - تسجيل وتتبع جميع رحلات نقل المركبات
- ✅ **جدول تسعير متدرج** - 12 شريحة سعرية حسب المسافة
- ✅ **حساب وقت الانتظار** - معدل 10€/ساعة
- ✅ **نظام الخصومات** - خصومات خاصة للعملاء
- ✅ **فواتير PDF احترافية** - تصميم ألماني معتمد
- ✅ **إدارة السائقين والمركبات**
- ✅ **تقارير وإحصائيات**

---

## 📁 هيكل الموديول

```
al_masri_tour/
├── __init__.py
├── __manifest__.py
├── models/
│   ├── __init__.py
│   ├── tour_pricing.py      # جدول التسعير
│   ├── tour_driver.py       # السائقين
│   ├── tour_vehicle.py      # المركبات
│   ├── tour_tour.py         # الرحلات
│   ├── tour_invoice.py      # الفواتير
│   └── res_partner.py       # العملاء
├── views/
│   ├── tour_pricing_views.xml
│   ├── tour_driver_views.xml
│   ├── tour_vehicle_views.xml
│   ├── tour_tour_views.xml
│   ├── tour_invoice_views.xml
│   ├── res_partner_views.xml
│   ├── menu_views.xml
│   └── report_views.xml
├── reports/
│   ├── __init__.py
│   ├── invoice_report.xml
│   └── report_templates.xml
├── security/
│   ├── security.xml
│   └── ir.model.access.csv
├── data/
│   ├── pricing_data.xml     # جدول التسعير
│   ├── company_data.xml     # بيانات الشركة
│   ├── partner_data.xml     # العملاء
│   └── demo_data.xml        # بيانات تجريبية
├── wizard/
│   ├── __init__.py
│   ├── tour_invoice_wizard.py
│   └── tour_invoice_wizard_views.xml
└── static/
    ├── description/
    │   ├── icon.png
    │   └── banner.png
    └── src/
        ├── css/
        ├── js/
        └── img/
```

---

## 💰 جدول التسعير

| المسافة (km) | السعر (€) |
|--------------|-----------|
| 0 - 20 | 19€ |
| 21 - 30 | 24€ |
| 31 - 50 | 40€ |
| 51 - 100 | 50€ |
| 101 - 150 | 75€ |
| 151 - 200 | 85€ |
| 201 - 250 | 100€ |
| 251 - 350 | 120€ |
| 351 - 450 | 145€ |
| 451 - 550 | 170€ |
| 551 - 650 | 185€ |
| 650+ | 185€ + 20€/100km |

---

## ⏱️ وقت الانتظار

- **المعدل:** 10€ لكل ساعة
- **الحساب:** دقائق × 0.1667€

---

## 🎯 القواعد الحسابية الستة

### القاعدة 1: معالجة الرقم "1"
```
"1 237,43" km → حذف "1 " → 237.43 km للحساب
                            → "1.237,43" للعرض
```

### القاعدة 2: جدول التسعير المتدرج
السعر يعتمد على شريحة المسافة

### القاعدة 3: وقت الانتظار
```
تكلفة الانتظار = دقائق × 0.1667€
```

### القاعدة 4: الخصومات
```
الخصم يُطبّق بعد وقت الانتظار
(السعر الأساسي + الانتظار) × (1 - نسبة الخصم)
```

### القاعدة 5: الضريبة
```
Nettobetrag × 0.19 = Umsatzsteuer
Nettobetrag + Umsatzsteuer = Gesamtbetrag
```

### القاعدة 6: التنسيق الألماني
```
1234.56 → 1.234,56 (نقطة للآلاف، فاصلة للعشريات)
```

---

## 📦 التثبيت

### المتطلبات:
- Odoo 17.0
- Python 3.10+
- PostgreSQL 14+

### خطوات التثبيت:

1. **نسخ الموديول:**
```bash
cp -r al_masri_tour /path/to/odoo/addons/
```

2. **تحديث قائمة الموديولات:**
```
Settings → Apps → Update Apps List
```

3. **تثبيت الموديول:**
```
Apps → Search "Al Masri" → Install
```

4. **تكوين الشركة:**
```
Settings → Companies → Update Company Info
- أدخل معلومات البنك
- أدخل الرقم الضريبي
```

---

## ⚙️ التكوين

### 1. إعداد جدول التسعير
```
Vehicle Transport → Settings → Pricing Table
```

### 2. إضافة السائقين
```
Vehicle Transport → Resources → Drivers → Create
```

### 3. إضافة المركبات
```
Vehicle Transport → Resources → Vehicles → Create
```

### 4. إضافة العملاء
```
Vehicle Transport → Customers → Create
☑ Is Tour Customer
```

---

## 🚀 الاستخدام

### إنشاء رحلة جديدة:
1. الذهاب إلى **Vehicle Transport → Tours → All Tours**
2. الضغط على **Create**
3. إدخال بيانات الرحلة:
   - رقم الرحلة (Tour NR)
   - العميل
   - المسافة (بالتسنيق الألماني: `1 237,43`)
   - وقت الانتظار (إن وجد)
   - الخصم (إن وجد)
4. حفظ الرحلة

### إنشاء فاتورة:
1. الذهاب إلى **Vehicle Transport → Invoices**
2. الضغط على **Create**
3. اختيار العميل والفترة
4. إضافة الرحلات المطلوبة
5. تأكيد الفاتورة وطباعتها

---

## 👥 مجموعات المستخدمين

| المجموعة | الصلاحيات |
|----------|----------|
| Tour User | إنشاء وتعديل الرحلات |
| Tour Manager | صلاحيات كاملة |
| Tour Driver | عرض وتحديث الرحلات المخصصة |

---

## 📊 التقارير

- **تحليل الرحلات** - Pivot/Graph
- **تقارير الإيرادات**
- **أداء السائقين**

---

## 📞 معلومات الشركة

**Al Masri Fahrzeugüberführung**
- **المالك:** Majd Alddin Almasri
- **العنوان:** Langendreerstr. 95, 44388 Dortmund
- **Steuernummer:** 314/5002/8490

**معلومات البنك:**
- **Holder:** Majd Alddin Almasri
- **IBAN:** DE79 4305 0001 0007 4331 39
- **Bank:** Sparkasse Bochum
- **BIC:** WELADED1BOC

---

## 📄 الترخيص

LGPL-3

---

## 🔄 التحديثات

### v17.0.1.0.0
- الإصدار الأولي
- جميع الميزات الأساسية

---

**تم التطوير بواسطة Al Masri Team** 🚗
