import { db } from '../firebase';
import { 
  collection, 
  getDocs, 
  getDoc, 
  doc, 
  query, 
  where, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  serverTimestamp,
  Timestamp,
  setDoc
} from 'firebase/firestore';
import { MOCK_SERVICES } from '../data/categories';

export interface Service {
  id: string;
  mainCategoryId: string;
  subCategoryId: string;
  title: string;
  location: string;
  price: number;
  originalPrice?: number;
  rating: number;
  reviews: number;
  images: string[];
  type: string;
  amenities: string[];
  features: string[];
  isPopular: boolean;
  host?: {
    name: string;
    isSuperhost: boolean;
    avatar: string;
  };
  authorUid: string;
  createdAt: any;
}

const SERVICES_COLLECTION = 'services';

export const seedServices = async (userUid: string) => {
  try {
    const querySnapshot = await getDocs(collection(db, SERVICES_COLLECTION));
    if (querySnapshot.empty) {
      console.log('Seeding services...');
      for (const service of MOCK_SERVICES) {
        const { id, ...serviceData } = service;
        try {
          await setDoc(doc(db, SERVICES_COLLECTION, id), {
            ...serviceData,
            authorUid: userUid,
            createdAt: serverTimestamp()
          });
        } catch (err) {
          // If we can't seed (e.g. not an admin), just skip it
          console.warn(`Could not seed service ${id}:`, err);
        }
      }
      console.log('Seeding complete or skipped.');
    }
  } catch (error) {
    console.error('Error during seeding check:', error);
    // Don't throw, just let the app continue
  }
};

export const getAllServices = async (): Promise<Service[]> => {
  const querySnapshot = await getDocs(collection(db, SERVICES_COLLECTION));
  return querySnapshot.docs.map(doc => ({
    id: doc.id,
    ...doc.data()
  })) as Service[];
};

export const getServicesByCategory = async (categoryId: string): Promise<Service[]> => {
  const q = query(collection(db, SERVICES_COLLECTION), where('mainCategoryId', '==', categoryId));
  const querySnapshot = await getDocs(q);
  return querySnapshot.docs.map(doc => ({
    id: doc.id,
    ...doc.data()
  })) as Service[];
};

export const getServiceById = async (id: string): Promise<Service | null> => {
  const docRef = doc(db, SERVICES_COLLECTION, id);
  const docSnap = await getDoc(docRef);
  if (docSnap.exists()) {
    return { id: docSnap.id, ...docSnap.data() } as Service;
  }
  return null;
};

export const createService = async (serviceData: Omit<Service, 'id' | 'createdAt'>) => {
  return await addDoc(collection(db, SERVICES_COLLECTION), {
    ...serviceData,
    createdAt: serverTimestamp()
  });
};

export const updateService = async (id: string, serviceData: Partial<Service>) => {
  const docRef = doc(db, SERVICES_COLLECTION, id);
  await updateDoc(docRef, serviceData);
};

export const deleteService = async (id: string) => {
  const docRef = doc(db, SERVICES_COLLECTION, id);
  await deleteDoc(docRef);
};
