import { Plane, HeartPulse, GraduationCap, Briefcase } from 'lucide-react';

export const MAIN_CATEGORIES = [
  {
    id: 'tourism',
    name: 'السياحة',
    description: 'اكتشف جمال سوريا، تاريخها العريق، وطبيعتها الساحرة',
    icon: Plane,
    color: 'emerald',
    image: 'https://picsum.photos/seed/syria_tourism/1200/400',
    subCategories: [
      { id: 'recreational', name: 'ترفيهية واستجمام', icon: '🏖️' },
      { id: 'cultural', name: 'ثقافية وتاريخية', icon: '🏛️' },
      { id: 'religious', name: 'دينية وروحانية', icon: '🕌' },
      { id: 'nature', name: 'طبيعية ومغامرة', icon: '🏔️' }
    ]
  },
  {
    id: 'medical',
    name: 'العلاج',
    description: 'رعاية صحية متميزة، أطباء خبراء، ومراكز طبية متقدمة',
    icon: HeartPulse,
    color: 'blue',
    image: 'https://picsum.photos/seed/syria_medical/1200/400',
    subCategories: [
      { id: 'medical', name: 'رعاية طبية', icon: '🏥' },
      { id: 'dental', name: 'طب الأسنان', icon: '🦷' },
      { id: 'eye', name: 'طب العيون', icon: '👁️' },
      { id: 'alternative', name: 'طب بديل واستشفاء', icon: '🌿' }
    ]
  },
  {
    id: 'education',
    name: 'الدراسة',
    description: 'جامعات عريقة، معاهد متخصصة، وبرامج تعليمية شاملة',
    icon: GraduationCap,
    color: 'amber',
    image: 'https://picsum.photos/seed/syria_education/1200/400',
    subCategories: [
      { id: 'university', name: 'تعليم جامعي', icon: '🎓' },
      { id: 'vocational', name: 'تأهيل مهني', icon: '📜' },
      { id: 'languages', name: 'تعلم اللغات', icon: '🗣️' },
      { id: 'arts', name: 'حرف وفنون', icon: '🎨' }
    ]
  },
  {
    id: 'business',
    name: 'الأعمال',
    description: 'فرص استثمارية، شراكات استراتيجية، وخدمات أعمال متكاملة',
    icon: Briefcase,
    color: 'purple',
    image: 'https://picsum.photos/seed/syria_business/1200/400',
    subCategories: [
      { id: 'investment', name: 'فرص استثمارية', icon: '💰' },
      { id: 'partnerships', name: 'شراكات تجارية', icon: '🤝' },
      { id: 'conferences', name: 'مؤتمرات ومعارض', icon: '📅' },
      { id: 'services', name: 'خدمات أعمال', icon: '🏢' }
    ]
  }
];

export const MOCK_SERVICES = [
  // ================= TOURISM =================
  {
    id: 't1',
    mainCategoryId: 'tourism',
    subCategoryId: 'recreational',
    title: 'منتجع الرمال الذهبية الفاخر',
    location: 'طرطوس، الشاطئ الأزرق',
    price: 150,
    originalPrice: 200, // For discount calculation
    rating: 4.9,
    reviews: 320,
    images: [
      'https://picsum.photos/seed/resort1/800/600',
      'https://picsum.photos/seed/resort2/800/600',
      'https://picsum.photos/seed/resort3/800/600'
    ],
    type: 'منتجع',
    amenities: ['مسبح خاص', 'واي فاي سريع', 'إطلالة بحرية', 'سبا ومساج', 'موقف سيارات مجاني', 'مطعم فاخر'],
    features: ['إلغاء مجاني', 'حجز فوري'],
    isPopular: true,
    host: { name: 'إدارة المنتجع', isSuperhost: true, avatar: 'https://i.pravatar.cc/150?u=t1' }
  },
  {
    id: 't2',
    mainCategoryId: 'tourism',
    subCategoryId: 'cultural',
    title: 'بيت دمشقي أثري (فندق الياسمين)',
    location: 'دمشق، باب توما',
    price: 85,
    rating: 4.8,
    reviews: 156,
    images: [
      'https://picsum.photos/seed/damascus1/800/600',
      'https://picsum.photos/seed/damascus2/800/600'
    ],
    type: 'فندق تراثي',
    amenities: ['فطور شامي مجاني', 'واي فاي', 'تكييف', 'جولات سياحية', 'فناء داخلي (أرض الديار)'],
    features: ['إلغاء مجاني'],
    isPopular: false,
    host: { name: 'عائلة دمشقية', isSuperhost: true, avatar: 'https://i.pravatar.cc/150?u=t2' }
  },
  {
    id: 't3',
    mainCategoryId: 'tourism',
    subCategoryId: 'nature',
    title: 'أكواخ صلنفة الخشبية المعلقة',
    location: 'اللاذقية، صلنفة',
    price: 60,
    originalPrice: 75,
    rating: 4.6,
    reviews: 89,
    images: [
      'https://picsum.photos/seed/cabin1/800/600',
      'https://picsum.photos/seed/cabin2/800/600'
    ],
    type: 'أكواخ وتخييم',
    amenities: ['مطبخ مجهز', 'تدفئة مركزية', 'إطلالة جبلية بانورامية', 'منطقة شواء', 'موقف سيارات'],
    features: ['حجز فوري'],
    isPopular: false,
    host: { name: 'أحمد', isSuperhost: false, avatar: 'https://i.pravatar.cc/150?u=t3' }
  },
  {
    id: 't4',
    mainCategoryId: 'tourism',
    subCategoryId: 'recreational',
    title: 'شاليهات النورس الملكية',
    location: 'اللاذقية، وادي قنديل',
    price: 120,
    rating: 4.7,
    reviews: 210,
    images: [
      'https://picsum.photos/seed/chalet1/800/600',
      'https://picsum.photos/seed/chalet2/800/600'
    ],
    type: 'شاليه',
    amenities: ['شاطئ رملي خاص', 'مسبح أطفال', 'تكييف', 'مطبخ كامل', 'ألعاب مائية'],
    features: ['إلغاء مجاني', 'مناسب للعائلات'],
    isPopular: true,
    host: { name: 'شركة النورس', isSuperhost: true, avatar: 'https://i.pravatar.cc/150?u=t4' }
  },
  {
    id: 't5',
    mainCategoryId: 'tourism',
    subCategoryId: 'cultural',
    title: 'فندق بارون التاريخي (مجدد)',
    location: 'حلب، مركز المدينة',
    price: 95,
    rating: 4.5,
    reviews: 420,
    images: [
      'https://picsum.photos/seed/baron1/800/600',
      'https://picsum.photos/seed/baron2/800/600'
    ],
    type: 'فندق',
    amenities: ['واي فاي', 'مطعم تاريخي', 'خدمة غرف 24/7', 'تكييف'],
    features: ['معلم تاريخي'],
    isPopular: false,
    host: { name: 'إدارة الفندق', isSuperhost: false, avatar: 'https://i.pravatar.cc/150?u=t5' }
  },
  
  // ================= MEDICAL =================
  {
    id: 'm1',
    mainCategoryId: 'medical',
    subCategoryId: 'dental',
    title: 'مركز ابتسامة الشام لطب وتجميل الأسنان',
    location: 'دمشق، المزة',
    price: 200, 
    originalPrice: 250,
    rating: 4.9,
    reviews: 412,
    images: [
      'https://picsum.photos/seed/dental1/800/600',
      'https://picsum.photos/seed/dental2/800/600'
    ],
    type: 'عيادة تخصصية',
    amenities: ['أشعة بانورامية 3D', 'تخدير حديث بدون ألم', 'تعقيم دولي', 'زراعة فورية', 'استشارة مجانية'],
    features: ['حجز موعد فوري', 'يقبل التأمين'],
    isPopular: true,
    host: { name: 'د. سامر', isSuperhost: true, avatar: 'https://i.pravatar.cc/150?u=m1' }
  },
  {
    id: 'm2',
    mainCategoryId: 'medical',
    subCategoryId: 'medical',
    title: 'مستشفى الشفاء التخصصي',
    location: 'حلب، الفرقان',
    price: 500,
    rating: 4.8,
    reviews: 230,
    images: [
      'https://picsum.photos/seed/hospital1/800/600',
      'https://picsum.photos/seed/hospital2/800/600'
    ],
    type: 'مستشفى',
    amenities: ['طوارئ 24/7', 'غرف إقامة فندقية', 'عناية مشددة متطورة', 'مختبر شامل', 'صيدلية'],
    features: ['خدمة الإسعاف', 'مرافقين مجاناً'],
    isPopular: false,
    host: { name: 'إدارة المستشفى', isSuperhost: true, avatar: 'https://i.pravatar.cc/150?u=m2' }
  },
  {
    id: 'm3',
    mainCategoryId: 'medical',
    subCategoryId: 'eye',
    title: 'المركز الدولي لليزك وجراحة العيون',
    location: 'اللاذقية، الزراعة',
    price: 350,
    rating: 4.9,
    reviews: 850,
    images: [
      'https://picsum.photos/seed/eye1/800/600',
      'https://picsum.photos/seed/eye2/800/600'
    ],
    type: 'مركز جراحي',
    amenities: ['فيمتو سمايل', 'تصوير طبقي للعين', 'غرف عمليات معقمة', 'متابعة مجانية'],
    features: ['تقسيط متاح', 'حجز فوري'],
    isPopular: true,
    host: { name: 'د. ريم', isSuperhost: true, avatar: 'https://i.pravatar.cc/150?u=m3' }
  },

  // ================= EDUCATION =================
  {
    id: 'e1',
    mainCategoryId: 'education',
    subCategoryId: 'languages',
    title: 'معهد دمشق لتعليم اللغة العربية للأجانب',
    location: 'دمشق، البرامكة',
    price: 300, 
    rating: 4.9,
    reviews: 540,
    images: [
      'https://picsum.photos/seed/education1/800/600',
      'https://picsum.photos/seed/education2/800/600'
    ],
    type: 'معهد لغات',
    amenities: ['شهادة معتمدة دولياً', 'سكن طلابي', 'أنشطة ثقافية أسبوعية', 'مكتبة شاملة', 'مدرسين ناطقين باللغة'],
    features: ['تأشيرة دراسية', 'إلغاء مجاني'],
    isPopular: true,
    host: { name: 'جامعة دمشق', isSuperhost: true, avatar: 'https://i.pravatar.cc/150?u=e1' }
  },
  
  // ================= BUSINESS =================
  {
    id: 'b1',
    mainCategoryId: 'business',
    subCategoryId: 'services',
    title: 'مساحة عمل مشتركة (Damascus Hub)',
    location: 'دمشق، كفرسوسة',
    price: 25, 
    originalPrice: 35,
    rating: 4.7,
    reviews: 120,
    images: [
      'https://picsum.photos/seed/business1/800/600',
      'https://picsum.photos/seed/business2/800/600'
    ],
    type: 'مساحة عمل',
    amenities: ['إنترنت ألياف ضوئية', 'قاعات اجتماعات ذكية', 'مقهى مجاني', 'طباعة وتصوير', 'خزائن شخصية'],
    features: ['دخول 24/7', 'حجز فوري'],
    isPopular: true,
    host: { name: 'Damascus Hub', isSuperhost: true, avatar: 'https://i.pravatar.cc/150?u=b1' }
  }
];
