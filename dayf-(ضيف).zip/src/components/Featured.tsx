import React from 'react';
import { Link } from 'react-router-dom';
import { Star, MapPin, Heart } from 'lucide-react';
import { motion } from 'motion/react';

const FEATURED = [
  {
    id: 1,
    title: 'فندق الياسمين الدمشقي',
    location: 'دمشق القديمة',
    price: 120,
    rating: 4.9,
    reviews: 128,
    image: 'https://images.unsplash.com/photo-1566073771259-6a8506099945?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
    type: 'فندق 5 نجوم'
  },
  {
    id: 2,
    title: 'شقة فاخرة بإطلالة بحرية',
    location: 'اللاذقية، الكورنيش',
    price: 85,
    rating: 4.8,
    reviews: 94,
    image: 'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
    type: 'شقة فندقية'
  },
  {
    id: 3,
    title: 'منتجع الجبل الأخضر',
    location: 'صلنفة',
    price: 150,
    rating: 4.7,
    reviews: 215,
    image: 'https://images.unsplash.com/photo-1582719478250-c89fae4658c0?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
    type: 'منتجع سياحي'
  }
];

export default function Featured() {
  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:justify-between md:items-end gap-4 mb-12">
          <div className="flex-1 min-w-0">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4 leading-tight truncate">إقامات مميزة</h2>
            <p className="text-lg text-gray-600 max-w-2xl leading-relaxed line-clamp-2 md:line-clamp-none">
              أفضل الأماكن للإقامة الموصى بها من قبل ضيوفنا
            </p>
          </div>
          <Link to="/category/tourism" className="hidden md:inline-flex shrink-0 items-center text-emerald-600 font-semibold hover:text-emerald-700 transition-colors">
            عرض الكل
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {FEATURED.map((item, index) => (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="group bg-white rounded-3xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 border border-gray-100 flex flex-col"
            >
              <Link to={`/listing/${item.id}`} className="relative h-64 overflow-hidden block shrink-0">
                <img 
                  src={item.image} 
                  alt={item.title} 
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  referrerPolicy="no-referrer"
                />
                <button 
                  onClick={(e) => e.preventDefault()}
                  className="absolute top-4 left-4 p-2 bg-white/80 backdrop-blur-sm rounded-full text-gray-600 hover:text-red-500 hover:bg-white transition-colors z-10"
                >
                  <Heart className="w-5 h-5" />
                </button>
                <div className="absolute top-4 right-4 px-3 py-1 bg-white/90 backdrop-blur-sm rounded-full text-sm font-semibold text-gray-900 shadow-sm">
                  {item.type}
                </div>
              </Link>
              
              <div className="p-6 flex-1 flex flex-col min-w-0">
                <div className="flex justify-between items-start mb-4 gap-2">
                  <div className="flex-1 min-w-0">
                    <Link to={`/listing/${item.id}`}>
                      <h3 className="text-xl font-bold text-gray-900 mb-2 truncate hover:text-emerald-600 transition-colors">{item.title}</h3>
                    </Link>
                    <div className="flex items-center text-gray-500 text-sm">
                      <MapPin className="w-4 h-4 mr-1 ml-1 shrink-0" />
                      <span className="truncate">{item.location}</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-1 bg-emerald-50 px-2 py-1 rounded-lg shrink-0">
                    <Star className="w-4 h-4 text-emerald-500 fill-emerald-500" />
                    <span className="font-bold text-emerald-700">{item.rating}</span>
                    <span className="text-emerald-600/60 text-xs">({item.reviews})</span>
                  </div>
                </div>

                <div className="pt-4 border-t border-gray-100 flex justify-between items-center mt-auto gap-4">
                  <div className="text-gray-900 shrink-0">
                    <span className="text-2xl font-bold">${item.price}</span>
                    <span className="text-gray-500 text-sm"> / ليلة</span>
                  </div>
                  <Link to={`/listing/${item.id}`} className="bg-gray-900 text-white px-6 py-2 rounded-xl font-medium hover:bg-emerald-600 transition-colors shrink-0">
                    احجز الآن
                  </Link>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
        
        <div className="mt-8 text-center md:hidden">
          <Link to="/category/tourism" className="inline-flex items-center text-emerald-600 font-semibold hover:text-emerald-700 transition-colors">
            عرض الكل
          </Link>
        </div>
      </div>
    </section>
  );
}
