import React, { useState } from 'react';
import { Search, MapPin, Calendar, Users, Briefcase, Stethoscope, GraduationCap, Plane, Sparkles } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useNavigate } from 'react-router-dom';

const TABS = [
  { id: 'tourism', label: 'السياحة', icon: Plane },
  { id: 'medical', label: 'العلاج', icon: Stethoscope },
  { id: 'education', label: 'الدراسة', icon: GraduationCap },
  { id: 'business', label: 'الأعمال', icon: Briefcase },
  { id: 'ai', label: 'بحث ذكي', icon: Sparkles },
];

export default function Hero() {
  const [activeTab, setActiveTab] = useState('tourism');
  const [aiQuery, setAiQuery] = useState('');
  const navigate = useNavigate();

  const handleAISearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!aiQuery.trim()) return;
    // We can default to tourism category for AI search, or a global search if we had one.
    // Let's redirect to tourism category with the ai_query param.
    navigate(`/category/tourism?ai_query=${encodeURIComponent(aiQuery)}`);
  };

  return (
    <div className="relative pt-32 pb-20 lg:pt-48 lg:pb-32 overflow-hidden">
      {/* Background Image & Overlay */}
      <div className="absolute inset-0 z-0">
        <img
          src="https://images.unsplash.com/photo-1585076641394-6302f23b7b65?ixlib=rb-4.0.3&auto=format&fit=crop&w=2000&q=80"
          alt="Syria Landscape"
          className="w-full h-full object-cover"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/40 to-white"></div>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <motion.h1 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-4xl md:text-6xl font-bold text-white mb-6 tracking-tight"
        >
          اكتشف سحر سوريا مع <span className="text-emerald-400">ضيف</span>
        </motion.h1>
        
        <motion.p 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="text-lg md:text-2xl text-gray-200 mb-12 max-w-3xl mx-auto font-medium"
        >
          منصة متكاملة للسياحة، العلاج، الدراسة، وفرص الأعمال. خطط لرحلتك القادمة بكل سهولة وأمان.
        </motion.p>

        {/* Search Widget */}
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="bg-white rounded-3xl shadow-2xl p-4 md:p-6 max-w-5xl mx-auto relative overflow-hidden"
        >
          {activeTab === 'ai' && (
            <div className="absolute inset-0 bg-gradient-to-r from-emerald-50 via-teal-50 to-emerald-50 opacity-50 pointer-events-none"></div>
          )}
          
          {/* Tabs */}
          <div className="flex overflow-x-auto pb-4 mb-4 border-b border-gray-100 gap-2 md:gap-8 justify-start md:justify-center hide-scrollbar relative z-10">
            {TABS.map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              const isAI = tab.id === 'ai';
              
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center gap-2 px-4 py-2 rounded-full whitespace-nowrap transition-all shrink-0 ${
                    isActive 
                      ? isAI ? 'bg-gradient-to-r from-emerald-500 to-teal-500 text-white font-bold shadow-md' : 'bg-emerald-100 text-emerald-700 font-bold' 
                      : 'text-gray-500 hover:text-gray-900 hover:bg-gray-50 font-medium'
                  }`}
                >
                  <Icon className={`w-5 h-5 ${isActive && !isAI ? 'text-emerald-600' : ''} ${isAI && !isActive ? 'text-emerald-500' : ''}`} />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>

          {/* Search Fields */}
          <div className="relative z-10">
            <AnimatePresence mode="wait">
              {activeTab === 'ai' ? (
                <motion.form 
                  key="ai-search"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  onSubmit={handleAISearch}
                  className="flex flex-col md:flex-row gap-4 items-center"
                >
                  <div className="flex-1 w-full flex items-center gap-3 p-4 border-2 border-emerald-200 rounded-xl bg-white focus-within:border-emerald-500 focus-within:ring-4 focus-within:ring-emerald-50 transition-all shadow-inner">
                    <Sparkles className="w-6 h-6 text-emerald-500 animate-pulse" />
                    <input 
                      type="text" 
                      value={aiQuery}
                      onChange={(e) => setAiQuery(e.target.value)}
                      placeholder="مثال: أريد فندق رخيص في دمشق القديمة مع مسبح وواي فاي..." 
                      className="w-full bg-transparent outline-none text-gray-900 font-medium placeholder-gray-400 text-lg"
                      dir="rtl"
                    />
                  </div>
                  <button 
                    type="submit"
                    disabled={!aiQuery.trim()}
                    className="w-full md:w-auto bg-gradient-to-r from-emerald-600 to-teal-600 text-white px-8 py-4 rounded-xl hover:from-emerald-700 hover:to-teal-700 transition-all flex items-center justify-center gap-2 font-bold text-lg disabled:opacity-50 shadow-md"
                  >
                    <Sparkles className="w-5 h-5" />
                    <span>ابحث بذكاء</span>
                  </button>
                </motion.form>
              ) : (
                <motion.div 
                  key="normal-search"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className="grid grid-cols-1 md:grid-cols-4 gap-4 items-center"
                >
                  <div className="flex items-center gap-3 p-3 border border-gray-200 rounded-xl hover:border-emerald-500 transition-colors cursor-text bg-white">
                    <MapPin className="w-5 h-5 text-emerald-600" />
                    <div className="flex flex-col text-right w-full">
                      <span className="text-xs text-gray-500 font-medium">الوجهة</span>
                      <input 
                        type="text" 
                        placeholder="إلى أين تريد الذهاب؟" 
                        className="w-full bg-transparent outline-none text-gray-900 font-medium placeholder-gray-400"
                      />
                    </div>
                  </div>

                  <div className="flex items-center gap-3 p-3 border border-gray-200 rounded-xl hover:border-emerald-500 transition-colors cursor-pointer bg-white">
                    <Calendar className="w-5 h-5 text-emerald-600" />
                    <div className="flex flex-col text-right w-full">
                      <span className="text-xs text-gray-500 font-medium">التاريخ</span>
                      <span className="text-gray-400 font-medium">أضف التواريخ</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 p-3 border border-gray-200 rounded-xl hover:border-emerald-500 transition-colors cursor-pointer bg-white">
                    <Users className="w-5 h-5 text-emerald-600" />
                    <div className="flex flex-col text-right w-full">
                      <span className="text-xs text-gray-500 font-medium">الضيوف</span>
                      <span className="text-gray-400 font-medium">أضف الضيوف</span>
                    </div>
                  </div>

                  <button 
                    onClick={() => navigate(`/category/${activeTab}`)}
                    className="bg-emerald-600 text-white p-4 rounded-xl hover:bg-emerald-700 transition-colors flex items-center justify-center gap-2 font-bold text-lg h-full shadow-md"
                  >
                    <Search className="w-5 h-5" />
                    <span>بحث</span>
                  </button>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
