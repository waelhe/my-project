import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Menu, Search, User, Globe, MessageSquare, LogOut } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

export default function Navbar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { user, userProfile, signInWithGoogle, logout } = useAuth();
  const isProvider = userProfile?.role === 'provider' || userProfile?.role === 'admin';

  return (
    <nav className="fixed top-0 left-0 right-0 bg-white/90 backdrop-blur-md z-50 border-b border-gray-100 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <Link to="/" className="flex-shrink-0 flex items-center gap-2 hover:opacity-90 transition-opacity">
            <div className="w-10 h-10 bg-emerald-600 rounded-xl flex items-center justify-center text-white font-bold text-xl">
              ض
            </div>
            <span className="font-bold text-2xl text-gray-900 tracking-tight">ضيف</span>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8 space-x-reverse">
            <Link to="/category/tourism" className="text-gray-700 hover:text-emerald-600 font-medium transition-colors">السياحة</Link>
            <Link to="/category/medical" className="text-gray-700 hover:text-emerald-600 font-medium transition-colors">العلاج</Link>
            <Link to="/category/education" className="text-gray-700 hover:text-emerald-600 font-medium transition-colors">الدراسة</Link>
            <Link to="/category/business" className="text-gray-700 hover:text-emerald-600 font-medium transition-colors">الأعمال</Link>
          </div>

          {/* Right Actions */}
          <div className="hidden md:flex items-center space-x-4 space-x-reverse">
            <button className="p-2 text-gray-500 hover:text-emerald-600 transition-colors">
              <Globe className="w-5 h-5" />
            </button>
            <button className="p-2 text-gray-500 hover:text-emerald-600 transition-colors">
              <MessageSquare className="w-5 h-5" />
            </button>
            
            {user ? (
              <div className="flex items-center gap-4">
                {isProvider && (
                  <Link to="/provider" className="text-emerald-600 hover:text-emerald-700 font-bold transition-colors">لوحة التحكم</Link>
                )}
                <Link to="/my-bookings" className="text-gray-700 hover:text-emerald-600 font-medium transition-colors">حجوزاتي</Link>
                <Link to="/profile" className="flex items-center gap-2 hover:opacity-80 transition-all">
                  {user.photoURL ? (
                    <img src={user.photoURL} alt={user.displayName || 'User'} className="w-8 h-8 rounded-full border border-gray-200" />
                  ) : (
                    <div className="w-8 h-8 rounded-full bg-emerald-100 flex items-center justify-center text-emerald-700 font-bold">
                      {user.displayName?.charAt(0) || user.email?.charAt(0) || 'U'}
                    </div>
                  )}
                  <span className="text-sm font-medium text-gray-700 hidden lg:block">{user.displayName || 'مستخدم'}</span>
                </Link>
                <button 
                  onClick={logout}
                  className="p-2 text-gray-500 hover:text-red-600 transition-colors"
                  title="تسجيل الخروج"
                >
                  <LogOut className="w-5 h-5" />
                </button>
              </div>
            ) : (
              <button 
                onClick={signInWithGoogle}
                className="flex items-center gap-2 bg-emerald-600 text-white px-4 py-2 rounded-full hover:bg-emerald-700 transition-colors font-medium"
              >
                <User className="w-4 h-4" />
                <span>تسجيل الدخول</span>
              </button>
            )}
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden flex items-center">
            <button 
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="p-2 text-gray-600 hover:text-emerald-600 focus:outline-none"
            >
              <Menu className="w-6 h-6" />
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="md:hidden bg-white border-t border-gray-100 px-4 pt-2 pb-4 space-y-1 shadow-lg">
          <Link to="/category/tourism" onClick={() => setIsMenuOpen(false)} className="block px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:text-emerald-600 hover:bg-emerald-50">السياحة</Link>
          <Link to="/category/medical" onClick={() => setIsMenuOpen(false)} className="block px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:text-emerald-600 hover:bg-emerald-50">العلاج</Link>
          <Link to="/category/education" onClick={() => setIsMenuOpen(false)} className="block px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:text-emerald-600 hover:bg-emerald-50">الدراسة</Link>
          <Link to="/category/business" onClick={() => setIsMenuOpen(false)} className="block px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:text-emerald-600 hover:bg-emerald-50">الأعمال</Link>
          <div className="mt-4 pt-4 border-t border-gray-100 flex flex-col gap-2">
            {user ? (
              <>
                {isProvider && (
                  <Link to="/provider" onClick={() => setIsMenuOpen(false)} className="block px-3 py-2 rounded-md text-base font-bold text-emerald-600 hover:bg-emerald-50">لوحة التحكم</Link>
                )}
                <Link to="/my-bookings" onClick={() => setIsMenuOpen(false)} className="block px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:text-emerald-600 hover:bg-emerald-50">حجوزاتي</Link>
                <Link to="/profile" onClick={() => setIsMenuOpen(false)} className="flex items-center gap-3 px-3 py-2 hover:bg-gray-50 rounded-md transition-colors">
                  {user.photoURL ? (
                    <img src={user.photoURL} alt={user.displayName || 'User'} className="w-10 h-10 rounded-full border border-gray-200" />
                  ) : (
                    <div className="w-10 h-10 rounded-full bg-emerald-100 flex items-center justify-center text-emerald-700 font-bold text-lg">
                      {user.displayName?.charAt(0) || user.email?.charAt(0) || 'U'}
                    </div>
                  )}
                  <div className="flex flex-col">
                    <span className="font-medium text-gray-900">{user.displayName || 'مستخدم'}</span>
                    <span className="text-xs text-gray-500">{user.email}</span>
                  </div>
                </Link>
                <button 
                  onClick={() => { logout(); setIsMenuOpen(false); }}
                  className="w-full flex items-center justify-center gap-2 bg-red-50 text-red-600 px-4 py-2 rounded-lg font-medium hover:bg-red-100 transition-colors mt-2"
                >
                  <LogOut className="w-4 h-4" />
                  <span>تسجيل الخروج</span>
                </button>
              </>
            ) : (
              <button 
                onClick={() => { signInWithGoogle(); setIsMenuOpen(false); }}
                className="w-full flex items-center justify-center gap-2 bg-emerald-600 text-white px-4 py-2 rounded-lg font-medium"
              >
                <User className="w-4 h-4" />
                <span>تسجيل الدخول</span>
              </button>
            )}
          </div>
        </div>
      )}
    </nav>
  );
}
