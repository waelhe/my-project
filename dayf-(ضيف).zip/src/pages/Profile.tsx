import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { db } from '../firebase';
import { doc, updateDoc, collection, query, where, getDocs, deleteDoc } from 'firebase/firestore';
import { User, Mail, Camera, Save, Loader2, Heart, MapPin, Star, Trash2, ExternalLink } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Link } from 'react-router-dom';
import { Service, getServiceById } from '../services/serviceService';

export default function Profile() {
  const { user, userProfile, loading } = useAuth();
  const [isEditing, setIsEditing] = useState(false);
  const [displayName, setDisplayName] = useState('');
  const [photoURL, setPhotoURL] = useState('');
  const [isSaving, setIsSaving] = useState(false);
  const [favorites, setFavorites] = useState<Service[]>([]);
  const [loadingFavorites, setLoadingFavorites] = useState(true);
  const [activeTab, setActiveTab] = useState<'info' | 'favorites'>('info');

  useEffect(() => {
    if (userProfile) {
      setDisplayName(userProfile.displayName || '');
      setPhotoURL(userProfile.photoURL || '');
    }
  }, [userProfile]);

  useEffect(() => {
    const fetchFavorites = async () => {
      if (!user) return;
      setLoadingFavorites(true);
      try {
        const q = query(collection(db, 'favorites'), where('userId', '==', user.uid));
        const querySnapshot = await getDocs(q);
        const serviceIds = querySnapshot.docs.map(doc => doc.data().serviceId);
        
        const servicesData: Service[] = [];
        for (const id of serviceIds) {
          const service = await getServiceById(id);
          if (service) servicesData.push(service);
        }
        setFavorites(servicesData);
      } catch (error) {
        console.error("Error fetching favorites:", error);
      } finally {
        setLoadingFavorites(false);
      }
    };

    if (activeTab === 'favorites') {
      fetchFavorites();
    }
  }, [user, activeTab]);

  const handleUpdateProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;

    setIsSaving(true);
    try {
      await updateDoc(doc(db, 'users', user.uid), {
        displayName,
        photoURL
      });
      setIsEditing(false);
      // Note: AuthContext will pick up changes on next reload or we could manually update local state if needed
      // For now, reload is simplest to ensure consistency
      window.location.reload();
    } catch (error) {
      console.error("Error updating profile:", error);
      alert('فشل في تحديث الملف الشخصي.');
    } finally {
      setIsSaving(false);
    }
  };

  const removeFavorite = async (serviceId: string) => {
    if (!user) return;
    try {
      const q = query(
        collection(db, 'favorites'), 
        where('userId', '==', user.uid),
        where('serviceId', '==', serviceId)
      );
      const querySnapshot = await getDocs(q);
      querySnapshot.forEach(async (document) => {
        await deleteDoc(doc(db, 'favorites', document.id));
      });
      setFavorites(prev => prev.filter(s => s.id !== serviceId));
    } catch (error) {
      console.error("Error removing favorite:", error);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-10 h-10 animate-spin text-emerald-600" />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="pt-32 pb-20 max-w-7xl mx-auto px-4 text-center">
        <div className="bg-white p-12 rounded-3xl shadow-sm border border-gray-100 max-w-md mx-auto">
          <User className="w-16 h-16 text-gray-300 mx-auto mb-6" />
          <h2 className="text-2xl font-bold text-gray-900 mb-4">يرجى تسجيل الدخول</h2>
          <p className="text-gray-600 mb-8">يجب عليك تسجيل الدخول للوصول إلى ملفك الشخصي.</p>
          <Link to="/" className="inline-block bg-emerald-600 text-white px-8 py-3 rounded-xl font-bold hover:bg-emerald-700 transition-colors">
            العودة للرئيسية
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="pt-24 pb-20 min-h-screen bg-gray-50">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Profile Header Card */}
        <div className="bg-white rounded-3xl shadow-sm border border-gray-100 overflow-hidden mb-8">
          <div className="h-32 bg-emerald-600 relative">
            <div className="absolute -bottom-12 right-8">
              <div className="relative">
                {userProfile?.photoURL ? (
                  <img 
                    src={userProfile.photoURL} 
                    alt={userProfile.displayName || 'User'} 
                    className="w-24 h-24 rounded-2xl border-4 border-white shadow-md object-cover"
                  />
                ) : (
                  <div className="w-24 h-24 rounded-2xl border-4 border-white shadow-md bg-emerald-100 flex items-center justify-center text-emerald-700 font-bold text-3xl">
                    {userProfile?.displayName?.charAt(0) || user.email?.charAt(0) || 'U'}
                  </div>
                )}
                {isEditing && (
                  <button className="absolute -bottom-2 -left-2 p-2 bg-white rounded-full shadow-lg border border-gray-100 text-emerald-600 hover:text-emerald-700">
                    <Camera className="w-4 h-4" />
                  </button>
                )}
              </div>
            </div>
          </div>
          <div className="pt-16 pb-8 px-8 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">{userProfile?.displayName || 'مستخدم ضيف'}</h1>
              <p className="text-gray-500 flex items-center gap-1 mt-1">
                <Mail className="w-4 h-4" />
                {user.email}
              </p>
              <div className="mt-3 flex items-center gap-2">
                <span className={`px-3 py-1 rounded-full text-xs font-bold ${
                  userProfile?.role === 'admin' ? 'bg-purple-100 text-purple-700' :
                  userProfile?.role === 'provider' ? 'bg-blue-100 text-blue-700' :
                  'bg-gray-100 text-gray-700'
                }`}>
                  {userProfile?.role === 'admin' ? 'مسؤول النظام' :
                   userProfile?.role === 'provider' ? 'مزود خدمة' :
                   'مستخدم'}
                </span>
              </div>
            </div>
            <button
              onClick={() => setIsEditing(!isEditing)}
              className={`px-6 py-2 rounded-xl font-bold transition-all ${
                isEditing ? 'bg-gray-100 text-gray-600 hover:bg-gray-200' : 'bg-emerald-600 text-white hover:bg-emerald-700'
              }`}
            >
              {isEditing ? 'إلغاء التعديل' : 'تعديل الملف الشخصي'}
            </button>
          </div>
        </div>

        {/* Tabs Navigation */}
        <div className="flex gap-4 mb-8 border-b border-gray-200">
          <button
            onClick={() => setActiveTab('info')}
            className={`pb-4 px-2 font-bold text-sm transition-all relative ${
              activeTab === 'info' ? 'text-emerald-600' : 'text-gray-500 hover:text-gray-700'
            }`}
          >
            المعلومات الشخصية
            {activeTab === 'info' && <motion.div layoutId="tab-underline" className="absolute bottom-0 left-0 right-0 h-1 bg-emerald-600 rounded-t-full" />}
          </button>
          <button
            onClick={() => setActiveTab('favorites')}
            className={`pb-4 px-2 font-bold text-sm transition-all relative ${
              activeTab === 'favorites' ? 'text-emerald-600' : 'text-gray-500 hover:text-gray-700'
            }`}
          >
            المفضلات ({favorites.length})
            {activeTab === 'favorites' && <motion.div layoutId="tab-underline" className="absolute bottom-0 left-0 right-0 h-1 bg-emerald-600 rounded-t-full" />}
          </button>
        </div>

        {/* Tab Content */}
        <AnimatePresence mode="wait">
          {activeTab === 'info' && (
            <motion.div
              key="info"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="bg-white rounded-3xl shadow-sm border border-gray-100 p-8"
            >
              <form onSubmit={handleUpdateProfile} className="max-w-2xl space-y-6">
                <div className="space-y-2">
                  <label className="text-sm font-bold text-gray-700">الاسم الكامل</label>
                  <div className="relative">
                    <User className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <input
                      type="text"
                      disabled={!isEditing}
                      value={displayName}
                      onChange={(e) => setDisplayName(e.target.value)}
                      className="w-full bg-gray-50 border border-gray-200 rounded-xl py-3 pr-12 pl-4 focus:outline-none focus:border-emerald-500 disabled:opacity-60 transition-all"
                      placeholder="أدخل اسمك الكامل"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-bold text-gray-700">رابط الصورة الشخصية</label>
                  <div className="relative">
                    <Camera className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <input
                      type="text"
                      disabled={!isEditing}
                      value={photoURL}
                      onChange={(e) => setPhotoURL(e.target.value)}
                      className="w-full bg-gray-50 border border-gray-200 rounded-xl py-3 pr-12 pl-4 focus:outline-none focus:border-emerald-500 disabled:opacity-60 transition-all"
                      placeholder="https://..."
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-bold text-gray-700">البريد الإلكتروني (لا يمكن تغييره)</label>
                  <div className="relative">
                    <Mail className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <input
                      type="email"
                      disabled
                      value={user.email || ''}
                      className="w-full bg-gray-100 border border-gray-200 rounded-xl py-3 pr-12 pl-4 text-gray-500"
                    />
                  </div>
                </div>

                {isEditing && (
                  <button
                    type="submit"
                    disabled={isSaving}
                    className="bg-emerald-600 text-white px-8 py-3 rounded-xl font-bold hover:bg-emerald-700 transition-all flex items-center gap-2 shadow-lg shadow-emerald-100 disabled:opacity-50"
                  >
                    {isSaving ? <Loader2 className="w-5 h-5 animate-spin" /> : <Save className="w-5 h-5" />}
                    <span>حفظ التغييرات</span>
                  </button>
                )}
              </form>
            </motion.div>
          )}

          {activeTab === 'favorites' && (
            <motion.div
              key="favorites"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-6"
            >
              {loadingFavorites ? (
                <div className="flex justify-center py-20">
                  <Loader2 className="w-10 h-10 animate-spin text-emerald-600" />
                </div>
              ) : favorites.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {favorites.map((service) => (
                    <div key={service.id} className="bg-white rounded-3xl shadow-sm border border-gray-100 overflow-hidden group hover:shadow-md transition-all">
                      <div className="flex h-40">
                        <div className="w-1/3 relative">
                          <img 
                            src={service.images[0]} 
                            alt={service.title} 
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <div className="w-2/3 p-4 flex flex-col justify-between">
                          <div>
                            <div className="flex justify-between items-start">
                              <h4 className="font-bold text-gray-900 line-clamp-1">{service.title}</h4>
                              <button 
                                onClick={() => removeFavorite(service.id)}
                                className="p-1.5 text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                            <p className="text-xs text-gray-500 flex items-center gap-1 mt-1">
                              <MapPin className="w-3 h-3" />
                              {service.location}
                            </p>
                            <div className="flex items-center gap-1 mt-2">
                              <Star className="w-3 h-3 text-amber-400 fill-amber-400" />
                              <span className="text-xs font-bold text-gray-900">{service.rating}</span>
                            </div>
                          </div>
                          <div className="flex justify-between items-center">
                            <span className="font-bold text-emerald-600">${service.price}</span>
                            <Link 
                              to={`/listing/${service.id}`}
                              className="text-xs font-bold text-gray-400 hover:text-emerald-600 flex items-center gap-1"
                            >
                              عرض
                              <ExternalLink className="w-3 h-3" />
                            </Link>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="bg-white rounded-3xl border border-gray-100 p-20 text-center">
                  <Heart className="w-16 h-16 text-gray-200 mx-auto mb-6" />
                  <h3 className="text-xl font-bold text-gray-900 mb-2">لا توجد مفضلات بعد</h3>
                  <p className="text-gray-500 mb-8">ابدأ باستكشاف الخدمات وأضف ما يعجبك إلى قائمتك المفضلة.</p>
                  <Link to="/" className="inline-block bg-emerald-600 text-white px-8 py-3 rounded-xl font-bold hover:bg-emerald-700 transition-colors">
                    استكشف الخدمات
                  </Link>
                </div>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
