import React, { useState, useMemo, useEffect } from 'react';
import { useParams, Link, useNavigate, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronRight, Filter, Search, Map, SlidersHorizontal, ChevronDown, List, Star, Check, Sparkles, Loader2 } from 'lucide-react';
import { MAIN_CATEGORIES } from '../data/categories';
import ServiceCard from '../components/ServiceCard';
import { GoogleGenAI } from '@google/genai';
import { getServicesByCategory, seedServices, Service } from '../services/serviceService';
import { useAuth } from '../contexts/AuthContext';

const ai = new GoogleGenAI({ apiKey: import.meta.env.VITE_GEMINI_API_KEY || process.env.GEMINI_API_KEY || '' });

export default function CategoryPage() {
  const { categoryId } = useParams();
  const navigate = useNavigate();
  const location = useLocation();
  const { user } = useAuth();
  
  // State
  const [services, setServices] = useState<Service[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeSubCategory, setActiveSubCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState('recommended');
  const [maxPrice, setMaxPrice] = useState<number>(1000);
  const [showFilters, setShowFilters] = useState(false);
  const [viewMode, setViewMode] = useState<'grid' | 'map'>('grid');
  
  // Advanced Filters State
  const [selectedAmenities, setSelectedAmenities] = useState<string[]>([]);
  const [minRating, setMinRating] = useState<number>(0);
  const [selectedTypes, setSelectedTypes] = useState<string[]>([]);

  // AI Search State
  const [isAILoading, setIsAILoading] = useState(false);
  const [aiRecommendedIds, setAiRecommendedIds] = useState<string[] | null>(null);
  const [aiExplanation, setAiExplanation] = useState<string | null>(null);

  const category = MAIN_CATEGORIES.find(c => c.id === categoryId);

  // Fetch services from Firestore
  useEffect(() => {
    const fetchServices = async () => {
      if (!categoryId) return;
      setLoading(true);
      try {
        // Seed if first time and user is logged in
        if (user) {
          await seedServices(user.uid);
        }
        const data = await getServicesByCategory(categoryId);
        setServices(data);
      } catch (error) {
        console.error("Error fetching services:", error);
      } finally {
        setLoading(false);
      }
    };
    fetchServices();
  }, [categoryId, user]);

  // Read subcategory and AI query from URL query params
  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const sub = params.get('sub');
    const aiQuery = params.get('ai_query');

    if (sub && category?.subCategories.some(s => s.id === sub)) {
      setActiveSubCategory(sub);
    } else {
      setActiveSubCategory('all');
    }

    if (aiQuery && services.length > 0) {
      performAISearch(aiQuery);
    } else {
      setAiRecommendedIds(null);
      setAiExplanation(null);
    }
  }, [location.search, category, services.length]);

  const performAISearch = async (query: string) => {
    setIsAILoading(true);
    setAiRecommendedIds(null);
    setAiExplanation(null);
    
    try {
      const servicesContext = services.map(s => 
        `ID: ${s.id} | Title: ${s.title} | Location: ${s.location} | Price: $${s.price} | Rating: ${s.rating} | Type: ${s.type} | Amenities: ${s.amenities?.join(',')}`
      ).join('\n');

      const prompt = `
أنت مساعد بحث ذكي لمنصة "ضيف". يبحث المستخدم عن: "${query}".
إليك قائمة بالخدمات المتاحة في هذا القسم:
${servicesContext}

بناءً على طلب المستخدم، اختر أفضل الخدمات المطابقة.
يجب أن يكون ردك بصيغة JSON فقط، يحتوي على مصفوفتين:
1. "recommendedIds": مصفوفة تحتوي على معرفات (IDs) الخدمات المطابقة (نصوص).
2. "explanation": نص قصير باللغة العربية يشرح سبب اختيارك لهذه الخدمات.

مثال للرد:
{
  "recommendedIds": ["1", "3"],
  "explanation": "لقد وجدت لك بعض الفنادق الرخيصة في دمشق القديمة التي تناسب ميزانيتك."
}
`;

      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: prompt,
        config: {
          responseMimeType: 'application/json',
        }
      });

      const result = JSON.parse(response.text || '{}');
      if (result.recommendedIds && Array.isArray(result.recommendedIds)) {
        setAiRecommendedIds(result.recommendedIds);
        setAiExplanation(result.explanation || 'تم العثور على هذه النتائج بناءً على طلبك.');
      }
    } catch (error) {
      console.error('AI Search Error:', error);
      setAiExplanation('عذراً، حدث خطأ أثناء معالجة طلبك الذكي. نعرض لك جميع النتائج.');
    } finally {
      setIsAILoading(false);
    }
  };

  // Redirect if not found
  if (!category) {
    navigate('/');
    return null;
  }

  // Derived styling classes
  const colorClasses = {
    emerald: 'bg-emerald-600 text-white',
    blue: 'bg-blue-600 text-white',
    amber: 'bg-amber-500 text-white',
    purple: 'bg-purple-600 text-white',
  };

  const textClasses = {
    emerald: 'text-emerald-600',
    blue: 'text-blue-600',
    amber: 'text-amber-600',
    purple: 'text-purple-600',
  };

  const bgLightClasses = {
    emerald: 'bg-emerald-50',
    blue: 'bg-blue-50',
    amber: 'bg-amber-50',
    purple: 'bg-purple-50',
  };

  const borderClasses = {
    emerald: 'border-emerald-600',
    blue: 'border-blue-600',
    amber: 'border-amber-500',
    purple: 'border-purple-600',
  };

  const activeColorClass = colorClasses[category.color as keyof typeof colorClasses];
  const activeTextClass = textClasses[category.color as keyof typeof textClasses];
  const activeBgLightClass = bgLightClasses[category.color as keyof typeof bgLightClasses];
  const activeBorderClass = borderClasses[category.color as keyof typeof borderClasses];

  // Extract unique amenities and types for filters based on current category
  const { availableAmenities, availableTypes } = useMemo(() => {
    const amenities = new Set<string>();
    const types = new Set<string>();
    services.forEach(s => {
      s.amenities?.forEach(a => amenities.add(a));
      if (s.type) types.add(s.type);
    });
    return {
      availableAmenities: Array.from(amenities),
      availableTypes: Array.from(types)
    };
  }, [services]);

  // Filtering & Sorting Logic
  const filteredAndSortedServices = useMemo(() => {
    let result = services.filter(service => {
      const matchesMain = service.mainCategoryId === category.id;
      
      if (aiRecommendedIds) {
        return matchesMain && aiRecommendedIds.includes(service.id);
      }

      const matchesSub = activeSubCategory === 'all' || service.subCategoryId === activeSubCategory;
      const matchesSearch = service.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                            service.location.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesPrice = service.price <= maxPrice;
      const matchesRating = service.rating >= minRating;
      
      const matchesAmenities = selectedAmenities.length === 0 || 
        selectedAmenities.every(amenity => service.amenities?.includes(amenity));
        
      const matchesTypes = selectedTypes.length === 0 || 
        selectedTypes.includes(service.type);
      
      return matchesMain && matchesSub && matchesSearch && matchesPrice && matchesRating && matchesAmenities && matchesTypes;
    });

    switch (sortBy) {
      case 'price-asc':
        result.sort((a, b) => a.price - b.price);
        break;
      case 'price-desc':
        result.sort((a, b) => b.price - a.price);
        break;
      case 'rating-desc':
        result.sort((a, b) => b.rating - a.rating);
        break;
      case 'recommended':
      default:
        result.sort((a, b) => {
          if (a.isPopular && !b.isPopular) return -1;
          if (!a.isPopular && b.isPopular) return 1;
          return b.rating - a.rating;
        });
        break;
    }

    return result;
  }, [services, category.id, activeSubCategory, searchQuery, maxPrice, sortBy, minRating, selectedAmenities, selectedTypes, aiRecommendedIds]);

  const toggleAmenity = (amenity: string) => {
    setSelectedAmenities(prev => 
      prev.includes(amenity) ? prev.filter(a => a !== amenity) : [...prev, amenity]
    );
  };

  const toggleType = (type: string) => {
    setSelectedTypes(prev => 
      prev.includes(type) ? prev.filter(t => t !== type) : [...prev, type]
    );
  };

  const clearFilters = () => {
    setMaxPrice(1000);
    setSearchQuery('');
    setMinRating(0);
    setSelectedAmenities([]);
    setSelectedTypes([]);
  };

  const handleSubCategoryClick = (subId: string) => {
    setActiveSubCategory(subId);
    // Update URL without full page reload
    const newUrl = subId === 'all' ? `/category/${category.id}` : `/category/${category.id}?sub=${subId}`;
    window.history.pushState({}, '', newUrl);
  };

  return (
    <div className="min-h-screen bg-gray-50 pt-16">
      {/* Sticky Top Bar (Subcategories & Search) */}
      <div className="sticky top-16 z-40 bg-white border-b border-gray-200 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
            
            {/* Sub-categories Tabs - Airbnb Style */}
            <div className="flex overflow-x-auto hide-scrollbar gap-6 pb-2 w-full md:w-auto flex-1">
              <button
                onClick={() => handleSubCategoryClick('all')}
                className={`flex flex-col items-center gap-2 min-w-[60px] pb-3 border-b-2 transition-all shrink-0 ${
                  activeSubCategory === 'all' 
                    ? `${activeBorderClass} ${activeTextClass}` 
                    : 'border-transparent text-gray-500 hover:text-gray-900 hover:border-gray-300'
                }`}
              >
                <div className="w-8 h-8 flex items-center justify-center bg-gray-100 rounded-full mb-1">
                  <category.icon className="w-4 h-4" />
                </div>
                <span className="text-sm font-medium whitespace-nowrap">الكل</span>
              </button>
              
              {category.subCategories.map((sub) => (
                <button
                  key={sub.id}
                  onClick={() => handleSubCategoryClick(sub.id)}
                  className={`flex flex-col items-center gap-2 min-w-[60px] pb-3 border-b-2 transition-all shrink-0 ${
                    activeSubCategory === sub.id 
                      ? `${activeBorderClass} ${activeTextClass}` 
                      : 'border-transparent text-gray-500 hover:text-gray-900 hover:border-gray-300'
                  }`}
                >
                  <div className="text-2xl mb-1 opacity-80">{sub.icon}</div>
                  <span className="text-sm font-medium whitespace-nowrap">{sub.name}</span>
                </button>
              ))}
            </div>

            {/* Search & Actions */}
            <div className="flex items-center gap-3 shrink-0">
              <div className="relative">
                <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <input 
                  type="text"
                  placeholder="ابحث عن وجهة أو خدمة..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-4 pr-10 py-2.5 bg-gray-50 border border-gray-200 rounded-full text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 w-full md:w-64 transition-all"
                />
              </div>
              <button 
                onClick={() => setShowFilters(!showFilters)}
                className={`lg:hidden flex items-center justify-center w-10 h-10 border rounded-full transition-colors ${showFilters ? activeColorClass : 'bg-white border-gray-200 text-gray-700 hover:bg-gray-50'}`}
              >
                <SlidersHorizontal className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        {/* Breadcrumbs & Title */}
        <div className="mb-8">
          <div className="flex items-center gap-2 text-sm text-gray-500 mb-4">
            <Link to="/" className="hover:text-gray-900 transition-colors">الرئيسية</Link>
            <ChevronRight className="w-4 h-4" />
            <span className="font-medium text-gray-900">{category.name}</span>
          </div>
          <div className="flex flex-col md:flex-row md:justify-between md:items-end gap-4">
            <div className="flex-1 min-w-0">
              <h1 className="text-3xl font-bold text-gray-900 mb-2 leading-tight truncate">{category.name} في سوريا</h1>
              <p className="text-gray-600 leading-relaxed line-clamp-2 md:line-clamp-none">{category.description}</p>
            </div>
            
            {/* View Mode Toggle */}
            <div className="flex items-center bg-white border border-gray-200 rounded-xl p-1 shrink-0 self-start md:self-auto shadow-sm">
              <button 
                onClick={() => setViewMode('grid')}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors ${viewMode === 'grid' ? 'bg-gray-100 text-gray-900' : 'text-gray-500 hover:text-gray-700'}`}
              >
                <List className="w-4 h-4" />
                <span>قائمة</span>
              </button>
              <button 
                onClick={() => setViewMode('map')}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors ${viewMode === 'map' ? 'bg-gray-100 text-gray-900' : 'text-gray-500 hover:text-gray-700'}`}
              >
                <Map className="w-4 h-4" />
                <span>خريطة</span>
              </button>
            </div>
          </div>
        </div>

        <div className="flex flex-col lg:flex-row gap-8">
          
          {/* Sidebar Filters (Desktop & Mobile) */}
          <AnimatePresence>
            {(showFilters || window.innerWidth >= 1024) && (
              <motion.aside 
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
                className={`lg:w-1/4 shrink-0 ${showFilters ? 'block' : 'hidden lg:block'}`}
              >
                <div className="bg-white border border-gray-200 rounded-2xl p-6 sticky top-40 shadow-sm">
                  <div className="flex items-center justify-between mb-6 pb-4 border-b border-gray-100">
                    <h3 className="text-lg font-bold text-gray-900 flex items-center gap-2">
                      <Filter className="w-5 h-5" />
                      تصفية متقدمة
                    </h3>
                    {showFilters && (
                      <button onClick={() => setShowFilters(false)} className="lg:hidden text-sm text-gray-500 hover:text-gray-900">إغلاق</button>
                    )}
                  </div>

                  {/* Price Filter */}
                  <div className="mb-8">
                    <h4 className="font-semibold text-gray-900 mb-4">نطاق السعر (لليلة)</h4>
                    <div className="flex items-center justify-between text-sm text-gray-600 mb-3">
                      <span>$0</span>
                      <span className={`font-bold ${activeTextClass}`}>${maxPrice}</span>
                    </div>
                    <input 
                      type="range" 
                      min="0" 
                      max="1000" 
                      step="10"
                      value={maxPrice}
                      onChange={(e) => setMaxPrice(Number(e.target.value))}
                      className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-emerald-600"
                    />
                  </div>

                  {/* Rating Filter */}
                  <div className="mb-8">
                    <h4 className="font-semibold text-gray-900 mb-4">تقييم الضيوف</h4>
                    <div className="space-y-2">
                      {[4, 3, 2].map((rating) => (
                        <label key={rating} className="flex items-center gap-3 cursor-pointer group">
                          <div className={`flex items-center justify-center w-5 h-5 border-2 rounded-md transition-colors ${minRating === rating ? 'border-emerald-500 bg-emerald-500' : 'border-gray-300 group-hover:border-emerald-500'}`}>
                            <input 
                              type="radio" 
                              name="rating" 
                              className="sr-only" 
                              checked={minRating === rating}
                              onChange={() => setMinRating(rating)}
                            />
                            {minRating === rating && <Check className="w-3.5 h-3.5 text-white" />}
                          </div>
                          <div className="flex items-center gap-1">
                            <Star className="w-4 h-4 text-amber-400 fill-current" />
                            <span className="text-gray-700 text-sm">{rating}+ نجوم</span>
                          </div>
                        </label>
                      ))}
                      <label className="flex items-center gap-3 cursor-pointer group">
                        <div className={`flex items-center justify-center w-5 h-5 border-2 rounded-md transition-colors ${minRating === 0 ? 'border-emerald-500 bg-emerald-500' : 'border-gray-300 group-hover:border-emerald-500'}`}>
                          <input 
                            type="radio" 
                            name="rating" 
                            className="sr-only" 
                            checked={minRating === 0}
                            onChange={() => setMinRating(0)}
                          />
                          {minRating === 0 && <Check className="w-3.5 h-3.5 text-white" />}
                        </div>
                        <span className="text-gray-700 text-sm">الكل</span>
                      </label>
                    </div>
                  </div>

                  {/* Property Type Filter */}
                  {availableTypes.length > 0 && (
                    <div className="mb-8">
                      <h4 className="font-semibold text-gray-900 mb-4">نوع المكان</h4>
                      <div className="space-y-3">
                        {availableTypes.map((type, idx) => (
                          <label key={idx} className="flex items-center gap-3 cursor-pointer group">
                            <div className={`flex items-center justify-center w-5 h-5 border-2 rounded-md transition-colors ${selectedTypes.includes(type) ? 'border-emerald-500 bg-emerald-500' : 'border-gray-300 group-hover:border-emerald-500'}`}>
                              <input 
                                type="checkbox" 
                                className="sr-only" 
                                checked={selectedTypes.includes(type)}
                                onChange={() => toggleType(type)}
                              />
                              {selectedTypes.includes(type) && <Check className="w-3.5 h-3.5 text-white" />}
                            </div>
                            <span className="text-gray-700 text-sm">{type}</span>
                          </label>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Amenities Filter */}
                  {availableAmenities.length > 0 && (
                    <div className="mb-8">
                      <h4 className="font-semibold text-gray-900 mb-4">المرافق والمميزات</h4>
                      <div className="space-y-3 max-h-48 overflow-y-auto pr-2 custom-scrollbar">
                        {availableAmenities.map((amenity, idx) => (
                          <label key={idx} className="flex items-center gap-3 cursor-pointer group">
                            <div className={`flex items-center justify-center w-5 h-5 border-2 rounded-md transition-colors ${selectedAmenities.includes(amenity) ? 'border-emerald-500 bg-emerald-500' : 'border-gray-300 group-hover:border-emerald-500'}`}>
                              <input 
                                type="checkbox" 
                                className="sr-only" 
                                checked={selectedAmenities.includes(amenity)}
                                onChange={() => toggleAmenity(amenity)}
                              />
                              {selectedAmenities.includes(amenity) && <Check className="w-3.5 h-3.5 text-white" />}
                            </div>
                            <span className="text-gray-700 text-sm">{amenity}</span>
                          </label>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Reset Button */}
                  <button 
                    onClick={clearFilters}
                    className="w-full py-3 text-sm font-bold text-gray-600 bg-gray-50 hover:bg-gray-100 rounded-xl transition-colors border border-gray-200"
                  >
                    مسح جميع الفلاتر
                  </button>
                </div>
              </motion.aside>
            )}
          </AnimatePresence>

          {/* Results Area */}
          <main className="flex-1 min-w-0">
            {loading && (
              <div className="w-full py-20 flex flex-col items-center justify-center text-gray-500">
                <Loader2 className="w-10 h-10 animate-spin mb-4 text-emerald-600" />
                <p className="text-lg font-medium">جاري تحميل الخدمات...</p>
              </div>
            )}

            {!loading && isAILoading && (
              <div className="w-full bg-emerald-50 border border-emerald-100 rounded-2xl p-6 mb-8 flex flex-col items-center justify-center text-emerald-700">
                <Loader2 className="w-8 h-8 animate-spin mb-4" />
                <h3 className="text-lg font-bold mb-2">الذكاء الاصطناعي يبحث لك...</h3>
                <p className="text-sm opacity-80">جاري تحليل طلبك والبحث عن أفضل الخيارات المناسبة.</p>
              </div>
            )}

            {!loading && !isAILoading && aiExplanation && (
              <motion.div 
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                className="w-full bg-gradient-to-r from-emerald-50 to-teal-50 border border-emerald-100 rounded-2xl p-6 mb-8 shadow-sm relative overflow-hidden"
              >
                <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/10 rounded-full blur-3xl -mr-10 -mt-10"></div>
                <div className="flex items-start gap-4 relative z-10">
                  <div className="w-12 h-12 bg-emerald-100 rounded-full flex items-center justify-center shrink-0">
                    <Sparkles className="w-6 h-6 text-emerald-600" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-gray-900 mb-2 flex items-center gap-2">
                      توصيات الذكاء الاصطناعي
                      <span className="text-xs bg-emerald-100 text-emerald-700 px-2 py-1 rounded-full font-medium">Gemini AI</span>
                    </h3>
                    <p className="text-gray-700 leading-relaxed text-sm md:text-base">{aiExplanation}</p>
                    <button 
                      onClick={() => {
                        setAiRecommendedIds(null);
                        setAiExplanation(null);
                        const newUrl = new URL(window.location.href);
                        newUrl.searchParams.delete('ai_query');
                        window.history.pushState({}, '', newUrl.toString());
                      }}
                      className="mt-4 text-sm font-bold text-emerald-600 hover:text-emerald-700 underline underline-offset-4"
                    >
                      عرض جميع النتائج
                    </button>
                  </div>
                </div>
              </motion.div>
            )}

            {!loading && (viewMode === 'map' ? (
              <div className="w-full h-[600px] bg-gray-200 rounded-3xl border border-gray-300 flex flex-col items-center justify-center relative overflow-hidden">
                <div className="absolute inset-0 opacity-20" style={{ backgroundImage: 'url("https://images.unsplash.com/photo-1524661135-423995f22d0b?auto=format&fit=crop&w=1200&q=80")', backgroundSize: 'cover', backgroundPosition: 'center' }}></div>
                <Map className="w-16 h-16 text-gray-400 mb-4 relative z-10" />
                <h3 className="text-xl font-bold text-gray-800 relative z-10">عرض الخريطة التفاعلية</h3>
                <p className="text-gray-500 mt-2 relative z-10">سيتم دمج خرائط Google هنا لعرض المواقع بدقة.</p>
                <button onClick={() => setViewMode('grid')} className="mt-6 px-6 py-2 bg-white rounded-xl shadow-sm font-medium text-gray-700 hover:bg-gray-50 relative z-10">
                  العودة للقائمة
                </button>
              </div>
            ) : (
              <>
                {/* Results Header */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
                  <p className="text-gray-600 font-medium">
                    تم العثور على <span className="font-bold text-gray-900">{filteredAndSortedServices.length}</span> نتيجة
                  </p>
                  
                  <div className="flex items-center gap-2 shrink-0">
                    <span className="text-sm text-gray-500">ترتيب حسب:</span>
                    <div className="relative">
                      <select 
                        value={sortBy}
                        onChange={(e) => setSortBy(e.target.value)}
                        className="appearance-none bg-white border border-gray-200 text-gray-700 py-2 pl-10 pr-4 rounded-xl text-sm font-medium focus:outline-none focus:ring-2 focus:ring-emerald-500 cursor-pointer"
                      >
                        <option value="recommended">الأوصى به</option>
                        <option value="price-asc">السعر: من الأقل للأعلى</option>
                        <option value="price-desc">السعر: من الأعلى للأقل</option>
                        <option value="rating-desc">الأعلى تقييماً</option>
                      </select>
                      <ChevronDown className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500 pointer-events-none" />
                    </div>
                  </div>
                </div>

                {/* Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                  {filteredAndSortedServices.length > 0 ? (
                    filteredAndSortedServices.map((service) => (
                      <ServiceCard 
                        key={service.id} 
                        service={service} 
                        activeColorClass={activeColorClass}
                        activeTextClass={activeTextClass}
                        activeBgLightClass={activeBgLightClass}
                      />
                    ))
                  ) : (
                    <div className="col-span-full py-20 text-center bg-white rounded-3xl border border-gray-100 shadow-sm">
                      <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-gray-50 mb-4">
                        <Search className="w-8 h-8 text-gray-400" />
                      </div>
                      <h3 className="text-xl font-bold text-gray-900 mb-2">لا توجد نتائج مطابقة</h3>
                      <p className="text-gray-500 max-w-md mx-auto">حاول تغيير خيارات البحث، أو تقليل الفلاتر المحددة لرؤية المزيد من النتائج المتاحة.</p>
                      <button 
                        onClick={clearFilters}
                        className={`mt-6 px-6 py-2.5 rounded-xl font-medium transition-colors shadow-sm ${activeColorClass}`}
                      >
                        مسح جميع الفلاتر
                      </button>
                    </div>
                  )}
                </div>
              </>
            ))}
          </main>
        </div>
      </div>
    </div>
  );
}
