import React, { useState, useEffect } from 'react';
import { LayoutDashboard, Package, Calendar, Settings, Plus, Loader2, AlertCircle } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import ServiceManagement from '../components/provider/ServiceManagement';
import BookingManagement from '../components/provider/BookingManagement';

export default function ProviderDashboard() {
  const { user, userProfile, loading } = useAuth();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<'overview' | 'services' | 'bookings' | 'settings'>('overview');

  useEffect(() => {
    if (!loading && (!user || (userProfile?.role !== 'provider' && userProfile?.role !== 'admin'))) {
      navigate('/');
    }
  }, [user, userProfile, loading, navigate]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-10 h-10 animate-spin text-emerald-600" />
      </div>
    );
  }

  if (!user || (userProfile?.role !== 'provider' && userProfile?.role !== 'admin')) {
    return null;
  }

  return (
    <div className="pt-24 pb-20 min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row gap-8">
          {/* Sidebar */}
          <aside className="w-full md:w-64 shrink-0">
            <div className="bg-white rounded-3xl shadow-sm border border-gray-100 overflow-hidden sticky top-28">
              <div className="p-6 border-b border-gray-100">
                <h2 className="font-bold text-xl text-gray-900">لوحة التحكم</h2>
                <p className="text-sm text-gray-500 mt-1">أهلاً بك، {userProfile?.displayName || 'المزود'}</p>
              </div>
              <nav className="p-2">
                <button
                  onClick={() => setActiveTab('overview')}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-colors ${activeTab === 'overview' ? 'bg-emerald-50 text-emerald-700' : 'text-gray-600 hover:bg-gray-50'}`}
                >
                  <LayoutDashboard className="w-5 h-5" />
                  <span>نظرة عامة</span>
                </button>
                <button
                  onClick={() => setActiveTab('services')}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-colors ${activeTab === 'services' ? 'bg-emerald-50 text-emerald-700' : 'text-gray-600 hover:bg-gray-50'}`}
                >
                  <Package className="w-5 h-5" />
                  <span>إدارة الخدمات</span>
                </button>
                <button
                  onClick={() => setActiveTab('bookings')}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-colors ${activeTab === 'bookings' ? 'bg-emerald-50 text-emerald-700' : 'text-gray-600 hover:bg-gray-50'}`}
                >
                  <Calendar className="w-5 h-5" />
                  <span>الحجوزات</span>
                </button>
                <button
                  onClick={() => setActiveTab('settings')}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-colors ${activeTab === 'settings' ? 'bg-emerald-50 text-emerald-700' : 'text-gray-600 hover:bg-gray-50'}`}
                >
                  <Settings className="w-5 h-5" />
                  <span>الإعدادات</span>
                </button>
              </nav>
            </div>
          </aside>

          {/* Main Content */}
          <main className="flex-1">
            {activeTab === 'overview' && (
              <div className="space-y-8">
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
                  <div className="bg-white p-6 rounded-3xl shadow-sm border border-gray-100">
                    <p className="text-sm text-gray-500 font-medium mb-1">إجمالي الخدمات</p>
                    <h3 className="text-3xl font-bold text-gray-900">12</h3>
                  </div>
                  <div className="bg-white p-6 rounded-3xl shadow-sm border border-gray-100">
                    <p className="text-sm text-gray-500 font-medium mb-1">الحجوزات النشطة</p>
                    <h3 className="text-3xl font-bold text-gray-900">8</h3>
                  </div>
                  <div className="bg-white p-6 rounded-3xl shadow-sm border border-gray-100">
                    <p className="text-sm text-gray-500 font-medium mb-1">إجمالي الأرباح</p>
                    <h3 className="text-3xl font-bold text-emerald-600">$2,450</h3>
                  </div>
                </div>

                <div className="bg-white rounded-3xl shadow-sm border border-gray-100 p-8">
                  <h3 className="text-xl font-bold text-gray-900 mb-6">آخر النشاطات</h3>
                  <div className="space-y-6">
                    {[1, 2, 3].map((i) => (
                      <div key={i} className="flex items-center gap-4 pb-6 border-b border-gray-50 last:border-0 last:pb-0">
                        <div className="w-12 h-12 bg-emerald-50 rounded-full flex items-center justify-center text-emerald-600">
                          <Calendar className="w-6 h-6" />
                        </div>
                        <div>
                          <p className="font-bold text-gray-900">حجز جديد: فندق الياسمين</p>
                          <p className="text-sm text-gray-500">منذ ساعتين · بواسطة محمد علي</p>
                        </div>
                        <span className="mr-auto text-sm font-bold text-emerald-600">+$120</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'services' && <ServiceManagement />}
            {activeTab === 'bookings' && <BookingManagement />}
            {activeTab === 'settings' && (
              <div className="bg-white rounded-3xl shadow-sm border border-gray-100 p-8">
                <h3 className="text-xl font-bold text-gray-900 mb-6">إعدادات الحساب</h3>
                <p className="text-gray-500">هذه الصفحة قيد التطوير...</p>
              </div>
            )}
          </main>
        </div>
      </div>
    </div>
  );
}
