import React from 'react';
import Hero from '../components/Hero';
import Categories from '../components/Categories';
import Featured from '../components/Featured';

export default function Home() {
  return (
    <main>
      <Hero />
      <Categories />
      <Featured />
    </main>
  );
}
