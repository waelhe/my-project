import React, { useState, useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { Loader2, ChevronLeft, ChevronRight, ArrowLeft, ArrowRight } from 'lucide-react';
import ServiceCard from './ServiceCard';
import { getAllServices, Service } from '../infrastructure/firebase/serviceService';
import { useLanguage } from '../contexts/LanguageContext';

interface ServiceSectionProps {
  title: string;
  subtitle?: string;
  categoryId?: string;
  filterPopular?: boolean;
  limit?: number;
  viewAllPath?: string;
}

export default function ServiceSection({ 
  title, 
  subtitle, 
  categoryId, 
  filterPopular = false, 
  limit = 8,
  viewAllPath
}: ServiceSectionProps) {
  const { language } = useLanguage();
  const [services, setServices] = useState<Service[]>([]);
  const [loading, setLoading] = useState(true);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const fetchServices = async () => {
      try {
        const data = await getAllServices();
        let filtered = data;
        
        if (categoryId) {
          filtered = filtered.filter(s => s.mainCategoryId === categoryId);
        }
        
        if (filterPopular) {
          filtered = filtered.sort((a, b) => (b.isPopular ? 1 : 0) - (a.isPopular ? 1 : 0) || b.rating - a.rating);
        } else {
          filtered = filtered.sort((a, b) => b.rating - a.rating);
        }
        
        setServices(filtered.slice(0, limit));
      } catch (error) {
        console.error('Error fetching services for section:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchServices();
  }, [categoryId, filterPopular, limit]);

  const scroll = (direction: 'left' | 'right') => {
    if (scrollRef.current) {
      const { scrollLeft, clientWidth } = scrollRef.current;
      const scrollTo = direction === 'left' 
        ? scrollLeft - clientWidth * 0.8 
        : scrollLeft + clientWidth * 0.8;
      
      scrollRef.current.scrollTo({ left: scrollTo, behavior: 'smooth' });
    }
  };

  if (!loading && services.length === 0) return null;

  return (
    <section className="py-6 bg-white overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex justify-between items-end mb-4">
          <div className="flex-1">
            <h2 className="text-xl md:text-2xl font-bold text-gray-900 leading-tight">
              {title}
            </h2>
            {subtitle && <p className="text-sm text-gray-500 mt-1 max-w-2xl">{subtitle}</p>}
          </div>

          <div className="flex items-center gap-3">
            {viewAllPath && (
              <Link to={viewAllPath} className="p-2 hover:bg-gray-100 rounded-full transition-colors hidden sm:block">
                {language === 'ar' ? <ArrowLeft className="w-5 h-5 text-gray-900" /> : <ArrowRight className="w-5 h-5 text-gray-900" />}
              </Link>
            )}
            <div className="flex items-center gap-1">
              <button 
                onClick={() => scroll('right')}
                className="p-2 rounded-full border border-gray-200 hover:bg-gray-50 transition-colors shadow-sm bg-white"
              >
                <ChevronRight className="w-4 h-4 text-gray-600" />
              </button>
              <button 
                onClick={() => scroll('left')}
                className="p-2 rounded-full border border-gray-200 hover:bg-gray-50 transition-colors shadow-sm bg-white"
              >
                <ChevronLeft className="w-4 h-4 text-gray-600" />
              </button>
            </div>
          </div>
        </div>

        {loading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="w-8 h-8 animate-spin text-emerald-600" />
          </div>
        ) : (
          <div 
            ref={scrollRef}
            className="flex gap-4 md:gap-6 overflow-x-auto pb-4 snap-x snap-mandatory"
          >
            {services.map((service) => (
              <div key={service.id} className="snap-start">
                <ServiceCard 
                  service={service} 
                  activeColorClass="bg-emerald-600 text-white"
                  activeTextClass="text-emerald-600"
                  activeBgLightClass="bg-emerald-50"
                />
              </div>
            ))}
          </div>
        )}
      </div>
    </section>
  );
}
