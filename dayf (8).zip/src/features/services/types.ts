import { z } from 'zod';

export const ServiceSchema = z.object({
  id: z.string().optional(),
  mainCategoryId: z.string().min(1, "Main category is required"),
  subCategoryId: z.string().min(1, "Sub category is required"),
  subSubCategoryId: z.string().optional(),
  title: z.string().min(3, "Title must be at least 3 characters").max(100, "Title is too long"),
  location: z.string().min(3, "Location is required"),
  price: z.number().positive("Price must be positive"),
  originalPrice: z.number().positive().optional(),
  rating: z.number().min(0).max(5),
  reviews: z.number().int().nonnegative(),
  images: z.array(z.string().url()).min(1, "At least one image is required"),
  type: z.string().min(1, "Type is required"),
  amenities: z.array(z.string()),
  features: z.array(z.string()),
  isPopular: z.boolean(),
  host: z.object({
    name: z.string().min(2),
    isSuperhost: z.boolean(),
    avatar: z.string().url(),
  }).optional(),
  authorUid: z.string().min(1),
  createdAt: z.any().optional(), // Firestore Timestamp
});

export type Service = z.infer<typeof ServiceSchema>;
