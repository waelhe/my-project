import { db } from '../../firebase';
import { 
  collection, 
  getDocs, 
  getDoc, 
  doc, 
  query, 
  where, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  serverTimestamp,
  setDoc,
} from 'firebase/firestore';
import { INITIAL_SERVICES } from '../../data/initialServices';
import { ServiceSchema, Service } from '../../features/services/types';
import { handleFirestoreError, OperationType } from '../../utils/firestoreError';

export type { Service };

const SERVICES_COLLECTION = 'services';

export const seedServices = async (userUid: string) => {
  try {
    const querySnapshot = await getDocs(collection(db, SERVICES_COLLECTION));
    if (querySnapshot.empty) {
      console.log('Seeding services...');
      for (const service of INITIAL_SERVICES) {
        const { id, ...serviceData } = service;
        const validatedData = ServiceSchema.parse({ ...serviceData, authorUid: userUid });
        try {
          await setDoc(doc(db, SERVICES_COLLECTION, id), {
            ...validatedData,
            createdAt: serverTimestamp()
          });
        } catch (err) {
          console.warn(`Could not seed service ${id}:`, err);
        }
      }
      console.log('Seeding complete or skipped.');
    }
  } catch (error) {
    console.error('Error during seeding check:', error);
  }
};

export const getAllServices = async (): Promise<Service[]> => {
  try {
    const querySnapshot = await getDocs(collection(db, SERVICES_COLLECTION));
    return querySnapshot.docs.map(doc => {
      const data = { id: doc.id, ...doc.data() };
      return ServiceSchema.parse(data);
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, SERVICES_COLLECTION);
  }
};

export const getServicesByCategory = async (categoryId: string): Promise<Service[]> => {
  const q = query(collection(db, SERVICES_COLLECTION), where('mainCategoryId', '==', categoryId));
  try {
    const querySnapshot = await getDocs(q);
    return querySnapshot.docs.map(doc => {
      const data = { id: doc.id, ...doc.data() };
      return ServiceSchema.parse(data);
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, SERVICES_COLLECTION);
  }
};

export const getServiceById = async (id: string): Promise<Service | null> => {
  const docRef = doc(db, SERVICES_COLLECTION, id);
  try {
    const docSnap = await getDoc(docRef);
    if (docSnap.exists()) {
      const data = { id: docSnap.id, ...docSnap.data() };
      return ServiceSchema.parse(data);
    }
    return null;
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, SERVICES_COLLECTION + '/' + id);
  }
};

export const createService = async (serviceData: Omit<Service, 'id' | 'createdAt'>) => {
  try {
    const validatedData = ServiceSchema.parse(serviceData);
    return await addDoc(collection(db, SERVICES_COLLECTION), {
      ...validatedData,
      createdAt: serverTimestamp()
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, SERVICES_COLLECTION);
  }
};

export const updateService = async (id: string, serviceData: Partial<Service>) => {
  const docRef = doc(db, SERVICES_COLLECTION, id);
  try {
    await updateDoc(docRef, serviceData);
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, SERVICES_COLLECTION + '/' + id);
  }
};

export const deleteService = async (id: string) => {
  const docRef = doc(db, SERVICES_COLLECTION, id);
  try {
    await deleteDoc(docRef);
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, SERVICES_COLLECTION + '/' + id);
  }
};
