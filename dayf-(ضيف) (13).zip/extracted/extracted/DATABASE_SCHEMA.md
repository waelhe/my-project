# 🗄️ مخطط قاعدة البيانات - مشروع "ضيف"

## 📊 نظرة عامة

إجمالي عدد الجداول: **62 جدول**

```
┌─────────────────────────────────────────────────────────────────┐
│                     تصنيف الجداول                               │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  👤 المستخدمون والشركات         9 جداول                        │
│  🌍 السياحة                     8 جداول                        │
│  🏥 العلاج                      4 جداول                        │
│  📚 الدراسة                     4 جداول                        │
│  💼 العمل                       4 جداول                        │
│  📅 الحجوزات                    3 جداول                        │
│  💰 المالية والضمان             5 جداول                        │
│  ⭐ التقييمات                   3 جداول                        │
│  👥 المجتمع                     5 جداول                        │
│  🛒 السوق                       4 جداول                        │
│  🎁 العروض والولاء              4 جداول                        │
│  ⚖️ المنازعات                   3 جداول                        │
│  🔔 الإشعارات                   2 جداول                        │
│  ⚙️ الإعدادات                   4 جداول                        │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## 👤 المستخدمون والشركات (9 جداول)

### 1. users
```prisma
model User {
  id                String    @id @default(cuid())
  email             String?   @unique
  phone             String?   @unique
  passwordHash      String?
  
  // المعلومات الأساسية
  firstName         String?
  lastName          String?
  displayName       String?
  avatar            String?
  bio               String?
  dateOfBirth       DateTime?
  gender            Gender?
  nationality       String?
  
  // معلومات الموقع
  country           String?
  city              String?
  address           String?
  
  // الحالة
  status            UserStatus    @default(PENDING)
  role              Role          @default(USER)
  emailVerified     DateTime?
  phoneVerified     DateTime?
  
  // العضوية
  membershipLevel   MembershipLevel @default(BRONZE)
  loyaltyPoints     Int           @default(0)
  
  // التفضيلات
  preferredLanguage String        @default("ar")
  preferredCurrency String        @default("SYP")
  notificationSettings Json?
  
  // التواريخ
  lastLoginAt       DateTime?
  createdAt         DateTime      @default(now())
  updatedAt         DateTime      @updatedAt
  
  // العلاقات
  oauthAccounts     OAuthAccount[]
  sessions          Session[]
  profiles          UserProfile[]
  bookings          Booking[]
  reviews           Review[]
  companies         Company[]
  listings          Listing[]
  messages          Message[]
  notifications     Notification[]
  disputes          Dispute[]
  loyaltyTransactions LoyaltyTransaction[]
  
  @@index([email])
  @@index([phone])
  @@index([role])
  @@index([status])
}

enum Gender {
  MALE
  FEMALE
  OTHER
}

enum UserStatus {
  PENDING     // في الانتظار
  ACTIVE      // نشط
  SUSPENDED   // معلق
  DELETED     // محذوف
}

enum Role {
  GUEST       // زائر
  USER        // مستخدم
  HOST        // مضيف
  COMPANY     // شركة
  ADMIN       // مدير
  SUPER_ADMIN // مدير عام
}

enum MembershipLevel {
  BRONZE      // برونزي
  SILVER      // فضي
  GOLD        // ذهبي
  PLATINUM    // بلاتيني
}
```

### 2. oauth_accounts
```prisma
model OAuthAccount {
  id            String    @id @default(cuid())
  userId        String
  provider      OAuthProvider
  providerId    String
  accessToken   String?
  refreshToken  String?
  expiresAt     DateTime?
  createdAt     DateTime  @default(now())
  
  user          User      @relation(fields: [userId], references: [id], onDelete: Cascade)
  
  @@unique([provider, providerId])
  @@index([userId])
}

enum OAuthProvider {
  GOOGLE
  APPLE
  FACEBOOK
  TWITTER
}
```

### 3. sessions
```prisma
model Session {
  id            String    @id @default(cuid())
  userId        String
  token         String    @unique
  userAgent     String?
  ipAddress     String?
  expiresAt     DateTime
  createdAt     DateTime  @default(now())
  
  user          User      @relation(fields: [userId], references: [id], onDelete: Cascade)
  
  @@index([userId])
  @@index([token])
}
```

### 4. otp_codes
```prisma
model OTPCode {
  id            String    @id @default(cuid())
  phone         String
  code          String
  type          OTPType
  verified      Boolean   @default(false)
  expiresAt     DateTime
  createdAt     DateTime  @default(now())
  
  @@unique([phone, code, type])
  @@index([phone])
}

enum OTPType {
  LOGIN
  REGISTER
  VERIFY
  RESET_PASSWORD
}
```

### 5. user_profiles
```prisma
model UserProfile {
  id            String    @id @default(cuid())
  userId        String
  type          ProfileType
  
  // معلومات إضافية
  preferences   Json?
  interests     String[]
  languages     String[]
  
  // للمضيفين
  hostingSince  DateTime?
  responseRate  Float?
  responseTime  Int?       // بالدقائق
  
  // للشركات
  companyName   String?
  companyRole   String?
  
  createdAt     DateTime  @default(now())
  updatedAt     DateTime  @updatedAt
  
  user          User      @relation(fields: [userId], references: [id], onDelete: Cascade)
  
  @@unique([userId, type])
}

enum ProfileType {
  TRAVELER    // مسافر
  HOST        // مضيف
  COMPANY     // شركة
}
```

### 6. companies
```prisma
model Company {
  id              String    @id @default(cuid())
  userId          String
  
  // معلومات الشركة
  name            String
  slug            String    @unique
  description     String?
  logo            String?
  coverImage      String?
  website         String?
  
  // معلومات الاتصال
  email           String?
  phone           String?
  address         String?
  city            String?
  country         String?
  
  // التصنيف
  type            CompanyType
  categories      String[]
  
  // التحقق
  verified        Boolean   @default(false)
  verifiedAt      DateTime?
  documents       Json?     // الوثائق المقدمة
  
  // الإحصائيات
  totalListings   Int       @default(0)
  totalBookings   Int       @default(0)
  totalReviews    Int       @default(0)
  avgRating       Float?
  
  // الحالة
  status          CompanyStatus @default(PENDING)
  
  createdAt       DateTime  @default(now())
  updatedAt       DateTime  @updatedAt
  
  user            User      @relation(fields: [userId], references: [id], onDelete: Cascade)
  listings        Listing[]
  services        Service[]
  
  @@index([userId])
  @@index([type])
  @@index([status])
}

enum CompanyType {
  HOTEL           // فندق
  TOURISM_AGENCY  // وكالة سياحية
  MEDICAL_CENTER  // مركز طبي
  EDUCATIONAL     // تعليمية
  BUSINESS        // أعمال
  OTHER           // أخرى
}

enum CompanyStatus {
  PENDING     // في الانتظار
  ACTIVE      // نشط
  SUSPENDED   // معلق
  CLOSED      // مغلق
}
```

### 7. company_employees
```prisma
model CompanyEmployee {
  id            String    @id @default(cuid())
  companyId     String
  userId        String
  role          EmployeeRole
  permissions   String[]
  
  invitedBy     String?
  invitedAt     DateTime?
  acceptedAt    DateTime?
  
  createdAt     DateTime  @default(now())
  updatedAt     DateTime  @updatedAt
  
  company       Company   @relation(fields: [companyId], references: [id], onDelete: Cascade)
  user          User      @relation(fields: [userId], references: [id], onDelete: Cascade)
  
  @@unique([companyId, userId])
}

enum EmployeeRole {
  OWNER       // مالك
  ADMIN       // مدير
  MANAGER     // مشرف
  STAFF       // موظف
}
```

### 8. user_favorites
```prisma
model UserFavorite {
  id            String    @id @default(cuid())
  userId        String
  listingId     String?
  destinationId String?
  activityId    String?
  
  createdAt     DateTime  @default(now())
  
  @@unique([userId, listingId])
  @@unique([userId, destinationId])
  @@unique([userId, activityId])
}
```

### 9. user_verifications
```prisma
model UserVerification {
  id            String    @id @default(cuid())
  userId        String
  type          VerificationType
  status        VerificationStatus @default(PENDING)
  
  // الوثائق
  documentType  String?
  documentUrl   String?
  documentNumber String?
  
  // التحقق
  verifiedAt    DateTime?
  verifiedBy    String?
  rejectionReason String?
  
  createdAt     DateTime  @default(now())
  updatedAt     DateTime  @updatedAt
  
  @@index([userId])
  @@index([type])
  @@index([status])
}

enum VerificationType {
  IDENTITY     // الهوية
  PHONE        // الهاتف
  EMAIL        // البريد
  ADDRESS      // العنوان
  BUSINESS     // العمل
}

enum VerificationStatus {
  PENDING
  APPROVED
  REJECTED
}
```

---

## 🌍 السياحة (8 جداول)

### 10. destinations
```prisma
model Destination {
  id              String    @id @default(cuid())
  
  // المعلومات الأساسية
  name            String
  slug            String    @unique
  description     String
  shortDescription String?
  
  // الموقع
  country         String    @default("Syria")
  region          String?
  city            String?
  address         String?
  latitude        Float?
  longitude       Float?
  
  // التصنيف
  type            DestinationType
  subTypes        String[]
  tags            String[]
  
  // الصور والفيديو
  images          String[]
  featuredImage   String?
  videoUrl        String?
  
  // التقييم والإحصائيات
  avgRating       Float?
  totalReviews    Int       @default(0)
  viewCount       Int       @default(0)
  visitCount      Int       @default(0)
  
  // الموسم والأوقات
  bestSeason      String[]?
  openingHours    Json?
  entryFee        Float?
  
  // المرافق والخدمات
  amenities       String[]
  accessibility   String[]?
  
  // الحالة
  status          ContentStatus @default(DRAFT)
  featured        Boolean   @default(false)
  
  // SEO
  metaTitle       String?
  metaDescription String?
  
  createdAt       DateTime  @default(now())
  updatedAt       DateTime  @updatedAt
  
  listings        Listing[]
  activities      Activity[]
  favorites       UserFavorite[]
  
  @@index([type])
  @@index([city])
  @@index([status])
  @@index([featured])
}

enum DestinationType {
  TOURISM       // سياحي عام
  ENTERTAINMENT // ترفيهي
  CULTURAL      // ثقافي
  RELIGIOUS     // ديني
  NATURE        // طبيعي
  HISTORICAL    // تاريخي
}

enum ContentStatus {
  DRAFT       // مسودة
  PENDING     // في الانتظار
  PUBLISHED   // منشور
  ARCHIVED    // مؤرشف
}
```

### 11. listings (الإقامات)
```prisma
model Listing {
  id              String    @id @default(cuid())
  
  // الملكية
  userId          String
  companyId       String?
  
  // المعلومات الأساسية
  title           String
  slug            String    @unique
  description     String
  summary         String?
  
  // الموقع
  country         String    @default("Syria")
  region          String?
  city            String?
  address         String?
  neighborhood    String?
  latitude        Float?
  longitude       Float?
  
  // التصنيف
  type            ListingType
  subTypes        String[]
  tags            String[]
  
  // المساحة والسعة
  size            Float?    // بالمتر المربع
  maxGuests       Int       @default(2)
  bedrooms        Int       @default(1)
  beds            Int       @default(1)
  bathrooms       Int       @default(1)
  
  // الأسعار
  basePrice       Float
  currency        String    @default("SYP")
  weekendPrice    Float?
  weeklyDiscount  Float?    @default(0.1)
  monthlyDiscount Float?    @default(0.2)
  cleaningFee     Float?
  serviceFee      Float?
  
  // الحد الأدنى للإقامة
  minNights       Int       @default(1)
  maxNights       Int?
  
  // أوقات الوصول والمغادرة
  checkInTime     String    @default("15:00")
  checkOutTime    String    @default("11:00")
  
  // المرافق
  amenities       String[]
  safetyFeatures  String[]?
  accessibilityFeatures String[]?
  
  // القواعد
  houseRules      String[]?
  smokingAllowed  Boolean   @default(false)
  petsAllowed     Boolean   @default(false)
  partiesAllowed  Boolean   @default(false)
  childrenAllowed Boolean   @default(true)
  
  // الصور
  images          String[]
  featuredImage   String?
  virtualTourUrl  String?
  
  // التقييم والإحصائيات
  avgRating       Float?
  totalReviews    Int       @default(0)
  viewCount       Int       @default(0)
  bookingCount    Int       @default(0)
  
  // التوفر
  availability    Json?     // التقويم
  instantBook     Boolean   @default(false)
  
  // الحالة
  status          ContentStatus @default(DRAFT)
  verified        Boolean   @default(false)
  verifiedAt      DateTime?
  
  // التواريخ
  publishedAt     DateTime?
  createdAt       DateTime  @default(now())
  updatedAt       DateTime  @updatedAt
  
  // العلاقات
  user            User      @relation(fields: [userId], references: [id])
  company         Company?  @relation(fields: [companyId], references: [id])
  destination     Destination? @relation(fields: [destinationId], references: [id])
  bookings        Booking[]
  reviews         Review[]
  availabilityCalendar AvailabilityCalendar[]
  
  @@index([userId])
  @@index([type])
  @@index([city])
  @@index([status])
  @@index([basePrice])
}

enum ListingType {
  HOTEL       // فندق
  APARTMENT   // شقة
  HOUSE       // منزل
  ROOM        // غرفة
  VILLA       // فيلا
  CAMP        // مخيم
  BOAT        // قارب
  OTHER       // أخرى
}
```

### 12. listing_amenities
```prisma
model ListingAmenity {
  id            String    @id @default(cuid())
  listingId     String
  amenityId     String
  available     Boolean   @default(true)
  description   String?
  
  createdAt     DateTime  @default(now())
  
  @@unique([listingId, amenityId])
}

model Amenity {
  id            String    @id @default(cuid())
  name          String
  nameAr        String
  icon          String?
  category      String?
  
  createdAt     DateTime  @default(now())
}
```

### 13. activities
```prisma
model Activity {
  id              String    @id @default(cuid())
  destinationId   String?
  
  // المعلومات الأساسية
  title           String
  slug            String    @unique
  description     String
  shortDescription String?
  
  // التصنيف
  type            ActivityType
  subTypes        String[]
  difficulty      Difficulty?
  duration        Int?      // بالدقائق
  
  // الموقع
  meetingPoint    String?
  latitude        Float?
  longitude       Float?
  
  // الجدول
  schedule        Json?
  availableDays   String[]  // أيام الأسبوع المتاحة
  
  // الأسعار
  basePrice       Float
  currency        String    @default("SYP")
  pricePerPerson  Boolean   @default(true)
  
  // السعة
  maxParticipants Int?
  minParticipants Int?
  
  // المتطلبات
  requirements    String[]?
  whatToBring     String[]?
  ageRestriction  Int?
  
  // اللغات
  languages       String[]
  
  // الصور
  images          String[]
  featuredImage   String?
  
  // التقييم
  avgRating       Float?
  totalReviews    Int       @default(0)
  bookingCount    Int       @default(0)
  
  // المزود
  providerId      String?
  providerType    ProviderType?
  
  // الحالة
  status          ContentStatus @default(DRAFT)
  
  createdAt       DateTime  @default(now())
  updatedAt       DateTime  @updatedAt
  
  destination     Destination? @relation(fields: [destinationId], references: [id])
  bookings        Booking[]
  
  @@index([type])
  @@index([status])
}

enum ActivityType {
  TOUR        // جولة
  EXPERIENCE  // تجربة
  WORKSHOP    // ورشة
  ADVENTURE   // مغامرة
  CRUISE      // رحلة بحرية
  TRANSFER    // نقل
  OTHER       // أخرى
}

enum Difficulty {
  EASY
  MODERATE
  HARD
  EXTREME
}

enum ProviderType {
  USER
  COMPANY
}
```

### 14. tours
```prisma
model Tour {
  id              String    @id @default(cuid())
  
  // المعلومات الأساسية
  title           String
  slug            String    @unique
  description     String
  
  // التصنيف
  type            TourType
  duration        Int       // بالأيام
  
  // البرنامج
  itinerary       Json      // البرنامج اليومي
  
  // الأسعار
  basePrice       Float
  currency        String    @default("SYP")
  includes        String[]
  excludes        String[]
  
  // التواريخ المتاحة
  availableDates  Json?
  
  // المزود
  companyId       String?
  userId          String?
  
  // الحالة
  status          ContentStatus @default(DRAFT)
  
  createdAt       DateTime  @default(now())
  updatedAt       DateTime  @updatedAt
}

enum TourType {
  CITY_TOUR       // جولة مدينة
  MULTI_DAY       // متعدد الأيام
  DAY_TRIP        // رحلة يوم
  PACKAGE         // باقة
}
```

### 15. availability_calendar
```prisma
model AvailabilityCalendar {
  id            String    @id @default(cuid())
  listingId     String
  date          DateTime
  status        AvailabilityStatus
  price         Float?
  minNights     Int?
  maxNights     Int?
  notes         String?
  
  createdAt     DateTime  @default(now())
  updatedAt     DateTime  @updatedAt
  
  listing       Listing   @relation(fields: [listingId], references: [id], onDelete: Cascade)
  
  @@unique([listingId, date])
  @@index([listingId])
  @@index([date])
}

enum AvailabilityStatus {
  AVAILABLE     // متاح
  BOOKED        // محجوز
  BLOCKED       // محجوب
  UNAVAILABLE   // غير متاح
}
```

### 16. destination_categories
```prisma
model DestinationCategory {
  id            String    @id @default(cuid())
  name          String
  nameAr        String
  slug          String    @unique
  parentId      String?
  icon          String?
  order         Int       @default(0)
  
  createdAt     DateTime  @default(now())
  
  parent        DestinationCategory?  @relation("CategoryHierarchy", fields: [parentId], references: [id])
  children      DestinationCategory[] @relation("CategoryHierarchy")
}
```

### 17. destination_highlights
```prisma
model DestinationHighlight {
  id            String    @id @default(cuid())
  destinationId String
  title         String
  description   String?
  image         String?
  order         Int       @default(0)
  
  createdAt     DateTime  @default(now())
}
```

---

## 🏥 العلاج (4 جداول)

### 18. medical_centers
```prisma
model MedicalCenter {
  id              String    @id @default(cuid())
  companyId       String
  
  // المعلومات الأساسية
  name            String
  slug            String    @unique
  description     String
  
  // التصنيف
  type            MedicalType
  specialties     String[]
  
  // الموقع
  city            String
  address         String?
  latitude        Float?
  longitude       Float?
  
  // الأطباء
  doctorsCount    Int       @default(0)
  
  // الخدمات
  services        String[]
  facilities      String[]
  
  // الأسعار
  priceRange      PriceRange?
  
  // الشهادات
  accreditations  String[]
  
  // التقييم
  avgRating       Float?
  totalReviews    Int       @default(0)
  
  // الحالة
  status          ContentStatus @default(DRAFT)
  verified        Boolean   @default(false)
  
  createdAt       DateTime  @default(now())
  updatedAt       DateTime  @updatedAt
  
  company         Company   @relation(fields: [companyId], references: [id])
  doctors         Doctor[]
  bookings        Booking[]
  
  @@index([type])
  @@index([city])
}

enum MedicalType {
  GENERAL        // طب عام
  DENTAL         // أسنان
  OPHTHALMOLOGY  // عيون
  DERMATOLOGY    // جلدية
  ORTHOPEDICS    // عظام
  CARDIOLOGY     // قلب
  FERTILITY      // خصوبة
  ALTERNATIVE    // طب بديل
  OTHER          // أخرى
}

enum PriceRange {
  BUDGET      // اقتصادي
  MODERATE    // متوسط
  LUXURY      // فاخر
}
```

### 19. doctors
```prisma
model Doctor {
  id              String    @id @default(cuid())
  medicalCenterId String
  
  // المعلومات الأساسية
  name            String
  slug            String    @unique
  title           String?   // د، أ.د، إلخ
  bio             String?
  image           String?
  
  // التخصص
  specialty       String
  subSpecialties  String[]
  
  // الخبرة
  yearsOfExperience Int?
  education       String[]
  certifications  String[]
  
  // اللغات
  languages       String[]
  
  // التقييم
  avgRating       Float?
  totalReviews    Int       @default(0)
  
  // التوفر
  availability    Json?
  
  createdAt       DateTime  @default(now())
  updatedAt       DateTime  @updatedAt
  
  medicalCenter   MedicalCenter @relation(fields: [medicalCenterId], references: [id])
}
```

### 20. medical_services
```prisma
model MedicalService {
  id              String    @id @default(cuid())
  medicalCenterId String
  
  // المعلومات
  name            String
  description     String?
  
  // السعر
  price           Float?
  currency        String    @default("SYP")
  
  // المدة
  duration        Int?      // بالدقائق
  
  createdAt       DateTime  @default(now())
  
  medicalCenter   MedicalCenter @relation(fields: [medicalCenterId], references: [id])
}
```

### 21. medical_bookings
```prisma
model MedicalBooking {
  id              String    @id @default(cuid())
  bookingId       String
  
  // تفاصيل طبية
  patientName     String
  patientAge      Int?
  patientGender   Gender?
  medicalHistory  String?
  currentMedications String?
  allergies       String?
  
  // الموعد
  appointmentDate DateTime
  appointmentTime String
  
  // التخصص
  specialty       String
  doctorId        String?
  serviceId       String?
  
  createdAt       DateTime  @default(now())
  updatedAt       DateTime  @updatedAt
}
```

---

## 📚 الدراسة (4 جداول)

### 22. educational_institutions
```prisma
model EducationalInstitution {
  id              String    @id @default(cuid())
  companyId       String?
  
  // المعلومات الأساسية
  name            String
  slug            String    @unique
  description     String
  
  // التصنيف
  type            InstitutionType
  
  // الموقع
  city            String
  address         String?
  
  // البرامج
  programs        String[]
  
  // التصنيفات
  ranking         Int?
  accreditation   String[]
  
  // التقييم
  avgRating       Float?
  totalReviews    Int       @default(0)
  
  // الحالة
  status          ContentStatus @default(DRAFT)
  
  createdAt       DateTime  @default(now())
  updatedAt       DateTime  @updatedAt
  
  company         Company?  @relation(fields: [companyId], references: [id])
  programs_rel    Program[]
  
  @@index([type])
  @@index([city])
}

enum InstitutionType {
  UNIVERSITY     // جامعة
  COLLEGE        // كلية
  INSTITUTE      // معهد
  LANGUAGE_SCHOOL // مدرسة لغات
  VOCATIONAL     // مهني
  TRAINING_CENTER // مركز تدريب
}
```

### 23. programs
```prisma
model Program {
  id              String    @id @default(cuid())
  institutionId   String
  
  // المعلومات الأساسية
  name            String
  description     String
  
  // التصنيف
  type            ProgramType
  field           String
  
  // المدة
  duration        Int       // بالأشهر
  
  // السعر
  tuitionFee      Float?
  currency        String    @default("SYP")
  
  // المتطلبات
  requirements    String[]
  
  // اللغة
  language        String
  
  createdAt       DateTime  @default(now())
  updatedAt       DateTime  @updatedAt
  
  institution     EducationalInstitution @relation(fields: [institutionId], references: [id])
}

enum ProgramType {
  BACHELOR      // بكالوريوس
  MASTER        // ماجستير
  PHD           // دكتوراه
  DIPLOMA       // دبلوم
  CERTIFICATE   // شهادة
  COURSE        // دورة
  WORKSHOP      // ورشة
}
```

### 24. courses
```prisma
model Course {
  id              String    @id @default(cuid())
  institutionId   String?
  
  // المعلومات
  title           String
  description     String
  
  // التصنيف
  category        String
  level           CourseLevel
  
  // المدة
  duration        Int       // بالساعات
  
  // السعر
  price           Float?
  currency        String    @default("SYP")
  
  // الجدول
  schedule        Json?
  
  // الحالة
  status          ContentStatus @default(DRAFT)
  
  createdAt       DateTime  @default(now())
  updatedAt       DateTime  @updatedAt
}

enum CourseLevel {
  BEGINNER
  INTERMEDIATE
  ADVANCED
  PROFESSIONAL
}
```

### 25. student_applications
```prisma
model StudentApplication {
  id              String    @id @default(cuid())
  bookingId       String
  
  // معلومات الطالب
  firstName       String
  lastName        String
  dateOfBirth     DateTime
  nationality     String
  
  // التعليم السابق
  previousEducation String?
  gpa             Float?
  
  // البرنامج
  institutionId   String
  programId       String?
  
  // الوثائق
  documents       Json?
  
  // الحالة
  status          ApplicationStatus @default(PENDING)
  
  createdAt       DateTime  @default(now())
  updatedAt       DateTime  @updatedAt
}

enum ApplicationStatus {
  PENDING
  UNDER_REVIEW
  ACCEPTED
  REJECTED
  ENROLLED
}
```

---

## 💼 العمل (4 جداول)

### 26. business_opportunities
```prisma
model BusinessOpportunity {
  id              String    @id @default(cuid())
  companyId       String?
  
  // المعلومات الأساسية
  title           String
  slug            String    @unique
  description     String
  
  // التصنيف
  type            BusinessType
  sector          String
  
  // الموقع
  city            String?
  
  // الاستثمار
  minInvestment   Float?
  maxInvestment   Float?
  currency        String    @default("SYP")
  
  // العائد المتوقع
  expectedReturn  Float?
  
  // الحالة
  status          ContentStatus @default(DRAFT)
  
  createdAt       DateTime  @default(now())
  updatedAt       DateTime  @updatedAt
  
  @@index([type])
  @@index([sector])
}

enum BusinessType {
  INVESTMENT    // استثمار
  PARTNERSHIP   // شراكة
  FRANCHISE     // امتياز
  SALE          // بيع
  TENDER        // مناقصة
}
```

### 27. conferences
```prisma
model Conference {
  id              String    @id @default(cuid())
  companyId       String?
  
  // المعلومات
  title           String
  slug            String    @unique
  description     String
  
  // الموقع
  venue           String
  city            String
  address         String?
  
  // التواريخ
  startDate       DateTime
  endDate         DateTime
  
  // التسجيل
  registrationFee Float?
  currency        String    @default("SYP")
  capacity        Int?
  registered      Int       @default(0)
  
  // الحالة
  status          ContentStatus @default(DRAFT)
  
  createdAt       DateTime  @default(now())
  updatedAt       DateTime  @updatedAt
}
```

### 28. conference_attendees
```prisma
model ConferenceAttendee {
  id              String    @id @default(cuid())
  conferenceId    String
  userId          String?
  
  // المعلومات
  firstName       String
  lastName        String
  email           String
  phone           String?
  company         String?
  jobTitle        String?
  
  // الحالة
  status          AttendeeStatus @default(REGISTERED)
  paid            Boolean   @default(false)
  
  createdAt       DateTime  @default(now())
  
  @@unique([conferenceId, email])
}

enum AttendeeStatus {
  REGISTERED
  CONFIRMED
  CANCELLED
  ATTENDED
}
```

### 29. business_services
```prisma
model BusinessService {
  id              String    @id @default(cuid())
  companyId       String
  
  // المعلومات
  name            String
  description     String
  
  // التصنيف
  category        String
  
  // السعر
  price           Float?
  currency        String    @default("SYP")
  
  // الحالة
  status          ContentStatus @default(DRAFT)
  
  createdAt       DateTime  @default(now())
  updatedAt       DateTime  @updatedAt
  
  company         Company   @relation(fields: [companyId], references: [id])
}
```

---

## 📅 الحجوزات (3 جداول)

### 30. bookings
```prisma
model Booking {
  id              String    @id @default(cuid())
  bookingNumber   String    @unique
  
  // المستخدمين
  userId          String
  listingId       String?
  activityId      String?
  tourId          String?
  
  // التواريخ
  checkIn         DateTime?
  checkOut        DateTime?
  
  // الضيوف
  guests          Int       @default(1)
  adults          Int       @default(1)
  children        Int       @default(0)
  infants         Int       @default(0)
  
  // التفاصيل
  specialRequests String?
  
  // الأسعار
  basePrice       Float
  cleaningFee     Float?
  serviceFee      Float?
  taxes           Float?
  discount        Float?
  totalPrice      Float
  currency        String    @default("SYP")
  
  // الضمان
  escrowId        String?
  
  // الحالة
  status          BookingStatus @default(PENDING)
  paymentStatus   PaymentStatus @default(PENDING)
  
  // التواريخ المهمة
  confirmedAt     DateTime?
  cancelledAt     DateTime?
  cancellationReason String?
  completedAt     DateTime?
  
  createdAt       DateTime  @default(now())
  updatedAt       DateTime  @updatedAt
  
  // العلاقات
  user            User      @relation(fields: [userId], references: [id])
  listing         Listing?  @relation(fields: [listingId], references: [id])
  activity        Activity? @relation(fields: [activityId], references: [id])
  payments        Payment[]
  reviews         Review[]
  dispute         Dispute?
  escrow          Escrow?   @relation(fields: [escrowId], references: [id])
  
  @@index([userId])
  @@index([listingId])
  @@index([status])
  @@index([checkIn])
}

enum BookingStatus {
  PENDING       // في الانتظار
  CONFIRMED     // مؤكد
  CANCELLED     // ملغي
  COMPLETED     // مكتمل
  NO_SHOW       // لم يحضر
}

enum PaymentStatus {
  PENDING       // في الانتظار
  PROCESSING    // قيد المعالجة
  PAID          // مدفوع
  FAILED        // فشل
  REFUNDED      // مسترد
  PARTIALLY_REFUNDED // مسترد جزئياً
}
```

### 31. booking_items
```prisma
model BookingItem {
  id              String    @id @default(cuid())
  bookingId       String
  
  // العنصر
  itemType        BookingItemType
  itemId          String
  name            String
  
  // التفاصيل
  quantity        Int       @default(1)
  unitPrice       Float
  totalPrice      Float
  
  // التواريخ
  date            DateTime?
  startTime       String?
  endTime         String?
  
  createdAt       DateTime  @default(now())
  
  @@index([bookingId])
}

enum BookingItemType {
  ACCOMMODATION
  ACTIVITY
  TOUR
  TRANSFER
  MEAL
  EXTRA_SERVICE
}
```

### 32. booking_guests
```prisma
model BookingGuest {
  id              String    @id @default(cuid())
  bookingId       String
  
  // معلومات الضيف
  firstName       String
  lastName        String
  email           String?
  phone           String?
  dateOfBirth     DateTime?
  nationality     String?
  idType          String?
  idNumber        String?
  
  // الضيف الرئيسي
  isPrimary       Boolean   @default(false)
  
  createdAt       DateTime  @default(now())
  
  @@index([bookingId])
}
```

---

## 💰 المالية والضمان (5 جداول)

### 33. payments
```prisma
model Payment {
  id              String    @id @default(cuid())
  paymentNumber   String    @unique
  bookingId       String
  
  // المبلغ
  amount          Float
  currency        String    @default("SYP")
  
  // الطريقة
  method          PaymentMethod
  provider        String?
  providerTransactionId String?
  
  // الحالة
  status          PaymentStatus @default(PENDING)
  
  // التفاصيل
  metadata        Json?
  
  // رد المزود
  providerResponse Json?
  
  // التواريخ
  paidAt          DateTime?
  refundedAt      DateTime?
  refundAmount    Float?
  
  createdAt       DateTime  @default(now())
  updatedAt       DateTime  @updatedAt
  
  booking         Booking   @relation(fields: [bookingId], references: [id])
  
  @@index([bookingId])
  @@index([status])
}

enum PaymentMethod {
  CREDIT_CARD   // بطاقة ائتمان
  DEBIT_CARD    // بطاقة خصم
  CASH          // نقدي
  BANK_TRANSFER // تحويل بنكي
  WALLET        // محفظة إلكترونية
}
```

### 34. escrow_accounts
```prisma
model Escrow {
  id              String    @id @default(cuid())
  escrowNumber    String    @unique
  bookingId       String    @unique
  
  // المبلغ
  amount          Float
  currency        String    @default("SYP")
  platformFee     Float?
  
  // الحالة
  status          EscrowStatus @default(PENDING)
  
  // التواريخ
  fundedAt        DateTime?
  releasedAt      DateTime?
  refundedAt      DateTime?
  
  // التفاصيل
  releaseConditions Json?
  
  createdAt       DateTime  @default(now())
  updatedAt       DateTime  @updatedAt
  
  booking         Booking   @relation(fields: [bookingId], references: [id])
  transactions    EscrowTransaction[]
  
  @@index([bookingId])
  @@index([status])
}

enum EscrowStatus {
  PENDING       // في الانتظار
  FUNDED        // ممول
  RELEASED      // تم الإطلاق
  DISPUTED      // منازعة
  REFUNDED      // مسترد
  PARTIAL       // إطلاق جزئي
}
```

### 35. escrow_transactions
```prisma
model EscrowTransaction {
  id              String    @id @default(cuid())
  escrowId        String
  
  // النوع
  type            EscrowTransactionType
  
  // المبلغ
  amount          Float
  currency        String    @default("SYP")
  
  // الوصف
  description     String?
  
  createdAt       DateTime  @default(now())
  
  escrow          Escrow    @relation(fields: [escrowId], references: [id])
  
  @@index([escrowId])
}

enum EscrowTransactionType {
  DEPOSIT       // إيداع
  RELEASE       // إطلاق
  REFUND        // استرداد
  PARTIAL_RELEASE // إطلاق جزئي
  FEE           // رسوم
}
```

### 36. refunds
```prisma
model Refund {
  id              String    @id @default(cuid())
  refundNumber    String    @unique
  paymentId       String
  
  // المبلغ
  amount          Float
  currency        String    @default("SYP")
  
  // السبب
  reason          String
  description     String?
  
  // الحالة
  status          RefundStatus @default(PENDING)
  
  // التواريخ
  processedAt     DateTime?
  
  createdAt       DateTime  @default(now())
  updatedAt       DateTime  @updatedAt
  
  @@index([paymentId])
  @@index([status])
}

enum RefundStatus {
  PENDING
  PROCESSING
  COMPLETED
  FAILED
}
```

### 37. transactions
```prisma
model Transaction {
  id              String    @id @default(cuid())
  transactionNumber String  @unique
  
  // المستخدم
  userId          String
  
  // النوع
  type            TransactionType
  
  // المبلغ
  amount          Float
  currency        String    @default("SYP")
  fee             Float?
  netAmount       Float
  
  // الحالة
  status          TransactionStatus @default(PENDING)
  
  // المرجع
  referenceType   String?
  referenceId     String?
  
  // التفاصيل
  description     String?
  metadata        Json?
  
  createdAt       DateTime  @default(now())
  updatedAt       DateTime  @updatedAt
  
  @@index([userId])
  @@index([type])
  @@index([status])
}

enum TransactionType {
  PAYMENT       // دفع
  PAYOUT        // صرف
  REFUND        // استرداد
  FEE           // رسوم
  BONUS         // مكافأة
  ADJUSTMENT    // تعديل
}

enum TransactionStatus {
  PENDING
  PROCESSING
  COMPLETED
  FAILED
  CANCELLED
}
```

---

## ⭐ التقييمات (3 جداول)

### 38. reviews
```prisma
model Review {
  id              String    @id @default(cuid())
  reviewNumber    String    @unique
  
  // المستخدمين
  userId          String
  bookingId       String
  listingId       String?
  activityId      String?
  
  // التقييم
  rating          Int       // 1-5
  ratings         Json?     // تقييمات فرعية
  
  // المحتوى
  title           String?
  content         String
  images          String[]?
  
  // الحالة
  status          ReviewStatus @default(PENDING)
  
  // الرد
  reply           String?
  repliedAt       DateTime?
  repliedBy       String?
  
  // التفاعل
  helpfulCount    Int       @default(0)
  
  createdAt       DateTime  @default(now())
  updatedAt       DateTime  @updatedAt
  
  user            User      @relation(fields: [userId], references: [id])
  booking         Booking   @relation(fields: [bookingId], references: [id])
  listing         Listing?  @relation(fields: [listingId], references: [id])
  
  @@index([userId])
  @@index([listingId])
  @@index([bookingId])
  @@index([status])
}

enum ReviewStatus {
  PENDING       // في الانتظار
  APPROVED      // معتمد
  REJECTED      // مرفوض
  HIDDEN        // مخفي
}
```

### 39. review_ratings
```prisma
model ReviewRating {
  id              String    @id @default(cuid())
  reviewId        String
  
  // الفئة
  category        String    // cleanliness, location, value, etc.
  rating          Int       // 1-5
  
  createdAt       DateTime  @default(now())
  
  @@unique([reviewId, category])
  @@index([reviewId])
}
```

### 40. review_helpful
```prisma
model ReviewHelpful {
  id              String    @id @default(cuid())
  reviewId        String
  userId          String
  helpful         Boolean   @default(true)
  
  createdAt       DateTime  @default(now())
  
  @@unique([reviewId, userId])
  @@index([reviewId])
}
```

---

## 👥 المجتمع (5 جداول)

### 41. posts
```prisma
model Post {
  id              String    @id @default(cuid())
  userId          String
  
  // المحتوى
  title           String?
  content         String
  images          String[]?
  video           String?
  
  // التصنيف
  category        String?
  tags            String[]
  
  // الموقع
  location        String?
  
  // التفاعل
  likeCount       Int       @default(0)
  commentCount    Int       @default(0)
  shareCount      Int       @default(0)
  viewCount       Int       @default(0)
  
  // الحالة
  status          ContentStatus @default(PUBLISHED)
  
  createdAt       DateTime  @default(now())
  updatedAt       DateTime  @updatedAt
  
  @@index([userId])
  @@index([category])
  @@index([status])
}
```

### 42. comments
```prisma
model Comment {
  id              String    @id @default(cuid())
  postId          String
  userId          String
  parentId        String?
  
  // المحتوى
  content         String
  images          String[]?
  
  // التفاعل
  likeCount       Int       @default(0)
  
  // الحالة
  status          ContentStatus @default(PUBLISHED)
  
  createdAt       DateTime  @default(now())
  updatedAt       DateTime  @updatedAt
  
  @@index([postId])
  @@index([userId])
  @@index([parentId])
}
```

### 43. likes
```prisma
model Like {
  id              String    @id @default(cuid())
  userId          String
  likeableType    LikeableType
  likeableId      String
  
  createdAt       DateTime  @default(now())
  
  @@unique([userId, likeableType, likeableId])
}

enum LikeableType {
  POST
  COMMENT
  REVIEW
}
```

### 44. groups
```prisma
model Group {
  id              String    @id @default(cuid())
  creatorId       String
  
  // المعلومات
  name            String
  slug            String    @unique
  description     String
  image           String?
  coverImage      String?
  
  // الإعدادات
  isPublic        Boolean   @default(true)
  allowPosting    Boolean   @default(true)
  
  // الأعضاء
  memberCount     Int       @default(0)
  
  // الحالة
  status          ContentStatus @default(PUBLISHED)
  
  createdAt       DateTime  @default(now())
  updatedAt       DateTime  @updatedAt
  
  @@index([creatorId])
  @@index([status])
}
```

### 45. group_members
```prisma
model GroupMember {
  id              String    @id @default(cuid())
  groupId         String
  userId          String
  
  // الدور
  role            GroupRole @default(MEMBER)
  
  // الحالة
  status          MemberStatus @default(ACTIVE)
  
  joinedAt        DateTime  @default(now())
  
  @@unique([groupId, userId])
  @@index([groupId])
  @@index([userId])
}

enum GroupRole {
  ADMIN
  MODERATOR
  MEMBER
}

enum MemberStatus {
  ACTIVE
  BANNED
  LEFT
}
```

---

## 🛒 السوق (4 جداول)

### 46. products
```prisma
model Product {
  id              String    @id @default(cuid())
  sellerId        String
  companyId       String?
  
  // المعلومات
  name            String
  slug            String    @unique
  description     String
  
  // التصنيف
  category        String
  tags            String[]
  
  // السعر
  price           Float
  currency        String    @default("SYP")
  discountPrice   Float?
  
  // المخزون
  stock           Int       @default(0)
  sku             String?
  
  // الصور
  images          String[]
  featuredImage   String?
  
  // الشحن
  weight          Float?
  dimensions      Json?
  freeShipping    Boolean   @default(false)
  
  // التقييم
  avgRating       Float?
  totalReviews    Int       @default(0)
  
  // الحالة
  status          ContentStatus @default(DRAFT)
  
  createdAt       DateTime  @default(now())
  updatedAt       DateTime  @updatedAt
  
  @@index([sellerId])
  @@index([category])
  @@index([status])
}
```

### 47. product_categories
```prisma
model ProductCategory {
  id              String    @id @default(cuid())
  name            String
  nameAr          String
  slug            String    @unique
  parentId        String?
  icon            String?
  order           Int       @default(0)
  
  createdAt       DateTime  @default(now())
  
  parent          ProductCategory? @relation("ProductCategoryHierarchy", fields: [parentId], references: [id])
  children        ProductCategory[] @relation("ProductCategoryHierarchy")
}
```

### 48. orders
```prisma
model Order {
  id              String    @id @default(cuid())
  orderNumber     String    @unique
  buyerId         String
  
  // المبلغ
  subtotal        Float
  shippingCost    Float?
  taxes           Float?
  discount        Float?
  total           Float
  currency        String    @default("SYP")
  
  // الشحن
  shippingAddress Json
  
  // الحالة
  status          OrderStatus @default(PENDING)
  paymentStatus   PaymentStatus @default(PENDING)
  
  // التواريخ
  paidAt          DateTime?
  shippedAt       DateTime?
  deliveredAt     DateTime?
  
  createdAt       DateTime  @default(now())
  updatedAt       DateTime  @updatedAt
  
  @@index([buyerId])
  @@index([status])
}

enum OrderStatus {
  PENDING
  PROCESSING
  SHIPPED
  DELIVERED
  CANCELLED
  RETURNED
}
```

### 49. order_items
```prisma
model OrderItem {
  id              String    @id @default(cuid())
  orderId         String
  productId       String
  
  // التفاصيل
  productName     String
  quantity        Int
  unitPrice       Float
  totalPrice      Float
  
  createdAt       DateTime  @default(now())
  
  @@index([orderId])
  @@index([productId])
}
```

---

## 🎁 العروض والولاء (4 جداول)

### 50. offers
```prisma
model Offer {
  id              String    @id @default(cuid())
  
  // المعلومات
  title           String
  slug            String    @unique
  description     String
  image           String?
  
  // النوع
  type            OfferType
  discountType    DiscountType
  discountValue   Float
  
  // الشروط
  minPurchase     Float?
  maxDiscount     Float?
  
  // التطبيق
  applicableTo    String[]  // listing, activity, tour
  applicableIds   String[]?
  
  // الاستخدام
  usageLimit      Int?
  usageCount      Int       @default(0)
  perUserLimit    Int?
  
  // التواريخ
  startsAt        DateTime
  endsAt          DateTime
  
  // الحالة
  status          ContentStatus @default(DRAFT)
  
  createdAt       DateTime  @default(now())
  updatedAt       DateTime  @updatedAt
  
  @@index([type])
  @@index([status])
}

enum OfferType {
  PROMO_CODE    // كود خصم
  AUTOMATIC     // تلقائي
  FLASH_SALE    // عرض سريع
  SEASONAL      // موسمي
}

enum DiscountType {
  PERCENTAGE    // نسبة مئوية
  FIXED         // مبلغ ثابت
}
```

### 51. promo_codes
```prisma
model PromoCode {
  id              String    @id @default(cuid())
  offerId         String?
  
  // الكود
  code            String    @unique
  
  // الاستخدام
  usageLimit      Int?
  usageCount      Int       @default(0)
  
  // التواريخ
  expiresAt       DateTime?
  
  // الحالة
  active          Boolean   @default(true)
  
  createdAt       DateTime  @default(now())
  
  @@index([code])
}
```

### 52. loyalty_points
```prisma
model LoyaltyTransaction {
  id              String    @id @default(cuid())
  userId          String
  
  // النوع
  type            LoyaltyTransactionType
  
  // النقاط
  points          Int
  balance         Int       // الرصيد بعد العملية
  
  // المرجع
  referenceType   String?
  referenceId     String?
  
  // الوصف
  description     String?
  
  createdAt       DateTime  @default(now())
  
  user            User      @relation(fields: [userId], references: [id])
  
  @@index([userId])
  @@index([type])
}

enum LoyaltyTransactionType {
  EARN          // كسب
  REDEEM        // استبدال
  EXPIRE        // انتهاء
  BONUS         // مكافأة
  ADJUSTMENT    // تعديل
}
```

### 53. user_achievements
```prisma
model UserAchievement {
  id              String    @id @default(cuid())
  userId          String
  achievementId   String
  
  // التقدم
  progress        Int       @default(0)
  target          Int
  completed       Boolean   @default(false)
  
  completedAt     DateTime?
  
  createdAt       DateTime  @default(now())
  updatedAt       DateTime  @updatedAt
  
  @@unique([userId, achievementId])
}

model Achievement {
  id              String    @id @default(cuid())
  name            String
  nameAr          String
  description     String
  icon            String?
  points          Int
  target          Int
  
  createdAt       DateTime  @default(now())
}
```

---

## ⚖️ المنازعات (3 جداول)

### 54. disputes
```prisma
model Dispute {
  id              String    @id @default(cuid())
  disputeNumber   String    @unique
  bookingId       String
  escrowId        String?
  
  // المستخدمين
  openedBy        String    // userId
  againstId       String?   // hostId أو companyId
  
  // النوع
  type            DisputeType
  reason          String
  
  // المحتوى
  description     String
  evidence        String[]  // صور، وثائق
  
  // المبلغ المتنازع عليه
  disputedAmount  Float?
  currency        String    @default("SYP")
  
  // الحالة
  status          DisputeStatus @default(OPENED)
  
  // الحل
  resolution      String?
  resolvedBy      String?
  resolvedAt      DateTime?
  
  createdAt       DateTime  @default(now())
  updatedAt       DateTime  @updatedAt
  
  booking         Booking   @relation(fields: [bookingId], references: [id])
  messages        DisputeMessage[]
  
  @@index([bookingId])
  @@index([status])
}

enum DisputeType {
  LISTING_NOT_AS_DESCRIBED  // غير مطابق للوصف
  CLEANLINESS_ISSUE         // مشكلة نظافة
  AMENITY_ISSUE             // مشكلة مرافق
  HOST_CANCELLATION         // إلغاء من المضيف
  PAYMENT_ISSUE             // مشكلة دفع
  SERVICE_NOT_PROVIDED      // الخدمة لم تُقدم
  OTHER                     // أخرى
}

enum DisputeStatus {
  OPENED        // مفتوحة
  NEGOTIATING   // في المفاوضات
  ESCALATED     // تصعيد
  INVESTIGATING // تحقيق
  RESOLVED      // تم الحل
  CLOSED        // مغلقة
}
```

### 55. dispute_messages
```prisma
model DisputeMessage {
  id              String    @id @default(cuid())
  disputeId       String
  senderId        String
  
  // المحتوى
  message         String
  attachments     String[]?
  
  // النوع
  isInternal      Boolean   @default(false) // للإدارة فقط
  
  createdAt       DateTime  @default(now())
  
  dispute         Dispute   @relation(fields: [disputeId], references: [id])
  
  @@index([disputeId])
}
```

### 56. dispute_resolutions
```prisma
model DisputeResolution {
  id              String    @id @default(cuid())
  disputeId       String
  
  // القرار
  decision        DisputeDecision
  reasoning       String
  
  // المبالغ
  refundAmount    Float?
  hostAmount      Float?
  currency        String    @default("SYP")
  
  // الإجراءات
  actions         Json?     // إجراءات إضافية
  
  resolvedBy      String
  resolvedAt      DateTime  @default(now())
  
  createdAt       DateTime  @default(now())
}

enum DisputeDecision {
  FAVOR_GUEST     // لصالح الضيف
  FAVOR_HOST      // لصالح المضيف
  PARTIAL         // حل وسط
  NO_ACTION       // لا إجراء
}
```

---

## 🔔 الإشعارات (2 جداول)

### 57. notifications
```prisma
model Notification {
  id              String    @id @default(cuid())
  userId          String
  
  // المحتوى
  type            NotificationType
  title           String
  message         String
  image           String?
  
  // الرابط
  link            String?
  
  // البيانات الإضافية
  data            Json?
  
  // الحالة
  read            Boolean   @default(false)
  readAt          DateTime?
  
  createdAt       DateTime  @default(now())
  
  user            User      @relation(fields: [userId], references: [id], onDelete: Cascade)
  
  @@index([userId])
  @@index([read])
  @@index([createdAt])
}

enum NotificationType {
  BOOKING_CREATED
  BOOKING_CONFIRMED
  BOOKING_CANCELLED
  PAYMENT_RECEIVED
  REVIEW_RECEIVED
  MESSAGE_RECEIVED
  DISPUTE_OPENED
  DISPUTE_RESOLVED
  OFFER_AVAILABLE
  SYSTEM_ANNOUNCEMENT
}
```

### 58. notification_preferences
```prisma
model NotificationPreference {
  id              String    @id @default(cuid())
  userId          String
  
  // القنوات
  emailEnabled    Boolean   @default(true)
  pushEnabled     Boolean   @default(true)
  smsEnabled      Boolean   @default(true)
  
  // الأنواع
  bookingEmails   Boolean   @default(true)
  marketingEmails Boolean   @default(false)
  reviewEmails    Boolean   @default(true)
  
  createdAt       DateTime  @default(now())
  updatedAt       DateTime  @updatedAt
  
  @@unique([userId])
}
```

---

## ⚙️ الإعدادات (4 جداول)

### 59. settings
```prisma
model Setting {
  id              String    @id @default(cuid())
  key             String    @unique
  value           Json
  type            SettingType
  description     String?
  public          Boolean   @default(false)
  
  createdAt       DateTime  @default(now())
  updatedAt       DateTime  @updatedAt
  
  @@index([key])
}

enum SettingType {
  STRING
  NUMBER
  BOOLEAN
  JSON
}
```

### 60. translations
```prisma
model Translation {
  id              String    @id @default(cuid())
  key             String
  language        String
  namespace       String?
  value           String
  
  createdAt       DateTime  @default(now())
  updatedAt       DateTime  @updatedAt
  
  @@unique([key, language, namespace])
  @@index([key])
  @@index([language])
}
```

### 61. audit_logs
```prisma
model AuditLog {
  id              String    @id @default(cuid())
  userId          String?
  
  // الفعل
  action          String
  entity          String
  entityId        String?
  
  // البيانات
  oldValue        Json?
  newValue        Json?
  
  // المعلومات
  ipAddress       String?
  userAgent       String?
  
  createdAt       DateTime  @default(now())
  
  @@index([userId])
  @@index([action])
  @@index([entity])
  @@index([createdAt])
}
```

### 62. system_health
```prisma
model SystemHealth {
  id              String    @id @default(cuid())
  
  // المكون
  component       String
  status          HealthStatus
  responseTime    Int?      // milliseconds
  
  // التفاصيل
  message         String?
  metadata        Json?
  
  checkedAt       DateTime  @default(now())
  
  @@index([component])
  @@index([checkedAt])
}

enum HealthStatus {
  HEALTHY
  DEGRADED
  UNHEALTHY
}
```

---

## 🔗 العلاقات الرئيسية

```
┌─────────────────────────────────────────────────────────────────┐
│                     العلاقات الرئيسية                           │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  User ──┬── Profile (1:N)                                      │
│         ├── OAuthAccount (1:N)                                 │
│         ├── Session (1:N)                                      │
│         ├── Booking (1:N)                                      │
│         ├── Review (1:N)                                       │
│         ├── Company (1:N)                                      │
│         ├── Listing (1:N)                                      │
│         ├── Notification (1:N)                                 │
│         └── LoyaltyTransaction (1:N)                           │
│                                                                 │
│  Company ──┬── Employee (1:N)                                  │
│            ├── Listing (1:N)                                   │
│            ├── Service (1:N)                                   │
│            └── MedicalCenter (1:1)                             │
│                                                                 │
│  Listing ──┬── Booking (1:N)                                   │
│            ├── Review (1:N)                                    │
│            └── AvailabilityCalendar (1:N)                      │
│                                                                 │
│  Booking ──┬── Payment (1:N)                                   │
│            ├── Review (1:1)                                    │
│            ├── Dispute (1:1)                                   │
│            └── Escrow (1:1)                                    │
│                                                                 │
│  Destination ──┬── Listing (1:N)                               │
│                └── Activity (1:N)                              │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## 📈 الفهارس (Indexes)

### فهارس الأداء

```sql
-- البحث السريع
CREATE INDEX idx_listings_search ON listings(city, type, status);
CREATE INDEX idx_bookings_search ON bookings(userId, status, checkIn);
CREATE INDEX idx_reviews_search ON reviews(listingId, status);

-- التقارير
CREATE INDEX idx_bookings_date ON bookings(createdAt);
CREATE INDEX idx_payments_date ON payments(createdAt);
CREATE INDEX idx_transactions_date ON transactions(createdAt);

-- الإشعارات
CREATE INDEX idx_notifications_unread ON notifications(userId, read);
```

---

## 🔄 ترحيل البيانات (Migrations)

### ترتيب الإنشاء

1. المستخدمون والشركات
2. الوجهات والإقامات
3. الأنشطة والخدمات
4. الحجوزات
5. المدفوعات والضمان
6. التقييمات والمنازعات
7. المجتمع والسوق
8. العروض والولاء
9. الإعدادات والسجلات

---

*آخر تحديث: 2025*
