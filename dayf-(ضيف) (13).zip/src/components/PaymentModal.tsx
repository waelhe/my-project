import React, { useState, useEffect } from 'react';
import { loadStripe } from '@stripe/stripe-js';
import {
  Elements,
  PaymentElement,
  useStripe,
  useElements,
} from '@stripe/react-stripe-js';
import { X, Loader2, ShieldCheck } from 'lucide-react';
import toast from 'react-hot-toast';

// Initialize Stripe outside of component to avoid recreating the Stripe object on every render
const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY || 'pk_test_placeholder');

interface PaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  amount: number;
  onSuccess: () => void;
  title: string;
}

const CheckoutForm = ({ amount, onSuccess, onClose }: { amount: number, onSuccess: () => void, onClose: () => void }) => {
  const stripe = useStripe();
  const elements = useElements();
  const [isProcessing, setIsProcessing] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!stripe || !elements) {
      return;
    }

    setIsProcessing(true);
    setErrorMessage(null);

    try {
      // Confirm the payment
      const { error, paymentIntent } = await stripe.confirmPayment({
        elements,
        confirmParams: {
          // Make sure to change this to your payment completion page
          return_url: window.location.origin,
        },
        redirect: 'if_required', // We don't want to redirect for this SPA flow
      });

      if (error) {
        setErrorMessage(error.message || 'حدث خطأ غير متوقع.');
        toast.error(error.message || 'فشلت عملية الدفع');
      } else if (paymentIntent && paymentIntent.status === 'succeeded') {
        onSuccess();
      } else {
        setErrorMessage('حالة الدفع غير معروفة.');
      }
    } catch (err: any) {
      console.error('Payment confirmation error:', err);
      setErrorMessage('حدث خطأ أثناء معالجة الدفع.');
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="bg-gray-50 p-4 rounded-xl border border-gray-200 mb-6">
        <div className="flex justify-between items-center mb-2">
          <span className="text-gray-600">المبلغ الإجمالي:</span>
          <span className="text-xl font-bold text-gray-900">${amount}</span>
        </div>
        <div className="flex items-center gap-2 text-xs text-emerald-600 bg-emerald-50 p-2 rounded-lg mt-2">
          <ShieldCheck className="w-4 h-4" />
          <span>دفع آمن ومحمي بواسطة Stripe</span>
        </div>
      </div>

      <PaymentElement id="payment-element" options={{ layout: 'tabs' }} />
      
      {errorMessage && (
        <div className="text-red-500 text-sm mt-2">{errorMessage}</div>
      )}

      <div className="flex gap-3 pt-4 border-t border-gray-100">
        <button
          type="button"
          onClick={onClose}
          disabled={isProcessing}
          className="flex-1 py-3 px-4 bg-gray-100 text-gray-700 font-bold rounded-xl hover:bg-gray-200 transition-colors disabled:opacity-50"
        >
          إلغاء
        </button>
        <button
          type="submit"
          disabled={isProcessing || !stripe || !elements}
          className="flex-1 py-3 px-4 bg-emerald-600 text-white font-bold rounded-xl hover:bg-emerald-700 transition-colors disabled:opacity-50 flex justify-center items-center gap-2"
        >
          {isProcessing ? (
            <>
              <Loader2 className="w-5 h-5 animate-spin" />
              <span>جاري الدفع...</span>
            </>
          ) : (
            `دفع $${amount}`
          )}
        </button>
      </div>
    </form>
  );
};

export default function PaymentModal({ isOpen, onClose, amount, onSuccess, title }: PaymentModalProps) {
  const [clientSecret, setClientSecret] = useState('');
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (isOpen && amount > 0) {
      setIsLoading(true);
      // Fetch PaymentIntent client secret from backend
      fetch('/api/create-payment-intent', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ amount, currency: 'usd' }),
      })
        .then((res) => {
          if (!res.ok) throw new Error('Network response was not ok');
          return res.json();
        })
        .then((data) => {
          if (data.clientSecret) {
            setClientSecret(data.clientSecret);
          } else if (data.error) {
            toast.error(data.error);
            onClose();
          }
        })
        .catch((error) => {
          console.error('Error fetching client secret:', error);
          toast.error('فشل في تهيئة بوابة الدفع. تأكد من إعداد مفاتيح Stripe.');
          onClose();
        })
        .finally(() => {
          setIsLoading(false);
        });
    }
  }, [isOpen, amount, onClose]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
      <div className="bg-white rounded-2xl shadow-xl w-full max-w-md overflow-hidden flex flex-col max-h-[90vh]">
        <div className="flex items-center justify-between p-6 border-b border-gray-100 shrink-0">
          <h2 className="text-xl font-bold text-gray-900">{title}</h2>
          <button
            onClick={onClose}
            className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-full transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 overflow-y-auto flex-1">
          {isLoading ? (
            <div className="flex flex-col items-center justify-center py-12">
              <Loader2 className="w-10 h-10 animate-spin text-emerald-600 mb-4" />
              <p className="text-gray-500">جاري الاتصال ببوابة الدفع الآمنة...</p>
            </div>
          ) : clientSecret ? (
            <Elements options={{ clientSecret, appearance: { theme: 'stripe' } }} stripe={stripePromise}>
              <CheckoutForm amount={amount} onSuccess={onSuccess} onClose={onClose} />
            </Elements>
          ) : (
            <div className="text-center py-8 text-red-500">
              فشل في تحميل نموذج الدفع.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
