import React, { useState, useEffect } from 'react';
import { Search, Globe, User, Menu } from 'lucide-react';
import { motion, useScroll } from 'motion/react';
import { Link, useLocation } from 'react-router-dom';
import { useLanguage } from '../contexts/LanguageContext';
import { useScrollDirection } from '../hooks/useScrollDirection';

export default function Header() {
  const { scrollY } = useScroll();
  const [isExpanded, setIsExpanded] = useState(true);
  const { scrollDirection, isScrolled } = useScrollDirection();
  const location = useLocation();
  const { t, language, setLanguage } = useLanguage();
  const isHome = location.pathname === '/';

  const isMinimized = scrollDirection === 'down' && isScrolled;

  useEffect(() => {
    return scrollY.on('change', (latest) => {
      setIsExpanded(latest <= 0);
    });
  }, [scrollY]);

  const toggleLanguage = () => {
    setLanguage(language === 'ar' ? 'en' : 'ar');
  };

  return (
    <motion.header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isHome && !isScrolled 
          ? 'bg-transparent border-transparent' 
          : 'bg-white/95 backdrop-blur-md border-b border-gray-200 shadow-sm'
      }`}
      initial={{ height: '80px' }}
      animate={{ height: isMinimized ? '52px' : (isExpanded ? '80px' : '64px') }}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-full flex items-center justify-between transition-all duration-300">
        {/* Logo */}
        <Link 
          to="/" 
          className={`font-bold transition-all duration-300 ${
            isHome && !isScrolled ? 'text-white' : 'text-emerald-600'
          } ${isMinimized ? 'text-xl' : 'text-2xl'}`}
        >
          ضيف
        </Link>
        
        {/* Search Bar - Hidden on mobile if not expanded, or simplified */}
        <motion.div
          className={`hidden md:flex items-center gap-0 bg-white border border-gray-200 rounded-full shadow-sm cursor-pointer hover:shadow-md transition-all duration-300 overflow-hidden ${
            isHome && !isScrolled ? 'bg-white/90' : 'bg-white'
          }`}
          animate={{ 
            scale: !isMinimized ? 1 : 0.9,
            opacity: isMinimized ? 0.8 : 1
          }}
        >
          <button className={`px-5 font-semibold hover:bg-gray-50 transition-all duration-300 ${isMinimized ? 'py-1.5 text-xs' : 'py-2.5 text-sm'}`}>
            {t('header.anywhere')}
          </button>
          <div className="h-6 w-[1px] bg-gray-200" />
          <button className={`px-5 font-semibold hover:bg-gray-50 transition-all duration-300 ${isMinimized ? 'py-1.5 text-xs' : 'py-2.5 text-sm'}`}>
            {t('header.any_week')}
          </button>
          <div className="h-6 w-[1px] bg-gray-200" />
          <button className={`px-5 font-medium text-gray-500 hover:bg-gray-50 transition-all duration-300 flex items-center gap-2 ${isMinimized ? 'py-1.5 text-xs' : 'py-2.5 text-sm'}`}>
            {t('header.add_guests')}
            <div className={`bg-emerald-600 text-white rounded-full transition-all duration-300 overflow-hidden flex items-center justify-center ${isMinimized ? 'w-0 h-0 p-0 opacity-0' : 'p-1.5 w-7 h-7 opacity-100'}`}>
              <Search className="w-3.5 h-3.5" />
            </div>
          </button>
        </motion.div>

        {/* Mobile Search Trigger */}
        <div className={`md:hidden flex-1 mx-4 transition-all duration-300 ${isMinimized ? 'max-w-full' : 'max-w-[200px]'}`}>
          <div className={`flex items-center gap-2 bg-white border border-gray-200 rounded-full shadow-sm transition-all duration-300 ${isMinimized ? 'px-3 py-1.5 justify-center' : 'px-3 py-2'}`}>
            <div className={`transition-all duration-300 overflow-hidden flex items-center justify-center ${isMinimized ? 'w-0 opacity-0' : 'w-4 opacity-100'}`}>
              <Search className="w-4 h-4 text-emerald-600" />
            </div>
            <span className={`font-medium text-gray-500 truncate transition-all duration-300 ${isMinimized ? 'text-[11px]' : 'text-xs'}`}>{t('hero.placeholder')}</span>
          </div>
        </div>

        {/* Actions */}
        <div className={`flex items-center transition-all duration-300 overflow-hidden ${isMinimized ? 'w-0 opacity-0 gap-0' : 'w-auto opacity-100 gap-2 sm:gap-4'}`}>
          <Link 
            to="/provider" 
            className={`hidden sm:block text-sm font-semibold px-3 py-2 rounded-full hover:bg-black/5 transition-colors ${
              isHome && !isScrolled ? 'text-white hover:bg-white/10' : 'text-gray-700'
            }`}
          >
            {t('header.host')}
          </Link>
          
          <button 
            onClick={toggleLanguage}
            className={`p-2 rounded-full hover:bg-black/5 transition-colors ${
              isHome && !isScrolled ? 'text-white hover:bg-white/10' : 'text-gray-700'
            }`}
            title={language === 'ar' ? 'English' : 'العربية'}
          >
            <Globe className="w-5 h-5" />
          </button>

          <div className={`flex items-center gap-2 border border-gray-200 rounded-full p-1.5 hover:shadow-md transition-all cursor-pointer ${
            isHome && !isScrolled ? 'bg-white/10 border-white/20 text-white' : 'bg-white text-gray-700'
          }`}>
            <Menu className="w-4 h-4 ms-1" />
            <div className="w-7 h-7 rounded-full bg-gray-500 flex items-center justify-center overflow-hidden">
              <User className="w-4 h-4 text-white" />
            </div>
          </div>
        </div>
      </div>
    </motion.header>
  );
}
