import React, { useEffect } from 'react';
import Hero from '../components/Hero';
import Categories from '../components/Categories';
import ServiceSection from '../components/ServiceSection';
import CommunityHighlights from '../components/CommunityHighlights';
import MarketHighlights from '../components/MarketHighlights';
import { useLanguage } from '../contexts/LanguageContext';
import { seedServices } from '../infrastructure/firebase/serviceService';
import { useAuth } from '../contexts/AuthContext';

export default function Home() {
  const { language } = useLanguage();
  const { user } = useAuth();

  useEffect(() => {
    // Seed services if the database is empty
    // Always use system-initial-seed to bypass provider/admin checks for initial data
    seedServices('system-initial-seed');
  }, []);

  return (
    <main>
      <Hero />
      <Categories />
      
      <div className="pb-12">
        <ServiceSection 
          title={language === 'ar' ? 'أماكن إقامة مميزة' : 'Featured Accommodations'}
          categoryId="tourism"
          filterPopular={true}
          viewAllPath="/category/tourism"
        />

        <ServiceSection 
          title={language === 'ar' ? 'فنادق ومنتجعات' : 'Hotels & Resorts'}
          subtitle={language === 'ar' ? 'مجموعة من الفنادق المستقلة والمختارة بعناية' : 'A curated collection of independent hotels'}
          categoryId="tourism"
          limit={8}
          viewAllPath="/category/tourism"
        />

        <ServiceSection 
          title={language === 'ar' ? 'تجارب فريدة' : 'Unique experiences'}
          categoryId="experiences"
          limit={8}
          viewAllPath="/category/experiences"
        />

        <ServiceSection 
          title={language === 'ar' ? 'خدمات طبية متميزة' : 'Top medical services'}
          subtitle={language === 'ar' ? 'أفضل المراكز الطبية والأطباء في سوريا' : 'The best medical centers and doctors in Syria'}
          categoryId="medical"
          limit={8}
          viewAllPath="/category/medical"
        />

        <ServiceSection 
          title={language === 'ar' ? 'فرص عقارية' : 'Real Estate Opportunities'}
          subtitle={language === 'ar' ? 'اكتشف أفضل العقارات المتاحة للبيع والإيجار' : 'Discover the best properties available for sale and rent'}
          categoryId="realestate"
          limit={8}
          viewAllPath="/category/realestate"
        />

        <ServiceSection 
          title={language === 'ar' ? 'خدمات الأعمال' : 'Business Services'}
          subtitle={language === 'ar' ? 'حلول احترافية لنمو أعمالك' : 'Professional solutions for your business growth'}
          categoryId="business"
          limit={8}
          viewAllPath="/category/business"
        />

        <ServiceSection 
          title={language === 'ar' ? 'تعليم وتدريب' : 'Education & Training'}
          subtitle={language === 'ar' ? 'طور مهاراتك مع أفضل الخبراء' : 'Develop your skills with the best experts'}
          categoryId="education"
          limit={8}
          viewAllPath="/category/education"
        />

        <MarketHighlights />
        <CommunityHighlights />
      </div>
    </main>
  );
}
