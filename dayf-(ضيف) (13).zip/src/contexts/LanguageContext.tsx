import React, { createContext, useContext, useState, useEffect } from 'react';

type Language = 'ar' | 'en';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const translations = {
  ar: {
    'nav.tourism': 'السياحة',
    'nav.medical': 'العلاج',
    'nav.education': 'الدراسة',
    'nav.business': 'الأعمال',
    'nav.community': 'المجتمع',
    'nav.marketplace': 'السوق',
    'nav.services': 'الخدمات',
    'nav.home': 'الرئيسية',
    'nav.profile': 'حسابي',
    'nav.dashboard': 'لوحة التحكم',
    'nav.my_bookings': 'حجوزاتي',
    'nav.login': 'تسجيل الدخول',
    'nav.logout': 'تسجيل الخروج',
    'hero.title': 'اكتشف سحر سوريا مع ضيف',
    'hero.subtitle': 'منصة متكاملة للسياحة، العلاج، الدراسة، وفرص الأعمال. خطط لرحلتك القادمة بكل سهولة وأمان.',
    'hero.smart_travel': 'الجيل الجديد من السفر الذكي في سوريا',
    'hero.search': 'بحث',
    'hero.ai_search': 'بحث بذكاء',
    'hero.ai_placeholder': 'أريد فندق رخيص في دمشق القديمة...',
    'hero.destination': 'الوجهة',
    'hero.date': 'التاريخ',
    'hero.guests': 'الضيوف',
    'hero.guest_unit': 'ضيف',
    'hero.guests_unit': 'ضيوف',
    'hero.placeholder': 'إلى أين تريد الذهاب؟',
    'hero.tab.tourism': 'السياحة',
    'hero.tab.medical': 'العلاج',
    'hero.tab.education': 'الدراسة',
    'hero.tab.business': 'الأعمال',
    'hero.tab.ai': 'بحث ذكي',
    'header.anywhere': 'أي مكان',
    'header.any_week': 'أي أسبوع',
    'header.add_guests': 'إضافة ضيوف',
    'header.host': 'استضافة',
    'coming_soon': 'سيتم تفعيل هذه الميزة قريباً',
    'featured.title': 'إقامات وخدمات مميزة',
    'featured.subtitle': 'اكتشف أفضل العروض والخدمات الموصى بها في جميع أنحاء سوريا',
    'featured.view_all': 'عرض الكل',
    'categories.title': 'استكشف حسب الفئة',
    'categories.subtitle': 'اختر الفئة التي تناسب احتياجاتك لتبدأ رحلتك',
  },
  en: {
    'nav.tourism': 'Tourism',
    'nav.medical': 'Medical',
    'nav.education': 'Education',
    'nav.business': 'Business',
    'nav.community': 'Community',
    'nav.marketplace': 'Marketplace',
    'nav.services': 'Services',
    'nav.home': 'Home',
    'nav.profile': 'Profile',
    'nav.dashboard': 'Dashboard',
    'nav.my_bookings': 'My Bookings',
    'nav.login': 'Login',
    'nav.logout': 'Logout',
    'hero.title': 'Discover the Magic of Syria with Dayf',
    'hero.subtitle': 'A comprehensive platform for tourism, medical, education, and business services. Plan your next trip with ease and safety.',
    'hero.smart_travel': 'The next generation of smart travel in Syria',
    'hero.search': 'Search',
    'hero.ai_search': 'AI Search',
    'hero.ai_placeholder': 'I want a cheap hotel in Old Damascus...',
    'hero.destination': 'Destination',
    'hero.date': 'Date',
    'hero.guests': 'Guests',
    'hero.guest_unit': 'Guest',
    'hero.guests_unit': 'Guests',
    'hero.placeholder': 'Where do you want to go?',
    'hero.tab.tourism': 'Tourism',
    'hero.tab.medical': 'Medical',
    'hero.tab.education': 'Education',
    'hero.tab.business': 'Business',
    'hero.tab.ai': 'AI Search',
    'header.anywhere': 'Anywhere',
    'header.any_week': 'Any week',
    'header.add_guests': 'Add guests',
    'header.host': 'Host',
    'coming_soon': 'This feature will be available soon',
    'featured.title': 'Featured Stays & Services',
    'featured.subtitle': 'Discover the best recommended offers and services across Syria',
    'featured.view_all': 'View All',
    'categories.title': 'Explore by Category',
    'categories.subtitle': 'Choose the category that fits your needs to start your journey',
  }
};

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export function LanguageProvider({ children }: { children: React.ReactNode }) {
  const [language, setLanguage] = useState<Language>(() => {
    const saved = localStorage.getItem('language');
    return (saved as Language) || 'ar';
  });

  useEffect(() => {
    localStorage.setItem('language', language);
    document.documentElement.dir = language === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.lang = language;
  }, [language]);

  const t = (key: string) => {
    return translations[language][key as keyof typeof translations['ar']] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
}
