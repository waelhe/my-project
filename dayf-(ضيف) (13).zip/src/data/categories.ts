import { Plane, HeartPulse, GraduationCap, Briefcase } from 'lucide-react';

export const MAIN_CATEGORIES = [
  {
    id: 'tourism',
    name: 'السياحة',
    description: 'اكتشف جمال سوريا، تاريخها العريق، وطبيعتها الساحرة',
    icon: Plane,
    color: 'emerald',
    image: 'https://images.unsplash.com/photo-1585076641394-6302f23b7b65?q=80&w=1200&h=400&fit=crop',
    subCategories: [
      { 
        id: 'recreational', 
        name: 'ترفيهية واستجمام', 
        icon: '🏖️',
        subCategories: [
          { id: 'destinations', name: 'الوجهات' },
          { id: 'stays', name: 'الإقامات' },
          { id: 'activities', name: 'الأنشطة' },
          { id: 'services', name: 'الخدمات' }
        ]
      },
      { 
        id: 'cultural', 
        name: 'ثقافية وتاريخية', 
        icon: '🏛️',
        subCategories: [
          { id: 'landmarks', name: 'المعالم' },
          { id: 'services', name: 'الخدمات' },
          { id: 'workshops', name: 'الورش' }
        ]
      },
      { 
        id: 'religious', 
        name: 'دينية وروحانية', 
        icon: '🕌',
        subCategories: [
          { id: 'landmarks', name: 'المعالم' },
          { id: 'services', name: 'الخدمات' },
          { id: 'programs', name: 'البرامج' }
        ]
      },
      { 
        id: 'nature', 
        name: 'طبيعية ومغامرة', 
        icon: '🏔️',
        subCategories: [
          { id: 'landmarks', name: 'المعالم' },
          { id: 'activities', name: 'الأنشطة' },
          { id: 'adventures', name: 'المغامرات' }
        ]
      }
    ]
  },
  {
    id: 'medical',
    name: 'العلاج',
    description: 'رعاية صحية متميزة، أطباء خبراء، ومراكز طبية متقدمة',
    icon: HeartPulse,
    color: 'blue',
    image: 'https://images.unsplash.com/photo-1505751172107-573967a4f22a?q=80&w=1200&h=400&fit=crop',
    subCategories: [
      { 
        id: 'medical', 
        name: 'رعاية طبية', 
        icon: '🏥',
        subCategories: [
          { id: 'hospitals', name: 'مستشفيات' },
          { id: 'surgeries', name: 'عمليات جراحية' },
          { id: 'specialized', name: 'علاجات متخصصة' },
          { id: 'diagnosis', name: 'تشخيص ومتابعة' }
        ]
      },
      { 
        id: 'dental', 
        name: 'طب الأسنان', 
        icon: '🦷',
        subCategories: [
          { id: 'clinics', name: 'عيادات متخصصة' },
          { id: 'cosmetic', name: 'تجميل الأسنان' },
          { id: 'implants', name: 'زراعة وتقويم' },
          { id: 'whitening', name: 'تبييض وحشوات' }
        ]
      },
      { 
        id: 'eye', 
        name: 'طب العيون', 
        icon: '👁️',
        subCategories: [
          { id: 'centers', name: 'مراكز دولية' },
          { id: 'lasik', name: 'عمليات الليزر' },
          { id: 'lenses', name: 'عدسات وعلاجات' },
          { id: 'exams', name: 'فحوصات شاملة' }
        ]
      },
      { 
        id: 'alternative', 
        name: 'طب بديل واستشفاء', 
        icon: '🌿',
        subCategories: [
          { id: 'herbal', name: 'مراكز أعشاب' },
          { id: 'natural', name: 'حجامة وعلاجات طبيعية' },
          { id: 'spa', name: 'استشفاء وسبا صحي' },
          { id: 'yoga', name: 'يوغا وتأمل' }
        ]
      },
      {
        id: 'foreign_patients',
        name: 'خدمات المرضى الأجانب',
        icon: '🛠️',
        subCategories: [
          { id: 'arrangements', name: 'ترتيبات العلاج' },
          { id: 'transport', name: 'نقل ومواصلات' },
          { id: 'translation', name: 'ترجمة طبية' },
          { id: 'visas', name: 'تأشيرات علاجية' },
          { id: 'recovery', name: 'إقامة وتعافي' }
        ]
      }
    ]
  },
  {
    id: 'education',
    name: 'الدراسة',
    description: 'جامعات عريقة، معاهد متخصصة، وبرامج تعليمية شاملة',
    icon: GraduationCap,
    color: 'amber',
    image: 'https://images.unsplash.com/photo-1541339907198-e08756ebafe3?q=80&w=1200&h=400&fit=crop',
    subCategories: [
      { 
        id: 'university', 
        name: 'تعليم جامعي', 
        icon: '🎓',
        subCategories: [
          { id: 'public', name: 'جامعات حكومية' },
          { id: 'degrees', name: 'بكالوريوس وماجستير' },
          { id: 'specialties', name: 'تخصصات متنوعة' },
          { id: 'registration', name: 'قبول وتسجيل' }
        ]
      },
      { 
        id: 'vocational', 
        name: 'تأهيل مهني', 
        icon: '📜',
        subCategories: [
          { id: 'technical', name: 'معاهد تقنية' },
          { id: 'training', name: 'دورات تأهيل' },
          { id: 'certificates', name: 'شهادات مهنية' },
          { id: 'workshops', name: 'ورش تدريبية' }
        ]
      },
      { 
        id: 'languages', 
        name: 'تعلم اللغات', 
        icon: '🗣️',
        subCategories: [
          { id: 'arabic', name: 'العربية للأجانب' },
          { id: 'english', name: 'الإنجليزية' },
          { id: 'other', name: 'لغات أخرى' },
          { id: 'immersion', name: 'محادثة وانغماس' }
        ]
      },
      { 
        id: 'arts', 
        name: 'حرف وفنون', 
        icon: '🎨',
        subCategories: [
          { id: 'crafts', name: 'ورش حرفية' },
          { id: 'traditional', name: 'فنون تقليدية' },
          { id: 'design', name: 'تصميم وإبداع' },
          { id: 'heritage', name: 'تراث وحرف يدوية' }
        ]
      },
      {
        id: 'foreign_students',
        name: 'خدمات الطلاب الأجانب',
        icon: '🛠️',
        subCategories: [
          { id: 'visas', name: 'تأشيرات طالب' },
          { id: 'housing', name: 'سكن طلابي' },
          { id: 'insurance', name: 'تأمين صحي' },
          { id: 'transport', name: 'تنقلات' },
          { id: 'support', name: 'دعم أكاديمي' }
        ]
      }
    ]
  },
  {
    id: 'business',
    name: 'الأعمال',
    description: 'فرص استثمارية، شراكات استراتيجية، وخدمات أعمال متكاملة',
    icon: Briefcase,
    color: 'purple',
    image: 'https://images.unsplash.com/photo-1497366216548-37526070297c?q=80&w=1200&h=400&fit=crop',
    subCategories: [
      { 
        id: 'investment', 
        name: 'فرص استثمارية', 
        icon: '💰',
        subCategories: [
          { id: 'realestate', name: 'عقارات' },
          { id: 'tourism', name: 'سياحي' },
          { id: 'industrial', name: 'صناعي' },
          { id: 'commercial', name: 'تجاري' }
        ]
      },
      { 
        id: 'partnerships', 
        name: 'شراكات تجارية', 
        icon: '🤝',
        subCategories: [
          { id: 'commercial', name: 'شراكات تجارية' },
          { id: 'industrial', name: 'شراكات صناعية' },
          { id: 'services', name: 'شراكات خدمات' },
          { id: 'opportunities', name: 'فرص مشتركة' }
        ]
      },
      { 
        id: 'conferences', 
        name: 'مؤتمرات ومعارض', 
        icon: '📅',
        subCategories: [
          { id: 'trade', name: 'معارض تجارية' },
          { id: 'economic', name: 'مؤتمرات اقتصادية' },
          { id: 'workshops', name: 'ورش عمل' },
          { id: 'networking', name: 'فعاليات التواصل' }
        ]
      },
      { 
        id: 'services', 
        name: 'خدمات أعمال', 
        icon: '🏢',
        subCategories: [
          { id: 'offices', name: 'مكاتب مؤقتة' },
          { id: 'meetings', name: 'قاعات اجتماعات' },
          { id: 'legal', name: 'استشارات قانونية' },
          { id: 'feasibility', name: 'دراسات جدوى' },
          { id: 'translation', name: 'ترجمة معتمدة' },
          { id: 'government', name: 'تسهيلات حكومية' }
        ]
      }
    ]
  }
];
