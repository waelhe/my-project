import { useState, useEffect } from 'react';

export function useScrollDirection() {
  const [scrollDirection, setScrollDirection] = useState<'up' | 'down'>('up');
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    let lastScrollY = window.scrollY;

    const updateScrollDirection = () => {
      const scrollY = window.scrollY;
      
      if (scrollY !== lastScrollY) {
        const direction = scrollY > lastScrollY ? 'down' : 'up';
        setScrollDirection(prev => prev !== direction ? direction : prev);
      }
      
      setIsScrolled(prev => prev !== (scrollY > 0) ? (scrollY > 0) : prev);
      lastScrollY = scrollY > 0 ? scrollY : 0;
    };

    window.addEventListener('scroll', updateScrollDirection, { passive: true });
    return () => window.removeEventListener('scroll', updateScrollDirection);
  }, []);

  return { scrollDirection, isScrolled };
}
