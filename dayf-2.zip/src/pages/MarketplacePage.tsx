import React, { useState, useEffect } from 'react';
import { ShoppingBag, MapPin, Star, Filter, Search, ShoppingCart } from 'lucide-react';
import { motion } from 'framer-motion';
import { useLanguage } from '../contexts/LanguageContext';
import toast from 'react-hot-toast';
import { marketplaceService } from '../infrastructure/firebase/marketplaceService';
import { Product } from '../features/marketplace/types';

const CATEGORIES = [
  { id: 'all', name: 'الكل' },
  { id: 'sweets', name: 'حلويات شامية' },
  { id: 'soap', name: 'صابون غار' },
  { id: 'spices', name: 'بهارات وتوابل' },
  { id: 'crafts', name: 'صناعات يدوية' },
  { id: 'textiles', name: 'أقمشة ومطرزات' },
];

export default function MarketplacePage() {
  const { t } = useLanguage();
  const [activeCategory, setActiveCategory] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const data = await marketplaceService.getProducts();
        setProducts(data);
      } catch (error) {
        console.error('Error fetching products:', error);
        toast.error('حدث خطأ أثناء تحميل المنتجات');
      } finally {
        setLoading(false);
      }
    };
    fetchProducts();
  }, []);

  const filteredProducts = products.filter(product => {
    const matchesCategory = activeCategory === 'all' || product.category === activeCategory;
    const matchesSearch = product.name.includes(searchQuery) || product.description.includes(searchQuery) || product.location.includes(searchQuery);
    return matchesCategory && matchesSearch;
  });

  const handleAddToCart = () => {
    toast.success('تمت الإضافة إلى سلة التسوق');
  };

  return (
    <div className="min-h-screen bg-gray-50 pt-24 pb-12">
      {/* Header */}
      <div className="bg-emerald-600 text-white py-12 mb-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div>
              <h1 className="text-3xl md:text-4xl font-bold mb-4 flex items-center gap-3">
                <ShoppingBag className="w-8 h-8" />
                سوق ضيف
              </h1>
              <p className="text-emerald-100 text-lg max-w-2xl">
                اكتشف وتسوق أفضل المنتجات المحلية السورية. من الحلويات الشامية إلى الصناعات اليدوية العريقة، تصلك أينما كنت.
              </p>
            </div>
            <div className="bg-white/10 p-4 rounded-2xl backdrop-blur-sm border border-white/20 flex items-center gap-4">
              <div className="flex flex-col items-center justify-center bg-white/20 w-16 h-16 rounded-xl">
                <ShoppingCart className="w-6 h-6 mb-1" />
                <span className="text-xs font-bold">السلة (0)</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col lg:flex-row gap-8">
          
          {/* Sidebar / Filters */}
          <div className="w-full lg:w-1/4">
            <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 sticky top-24">
              <h3 className="text-lg font-bold text-gray-900 mb-4 flex items-center gap-2">
                <Filter className="w-5 h-5 text-emerald-600" />
                تصفية المنتجات
              </h3>
              
              {/* Search */}
              <div className="relative mb-6">
                <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <input 
                  type="text"
                  placeholder="ابحث عن منتج..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-4 pr-10 py-2 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 transition-all"
                />
              </div>

              {/* Categories */}
              <div className="space-y-2">
                <h4 className="font-semibold text-gray-700 mb-3">التصنيفات</h4>
                {CATEGORIES.map(category => (
                  <button
                    key={category.id}
                    onClick={() => setActiveCategory(category.id)}
                    className={`w-full text-right px-4 py-2 rounded-xl text-sm transition-colors ${
                      activeCategory === category.id
                        ? 'bg-emerald-50 text-emerald-700 font-bold'
                        : 'text-gray-600 hover:bg-gray-50'
                    }`}
                  >
                    {category.name}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Products Grid */}
          <div className="w-full lg:w-3/4">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-gray-900">
                {activeCategory === 'all' ? 'جميع المنتجات' : CATEGORIES.find(c => c.id === activeCategory)?.name}
              </h2>
              <span className="text-gray-500 text-sm">{filteredProducts.length} منتج</span>
            </div>

            {loading ? (
              <div className="bg-white rounded-2xl p-12 text-center border border-gray-100">
                <p>جاري تحميل المنتجات...</p>
              </div>
            ) : filteredProducts.length === 0 ? (
              <div className="bg-white rounded-2xl p-12 text-center border border-gray-100">
                <ShoppingBag className="w-12 h-12 text-gray-300 mx-auto mb-4" />
                <h3 className="text-lg font-bold text-gray-900 mb-2">لا توجد منتجات</h3>
                <p className="text-gray-500">لم نتمكن من العثور على منتجات تطابق بحثك.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                {filteredProducts.map((product, index) => (
                  <motion.div
                    key={product.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.05 }}
                    className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden hover:shadow-md transition-shadow group flex flex-col"
                  >
                    <div className="relative h-48 overflow-hidden">
                      <img 
                        src={product.image} 
                        alt={product.name} 
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                        referrerPolicy="no-referrer"
                      />
                      <div className="absolute top-3 right-3 bg-white/90 backdrop-blur-sm px-2 py-1 rounded-lg text-xs font-bold text-emerald-700 flex items-center gap-1">
                        <MapPin className="w-3 h-3" />
                        {product.location}
                      </div>
                    </div>
                    
                    <div className="p-5 flex flex-col flex-1">
                      <div className="flex justify-between items-start mb-2">
                        <h3 className="font-bold text-gray-900 text-lg line-clamp-1">{product.name}</h3>
                      </div>
                      
                      <p className="text-gray-500 text-sm mb-4 line-clamp-2 flex-1">
                        {product.description}
                      </p>
                      
                      <div className="flex items-center gap-2 mb-4 text-sm">
                        <div className="flex items-center text-amber-500">
                          <Star className="w-4 h-4 fill-current" />
                          <span className="mr-1 font-bold">{product.rating}</span>
                        </div>
                        <span className="text-gray-400">({product.reviews})</span>
                        <span className="text-gray-300 mx-1">•</span>
                        <span className="text-gray-600 text-xs">{product.vendor}</span>
                      </div>
                      
                      <div className="flex items-center justify-between mt-auto pt-4 border-t border-gray-50">
                        <span className="font-bold text-emerald-600 text-lg">
                          {product.price.toLocaleString('ar-SA')} ل.س
                        </span>
                        <button 
                          onClick={handleAddToCart}
                          className="bg-gray-900 text-white px-4 py-2 rounded-xl text-sm font-bold hover:bg-gray-800 transition-colors flex items-center gap-2"
                        >
                          إضافة
                        </button>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            )}
          </div>
          
        </div>
      </div>
    </div>
  );
}
