import React from 'react';
import Hero from '../components/Hero';
import MobileCategoryBar from '../components/MobileCategoryBar';
import Categories from '../components/Categories';
import Featured from '../components/Featured';
import CommunityHighlights from '../components/CommunityHighlights';
import MarketHighlights from '../components/MarketHighlights';

export default function Home() {
  return (
    <main>
      <Hero />
      <MobileCategoryBar />
      <Categories />
      <Featured />
      <MarketHighlights />
      <CommunityHighlights />
    </main>
  );
}
