import React, { useState, useEffect } from 'react';
import { Search, MapPin, Calendar, Users, Briefcase, Stethoscope, GraduationCap, Plane, Sparkles, ChevronRight, ChevronLeft } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';

const TABS = [
  { id: 'tourism', label: 'السياحة', icon: Plane },
  { id: 'medical', label: 'العلاج', icon: Stethoscope },
  { id: 'education', label: 'الدراسة', icon: GraduationCap },
  { id: 'business', label: 'الأعمال', icon: Briefcase },
  { id: 'ai', label: 'بحث ذكي', icon: Sparkles },
];

const SYRIA_REGIONS = [
  {
    id: 'damascus',
    name: 'دمشق القديمة',
    description: 'أقدم عاصمة مأهولة في التاريخ',
    image: 'https://images.unsplash.com/photo-1585076641394-6302f23b7b65?ixlib=rb-4.0.3&auto=format&fit=crop&w=2000&q=80'
  },
  {
    id: 'aleppo',
    name: 'قلعة حلب',
    description: 'رمز الصمود والتاريخ العريق',
    image: 'https://images.unsplash.com/photo-1615811361523-6bd03d7748e7?ixlib=rb-4.0.3&auto=format&fit=crop&w=2000&q=80'
  },
  {
    id: 'palmyra',
    name: 'تدمر',
    description: 'عروس البادية ولؤلؤة الصحراء',
    image: 'https://images.unsplash.com/photo-1503917988258-f87a78e3c995?ixlib=rb-4.0.3&auto=format&fit=crop&w=2000&q=80'
  },
  {
    id: 'latakia',
    name: 'اللاذقية',
    description: 'سحر البحر والجبل',
    image: 'https://images.unsplash.com/photo-1598335624134-490024f82661?ixlib=rb-4.0.3&auto=format&fit=crop&w=2000&q=80'
  },
  {
    id: 'tartus',
    name: 'طرطوس',
    description: 'جمال الساحل السوري وجزيرة أرواد',
    image: 'https://images.unsplash.com/photo-1565674484010-47a339784945?ixlib=rb-4.0.3&auto=format&fit=crop&w=2000&q=80'
  }
];

export default function Hero() {
  const [activeTab, setActiveTab] = useState('tourism');
  const [aiQuery, setAiQuery] = useState('');
  const [location, setLocation] = useState('');
  const [date, setDate] = useState('');
  const [guests, setGuests] = useState(1);
  const [currentRegionIndex, setCurrentRegionIndex] = useState(0);
  const navigate = useNavigate();

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentRegionIndex((prev) => (prev + 1) % SYRIA_REGIONS.length);
    }, 6000);
    return () => clearInterval(timer);
  }, []);

  const handleAISearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!aiQuery.trim()) return;
    navigate(`/category/tourism?ai_query=${encodeURIComponent(aiQuery)}`);
  };

  const handleSearch = () => {
    const params = new URLSearchParams();
    if (location) params.set('search', location);
    if (date) params.set('date', date);
    if (guests > 1) params.set('guests', guests.toString());
    
    navigate(`/category/${activeTab}?${params.toString()}`);
  };

  const nextRegion = () => {
    setCurrentRegionIndex((prev) => (prev + 1) % SYRIA_REGIONS.length);
  };

  const prevRegion = () => {
    setCurrentRegionIndex((prev) => (prev - 1 + SYRIA_REGIONS.length) % SYRIA_REGIONS.length);
  };

  return (
    <div className="relative pt-32 pb-20 lg:pt-48 lg:pb-32 overflow-hidden min-h-[80vh] flex items-center">
      {/* Background Image Slideshow */}
      <div className="absolute inset-0 z-0">
        <AnimatePresence mode="wait">
          <motion.img
            key={SYRIA_REGIONS[currentRegionIndex].id}
            src={SYRIA_REGIONS[currentRegionIndex].image}
            alt={SYRIA_REGIONS[currentRegionIndex].name}
            initial={{ opacity: 0, scale: 1.1 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            transition={{ duration: 1.5, ease: "easeInOut" }}
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
        </AnimatePresence>
        <div className="absolute inset-0 bg-gradient-to-b from-black/70 via-black/40 to-white"></div>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center w-full">
        <div className="mb-12">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-4xl md:text-7xl font-bold text-white mb-6 tracking-tight"
          >
            اكتشف سحر سوريا مع <span className="text-emerald-400">ضيف</span>
          </motion.h1>
          
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="text-lg md:text-2xl text-gray-200 mb-8 max-w-3xl mx-auto font-medium"
          >
            منصة متكاملة للسياحة، العلاج، الدراسة، وفرص الأعمال. خطط لرحلتك القادمة بكل سهولة وأمان.
          </motion.p>

          {/* Region Indicator */}
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="inline-flex items-center gap-4 bg-black/30 backdrop-blur-md border border-white/20 rounded-full px-6 py-2 text-white mb-8"
          >
            <button onClick={prevRegion} className="hover:text-emerald-400 transition-colors">
              <ChevronRight className="w-5 h-5" />
            </button>
            <div className="flex flex-col items-center min-w-[150px]">
              <AnimatePresence mode="wait">
                <motion.div
                  key={SYRIA_REGIONS[currentRegionIndex].id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className="text-center"
                >
                  <span className="block font-bold text-emerald-400">{SYRIA_REGIONS[currentRegionIndex].name}</span>
                  <span className="block text-xs text-gray-300">{SYRIA_REGIONS[currentRegionIndex].description}</span>
                </motion.div>
              </AnimatePresence>
            </div>
            <button onClick={nextRegion} className="hover:text-emerald-400 transition-colors">
              <ChevronLeft className="w-5 h-5" />
            </button>
          </motion.div>
        </div>

        {/* Search Widget */}
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="bg-white/95 backdrop-blur-sm rounded-3xl shadow-2xl p-4 md:p-6 max-w-5xl mx-auto relative overflow-hidden"
        >
          {activeTab === 'ai' && (
            <div className="absolute inset-0 bg-gradient-to-r from-emerald-50 via-teal-50 to-emerald-50 opacity-50 pointer-events-none"></div>
          )}
          
          {/* Tabs */}
          <div className="flex overflow-x-auto pb-4 mb-4 border-b border-gray-100 gap-2 md:gap-8 justify-start md:justify-center hide-scrollbar relative z-10 -mx-4 px-4 sm:mx-0 sm:px-0">
            {TABS.map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              const isAI = tab.id === 'ai';
              
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center gap-2 px-4 py-2 rounded-full whitespace-nowrap transition-all shrink-0 ${
                    isActive 
                      ? isAI ? 'bg-gradient-to-r from-emerald-500 to-teal-500 text-white font-bold shadow-md' : 'bg-emerald-100 text-emerald-700 font-bold' 
                      : 'text-gray-500 hover:text-gray-900 hover:bg-gray-50 font-medium'
                  }`}
                >
                  <Icon className={`w-5 h-5 ${isActive && !isAI ? 'text-emerald-600' : ''} ${isAI && !isActive ? 'text-emerald-500' : ''}`} />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>

          {/* Search Fields */}
          <div className="relative z-10">
            <AnimatePresence mode="wait">
              {activeTab === 'ai' ? (
                <motion.form 
                  key="ai-search"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  onSubmit={handleAISearch}
                  className="flex flex-col md:flex-row gap-4 items-center"
                >
                  <div className="flex-1 w-full flex items-center gap-3 p-4 border-2 border-emerald-200 rounded-xl bg-white focus-within:border-emerald-500 focus-within:ring-4 focus-within:ring-emerald-50 transition-all shadow-inner">
                    <Sparkles className="w-6 h-6 text-emerald-500 animate-pulse" />
                    <input 
                      type="text" 
                      value={aiQuery}
                      onChange={(e) => setAiQuery(e.target.value)}
                      placeholder="مثال: أريد فندق رخيص في دمشق القديمة مع مسبح وواي فاي..." 
                      className="w-full bg-transparent outline-none text-gray-900 font-medium placeholder-gray-400 text-lg"
                      dir="rtl"
                    />
                  </div>
                  <button 
                    type="submit"
                    disabled={!aiQuery.trim()}
                    className="w-full md:w-auto bg-gradient-to-r from-emerald-600 to-teal-600 text-white px-8 py-4 rounded-xl hover:from-emerald-700 hover:to-teal-700 transition-all flex items-center justify-center gap-2 font-bold text-lg disabled:opacity-50 shadow-md"
                  >
                    <Sparkles className="w-5 h-5" />
                    <span>ابحث بذكاء</span>
                  </button>
                </motion.form>
              ) : (
                <motion.div 
                  key="normal-search"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className="grid grid-cols-1 md:grid-cols-4 gap-4 items-center"
                >
                  <div className="flex items-center gap-3 p-3 border border-gray-200 rounded-xl hover:border-emerald-500 transition-colors cursor-text bg-white">
                    <MapPin className="w-5 h-5 text-emerald-600" />
                    <div className="flex flex-col text-right w-full">
                      <span className="text-xs text-gray-500 font-medium">الوجهة</span>
                      <input 
                        type="text" 
                        value={location}
                        onChange={(e) => setLocation(e.target.value)}
                        placeholder="إلى أين تريد الذهاب؟" 
                        className="w-full bg-transparent outline-none text-gray-900 font-medium placeholder-gray-400"
                      />
                    </div>
                  </div>

                  <div className="flex items-center gap-3 p-3 border border-gray-200 rounded-xl hover:border-emerald-500 transition-colors cursor-pointer bg-white">
                    <Calendar className="w-5 h-5 text-emerald-600" />
                    <div className="flex flex-col text-right w-full">
                      <span className="text-xs text-gray-500 font-medium">التاريخ</span>
                      <input 
                        type="date"
                        value={date}
                        onChange={(e) => setDate(e.target.value)}
                        className="w-full bg-transparent outline-none text-gray-900 font-medium placeholder-gray-400"
                      />
                    </div>
                  </div>

                  <div className="flex items-center gap-3 p-3 border border-gray-200 rounded-xl hover:border-emerald-500 transition-colors cursor-pointer bg-white">
                    <Users className="w-5 h-5 text-emerald-600" />
                    <div className="flex flex-col text-right w-full">
                      <span className="text-xs text-gray-500 font-medium">الضيوف</span>
                      <select 
                        value={guests}
                        onChange={(e) => setGuests(Number(e.target.value))}
                        className="w-full bg-transparent outline-none text-gray-900 font-medium appearance-none"
                      >
                        {[1, 2, 3, 4, 5, 6, 7, 8].map(n => (
                          <option key={n} value={n}>{n} {n === 1 ? 'شخص' : 'أشخاص'}</option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <button 
                    onClick={handleSearch}
                    className="bg-emerald-600 text-white p-4 rounded-xl hover:bg-emerald-700 transition-colors flex items-center justify-center gap-2 font-bold text-lg h-full shadow-md"
                  >
                    <Search className="w-5 h-5" />
                    <span>بحث</span>
                  </button>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
