import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Search, Heart, Map, MessageSquare, User, ShoppingBag, Users } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

export default function BottomNav() {
  const location = useLocation();
  const { t } = useLanguage();

  const navItems = [
    {
      label: t('nav.tourism'),
      icon: Search,
      path: '/',
    },
    {
      label: 'السوق',
      icon: ShoppingBag,
      path: '/marketplace',
    },
    {
      label: t('nav.community'),
      icon: Users,
      path: '/community',
    },
    {
      label: t('nav.my_bookings'),
      icon: Heart,
      path: '/my-bookings',
    },
    {
      label: 'حسابي',
      icon: User,
      path: '/profile',
    },
  ];

  return (
    <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-100 px-2 py-1 z-50 shadow-[0_-4px_10px_rgba(0,0,0,0.05)]">
      <div className="flex justify-around items-center">
        {navItems.map((item) => {
          const isActive = location.pathname === item.path;
          const Icon = item.icon;
          
          return (
            <Link
              key={item.path}
              to={item.path}
              className={`flex flex-col items-center gap-1 p-2 min-w-[64px] transition-colors ${
                isActive ? 'text-emerald-600' : 'text-gray-400 hover:text-gray-600'
              }`}
            >
              <Icon className={`w-6 h-6 ${isActive ? 'stroke-[2.5px]' : 'stroke-[2px]'}`} />
              <span className={`text-[10px] font-medium ${isActive ? 'text-emerald-600' : 'text-gray-500'}`}>
                {item.label}
              </span>
            </Link>
          );
        })}
      </div>
    </div>
  );
}
