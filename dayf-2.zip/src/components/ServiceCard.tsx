import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Star, MapPin, Heart, ChevronRight, ChevronLeft, Loader2 } from 'lucide-react';
import { motion } from 'motion/react';
import { useAuth } from '../contexts/AuthContext';
import { db } from '../firebase';
import { collection, query, where, getDocs, addDoc, deleteDoc, doc, serverTimestamp, onSnapshot } from 'firebase/firestore';
import toast from 'react-hot-toast';
import { Service } from '../features/services/types';

interface ServiceCardProps {
  service: Service;
  activeColorClass: string;
  activeTextClass: string;
  activeBgLightClass: string;
}

const ServiceCard: React.FC<ServiceCardProps> = ({ service, activeColorClass, activeTextClass, activeBgLightClass }) => {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [isHovered, setIsHovered] = useState(false);
  const { user, signInWithGoogle } = useAuth();
  const [isFavorite, setIsFavorite] = useState(false);
  const [favoriteId, setFavoriteId] = useState<string | null>(null);
  const [isFavoriteLoading, setIsFavoriteLoading] = useState(false);

  useEffect(() => {
    if (!user || !service.id) {
      setIsFavorite(false);
      setFavoriteId(null);
      return;
    }

    const q = query(
      collection(db, 'favorites'),
      where('userId', '==', user.uid),
      where('serviceId', '==', service.id)
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      if (!snapshot.empty) {
        setIsFavorite(true);
        setFavoriteId(snapshot.docs[0].id);
      } else {
        setIsFavorite(false);
        setFavoriteId(null);
      }
    });

    return () => unsubscribe();
  }, [user, service.id]);

  const toggleFavorite = async (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();

    if (!user) {
      signInWithGoogle();
      return;
    }

    if (!service.id) return;

    setIsFavoriteLoading(true);
    try {
      if (isFavorite && favoriteId) {
        await deleteDoc(doc(db, 'favorites', favoriteId));
        toast.success('تمت الإزالة من المفضلة');
      } else {
        await addDoc(collection(db, 'favorites'), {
          userId: user.uid,
          serviceId: service.id,
          createdAt: serverTimestamp()
        });
        toast.success('تمت الإضافة إلى المفضلة');
      }
    } catch (error) {
      console.error("Error toggling favorite:", error);
      toast.error('حدث خطأ. يرجى المحاولة مرة أخرى.');
    } finally {
      setIsFavoriteLoading(false);
    }
  };

  const nextImage = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setCurrentImageIndex((prev) => (prev + 1) % service.images.length);
  };

  const prevImage = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setCurrentImageIndex((prev) => (prev - 1 + service.images.length) % service.images.length);
  };

  const formattedPrice = new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    maximumFractionDigits: 0,
  }).format(service.price);

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className="group bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-md transition-all duration-300 flex flex-col min-w-0"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div className="relative aspect-[4/3] overflow-hidden block shrink-0">
        {/* Image Carousel */}
        <Link to={`/listing/${service.id}`}>
          <img 
            src={service.images[currentImageIndex]} 
            alt={service.title} 
            className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
            referrerPolicy="no-referrer"
          />
        </Link>

        {/* Carousel Controls */}
        {isHovered && service.images.length > 1 && (
          <>
            <button 
              onClick={prevImage}
              className="absolute top-1/2 right-2 -translate-y-1/2 p-1.5 bg-white/90 backdrop-blur-sm rounded-full text-gray-700 hover:bg-white hover:scale-110 transition-all z-10 shadow-sm"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
            <button 
              onClick={nextImage}
              className="absolute top-1/2 left-2 -translate-y-1/2 p-1.5 bg-white/90 backdrop-blur-sm rounded-full text-gray-700 hover:bg-white hover:scale-110 transition-all z-10 shadow-sm"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
          </>
        )}

        {/* Carousel Dots */}
        {service.images.length > 1 && (
          <div className="absolute bottom-3 left-0 right-0 flex justify-center gap-1.5 z-10">
            {service.images.map((_, idx) => (
              <div 
                key={idx} 
                className={`h-1.5 rounded-full transition-all ${idx === currentImageIndex ? 'w-4 bg-white' : 'w-1.5 bg-white/60'}`}
              />
            ))}
          </div>
        )}

        {/* Top Badges */}
        <div className="absolute top-4 right-4 flex flex-col gap-2 items-end z-10">
          {service.isPopular && (
            <div className={`px-3 py-1 ${activeColorClass} rounded-full text-xs font-bold shadow-sm`}>
              الأكثر طلباً
            </div>
          )}
        </div>

        {/* Favorite Button */}
        <button 
          onClick={toggleFavorite}
          disabled={isFavoriteLoading}
          className={`absolute top-3 right-3 p-2 backdrop-blur-sm rounded-full transition-all z-10 shadow-sm ${
            isFavorite 
              ? 'bg-red-500 text-white scale-110' 
              : 'bg-white/80 text-gray-600 hover:text-red-500 hover:bg-white'
          }`}
        >
          {isFavoriteLoading ? (
            <Loader2 className="w-5 h-5 animate-spin" />
          ) : (
            <Heart className={`w-5 h-5 ${isFavorite ? 'fill-current' : ''}`} />
          )}
        </button>
      </div>
      
      <div className="p-4 flex-1 flex flex-col min-w-0">
        <div className="flex justify-between items-start mb-1 gap-2">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1">
              <span className="px-2 py-0.5 bg-emerald-50 text-emerald-700 text-[10px] font-bold rounded-md uppercase tracking-wider">
                {service.type}
              </span>
            </div>
            <Link to={`/listing/${service.id}`}>
              <h3 className={`text-base font-bold text-gray-900 truncate hover:${activeTextClass} transition-colors`}>
                {service.title}
              </h3>
            </Link>
            <div className="flex items-center text-gray-500 text-sm mt-0.5">
              <MapPin className="w-3.5 h-3.5 ml-1" />
              <span className="truncate">{service.location}</span>
            </div>
          </div>
          <div className="flex items-center gap-1 shrink-0">
            <Star className={`w-3.5 h-3.5 ${activeTextClass} fill-current`} />
            <span className={`font-bold text-sm text-gray-900`}>{service.rating}</span>
          </div>
        </div>

        <div className="mt-3 flex items-baseline gap-1">
          <span className="text-lg font-bold text-gray-900">{formattedPrice}</span>
          <span className="text-gray-500 text-sm font-normal">/ ليلة</span>
        </div>
      </div>
    </motion.div>
  );
};

export default ServiceCard;
