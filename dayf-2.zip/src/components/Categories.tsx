import React from 'react';
import { Link } from 'react-router-dom';
import { Plane, Stethoscope, GraduationCap, Briefcase, ChevronLeft } from 'lucide-react';
import { motion } from 'motion/react';
import { MAIN_CATEGORIES } from '../data/categories';

import { useLanguage } from '../contexts/LanguageContext';

export default function Categories() {
  const { t } = useLanguage();
  const colorMap = {
    emerald: 'bg-emerald-50 text-emerald-600',
    blue: 'bg-blue-50 text-blue-600',
    amber: 'bg-amber-50 text-amber-600',
    purple: 'bg-purple-50 text-purple-600',
  };

  const badgeColorMap = {
    emerald: 'bg-emerald-100 text-emerald-700 hover:bg-emerald-200',
    blue: 'bg-blue-100 text-blue-700 hover:bg-blue-200',
    amber: 'bg-amber-100 text-amber-700 hover:bg-amber-200',
    purple: 'bg-purple-100 text-purple-700 hover:bg-purple-200',
  };

  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16 px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4 leading-tight">{t('categories.title')}</h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto leading-relaxed">
            {t('categories.subtitle')}
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {MAIN_CATEGORIES.map((category, index) => {
            const Icon = category.icon;
            const colorClass = colorMap[category.color as keyof typeof colorMap];
            const badgeClass = badgeColorMap[category.color as keyof typeof badgeColorMap];
            
            return (
              <motion.div
                key={category.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="group bg-white rounded-3xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 border border-gray-100 flex flex-col"
              >
                <Link to={`/category/${category.id}`} className="block h-48 overflow-hidden relative shrink-0">
                  <img 
                    src={category.image} 
                    alt={category.name} 
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent"></div>
                  <div className={`absolute bottom-4 right-4 w-12 h-12 rounded-2xl flex items-center justify-center ${colorClass} bg-white shadow-lg`}>
                    <Icon className="w-6 h-6" />
                  </div>
                  <h3 className="absolute bottom-4 left-4 text-2xl font-bold text-white drop-shadow-md truncate max-w-[calc(100%-5rem)]">
                    {category.name}
                  </h3>
                </Link>
                
                <div className="p-6 flex flex-col flex-1 min-w-0">
                  <p className="text-gray-600 mb-6 line-clamp-2 leading-relaxed">{category.description}</p>
                  
                  {/* Subcategories Tags */}
                  <div className="flex flex-wrap gap-2 mb-6 mt-auto">
                    {category.subCategories.slice(0, 3).map((sub) => (
                      <Link 
                        key={sub.id}
                        to={`/category/${category.id}?sub=${sub.id}`}
                        className={`text-xs font-medium px-2.5 py-1 rounded-lg transition-colors truncate max-w-full ${badgeClass}`}
                      >
                        {sub.name}
                      </Link>
                    ))}
                    {category.subCategories.length > 3 && (
                      <span className="text-xs font-medium px-2.5 py-1 rounded-lg bg-gray-100 text-gray-600 shrink-0">
                        +{category.subCategories.length - 3}
                      </span>
                    )}
                  </div>

                  <Link to={`/category/${category.id}`} className="inline-flex items-center text-emerald-600 font-semibold hover:text-emerald-700 transition-colors group-hover:gap-2 mt-auto pt-4 border-t border-gray-50">
                    <span>تصفح جميع الخدمات</span>
                    <ChevronLeft className="w-5 h-5 rtl:rotate-180" />
                  </Link>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
