import React from 'react';
import { Link } from 'react-router-dom';
import { ShoppingBag, ArrowLeft, ArrowRight, MapPin, Star } from 'lucide-react';
import { motion } from 'framer-motion';
import { useLanguage } from '../contexts/LanguageContext';

const FEATURED_PRODUCTS = [
  {
    id: '1',
    name: 'صابون غار حلبي أصلي',
    price: 15000,
    location: 'حلب',
    rating: 4.8,
    image: 'https://images.unsplash.com/photo-1600857062241-98e5dba7f214?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
  },
  {
    id: '2',
    name: 'صندوق حلويات مشكلة',
    price: 85000,
    location: 'دمشق',
    rating: 4.9,
    image: 'https://images.unsplash.com/photo-1558961363-fa8fdf82db35?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
  },
  {
    id: '4',
    name: 'علبة موزاييك دمشقي',
    price: 120000,
    location: 'دمشق',
    rating: 5.0,
    image: 'https://images.unsplash.com/photo-1618172193622-ae2d025f4032?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
  }
];

export default function MarketHighlights() {
  const { language } = useLanguage();
  const isRTL = language === 'ar';

  return (
    <section className="py-16 bg-emerald-50/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-end mb-8">
          <div>
            <div className="flex items-center gap-2 text-emerald-600 font-bold mb-2">
              <ShoppingBag className="w-5 h-5" />
              <span>{isRTL ? 'سوق ضيف' : 'Dayf Market'}</span>
            </div>
            <h2 className="text-3xl font-bold text-gray-900">
              {isRTL ? 'منتجات محلية مميزة' : 'Featured Local Products'}
            </h2>
            <p className="text-gray-600 mt-2 max-w-2xl">
              {isRTL 
                ? 'اكتشف وتسوق أفضل المنتجات السورية الأصيلة، تصلك إلى مكان إقامتك.' 
                : 'Discover and shop the best authentic Syrian products, delivered to your stay.'}
            </p>
          </div>
          <Link 
            to="/marketplace" 
            className="hidden md:flex items-center gap-2 text-emerald-600 hover:text-emerald-700 font-bold transition-colors"
          >
            {isRTL ? 'تصفح السوق' : 'Browse Market'}
            {isRTL ? <ArrowLeft className="w-4 h-4" /> : <ArrowRight className="w-4 h-4" />}
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {FEATURED_PRODUCTS.map((product, index) => (
            <motion.div
              key={product.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden hover:shadow-md transition-shadow group flex flex-col"
            >
              <div className="relative h-48 overflow-hidden">
                <img 
                  src={product.image} 
                  alt={product.name} 
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute top-3 right-3 bg-white/90 backdrop-blur-sm px-2 py-1 rounded-lg text-xs font-bold text-emerald-700 flex items-center gap-1">
                  <MapPin className="w-3 h-3" />
                  {product.location}
                </div>
              </div>
              
              <div className="p-5 flex flex-col flex-1">
                <h3 className="font-bold text-gray-900 text-lg mb-2 line-clamp-1">{product.name}</h3>
                
                <div className="flex items-center gap-2 mb-4 text-sm">
                  <div className="flex items-center text-amber-500">
                    <Star className="w-4 h-4 fill-current" />
                    <span className="mr-1 font-bold">{product.rating}</span>
                  </div>
                </div>
                
                <div className="flex items-center justify-between mt-auto pt-4 border-t border-gray-50">
                  <span className="font-bold text-emerald-600 text-lg">
                    {product.price.toLocaleString('ar-SA')} ل.س
                  </span>
                  <Link 
                    to="/marketplace"
                    className="bg-gray-100 text-gray-700 px-4 py-2 rounded-xl text-sm font-bold hover:bg-gray-200 transition-colors"
                  >
                    {isRTL ? 'عرض' : 'View'}
                  </Link>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        <div className="mt-8 text-center md:hidden">
          <Link 
            to="/marketplace" 
            className="inline-flex items-center gap-2 text-emerald-600 hover:text-emerald-700 font-bold transition-colors"
          >
            {isRTL ? 'تصفح السوق' : 'Browse Market'}
            {isRTL ? <ArrowLeft className="w-4 h-4" /> : <ArrowRight className="w-4 h-4" />}
          </Link>
        </div>
      </div>
    </section>
  );
}
