import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { motion } from 'motion/react';
import { MAIN_CATEGORIES } from '../data/categories';

export default function MobileCategoryBar() {
  const location = useLocation();
  const currentPath = location.pathname;

  return (
    <div className="sticky top-16 bg-white z-40 border-b border-gray-100 shadow-sm">
      <div className="flex overflow-x-auto gap-6 px-4 py-3 scrollbar-hide">
        {MAIN_CATEGORIES.map((category) => {
          const Icon = category.icon;
          const isActive = currentPath === `/category/${category.id}`;
          
          return (
            <Link
              key={category.id}
              to={`/category/${category.id}`}
              className={`flex flex-col items-center gap-1.5 min-w-[4rem] group transition-all ${
                isActive ? 'text-gray-900' : 'text-gray-500 hover:text-gray-800'
              }`}
            >
              <Icon className={`w-6 h-6 ${isActive ? 'text-emerald-600' : 'group-hover:text-gray-800'}`} />
              <span className={`text-[10px] font-medium whitespace-nowrap ${isActive ? 'font-bold' : ''}`}>
                {category.name}
              </span>
              {isActive && (
                <motion.div 
                  layoutId="activeCategory"
                  className="h-0.5 w-full bg-gray-900 mt-1" 
                />
              )}
            </Link>
          );
        })}
      </div>
    </div>
  );
}
