# 📚 الدليل الشامل الكامل - الجزء 2
## البرمجة، الأمثلة العملية، والأخطاء الشائعة

---

# الجزء 4: البرمجة

## 4.1 نظرة عامة على الكود

الكود مقسم إلى 3 أجزاء رئيسية:

1. **الدوال الحسابية** - تطبيق القواعد الستة
2. **دوال الرسم** - رسم مكونات الفاتورة
3. **دالة البناء الرئيسية** - تجميع كل شيء

---

## 4.2 الدوال الحسابية الكاملة

### دالة معالجة المسافة:

```python
def parse_km(km_str):
    """
    تحويل المسافة من نص إلى رقم مع حذف "1" من البداية
    
    القاعدة 1: حذف "1 " أو "1." من بداية المسافة
    
    Args:
        km_str: المسافة كنص (مثل "1 237,43" أو "57,52")
        
    Returns:
        float: المسافة بالكيلومتر
        
    Examples:
        >>> parse_km("1 237,43")
        237.43
        >>> parse_km("1.496,91")
        496.91
        >>> parse_km("57,52")
        57.52
    """
    km_str = km_str.strip()
    
    # حذف "1 " أو "1." من البداية
    if km_str.startswith('1 '):
        km_str = km_str[2:]
    elif km_str.startswith('1.'):
        km_str = km_str[2:]
    
    # تحويل التنسيق الألماني إلى رقم
    km_str = km_str.replace('.', '')   # حذف نقاط الآلاف
    km_str = km_str.replace(',', '.')  # الفاصلة → نقطة عشرية
    
    return float(km_str)
```

### دالة حساب السعر:

```python
def get_price_from_km(km):
    """
    حساب السعر الأساسي من المسافة
    
    القاعدة 2: جدول التسعير المتدرج
    
    Args:
        km: المسافة بالكيلومتر
        
    Returns:
        float: السعر باليورو
    """
    if km <= 20:
        return 19
    elif km <= 30:
        return 24
    elif km <= 50:
        return 40
    elif km <= 100:
        return 50
    elif km <= 150:
        return 75
    elif km <= 200:
        return 85
    elif km <= 250:
        return 100
    elif km <= 350:
        return 120
    elif km <= 450:
        return 145
    elif km <= 550:
        return 170
    elif km <= 650:
        return 185
    else:
        # أكثر من 650 km
        extra_km = km - 650
        return 185 + (extra_km / 100) * 20
```

### دالة وقت الانتظار:

```python
# السعر الثابت
WZ_RATE = 10 / 60  # 0.1667 يورو/دقيقة

def calculate_waiting_time_cost(minutes):
    """
    حساب تكلفة وقت الانتظار
    
    القاعدة 3: 10€/ساعة = 0.1667€/دقيقة
    
    Args:
        minutes: عدد الدقائق
        
    Returns:
        float: التكلفة باليورو
    """
    return minutes * WZ_RATE
```

### دالة الخصم:

```python
def apply_discount(amount, discount_percent):
    """
    تطبيق الخصم
    
    القاعدة 4: الخصم يُطبّق بعد إضافة وقت الانتظار
    
    Args:
        amount: المبلغ قبل الخصم
        discount_percent: نسبة الخصم (0 أو 50)
        
    Returns:
        float: المبلغ بعد الخصم
    """
    if discount_percent == 0:
        return amount
    return amount / 2 if discount_percent == 50 else amount * (1 - discount_percent / 100)
```

### دالة التنسيق الألماني:

```python
def format_german(number):
    """
    تنسيق رقم بالطريقة الألمانية
    
    القاعدة 6: نقطة للآلاف، فاصلة للعشريات
    
    Args:
        number: رقم
        
    Returns:
        str: الرقم بالتنسيق الألماني
    """
    formatted = f"{number:,.2f}"
    return formatted.replace(',', 'X').replace('.', ',').replace('X', '.')
```

---

## 4.3 حساب صف واحد - خطوة بخطوة

```python
def calculate_row(tour_nr, name, km_str, wz_minutes, discount_percent):
    """
    حساب صف واحد كامل
    
    يطبق جميع القواعد الستة بالترتيب الصحيح
    """
    # القاعدة 1: معالجة المسافة
    km = parse_km(km_str)
    
    # القاعدة 2: السعر الأساسي
    base_price = get_price_from_km(km)
    
    # القاعدة 3: وقت الانتظار
    wz_cost = calculate_waiting_time_cost(wz_minutes)
    
    # السعر قبل الخصم
    price_before_discount = base_price + wz_cost
    
    # القاعدة 4: الخصم
    final_price = apply_discount(price_before_discount, discount_percent)
    
    # القاعدة 6: التنسيق
    km_display = f"1.{format_german(km)}"
    price_display = format_german(price_before_discount)
    betrag_display = format_german(final_price)
    rabatt_display = f"{discount_percent}%" if discount_percent > 0 else "—"
    
    return {
        'km': km,
        'base_price': base_price,
        'wz_cost': wz_cost,
        'price': price_before_discount,
        'betrag': final_price,
        'km_display': km_display,
        'price_display': price_display,
        'betrag_display': betrag_display,
        'rabatt_display': rabatt_display
    }
```

### مثال استخدام:

```python
# حساب صف: FESER +20 MIN WZ, 1.237,43 km
result = calculate_row(
    tour_nr='712386',
    name='FESER',
    km_str='1 237,43',
    wz_minutes=20,
    discount_percent=0
)

print(f"المسافة: {result['km']} km")           # 237.43 km
print(f"السعر الأساسي: {result['base_price']}€")  # 100€
print(f"وقت الانتظار: {result['wz_cost']:.2f}€")  # 3.33€
print(f"السعر النهائي: {result['betrag']:.2f}€")   # 103.33€
print(f"العرض: {result['km_display']}")        # 1.237,43
```

---

## 4.4 دوال الرسم

### رسم الهيدر:

```python
def draw_header(c, data):
    """
    رسم الهيدر - الصفحة الأولى فقط
    
    يحتوي على:
    - الشعار
    - مربع رقم الفاتورة
    - مربع الفترة + تاريخ الفاتورة
    - عناوين VON و AN
    
    Returns:
        float: موقع y النهائي (لبدء الجدول)
    """
    y = H - MT
    
    # الشعار
    logo_w = 55*mm
    logo_h = logo_w * (768/1408)
    if os.path.exists(data.get('logo_path', '')):
        c.drawImage(data['logo_path'], ML, y - logo_h, width=logo_w, height=logo_h)
        logo_h_val = logo_h
    else:
        # اسم الشركة نصياً
        c.setFont('Helvetica-Bold', 22)
        c.setFillColor(C_DARK)
        c.drawString(ML, y - 24, 'AL MASRI')
        c.setFont('Helvetica', 10)
        c.setFillColor(C_GREY)
        c.drawString(ML, y - 37, 'FAHRZEUGÜBERFÜHRUNG')
        logo_h_val = 50
    
    # مربع رقم الفاتورة
    bw, bh = 95, 48
    bx = W - MR - bw
    by = y - bh
    c.setFillColor(C_DARK)
    c.rect(bx, by, bw, bh, fill=1, stroke=0)
    c.setFont('Helvetica', 8.5)
    c.setFillColor(C_WHITE)
    c.drawCentredString(bx+bw/2, by+bh-14, 'RECHNUNG')
    c.setFont('Helvetica-Bold', 15)
    c.drawCentredString(bx+bw/2, by+10, data['invoice_number'])
    
    # خط فاصل
    sep_y = y - logo_h_val - 5
    c.setStrokeColor(HexColor('#dddddd'))
    c.setLineWidth(1.5)
    c.line(ML, sep_y, W-MR, sep_y)
    
    # مربع الفترة + التاريخ
    p_top = sep_y - 8
    p_h = 34
    c.setFillColor(C_LIGHT)
    c.rect(ML, p_top - p_h, CW, p_h, fill=1, stroke=0)
    c.setStrokeColor(C_BLUE)
    c.setLineWidth(3)
    c.line(ML, p_top - p_h, ML, p_top)
    
    # الفترة (يسار)
    c.setFont('Helvetica', 7.5)
    c.setFillColor(C_GREY)
    c.drawString(ML+8, p_top - 8, data['period_label'])
    c.setFont('Helvetica-Bold', 11)
    c.setFillColor(C_DARK)
    c.drawString(ML+8, p_top - 24, data['period_value'])
    
    # تاريخ الفاتورة (يمين)
    if 'invoice_date' in data:
        c.setFont('Helvetica', 7.5)
        c.setFillColor(C_GREY)
        c.drawRightString(W - MR - 8, p_top - 8, 'RECHNUNGSDATUM')
        c.setFont('Helvetica-Bold', 11)
        c.setFillColor(C_DARK)
        c.drawRightString(W - MR - 8, p_top - 24, data['invoice_date'])
    
    # العناوين VON و AN
    addr_y = p_top - p_h - 14
    col2 = ML + CW/2 + 5
    
    # VON
    c.setFont('Helvetica-Bold', 8.5)
    c.setFillColor(C_BLUE)
    c.drawString(ML, addr_y, 'VON')
    c.setFont('Helvetica-Bold', 10.5)
    c.setFillColor(C_DARK)
    c.drawString(ML, addr_y - 15, 'Al Masri Fahrzeugüberführung')
    c.setFont('Helvetica', 9.5)
    c.setFillColor(HexColor('#374151'))
    von_lines = ['Majd Alddin Almasri','Langendreerstr. 95','44388 Dortmund','Deutschland']
    for i, l in enumerate(von_lines):
        c.drawString(ML, addr_y - 29 - i*13, l)
    c.setFont('Helvetica', 8.5)
    c.setFillColor(C_GREY)
    c.drawString(ML, addr_y - 29 - len(von_lines)*13 - 2, 'Steuernummer: 314/5002/8490')
    
    # AN
    c.setFont('Helvetica-Bold', 8.5)
    c.setFillColor(C_BLUE)
    c.drawString(col2, addr_y, 'AN')
    c.setFont('Helvetica-Bold', 10.5)
    c.setFillColor(C_DARK)
    c.drawString(col2, addr_y - 15, 'DRIVE 500 LOGISTICS')
    c.setFont('Helvetica', 9.5)
    c.setFillColor(HexColor('#374151'))
    an_lines = ['Straßburgerstraße 130','46047 Oberhausen','Deutschland']
    for i, l in enumerate(an_lines):
        c.drawString(col2, addr_y - 29 - i*13, l)
    
    end_y = addr_y - 29 - max(len(von_lines), len(an_lines))*13 - 22 - 10
    return end_y
```

### رسم رأس الجدول:

```python
def draw_thead(c, y, headers, col_widths):
    """
    رسم رأس الجدول
    
    Args:
        c: canvas
        y: موقع y
        headers: قائمة العناوين
        col_widths: قائمة عرض الأعمدة
        
    Returns:
        float: موقع y الجديد (بعد الرأس)
    """
    THEAD_H = 28
    
    c.setFillColor(C_DARK)
    c.rect(ML, y - THEAD_H, CW, THEAD_H, fill=1, stroke=0)
    c.setFont('Helvetica-Bold', 8.5)
    c.setFillColor(C_WHITE)
    
    x = ML
    for i, h in enumerate(headers):
        c.drawCentredString(x + col_widths[i]/2, y - THEAD_H/2 - 3, h)
        x += col_widths[i]
    
    return y - THEAD_H
```

### رسم صف:

```python
def draw_row(c, y, row, col_widths, idx):
    """
    رسم صف واحد
    
    يدعم:
    - النصوص متعددة الأسطر
    - التفاف النص التلقائي
    - المسافة البادئة للأسطر الإضافية
    """
    row_h = calc_row_height(c, row, col_widths)
    
    # لون الخلفية (صفوف متناوبة)
    if idx % 2 == 0:
        c.setFillColor(C_ROW)
        c.rect(ML, y - row_h, CW, row_h, fill=1, stroke=0)
    
    # خط سفلي
    c.setStrokeColor(C_BORDER)
    c.setLineWidth(0.4)
    c.line(ML, y - row_h, W - MR, y - row_h)
    
    c.setFillColor(C_DARK)
    x = ML
    
    for i, cell in enumerate(row):
        txt = str(cell)
        
        if '\n' in txt:
            # نصوص متعددة الأسطر
            parts = txt.split('\n')
            all_lines = []
            
            for part_idx, part in enumerate(parts):
                wrapped = wrap_text(c, part, col_widths[i] - 16, 'Helvetica', 7.5)
                for w_line in wrapped:
                    indent = 0 if part_idx == 0 else 8
                    all_lines.append((w_line, indent))
            
            line_h = 10
            total_h = len(all_lines) * line_h
            start_y = y - row_h/2 + total_h/2 - 3
            
            c.setFont('Helvetica', 7.5)
            for idx_line, (line_text, indent) in enumerate(all_lines):
                line_y = start_y - idx_line * line_h
                c.drawString(x + 4 + indent, line_y, line_text)
        else:
            # نص عادي
            wrapped = wrap_text(c, txt, col_widths[i] - 10, 'Helvetica', 8.5)
            
            if len(wrapped) == 1:
                c.setFont('Helvetica', 8.5)
                c.drawCentredString(x + col_widths[i]/2, y - row_h/2 - 2, wrapped[0])
            else:
                line_h = 10
                total_h = len(wrapped) * line_h
                start_y = y - row_h/2 + total_h/2 - 3
                
                c.setFont('Helvetica', 8)
                for idx_line, line_text in enumerate(wrapped):
                    line_y = start_y - idx_line * line_h
                    c.drawString(x + 4, line_y, line_text)
        
        x += col_widths[i]
    
    return y - row_h
```

### رسم المجاميع والبنك:

```python
def draw_summary(c, y, data):
    """
    رسم قسم المجاميع والمعلومات البنكية
    """
    y -= 8
    
    # مربع المجاميع
    bw = 210
    bh = 82
    bx = W - MR - bw
    c.setFillColor(HexColor('#f9fafb'))
    c.setStrokeColor(C_BORDER)
    c.setLineWidth(0.7)
    c.rect(bx, y - bh, bw, bh, fill=1, stroke=1)
    
    ry = y - 16
    c.setFont('Helvetica', 10)
    c.setFillColor(C_DARK)
    c.drawString(bx+14, ry, 'Nettobetrag')
    c.drawRightString(bx+bw-14, ry, f'{format_german(data["totals"]["net"])} €')
    
    ry -= 18
    c.drawString(bx+14, ry, 'Umsatzsteuer 19%')
    c.drawRightString(bx+bw-14, ry, f'{format_german(data["totals"]["tax"])} €')
    
    ry -= 10
    c.setStrokeColor(HexColor('#cccccc'))
    c.setLineWidth(0.5)
    c.line(bx+14, ry, bx+bw-14, ry)
    
    ry -= 16
    c.setFont('Helvetica-Bold', 11)
    c.drawString(bx+14, ry, 'Gesamtbetrag')
    c.drawRightString(bx+bw-14, ry, f'{format_german(data["totals"]["total"])} €')
    
    # مربع البنك
    y -= bh + 12
    c.setFont('Helvetica-Bold', 10)
    c.setFillColor(C_DARK)
    c.drawString(ML, y, 'BANKVERBINDUNG')
    y -= 12
    
    bank_h = 68
    c.setFillColor(C_GOLD)
    c.rect(ML, y - bank_h, CW, bank_h, fill=1, stroke=0)
    
    x1 = ML + 14
    x2 = ML + CW/2 + 10
    by = y - 14
    
    c.setFont('Helvetica', 7)
    c.setFillColor(HexColor('#000'))
    c.drawString(x1, by, 'ZAHLUNGSEMPFÄNGER')
    c.setFont('Helvetica-Bold', 9.5)
    c.drawString(x1, by-13, 'Majd Alddin Almasri')
    c.setFont('Helvetica', 7)
    c.drawString(x1, by-30, 'IBAN')
    c.setFont('Helvetica-Bold', 9.5)
    c.drawString(x1, by-43, 'DE79 4305 0001 0007 4331 39')
    
    c.setFont('Helvetica', 7)
    c.drawString(x2, by, 'BANKNAME')
    c.setFont('Helvetica-Bold', 9.5)
    c.drawString(x2, by-13, 'Sparkasse Bochum')
    c.setFont('Helvetica', 7)
    c.drawString(x2, by-30, 'BIC')
    c.setFont('Helvetica-Bold', 9.5)
    c.drawString(x2, by-43, 'WELADED1BOC')
```

### رسم الفوتر:

```python
def draw_footer(c):
    """
    رسم الفوتر - يظهر في كل صفحة
    """
    FOOTER_TOP = MB + 40
    y = FOOTER_TOP
    
    c.setStrokeColor(HexColor('#cccccc'))
    c.setLineWidth(0.5)
    c.line(ML, y, W - MR, y)
    
    c.setFont('Helvetica-Bold', 8)
    c.setFillColor(C_DARK)
    c.drawCentredString(W/2, y - 10, 'Al Masri Fahrzeugüberführung • Majd Alddin Almasri')
    
    c.setFont('Helvetica', 7.5)
    c.setFillColor(C_GREY)
    c.drawCentredString(W/2, y - 20, 'Langendreerstr. 95 • 44388 Dortmund • Deutschland')
    c.drawCentredString(W/2, y - 29, 'Steuernummer: 314/5002/8490')
```

---

# الجزء 5: أمثلة عملية كاملة

## 5.1 مثال فاتورة LEISTUNGSZEITRAUM كاملة

### البيانات:

```python
INVOICE_DATA = {
    'invoice_number': '#13',
    'invoice_date': '05.02.2026',
    'period_label': 'LEISTUNGSZEITRAUM',
    'period_value': '19.01. - 23.01.2026',
    'logo_path': '/path/to/logo.png',  # اختياري
}
```

### الصفوف (البيانات الخام):

```python
raw_data = [
    {'tour_nr': '710925', 'name': 'FESER', 'desc2': '+160 MIN E-LADUNG & WAGENWÄSCHE', 
     'desc3': '(130 E Ladung + 30 Wagenwäsche)', 'km': '1 496,91', 'wz': 160, 'rabatt': 0},
    {'tour_nr': '709207', 'name': 'AH HÜLPERT', 'desc2': '+30 MIN WZ AIRBAG FEHLER LÖSCHUNG', 
     'desc3': '', 'km': '1 15,89', 'wz': 30, 'rabatt': 0},
    {'tour_nr': '712198', 'name': 'ARVAL', 'desc2': '', 
     'desc3': '', 'km': '1 521,78', 'wz': 0, 'rabatt': 50},
]
```

### الحساب خطوة بخطوة:

```python
rows = []
total = 0

for idx, item in enumerate(raw_data, 1):
    # 1. معالجة المسافة
    km = parse_km(item['km'])
    
    # 2. السعر الأساسي
    base = get_price_from_km(km)
    
    # 3. وقت الانتظار
    wz_cost = item['wz'] * WZ_RATE
    
    # 4. السعر قبل الخصم
    preis = base + wz_cost
    
    # 5. الخصم
    betrag = preis / 2 if item['rabatt'] == 50 else preis
    
    # 6. التنسيق
    km_display = f"1.{format_german(km)}"
    preis_display = format_german(preis)
    betrag_display = format_german(betrag)
    rabatt_txt = '50%' if item['rabatt'] == 50 else '—'
    
    # بناء الوصف
    desc_parts = [item['name']]
    if item['desc2']:
        desc_parts.append(item['desc2'])
    if item['desc3']:
        desc_parts.append(item['desc3'])
    desc = '\n'.join(desc_parts)
    
    # إنشاء الصف
    row = [
        f"{idx:02d}",           # #
        item['tour_nr'],        # TOUR NR.
        desc,                   # BESCHREIBUNG
        km_display,             # STRECKE (KM)
        preis_display,          # PREIS (€)
        rabatt_txt,             # RABATT
        betrag_display          # BETRAG (€)
    ]
    
    rows.append(row)
    total += betrag
    
    # طباعة لتأكيد
    print(f"{idx:02d}. {item['tour_nr']}: {km:.2f}km → {base}€ + {wz_cost:.2f}€ = {betrag:.2f}€")

# حساب المجاميع
netto = total
ust = netto * 0.19
gesamt = netto + ust

print(f"\nNettobetrag:      {netto:.2f} €")
print(f"Umsatzsteuer 19%: {ust:.2f} €")
print(f"Gesamtbetrag:     {gesamt:.2f} €")
```

### النتيجة:

```
01. 710925: 496.91km → 170€ + 26.67€ = 196.67€
02. 709207: 15.89km → 19€ + 5.00€ = 24.00€
03. 712198: 521.78km → 170€ + 0.00€ = 85.00€

Nettobetrag:      305.67 €
Umsatzsteuer 19%: 58.08 €
Gesamtbetrag:     363.75 €
```

### البيانات النهائية:

```python
INVOICE_DATA['headers'] = ['#', 'TOUR NR.', 'BESCHREIBUNG', 'STRECKE (KM)', 'PREIS (€)', 'RABATT', 'BETRAG (€)']
INVOICE_DATA['rows'] = rows
INVOICE_DATA['totals'] = {
    'net': round(netto, 2),
    'tax': round(ust, 2),
    'total': round(gesamt, 2)
}
```

---

## 5.2 مثال فاتورة AUSLAGENZEITRAUM

### البيانات:

```python
INVOICE_DATA = {
    'invoice_number': '#14',
    'invoice_date': '05.02.2026',
    'period_label': 'AUSLAGENZEITRAUM',
    'period_value': '26.01. - 30.01.2026',
    'headers': ['#', 'TOUR NR.', 'BESCHREIBUNG', 'PREIS (€)', 'UST. (€)', 'BETRAG (€)'],
    'rows': [
        ['01', '712748', 'CAR PROFESSIONAL\nDIESEL TANK DO-SY 244', '25,27', '4,80', '30,07'],
    ],
    'totals': {
        'net': 25.27,
        'tax': 4.80,
        'total': 30.07
    }
}
```

**ملاحظة:** في فواتير AUSLAGENZEITRAUM، الأسعار والضرائب **محسوبة مسبقاً**.

---

# الجزء 6: الأخطاء الشائعة

## 6.1 أخطاء حسابية

### ❌ خطأ 1: عدم حذف الرقم "1"

```python
# خطأ
km = parse_km("1 237,43")
# لو الدالة خاطئة وتعطي: 1237.43 km
price = get_price_from_km(1237.43)  # سعر خاطئ!

# صحيح
km = parse_km("1 237,43")  # 237.43 km
price = get_price_from_km(237.43)  # 100€ ✅
```

### ❌ خطأ 2: تطبيق الخصم قبل الانتظار

```python
# خطأ
base = 170
discounted = base / 2  # 85€
final = discounted + 26.67  # 111.67€ خطأ!

# صحيح
base = 170
with_wz = base + 26.67  # 196.67€
final = with_wz / 2  # 98.34€ ✅
```

### ❌ خطأ 3: التنسيق الأمريكي

```python
# خطأ
display = f"{amount:,.2f}"  # "1,234.56"

# صحيح
display = format_german(amount)  # "1.234,56" ✅
```

### ❌ خطأ 4: نسيان إضافة "1." للعرض

```python
# خطأ
km_display = format_german(237.43)  # "237,43"

# صحيح
km_display = f"1.{format_german(237.43)}"  # "1.237,43" ✅
```

---

## 6.2 أخطاء تصميمية

### ❌ خطأ 1: التاريخ في مكان خاطئ

```python
# خطأ: التاريخ تحت مربع الفاتورة
c.drawString(bx, by - 10, f"Datum: {date}")

# صحيح: التاريخ بجانب الفترة
c.drawRightString(W - MR - 8, p_top - 24, date)
```

### ❌ خطأ 2: عدم تكرار رأس الجدول

```python
# خطأ: رسم الرأس مرة واحدة فقط
draw_thead(c, y, headers, col_widths)

# صحيح: تكراره في كل صفحة
if page == 1:
    y = draw_header(c, data)
y = draw_thead(c, y, headers, col_widths)  # في كل صفحة
```

### ❌ خطأ 3: المجاميع في كل صفحة

```python
# خطأ
draw_summary(c, y, data)  # في كل صفحة

# صحيح
if drawn >= total_rows:  # فقط في الصفحة الأخيرة
    draw_summary(c, y, data)
```

---

## 6.3 أخطاء برمجية

### ❌ خطأ 1: عدم معالجة النصوص الطويلة

```python
# خطأ: النص سيتجاوز العمود
c.drawString(x, y, long_text)

# صحيح: استخدام word wrap
wrapped = wrap_text(c, long_text, max_width, font, size)
for line in wrapped:
    c.drawString(x, y, line)
    y -= line_height
```

### ❌ خطأ 2: ارتفاع صف ثابت

```python
# خطأ
row_height = 24  # ثابت

# صحيح
row_height = calc_row_height(c, row, col_widths)  # ديناميكي
```

---

# الجزء 7: قائمة التحقق النهائية

قبل إنشاء أي فاتورة، تحقق من:

## ✅ الحسابات:

- [ ] حذفت "1 " أو "1." من المسافات؟
- [ ] استخدمت جدول التسعير الصحيح؟
- [ ] حسبت وقت الانتظار (10€/ساعة = 0.1667€/دقيقة)؟
- [ ] طبقت الخصم **بعد** وقت الانتظار؟
- [ ] حسبت الضريبة 19% بشكل صحيح؟
- [ ] استخدمت التنسيق الألماني (1.234,56)؟

## ✅ العرض:

- [ ] أضفت "1." للمسافات في العرض؟
- [ ] فصلت أجزاء BESCHREIBUNG بـ `\n`؟
- [ ] أضفت مسافة بادئة للأسطر الإضافية؟
- [ ] RECHNUNGSDATUM بجانب الفترة (يمين)؟

## ✅ التصميم:

- [ ] حجم الصفحة A4 (595.276 × 841.89 pts)؟
- [ ] الهوامش صحيحة (20mm يسار/يمين، 15mm أعلى/أسفل)؟
- [ ] الألوان صحيحة؟
- [ ] الفوتر في كل صفحة؟
- [ ] رأس الجدول يتكرر في كل صفحة؟
- [ ] المجاميع والبنك في الصفحة الأخيرة فقط؟

---

# الخلاصة

هذا الدليل يحتوي على **كل** ما تحتاجه لإنشاء فواتير مطابقة 100% للفواتير الأصلية.

**الخطوات التالية:**
1. اقرأ القواعد الستة بعناية
2. افهم الأمثلة العملية
3. استخدم الكود المرفق
4. راجع قائمة التحقق قبل كل فاتورة

**تذكر:** القاعدة الأولى (حذف الرقم "1") هي الأكثر أهمية والأكثر عرضة للخطأ!

🎓 **نهاية الدليل**
