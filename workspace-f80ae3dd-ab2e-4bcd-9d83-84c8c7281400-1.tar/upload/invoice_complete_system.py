#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
================================================================================
نظام الفواتير الكامل - Al Masri Fahrzeugüberführung
================================================================================

هذا الكود يحتوي على كل ما تحتاجه لإنشاء فواتير احترافية مطابقة تماماً
للفواتير المُنشأة في المحادثة الأصلية.

المتطلبات:
    pip install reportlab --break-system-packages

الاستخدام:
    python invoice_complete_system.py

================================================================================
"""

from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.lib.colors import HexColor
import os

# ==================== الإعدادات الثابتة ====================
W, H = A4  # 595.276 × 841.89 pts
ML = 20*mm  # Margin Left
MR = 20*mm  # Margin Right
MT = 15*mm  # Margin Top
MB = 15*mm  # Margin Bottom
CW = W - ML - MR  # Content Width

# الألوان (بالضبط كما في الفواتير الأصلية)
C_DARK   = HexColor('#1f2937')  # النصوص الرئيسية
C_BLUE   = HexColor('#2563eb')  # العناوين والتأكيدات
C_GREY   = HexColor('#6b7280')  # النصوص الثانوية
C_LIGHT  = HexColor('#f3f4f6')  # الخلفيات الفاتحة
C_BORDER = HexColor('#e5e7eb')  # الحدود
C_GOLD   = HexColor('#fbbf24')  # مربع البنك
C_WHITE  = HexColor('#ffffff')  # الأبيض
C_ROW    = HexColor('#f9fafb')  # صفوف الجدول المتناوبة

# ارتفاعات ثابتة
THEAD_H = 28        # ارتفاع رأس الجدول
FOOTER_TOP = MB + 40  # موقع الفوتر من الأسفل
SUMMARY_H = 185     # ارتفاع قسم المجاميع والبنك

# ==================== القواعد الحسابية ====================

def get_price_from_km(km):
    """
    حساب السعر من المسافة حسب جدول التسعير المتدرج
    
    قاعدة مهمة: أي مسافة تتجاوز الحد الأعلى للشريحة بـ 0.5 km أو أكثر
    تنتقل للشريحة الأعلى
    
    Args:
        km (float): المسافة بالكيلومتر
        
    Returns:
        float: السعر باليورو
        
    Examples:
        >>> get_price_from_km(15.89)
        19
        >>> get_price_from_km(30.5)  # تجاوز 30 بـ 0.5
        40
        >>> get_price_from_km(496.91)
        170
    """
    if km <= 20:
        return 19
    elif km <= 30:
        return 24
    elif km <= 50:
        return 40
    elif km <= 100:
        return 50
    elif km <= 150:
        return 75
    elif km <= 200:
        return 85
    elif km <= 250:
        return 100
    elif km <= 350:
        return 120
    elif km <= 450:
        return 145
    elif km <= 550:
        return 170
    elif km <= 650:
        return 185
    else:
        # أكثر من 650: السعر الأساسي 185 + 20 يورو لكل 100 km إضافية
        extra_km = km - 650
        extra_charge = (extra_km / 100) * 20
        return 185 + extra_charge


def parse_km(km_str):
    """
    تحويل المسافة من النص إلى رقم
    
    قاعدة حرجة: الرقم "1" في بداية المسافة (مثل "1 237,43" أو "1.237,43")
    هو للتنسيق فقط ويجب حذفه تماماً قبل الحساب.
    
    المسافة الحقيقية للحساب = الرقم بعد حذف "1 " أو "1."
    لكن للعرض في الفاتورة نضيف "1." مرة أخرى
    
    Args:
        km_str (str): المسافة كنص (مثل "1 237,43" أو "496,91")
        
    Returns:
        float: المسافة كرقم عشري
        
    Examples:
        >>> parse_km("1 237,43")
        237.43  # ليس 1237.43!
        >>> parse_km("1.496,91")
        496.91
        >>> parse_km("57,52")
        57.52
    """
    km_str = km_str.strip()
    
    # حذف الرقم 1 من البداية
    if km_str.startswith('1 '):
        km_str = km_str[2:]  # حذف "1 "
    elif km_str.startswith('1.'):
        km_str = km_str[2:]  # حذف "1."
    
    # تحويل التنسيق الألماني إلى رقم
    km_str = km_str.replace('.', '')  # حذف نقاط الآلاف
    km_str = km_str.replace(',', '.')  # تحويل الفاصلة إلى نقطة عشرية
    
    return float(km_str)


def format_german(number):
    """
    تنسيق رقم بالطريقة الألمانية
    
    التنسيق الألماني: النقطة (.) للآلاف، الفاصلة (,) للعشريات
    
    Args:
        number (float): الرقم المراد تنسيقه
        
    Returns:
        str: الرقم بالتنسيق الألماني
        
    Examples:
        >>> format_german(1234.56)
        '1.234,56'
        >>> format_german(48.26)
        '48,26'
    """
    formatted = f"{number:,.2f}"  # تنسيق أمريكي أولاً
    # استبدال: , → X, . → ,, X → .
    return formatted.replace(',', 'X').replace('.', ',').replace('X', '.')


def calculate_waiting_time_cost(minutes):
    """
    حساب تكلفة وقت الانتظار (WARTEZEIT / WZ)
    
    المعدل الثابت: 0.16 يورو للدقيقة الواحدة
    
    Args:
        minutes (int): عدد الدقائق
        
    Returns:
        float: التكلفة باليورو
        
    Examples:
        >>> calculate_waiting_time_cost(20)
        3.2
        >>> calculate_waiting_time_cost(160)
        25.6
    """
    return minutes * 0.16


def apply_discount(amount, discount_percent):
    """
    تطبيق الخصم على المبلغ
    
    الخصم يُطبّق بعد إضافة جميع التكاليف (السعر الأساسي + وقت الانتظار)
    
    Args:
        amount (float): المبلغ الأصلي
        discount_percent (int): نسبة الخصم (مثل 50 لخصم 50%)
        
    Returns:
        float: المبلغ بعد الخصم
        
    Examples:
        >>> apply_discount(120, 50)
        60.0
        >>> apply_discount(100, 0)
        100.0
    """
    if discount_percent == 0:
        return amount
    return amount * (1 - discount_percent / 100)


# ==================== دوال مساعدة للرسم ====================

def wrap_text(c, text, max_width, font_name, font_size):
    """
    تقسيم النص الطويل إلى أسطر متعددة (word wrap)
    
    هذه الدالة مهمة لمنع تداخل النصوص في عمود BESCHREIBUNG
    """
    words = text.split()
    lines = []
    current_line = ""
    
    for word in words:
        test_line = current_line + (" " if current_line else "") + word
        if c.stringWidth(test_line, font_name, font_size) <= max_width:
            current_line = test_line
        else:
            if current_line:
                lines.append(current_line)
            current_line = word
    
    if current_line:
        lines.append(current_line)
    
    return lines if lines else [text]


def calc_row_height(c, row, col_widths):
    """
    حساب ارتفاع الصف بناءً على محتواه (ديناميكي)
    
    الصفوف التي تحتوي نصوص طويلة أو متعددة الأسطر تحتاج ارتفاع أكبر
    """
    max_lines = 1
    
    for i, cell in enumerate(row):
        txt = str(cell)
        if '\n' in txt:
            # نصوص مُقسّمة مسبقاً
            lines = txt.split('\n')
            total_lines = 0
            for line in lines:
                wrapped = wrap_text(c, line, col_widths[i] - 16, 'Helvetica', 7.5)
                total_lines += len(wrapped)
            max_lines = max(max_lines, total_lines)
        else:
            # نص عادي
            wrapped = wrap_text(c, txt, col_widths[i] - 10, 'Helvetica', 8.5)
            max_lines = max(max_lines, len(wrapped))
    
    # ارتفاع = 20 أساسي + (عدد الأسطر × 10)
    return max(24, 20 + max_lines * 10)


# ==================== رسم أجزاء الفاتورة ====================

def draw_footer(c):
    """
    رسم الفوتر - يظهر في كل صفحة
    
    يحتوي على:
    - اسم الشركة
    - العنوان
    - الرقم الضريبي
    """
    y = FOOTER_TOP
    c.setStrokeColor(HexColor('#cccccc'))
    c.setLineWidth(0.5)
    c.line(ML, y, W - MR, y)

    c.setFont('Helvetica-Bold', 8)
    c.setFillColor(C_DARK)
    c.drawCentredString(W/2, y - 10, 'Al Masri Fahrzeugüberführung • Majd Alddin Almasri')

    c.setFont('Helvetica', 7.5)
    c.setFillColor(C_GREY)
    c.drawCentredString(W/2, y - 20, 'Langendreerstr. 95 • 44388 Dortmund • Deutschland')
    c.drawCentredString(W/2, y - 29, 'Steuernummer: 314/5002/8490')


def draw_header(c, data):
    """
    رسم الهيدر - الصفحة الأولى فقط
    
    يحتوي على:
    - الشعار (إذا كان موجوداً)
    - مربع رقم الفاتورة
    - خط فاصل
    - مربع الفترة وتاريخ الفاتورة
    - عناوين VON و AN
    
    Returns:
        float: موقع y نهاية الهيدر (لبدء الجدول منه)
    """
    y = H - MT

    # الشعار
    logo_path = data.get('logo_path', '/home/claude/logo_transparent.png')
    if os.path.exists(logo_path):
        logo_w = 55*mm
        logo_h = logo_w * (768/1408)  # نسبة الارتفاع الأصلية
        c.drawImage(logo_path, ML, y - logo_h, width=logo_w, height=logo_h)
        logo_h_val = logo_h
    else:
        # بدون شعار - اسم الشركة نصياً
        c.setFont('Helvetica-Bold', 22)
        c.setFillColor(C_DARK)
        c.drawString(ML, y - 24, 'AL MASRI')
        c.setFont('Helvetica', 10)
        c.setFillColor(C_GREY)
        c.drawString(ML, y - 37, 'FAHRZEUGÜBERFÜHRUNG')
        logo_h_val = 50

    # مربع رقم الفاتورة
    bw, bh = 95, 48
    bx = W - MR - bw
    by = y - bh
    c.setFillColor(C_DARK)
    c.rect(bx, by, bw, bh, fill=1, stroke=0)
    c.setFont('Helvetica', 8.5)
    c.setFillColor(C_WHITE)
    c.drawCentredString(bx+bw/2, by+bh-14, 'RECHNUNG')
    c.setFont('Helvetica-Bold', 15)
    c.drawCentredString(bx+bw/2, by+10, data['invoice_number'])

    # خط فاصل
    sep_y = y - logo_h_val - 5
    c.setStrokeColor(HexColor('#dddddd'))
    c.setLineWidth(1.5)
    c.line(ML, sep_y, W-MR, sep_y)

    # مربع الفترة وتاريخ الفاتورة
    p_top = sep_y - 8
    p_h = 34
    c.setFillColor(C_LIGHT)
    c.rect(ML, p_top - p_h, CW, p_h, fill=1, stroke=0)
    c.setStrokeColor(C_BLUE)
    c.setLineWidth(3)
    c.line(ML, p_top - p_h, ML, p_top)

    # الفترة (يسار)
    c.setFont('Helvetica', 7.5)
    c.setFillColor(C_GREY)
    c.drawString(ML+8, p_top - 8, data['period_label'])
    c.setFont('Helvetica-Bold', 11)
    c.setFillColor(C_DARK)
    c.drawString(ML+8, p_top - 24, data['period_value'])
    
    # تاريخ الفاتورة (يمين)
    if 'invoice_date' in data:
        c.setFont('Helvetica', 7.5)
        c.setFillColor(C_GREY)
        c.drawRightString(W - MR - 8, p_top - 8, 'RECHNUNGSDATUM')
        c.setFont('Helvetica-Bold', 11)
        c.setFillColor(C_DARK)
        c.drawRightString(W - MR - 8, p_top - 24, data['invoice_date'])

    # العناوين VON و AN
    addr_y = p_top - p_h - 14
    col2 = ML + CW/2 + 5

    # VON
    c.setFont('Helvetica-Bold', 8.5)
    c.setFillColor(C_BLUE)
    c.drawString(ML, addr_y, 'VON')
    c.setFont('Helvetica-Bold', 10.5)
    c.setFillColor(C_DARK)
    c.drawString(ML, addr_y - 15, 'Al Masri Fahrzeugüberführung')
    c.setFont('Helvetica', 9.5)
    c.setFillColor(HexColor('#374151'))
    von_lines = ['Majd Alddin Almasri','Langendreerstr. 95','44388 Dortmund','Deutschland']
    for i, l in enumerate(von_lines):
        c.drawString(ML, addr_y - 29 - i*13, l)
    c.setFont('Helvetica', 8.5)
    c.setFillColor(C_GREY)
    c.drawString(ML, addr_y - 29 - len(von_lines)*13 - 2, 'Steuernummer: 314/5002/8490')

    # AN
    c.setFont('Helvetica-Bold', 8.5)
    c.setFillColor(C_BLUE)
    c.drawString(col2, addr_y, 'AN')
    c.setFont('Helvetica-Bold', 10.5)
    c.setFillColor(C_DARK)
    c.drawString(col2, addr_y - 15, 'DRIVE 500 LOGISTICS')
    c.setFont('Helvetica', 9.5)
    c.setFillColor(HexColor('#374151'))
    an_lines = ['Straßburgerstraße 130','46047 Oberhausen','Deutschland']
    for i, l in enumerate(an_lines):
        c.drawString(col2, addr_y - 29 - i*13, l)

    end_y = addr_y - 29 - max(len(von_lines), len(an_lines))*13 - 22 - 10
    return end_y


def draw_thead(c, y, headers, col_widths):
    """
    رسم رأس الجدول
    
    يتكرر في كل صفحة تحتوي على صفوف
    """
    c.setFillColor(C_DARK)
    c.rect(ML, y - THEAD_H, CW, THEAD_H, fill=1, stroke=0)
    c.setFont('Helvetica-Bold', 8.5)
    c.setFillColor(C_WHITE)
    x = ML
    for i, h in enumerate(headers):
        c.drawCentredString(x + col_widths[i]/2, y - THEAD_H/2 - 3, h)
        x += col_widths[i]
    return y - THEAD_H


def draw_row(c, y, row, col_widths, idx):
    """
    رسم صف واحد في الجدول
    
    يدعم:
    - النصوص متعددة الأسطر
    - التفاف النص التلقائي (word wrap)
    - المسافة البادئة للأسطر الإضافية
    - الصفوف المتناوبة الألوان
    """
    row_h = calc_row_height(c, row, col_widths)
    
    # لون الخلفية (صفوف متناوبة)
    if idx % 2 == 0:
        c.setFillColor(C_ROW)
        c.rect(ML, y - row_h, CW, row_h, fill=1, stroke=0)
    
    # خط سفلي
    c.setStrokeColor(C_BORDER)
    c.setLineWidth(0.4)
    c.line(ML, y - row_h, W - MR, y - row_h)

    c.setFillColor(C_DARK)
    x = ML
    
    for i, cell in enumerate(row):
        txt = str(cell)
        
        if '\n' in txt:
            # نصوص متعددة الأسطر (مثل عمود BESCHREIBUNG)
            parts = txt.split('\n')
            all_lines = []
            
            for part_idx, part in enumerate(parts):
                wrapped = wrap_text(c, part, col_widths[i] - 16, 'Helvetica', 7.5)
                for w_line in wrapped:
                    # السطر الأول بدون مسافة، الباقي مع مسافة بادئة
                    indent = 0 if part_idx == 0 else 8
                    all_lines.append((w_line, indent))
            
            line_h = 10
            total_h = len(all_lines) * line_h
            start_y = y - row_h/2 + total_h/2 - 3
            
            c.setFont('Helvetica', 7.5)
            for idx_line, (line_text, indent) in enumerate(all_lines):
                line_y = start_y - idx_line * line_h
                c.drawString(x + 4 + indent, line_y, line_text)
        else:
            # نص عادي في سطر واحد
            wrapped = wrap_text(c, txt, col_widths[i] - 10, 'Helvetica', 8.5)
            
            if len(wrapped) == 1:
                # سطر واحد - في الوسط
                c.setFont('Helvetica', 8.5)
                c.drawCentredString(x + col_widths[i]/2, y - row_h/2 - 2, wrapped[0])
            else:
                # أسطر متعددة - من اليسار
                line_h = 10
                total_h = len(wrapped) * line_h
                start_y = y - row_h/2 + total_h/2 - 3
                
                c.setFont('Helvetica', 8)
                for idx_line, line_text in enumerate(wrapped):
                    line_y = start_y - idx_line * line_h
                    c.drawString(x + 4, line_y, line_text)
        
        x += col_widths[i]
    
    return y - row_h


def draw_summary(c, y, data):
    """
    رسم قسم المجاميع والمعلومات البنكية
    
    يظهر في الصفحة الأخيرة فقط
    """
    y -= 8
    
    # مربع المجاميع
    bw = 210
    bh = 82
    bx = W - MR - bw
    c.setFillColor(HexColor('#f9fafb'))
    c.setStrokeColor(C_BORDER)
    c.setLineWidth(0.7)
    c.rect(bx, y - bh, bw, bh, fill=1, stroke=1)

    ry = y - 16
    c.setFont('Helvetica', 10)
    c.setFillColor(C_DARK)
    c.drawString(bx+14, ry, 'Nettobetrag')
    c.drawRightString(bx+bw-14, ry, f'{format_german(data["totals"]["net"])} €')

    ry -= 18
    c.drawString(bx+14, ry, 'Umsatzsteuer 19%')
    c.drawRightString(bx+bw-14, ry, f'{format_german(data["totals"]["tax"])} €')

    ry -= 10
    c.setStrokeColor(HexColor('#cccccc'))
    c.setLineWidth(0.5)
    c.line(bx+14, ry, bx+bw-14, ry)

    ry -= 16
    c.setFont('Helvetica-Bold', 11)
    c.setFillColor(C_DARK)
    c.drawString(bx+14, ry, 'Gesamtbetrag')
    c.drawRightString(bx+bw-14, ry, f'{format_german(data["totals"]["total"])} €')

    # المعلومات البنكية
    y -= bh + 12
    c.setFont('Helvetica-Bold', 10)
    c.setFillColor(C_DARK)
    c.drawString(ML, y, 'BANKVERBINDUNG')
    y -= 12

    bank_h = 68
    c.setFillColor(C_GOLD)
    c.rect(ML, y - bank_h, CW, bank_h, fill=1, stroke=0)

    x1 = ML + 14
    x2 = ML + CW/2 + 10
    by = y - 14

    c.setFont('Helvetica', 7)
    c.setFillColor(HexColor('#000'))
    c.drawString(x1, by, 'ZAHLUNGSEMPFÄNGER')
    c.setFont('Helvetica-Bold', 9.5)
    c.drawString(x1, by-13, 'Majd Alddin Almasri')
    c.setFont('Helvetica', 7)
    c.drawString(x1, by-30, 'IBAN')
    c.setFont('Helvetica-Bold', 9.5)
    c.drawString(x1, by-43, 'DE79 4305 0001 0007 4331 39')

    c.setFont('Helvetica', 7)
    c.drawString(x2, by, 'BANKNAME')
    c.setFont('Helvetica-Bold', 9.5)
    c.drawString(x2, by-13, 'Sparkasse Bochum')
    c.setFont('Helvetica', 7)
    c.drawString(x2, by-30, 'BIC')
    c.setFont('Helvetica-Bold', 9.5)
    c.drawString(x2, by-43, 'WELADED1BOC')


def get_col_widths(n):
    """
    إرجاع عرض الأعمدة حسب عددها
    
    لفواتير LEISTUNGSZEITRAUM: 7 أعمدة
    لفواتير AUSLAGENZEITRAUM: 6 أعمدة
    """
    if n == 7:
        # #, TOUR NR., BESCHREIBUNG, STRECKE (KM), PREIS (€), RABATT, BETRAG (€)
        return [10*mm, 18*mm, 48*mm, 22*mm, 18*mm, 14*mm, 20*mm]
    elif n == 6:
        # #, TOUR NR., BESCHREIBUNG, PREIS (€), UST. (€), BETRAG (€)
        return [10*mm, 20*mm, 60*mm, 18*mm, 14*mm, 18*mm]
    else:
        # افتراضي
        return [CW/n]*n


# ==================== بناء الفاتورة ====================

def build_invoice(data, output_path):
    """
    بناء الفاتورة الكاملة
    
    يدعم:
    - صفحات متعددة تلقائياً
    - رأس الجدول يتكرر في كل صفحة
    - الفوتر في كل صفحة
    - المجاميع والبنك في الصفحة الأخيرة فقط
    
    Args:
        data (dict): بيانات الفاتورة
        output_path (str): مسار ملف PDF الناتج
    """
    c = canvas.Canvas(output_path, pagesize=A4)
    headers = data['headers']
    rows = data['rows']
    col_widths = get_col_widths(len(headers))
    total_rows = len(rows)
    drawn = 0

    # الصفحة الأولى
    y = draw_header(c, data)
    y -= 6

    avail_first = y - FOOTER_TOP - THEAD_H
    sample_heights = [calc_row_height(c, r, col_widths) for r in rows[:min(3, len(rows))]]
    avg_row_h = sum(sample_heights) / len(sample_heights) if sample_heights else 30
    
    fit_with_sum = int((avail_first - SUMMARY_H) / avg_row_h)
    fit_no_sum = int(avail_first / avg_row_h)

    if total_rows <= fit_with_sum:
        take = total_rows
    else:
        take = fit_no_sum
        if take >= total_rows:
            take = fit_with_sum

    y = draw_thead(c, y, headers, col_widths)

    for i in range(take):
        y = draw_row(c, y, rows[i], col_widths, i)
    drawn += take

    c.setStrokeColor(C_BORDER)
    c.setLineWidth(0.5)
    c.line(ML, y, W-MR, y)

    if drawn >= total_rows:
        draw_summary(c, y, data)

    draw_footer(c)

    if drawn >= total_rows:
        c.save()
        return

    # صفحات إضافية
    while drawn < total_rows:
        c.showPage()
        y = H - MT

        avail = y - FOOTER_TOP - THEAD_H
        remaining = total_rows - drawn
        
        fit_with_sum = int((avail - SUMMARY_H) / avg_row_h)
        fit_no_sum = int(avail / avg_row_h)

        if remaining <= fit_with_sum:
            take = remaining
        else:
            take = min(fit_no_sum, remaining)

        y = draw_thead(c, y, headers, col_widths)

        for i in range(take):
            y = draw_row(c, y, rows[drawn + i], col_widths, drawn + i)
        drawn += take

        c.setStrokeColor(C_BORDER)
        c.setLineWidth(0.5)
        c.line(ML, y, W-MR, y)

        if drawn >= total_rows:
            draw_summary(c, y, data)

        draw_footer(c)

    c.save()


# ==================== أمثلة الاستخدام ====================

if __name__ == "__main__":
    """
    أمثلة عملية لإنشاء فواتير LEISTUNGSZEITRAUM و AUSLAGENZEITRAUM
    """
    
    # إنشاء مجلد للمخرجات
    os.makedirs('output', exist_ok=True)
    
    # ========== مثال 1: فاتورة LEISTUNGSZEITRAUM ==========
    print("\n" + "="*70)
    print("  إنشاء فاتورة LEISTUNGSZEITRAUM (نقل المركبات)")
    print("="*70)
    
    INVOICE_EXAMPLE_1 = {
        'invoice_number': '#13',
        'invoice_date': '05.02.2026',
        'period_label': 'LEISTUNGSZEITRAUM',
        'period_value': '19.01. - 23.01.2026',
        'logo_path': '/path/to/logo.png',  # اختياري
        'headers': ['#', 'TOUR NR.', 'BESCHREIBUNG', 'STRECKE (KM)', 'PREIS (€)', 'RABATT', 'BETRAG (€)'],
        'rows': [
            ['01', '710925', 'FESER\n+160 MIN E-LADUNG & WAGENWÄSCHE\n(130 E Ladung + 30 Wagenwäsche)', '1.496,91', '195,60', '—', '195,60'],
            ['02', '709207', 'AH HÜLPERT\n+30 MIN WZ AIRBAG FEHLER LÖSCHUNG', '1.15,89', '23,80', '—', '23,80'],
            ['03', '712198', 'ARVAL', '1.521,78', '170,00', '50%', '85,00'],
        ],
        'totals': {
            'net': 304.40,
            'tax': 57.84,
            'total': 362.24
        }
    }
    
    build_invoice(INVOICE_EXAMPLE_1, 'output/Example_Leistungszeitraum.pdf')
    print("✅ تم إنشاء: output/Example_Leistungszeitraum.pdf")
    
    # ========== مثال 2: فاتورة AUSLAGENZEITRAUM ==========
    print("\n" + "="*70)
    print("  إنشاء فاتورة AUSLAGENZEITRAUM (المصروفات)")
    print("="*70)
    
    INVOICE_EXAMPLE_2 = {
        'invoice_number': '#14',
        'invoice_date': '05.02.2026',
        'period_label': 'AUSLAGENZEITRAUM',
        'period_value': '26.01. - 30.01.2026',
        'headers': ['#', 'TOUR NR.', 'BESCHREIBUNG', 'PREIS (€)', 'UST. (€)', 'BETRAG (€)'],
        'rows': [
            ['01', '712748', 'CAR PROFESSIONAL\nDIESEL TANK DO-SY 244', '25,27', '4,80', '30,07'],
        ],
        'totals': {
            'net': 25.27,
            'tax': 4.80,
            'total': 30.07
        }
    }
    
    build_invoice(INVOICE_EXAMPLE_2, 'output/Example_Auslagenzeitraum.pdf')
    print("✅ تم إنشاء: output/Example_Auslagenzeitraum.pdf")
    
    print("\n" + "="*70)
    print("  ✅ انتهى! تحقق من مجلد output")
    print("="*70)
