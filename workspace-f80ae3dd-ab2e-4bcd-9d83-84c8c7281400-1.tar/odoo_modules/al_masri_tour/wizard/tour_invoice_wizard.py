# -*- coding: utf-8 -*-
"""
================================================================================
Tour Invoice Wizard - معالج إنشاء الفواتير
================================================================================
"""

from odoo import models, fields, api, _
from odoo.exceptions import UserError, ValidationError
from datetime import date, timedelta
import logging

_logger = logging.getLogger(__name__)


class TourInvoiceWizard(models.TransientModel):
    """
    معالج إنشاء فاتورة من رحلات محددة
    """
    _name = 'tour.invoice.wizard'
    _description = 'Create Invoice from Tours'
    
    # ==================== الحقول ====================
    
    partner_id = fields.Many2one(
        'res.partner',
        string='Customer',
        required=True,
        domain=[('is_tour_customer', '=', True)]
    )
    
    date_from = fields.Date(
        string='From Date',
        required=True,
        default=lambda self: date.today().replace(day=1)
    )
    
    date_to = fields.Date(
        string='To Date',
        required=True,
        default=lambda self: date.today()
    )
    
    period_type = fields.Selection([
        ('leistung', 'LEISTUNGSZEITRAUM'),
        ('auslage', 'AUSLAGENZEITRAUM'),
    ], string='Period Type',
        default='leistung',
        required=True
    )
    
    tour_ids = fields.Many2many(
        'tour.tour',
        string='Tours to Invoice',
        compute='_compute_tour_ids',
        store=False,
        readonly=True
    )
    
    tour_count = fields.Integer(
        string='Number of Tours',
        compute='_compute_tour_count'
    )
    
    total_amount = fields.Float(
        string='Total Amount',
        compute='_compute_total_amount',
        digits=(12, 2)
    )
    
    # ==================== الطرق المحسوبة ====================
    
    @api.depends('partner_id', 'date_from', 'date_to')
    def _compute_tour_ids(self):
        """حساب الرحلات المتاحة للفوترة"""
        for wizard in self:
            if wizard.partner_id and wizard.date_from and wizard.date_to:
                wizard.tour_ids = self.env['tour.tour'].search([
                    ('partner_id', '=', wizard.partner_id.id),
                    ('date', '>=', wizard.date_from),
                    ('date', '<=', wizard.date_to),
                    ('state', '=', 'completed'),
                    ('is_invoiced', '=', False),
                ])
            else:
                wizard.tour_ids = False
    
    @api.depends('tour_ids')
    def _compute_tour_count(self):
        """حساب عدد الرحلات"""
        for wizard in self:
            wizard.tour_count = len(wizard.tour_ids)
    
    @api.depends('tour_ids')
    def _compute_total_amount(self):
        """حساب المبلغ الإجمالي"""
        for wizard in self:
            wizard.total_amount = sum(wizard.tour_ids.mapped('total_amount'))
    
    # ==================== الإجراءات ====================
    
    def action_create_invoice(self):
        """إنشاء الفاتورة"""
        self.ensure_one()
        
        if not self.tour_ids:
            raise UserError(_('No tours found to invoice!'))
        
        # إنشاء الفاتورة
        invoice = self.env['tour.invoice'].create_invoice_from_tours(
            partner_id=self.partner_id.id,
            date_from=self.date_from,
            date_to=self.date_to,
            period_type=self.period_type
        )
        
        # فتح الفاتورة
        return {
            'name': _('Invoice'),
            'type': 'ir.actions.act_window',
            'res_model': 'tour.invoice',
            'res_id': invoice.id,
            'view_mode': 'form',
            'target': 'current',
        }
    
    def action_preview(self):
        """معاينة الرحلات"""
        self.ensure_one()
        
        return {
            'name': _('Tours to Invoice'),
            'type': 'ir.actions.act_window',
            'res_model': 'tour.tour',
            'domain': [('id', 'in', self.tour_ids.ids)],
            'view_mode': 'tree,form',
            'target': 'new',
        }


class TourInvoiceWizardLine(models.TransientModel):
    """
    سطر في معالج إنشاء الفاتورة (للاستخدام المستقبلي)
    """
    _name = 'tour.invoice.wizard.line'
    _description = 'Invoice Wizard Line'
    
    wizard_id = fields.Many2one(
        'tour.invoice.wizard',
        string='Wizard'
    )
    
    tour_id = fields.Many2one(
        'tour.tour',
        string='Tour'
    )
    
    selected = fields.Boolean(
        string='Select',
        default=True
    )
