# Al Masri Fahrzeugüberführung - Odoo Module

## 🚗 نظام إدارة نقل المركبات الكامل لـ Odoo 19

[![Odoo 19](https://img.shields.io/badge/Odoo-19.0-blue.svg)](https://github.com/odoo/odoo/tree/19.0)
[![License: LGPL v3](https://img.shields.io/badge/License-LGPL%20v3-blue.svg)](https://www.gnu.org/licenses/lgpl-3.0)

---

## 📋 نظرة عامة

هذا الموديول مصمم خصيصاً لشركة **Al Masri Fahrzeugüberführung** لإدارة عمليات نقل المركبات والفوترة.

### الميزات الرئيسية:

- ✅ **إدارة الرحلات (Tours)** - تسجيل وتتبع جميع رحلات نقل المركبات
- ✅ **جدول تسعير متدرج** - 12 شريحة سعرية حسب المسافة
- ✅ **حساب وقت الانتظار** - معدل 10€/ساعة = 0.1667€/دقيقة
- ✅ **نظام الخصومات** - خصومات خاصة للعملاء (50%)
- ✅ **فواتير PDF احترافية** - تصميم ألماني معتمد DIN A4
- ✅ **إدارة السائقين والمركبات**
- ✅ **تقارير وإحصائيات** - Pivot و Graph
- ✅ **معالجة الرقم "1"** - حذف تلقائي من المسافات

---

## 📦 المتطلبات

| المتطلب | الإصدار |
|---------|---------|
| **Odoo** | 19.0 |
| **Python** | 3.10+ |
| **PostgreSQL** | 14+ |

### وحدات Odoo المطلوبة:
- base
- account
- contacts
- mail
- portal
- product
- sale_management
- web

---

## 📁 هيكل الموديول

```
al_masri_tour/
├── __init__.py
├── __manifest__.py
├── models/
│   ├── tour_pricing.py      # جدول التسعير (12 شريحة)
│   ├── tour_driver.py       # السائقين
│   ├── tour_vehicle.py      # المركبات
│   ├── tour_tour.py         # الرحلات (النموذج الرئيسي)
│   ├── tour_invoice.py      # الفواتير
│   └── res_partner.py       # العملاء
├── views/
│   ├── tour_pricing_views.xml
│   ├── tour_driver_views.xml
│   ├── tour_vehicle_views.xml
│   ├── tour_tour_views.xml
│   ├── tour_invoice_views.xml
│   ├── res_partner_views.xml
│   └── menu_views.xml
├── reports/
│   ├── invoice_report.xml   # تقرير الفاتورة PDF
│   └── report_templates.xml
├── security/
│   ├── security.xml
│   └── ir.model.access.csv
├── data/
│   ├── pricing_data.xml     # جدول التسعير
│   ├── company_data.xml     # بيانات الشركة
│   └── partner_data.xml     # DRIVE 500 LOGISTICS
├── wizard/
│   └── tour_invoice_wizard.py
└── static/
    └── description/
        └── icon.png
```

---

## 💰 جدول التسعير المدمج

| الشريحة | المسافة (km) | السعر (€) |
|---------|-------------|-----------|
| 1 | 0 - 20 | 19€ |
| 2 | 21 - 30 | 24€ |
| 3 | 31 - 50 | 40€ |
| 4 | 51 - 100 | 50€ |
| 5 | 101 - 150 | 75€ |
| 6 | 151 - 200 | 85€ |
| 7 | 201 - 250 | 100€ |
| 8 | 251 - 350 | 120€ |
| 9 | 351 - 450 | 145€ |
| 10 | 451 - 550 | 170€ |
| 11 | 551 - 650 | 185€ |
| 12 | 650+ | 185€ + 20€/100km |

---

## ⏱️ وقت الانتظار

- **المعدل:** 10€ لكل ساعة
- **الحساب:** دقائق × 0.1667€
- **التنسيق:** +XX MIN WZ

---

## 🧮 القواعد الحسابية الستة

### القاعدة 1: معالجة الرقم "1"
```
"1 237,43" km → حذف "1 " → 237.43 km للحساب
                            → "1.237,43" للعرض
```

### القاعدة 2: جدول التسعير المتدرج
السعر يعتمد على شريحة المسافة

### القاعدة 3: وقت الانتظار
```
تكلفة الانتظار = دقائق × 0.1667€
```

### القاعدة 4: الخصومات
```
الخصم يُطبّق بعد وقت الانتظار
(السعر الأساسي + الانتظار) × (1 - نسبة الخصم)
```

### القاعدة 5: الضريبة
```
Nettobetrag × 0.19 = Umsatzsteuer
Nettobetrag + Umsatzsteuer = Gesamtbetrag
```

### القاعدة 6: التنسيق الألماني
```
1234.56 → 1.234,56 (نقطة للآلاف، فاصلة للعشريات)
```

---

## 🚀 التثبيت

### الطريقة 1: النسخ اليدوي

```bash
# 1. الانتقال إلى مجلد addons
cd /path/to/odoo/addons/

# 2. نسخ الموديول
cp -r /path/to/al_masri_tour .

# 3. إعادة تشغيل Odoo
sudo systemctl restart odoo
```

### الطريقة 2: من GitHub

```bash
cd /path/to/odoo/addons/
git clone https://github.com/your-repo/al_masri_tour.git
```

### خطوات التثبيت في Odoo:

1. تحديث قائمة الموديولات:
   ```
   Settings → Apps → Update Apps List
   ```

2. البحث عن الموديول:
   ```
   Apps → Search "Al Masri"
   ```

3. تثبيت الموديول:
   ```
   Click "Install"
   ```

---

## ⚙️ التكوين

### 1. إعداد جدول التسعير
```
Vehicle Transport → Settings → Pricing Table
```
- تم إضافة 12 شريحة افتراضية
- يمكن تعديل الأسعار حسب الحاجة

### 2. إضافة السائقين
```
Vehicle Transport → Resources → Drivers → Create
```

### 3. إضافة المركبات
```
Vehicle Transport → Resources → Vehicles → Create
```

### 4. إضافة العملاء
```
Vehicle Transport → Customers → Create
☑ Is Tour Customer
```

### 5. تكوين الشركة
```
Settings → Companies → Update Company Info
- أدخل معلومات البنك
- أدخل الرقم الضريبي
```

---

## 📄 استخدام الفواتير

### إنشاء رحلة جديدة:

1. الذهاب إلى **Vehicle Transport → Tours → All Tours**
2. الضغط على **Create**
3. إدخال بيانات الرحلة:
   - رقم الرحلة (Tour NR)
   - العميل
   - المسافة (بالتسنيق الألماني: `1 237,43`)
   - وقت الانتظار (إن وجد)
   - الخصم (إن وجد)
4. حفظ الرحلة

### إنشاء فاتورة:

1. الذهاب إلى **Vehicle Transport → Invoices**
2. الضغط على **Create**
3. اختيار العميل والفترة
4. إضافة الرحلات المطلوبة
5. تأكيد الفاتورة
6. طباعة PDF

---

## 📄 تنسيق الفاتورة PDF

```
┌────────────────────────────────────────────┐
│ [شعار]                    [مربع الفاتورة] │
├────────────────────────────────────────────┤
│ LEISTUNGSZEITRAUM   |   RECHNUNGSDATUM    │
│ 19.01. - 23.01.2026 |   05.02.2026        │
├────────────────────────────────────────────┤
│ VON                    AN                  │
│ Al Masri...           DRIVE 500...         │
├────────────────────────────────────────────┤
│ # │ TOUR │ BESCHREIBUNG │ STRECKE │ BETRAG │
│ 01 │ 7123 │ FESER       │ 1.237  │ 103,33 │
├────────────────────────────────────────────┤
│                    Nettobetrag:   XXX €    │
│                    USt. 19%:      XX €     │
│                    Gesamtbetrag:  XXX €    │
├────────────────────────────────────────────┤
│ BANKVERBINDUNG                             │
│ IBAN: DE79 4305 0001 0007 4331 39         │
│ BIC: WELADED1BOC                          │
└────────────────────────────────────────────┘
```

---

## 👥 مجموعات المستخدمين

| المجموعة | الصلاحيات |
|----------|----------|
| **Tour User** | إنشاء وتعديل الرحلات والفواتير |
| **Tour Manager** | صلاحيات كاملة + إعدادات |
| **Tour Driver** | عرض وتحديث الرحلات المخصصة فقط |

---

## 📊 التقارير المتاحة

- **تحليل الرحلات** - Pivot/Graph
- **تقارير الإيرادات** - حسب العميل/الشهر
- **أداء السائقين** - تقييم وإحصائيات
- **تقرير المسافات** - إجمالي المسافات

---

## 📞 معلومات الشركة

**Al Masri Fahrzeugüberführung**

| الحقل | القيمة |
|-------|--------|
| المالك | Majd Alddin Almasri |
| العنوان | Langendreerstr. 95, 44388 Dortmund |
| الدولة | Deutschland |
| Steuernummer | 314/5002/8490 |

**معلومات البنك:**

| الحقل | القيمة |
|-------|--------|
| Holder | Majd Alddin Almasri |
| IBAN | DE79 4305 0001 0007 4331 39 |
| Bank | Sparkasse Bochum |
| BIC | WELADED1BOC |

---

## 🔄 التحديثات

### v19.0.1.0.0 (2026-03-13)
- ✅ الإصدار الأولي لـ Odoo 19
- ✅ جميع الميزات الأساسية
- ✅ جدول التسعير (12 شريحة)
- ✅ نظام الخصومات
- ✅ تقارير PDF احترافية
- ✅ معالجة الرقم "1" تلقائياً

---

## 📄 الترخيص

LGPL-3 License

---

## 🤝 المساهمة

نرحب بالمساهمات! يرجى:
1. Fork المشروع
2. إنشاء branch جديد
3. تقديم Pull Request

---

## 📧 الدعم

للمساعدة والاستفسارات:
- **البريد:** support@al-masri-auto.com

---

**تم التطوير بواسطة Al Masri Team** 🚗

**متوافق مع Odoo 19.0** ✅
