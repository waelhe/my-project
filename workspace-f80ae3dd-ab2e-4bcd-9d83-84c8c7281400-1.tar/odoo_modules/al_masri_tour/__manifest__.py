# -*- coding: utf-8 -*-
"""
================================================================================
Al Masri Fahrzeugüberführung - Odoo Module
================================================================================

نظام إدارة نقل المركبات الكامل لشركة Al Masri

الإصدار: 19.0.1.0.0
المؤلف: Al Masri Team
الموقع: https://al-masri-auto.com

الميزات:
- إدارة الرحلات (Tours)
- جدول تسعير متدرج حسب المسافة
- حساب وقت الانتظار تلقائياً
- خصومات خاصة للعملاء
- إنشاء فواتير PDF احترافية
- تقارير مفصلة
- إدارة السائقين والمركبات

================================================================================
"""

{
    'name': 'Al Masri Fahrzeugüberführung',
    'version': '19.0.1.0.0',
    'category': 'Services/Transportation',
    'sequence': 10,
    'summary': 'Vehicle Transport Management System',
    'description': """
نظام متكامل لإدارة نقل المركبات يشمل:
========================================

🚗 إدارة الرحلات (Tours)
----------------------------
- تسجيل تفاصيل كل رحلة
- حساب المسافة والسعر تلقائياً
- تتبع حالة الرحلة

💰 جدول التسعير المتدرج
----------------------------
- 12 شريحة سعرية حسب المسافة
- أسعار من 19€ إلى 185€+
- رسوم إضافية للمسافات الطويلة

⏱️ حساب وقت الانتظار
----------------------------
- معدل 10€/ساعة
- حساب تلقائي: دقائق × 0.1667€

🎁 نظام الخصومات
----------------------------
- خصومات خاصة للعملاء
- خصم 50% للرحلات المعادة

📄 الفواتير والتقارير
----------------------------
- فواتير PDF احترافية
- تصميم ألماني معتمد
- حساب ضريبة 19% تلقائياً

👥 إدارة العملاء والسائقين
----------------------------
- قاعدة بيانات العملاء
- تتبع أداء السائقين
- تقارير شهرية
    """,
    
    'author': 'Al Masri Team',
    'website': 'https://al-masri-auto.com',
    'license': 'LGPL-3',
    'category': 'Services',
    
    # التبعيات - متوافقة مع Odoo 19
    'depends': [
        'base',
        'account',
        'contacts',
        'mail',
        'portal',
        'product',
        'sale_management',
        'web',
    ],
    
    # ملفات البيانات (تُحمّل بالترتيب)
    'data': [
        # الأمان أولاً
        'security/security.xml',
        'security/ir.model.access.csv',
        
        # البيانات الأولية
        'data/pricing_data.xml',
        'data/company_data.xml',
        'data/partner_data.xml',
        
        # النماذج والواجهات
        'views/res_partner_views.xml',
        'views/tour_pricing_views.xml',
        'views/tour_driver_views.xml',
        'views/tour_vehicle_views.xml',
        'views/tour_tour_views.xml',
        'views/tour_invoice_views.xml',
        'views/report_views.xml',
        
        # القوائم والقوائم الرئيسية
        'views/menu_views.xml',
        
        # التقارير
        'reports/invoice_report.xml',
        'reports/report_templates.xml',
        
        # المعالجات
        'wizard/tour_invoice_wizard_views.xml',
    ],
    
    # ملفات للعرض فقط (لا تُحمّل في التثبيت)
    'demo': [
        'data/demo_data.xml',
    ],
    
    # الأصول (CSS, JS, Images) - Odoo 19 format
    'assets': {
        'web.assets_backend': [
            'al_masri_tour/static/src/css/tour_dashboard.css',
            'al_masri_tour/static/src/js/tour_map.js',
            'al_masri_tour/static/src/js/tour_dashboard.js',
        ],
        'web.assets_frontend': [
            'al_masri_tour/static/src/css/portal.css',
        ],
    },
    
    # الصور
    'images': [
        'static/description/banner.png',
        'static/description/screenshot1.png',
        'static/description/screenshot2.png',
    ],
    
    # إعدادات التثبيت
    'installable': True,
    'application': True,
    'auto_install': False,
    'pre_init_hook': None,
    'post_init_hook': 'post_init_hook',
    'uninstall_hook': None,
    
    # معلومات إضافية
    'maintainer': 'Al Masri Team',
    'contributors': [
        'Majd Alddin Almasri <majd@al-masri-auto.com>',
    ],
    'support': 'support@al-masri-auto.com',
    
    # Odoo 19 specific
    'price': 0.0,
    'currency': 'EUR',
}
