# -*- coding: utf-8 -*-
"""
================================================================================
Tour Driver Model - نموذج السائقين
================================================================================

إدارة بيانات السائقين المتاحين لنقل المركبات

================================================================================
"""

from odoo import models, fields, api, _
from odoo.exceptions import ValidationError
import logging

_logger = logging.getLogger(__name__)


class TourDriver(models.Model):
    """
    نموذج السائق
    
    يحتوي على بيانات السائق والإحصائيات
    """
    _name = 'tour.driver'
    _description = 'Tour Driver'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'name asc'
    _rec_name = 'name'
    
    # ==================== الحقول الأساسية ====================
    
    name = fields.Char(
        string='Full Name',
        required=True,
        tracking=True,
        translate=True
    )
    
    code = fields.Char(
        string='Driver Code',
        required=True,
        size=10,
        copy=False,
        tracking=True,
        help='رمز فريد للسائق'
    )
    
    # ==================== معلومات الاتصال ====================
    
    phone = fields.Char(
        string='Phone',
        tracking=True
    )
    
    mobile = fields.Char(
        string='Mobile',
        tracking=True
    )
    
    email = fields.Char(
        string='Email',
        tracking=True
    )
    
    # ==================== العنوان ====================
    
    street = fields.Char(
        string='Street'
    )
    
    street2 = fields.Char(
        string='Street 2')
    
    city = fields.Char(
        string='City'
    )
    
    zip = fields.Char(
        string='ZIP'
    )
    
    country_id = fields.Many2one(
        'res.country',
        string='Country',
        default=lambda self: self.env.ref('base.de', raise_if_not_found=False)
    )
    
    # ==================== معلومات الترخيص ====================
    
    license_number = fields.Char(
        string='License Number',
        tracking=True
    )
    
    license_class = fields.Selection([
        ('b', 'Class B'),
        ('be', 'Class B+E'),
        ('c1', 'Class C1'),
        ('c1e', 'Class C1+E'),
        ('c', 'Class C'),
        ('ce', 'Class C+E'),
        ('d1', 'Class D1'),
        ('d1e', 'Class D1+E'),
        ('d', 'Class D'),
        ('de', 'Class D+E'),
    ], string='License Class',
        default='b',
        tracking=True
    )
    
    license_issue_date = fields.Date(
        string='License Issue Date'
    )
    
    license_expiry_date = fields.Date(
        string='License Expiry Date',
        tracking=True
    )
    
    # ==================== معلومات التوظيف ====================
    
    employee_id = fields.Many2one(
        'hr.employee',
        string='Related Employee'
    )
    
    hire_date = fields.Date(
        string='Hire Date',
        default=fields.Date.today
    )
    
    employment_type = fields.Selection([
        ('full_time', 'Full Time'),
        ('part_time', 'Part Time'),
        ('contractor', 'Contractor'),
        ('freelance', 'Freelance'),
    ], string='Employment Type',
        default='full_time'
    )
    
    hourly_rate = fields.Float(
        string='Hourly Rate (€)',
        digits=(10, 2),
        default=15.0
    )
    
    # ==================== الحالة ====================
    
    state = fields.Selection([
        ('available', 'Available'),
        ('on_tour', 'On Tour'),
        ('on_leave', 'On Leave'),
        ('inactive', 'Inactive'),
    ], string='Status',
        default='available',
        tracking=True
    )
    
    active = fields.Boolean(
        string='Active',
        default=True
    )
    
    # ==================== الإحصائيات ====================
    
    total_tours = fields.Integer(
        string='Total Tours',
        compute='_compute_statistics',
        store=True
    )
    
    total_distance = fields.Float(
        string='Total Distance (km)',
        compute='_compute_statistics',
        store=True,
        digits=(12, 2)
    )
    
    total_revenue = fields.Float(
        string='Total Revenue (€)',
        compute='_compute_statistics',
        store=True,
        digits=(12, 2)
    )
    
    completed_tours = fields.Integer(
        string='Completed Tours',
        compute='_compute_statistics',
        store=True
    )
    
    average_rating = fields.Float(
        string='Average Rating',
        compute='_compute_statistics',
        store=True,
        digits=(3, 2)
    )
    
    # ==================== العلاقات ====================
    
    tour_ids = fields.One2many(
        'tour.tour',
        'driver_id',
        string='Tours'
    )
    
    vehicle_ids = fields.One2many(
        'tour.vehicle',
        'driver_id',
        string='Assigned Vehicles'
    )
    
    company_id = fields.Many2one(
        'res.company',
        string='Company',
        default=lambda self: self.env.company
    )
    
    # ==================== ملاحظات ====================
    
    notes = fields.Text(
        string='Notes'
    )
    
    # ==================== صورة ====================
    
    image_1920 = fields.Image(
        string='Photo',
        max_width=1920,
        max_height=1920
    )
    
    image_128 = fields.Image(
        string='Small Photo',
        related='image_1920',
        max_width=128,
        max_height=128,
        store=True
    )
    
    # ==================== القيود ====================
    
    _sql_constraints = [
        (
            'code_unique',
            'UNIQUE(code)',
            'Driver code must be unique!'
        ),
    ]
    
    # ==================== الطرق المحسوبة ====================
    
    @api.depends('tour_ids', 'tour_ids.state', 'tour_ids.distance', 'tour_ids.total_amount')
    def _compute_statistics(self):
        """حساب الإحصائيات"""
        for driver in self:
            tours = driver.tour_ids.filtered(lambda t: t.state == 'completed')
            driver.total_tours = len(driver.tour_ids)
            driver.completed_tours = len(tours)
            driver.total_distance = sum(tours.mapped('distance'))
            driver.total_revenue = sum(tours.mapped('total_amount'))
            
            # حساب متوسط التقييم
            ratings = tours.mapped('rating')
            if ratings:
                driver.average_rating = sum(ratings) / len(ratings)
            else:
                driver.average_rating = 0.0
    
    # ==================== الطرق ====================
    
    def action_set_available(self):
        """تعيين الحالة إلى متاح"""
        self.write({'state': 'available'})
    
    def action_set_on_tour(self):
        """تعيين الحالة إلى في رحلة"""
        self.write({'state': 'on_tour'})
    
    def action_set_on_leave(self):
        """تعيين الحالة إلى في إجازة"""
        self.write({'state': 'on_leave'})
    
    def action_set_inactive(self):
        """تعيين الحالة إلى غير نشط"""
        self.write({'state': 'inactive', 'active': False})
    
    @api.model
    def get_available_drivers(self):
        """
        الحصول على قائمة السائقين المتاحين
        
        Returns:
            recordset: السائقين المتاحين
        """
        return self.search([
            ('state', '=', 'available'),
            ('active', '=', True),
        ])
    
    def name_get(self):
        """طريقة عرض اسم السائق"""
        result = []
        for driver in self:
            name = f"{driver.name} ({driver.code})"
            if driver.state == 'on_tour':
                name = f"🚗 {name}"
            elif driver.state == 'on_leave':
                name = f"🏖️ {name}"
            result.append((driver.id, name))
        return result
    
    @api.model
    def _name_search(self, name, args=None, operator='ilike', limit=100, name_get_uid=None):
        """بحث محسن"""
        args = args or []
        if name:
            args = ['|', '|'] + [
                ('name', operator, name),
                ('code', operator, name),
                ('phone', operator, name),
            ] + args
        return super()._name_search(name, args=args, operator=operator, limit=limit, name_get_uid=name_get_uid)
    
    @api.constrains('license_expiry_date')
    def _check_license_validity(self):
        """التحقق من صلاحية الرخصة"""
        for driver in self:
            if driver.license_expiry_date and driver.license_expiry_date < fields.Date.today():
                raise ValidationError(_(
                    'Driver %s license has expired on %s!'
                ) % (driver.name, driver.license_expiry_date))
