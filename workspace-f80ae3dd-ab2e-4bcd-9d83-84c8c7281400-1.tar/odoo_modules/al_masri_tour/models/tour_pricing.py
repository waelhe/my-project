# -*- coding: utf-8 -*-
"""
================================================================================
Tour Pricing Model - جدول التسعير المتدرج
================================================================================

يحتوي على شرائح الأسعار حسب المسافة:
- 12 شريحة أساسية من 0 إلى 650+ كيلومتر
- أسعار من 19€ إلى 185€
- رسوم إضافية للمسافات فوق 650 كيلومتر

================================================================================
"""

from odoo import models, fields, api, _
from odoo.exceptions import ValidationError
import logging

_logger = logging.getLogger(__name__)


class TourPricing(models.Model):
    """
    جدول التسعير المتدرج
    
    كل سجل يمثل شريحة سعرية واحدة
    السعر ثابت ضمن الشريحة
    """
    _name = 'tour.pricing'
    _description = 'Tour Pricing Table'
    _order = 'km_from asc'
    _rec_name = 'display_name'
    
    # ==================== الحقول الأساسية ====================
    
    name = fields.Char(
        string='Name',
        required=True,
        translate=True,
        help='اسم الشريحة السعرية'
    )
    
    display_name = fields.Char(
        string='Display Name',
        compute='_compute_display_name',
        store=True
    )
    
    km_from = fields.Float(
        string='From (km)',
        required=True,
        digits=(10, 2),
        help='بداية الشريحة بالكيلومتر'
    )
    
    km_to = fields.Float(
        string='To (km)',
        required=True,
        digits=(10, 2),
        help='نهاية الشريحة بالكيلومتر'
    )
    
    price = fields.Float(
        string='Price (€)',
        required=True,
        digits=(10, 2),
        help='السعر الثابت للشريحة باليورو'
    )
    
    # ==================== الحقول المحسوبة ====================
    
    distance_range = fields.Char(
        string='Distance Range',
        compute='_compute_distance_range',
        store=True
    )
    
    is_unlimited = fields.Boolean(
        string='Unlimited',
        compute='_compute_is_unlimited',
        store=True,
        help='شريحة بدون حد أعلى (650+ km)'
    )
    
    extra_charge_per_100km = fields.Float(
        string='Extra Charge per 100km (€)',
        digits=(10, 2),
        default=0.0,
        help='رسوم إضافية لكل 100 كيلومتر (للشريحة الأخيرة فقط)'
    )
    
    # ==================== حقول إضافية ====================
    
    active = fields.Boolean(
        string='Active',
        default=True
    )
    
    company_id = fields.Many2one(
        'res.company',
        string='Company',
        default=lambda self: self.env.company
    )
    
    notes = fields.Text(
        string='Notes',
        translate=True
    )
    
    sequence = fields.Integer(
        string='Sequence',
        default=10
    )
    
    # ==================== القيود ====================
    
    _sql_constraints = [
        (
            'km_from_positive',
            'CHECK(km_from >= 0)',
            'Distance from must be positive!'
        ),
        (
            'km_to_positive',
            'CHECK(km_to >= 0)',
            'Distance to must be positive!'
        ),
        (
            'price_positive',
            'CHECK(price >= 0)',
            'Price must be positive!'
        ),
        (
            'km_range_valid',
            'CHECK(km_to >= km_from)',
            'Distance to must be greater than or equal to distance from!'
        ),
    ]
    
    # ==================== الطرق المحسوبة ====================
    
    @api.depends('name', 'km_from', 'km_to')
    def _compute_display_name(self):
        """حساب اسم العرض"""
        for record in self:
            if record.km_to == 99999:
                record.display_name = f"{record.name} ({record.km_from:.0f}+ km) - {record.price:.0f}€"
            else:
                record.display_name = f"{record.name} ({record.km_from:.0f}-{record.km_to:.0f} km) - {record.price:.0f}€"
    
    @api.depends('km_from', 'km_to')
    def _compute_distance_range(self):
        """حساب نطاق المسافة للعرض"""
        for record in self:
            if record.km_to == 99999:
                record.distance_range = f"{record.km_from:.0f}+ km"
            else:
                record.distance_range = f"{record.km_from:.0f} - {record.km_to:.0f} km"
    
    @api.depends('km_to')
    def _compute_is_unlimited(self):
        """تحديد ما إذا كانت الشريحة بدون حد أعلى"""
        for record in self:
            record.is_unlimited = record.km_to >= 99999
    
    # ==================== الطرق ====================
    
    @api.model
    def get_price_for_distance(self, km):
        """
        الحصول على السعر لمسافة معينة
        
        القاعدة: أي مسافة تتجاوز الحد الأعلى للشريحة بـ 0.5 km
        أو أكثر تنتقل للشريحة الأعلى
        
        Args:
            km (float): المسافة بالكيلومتر
            
        Returns:
            float: السعر باليورو
        """
        if km <= 0:
            return 0.0
        
        # البحث عن الشريحة المناسبة
        pricing = self.search([
            ('km_from', '<=', km),
            ('km_to', '>=', km),
            ('active', '=', True),
        ], limit=1)
        
        if not pricing:
            # البحث عن الشريحة الأخيرة (650+)
            pricing = self.search([
                ('is_unlimited', '=', True),
                ('active', '=', True),
            ], limit=1)
        
        if not pricing:
            raise ValidationError(_('No pricing found for distance %s km') % km)
        
        # حساب السعر
        if pricing.is_unlimited and km > pricing.km_from:
            # المسافات فوق 650 كيلومتر
            extra_km = km - pricing.km_from
            extra_charge = (extra_km / 100) * pricing.extra_charge_per_100km
            return pricing.price + extra_charge
        else:
            return pricing.price
    
    @api.model
    def get_pricing_table_summary(self):
        """
        الحصول على ملخص جدول التسعير
        
        Returns:
            list: قائمة بجميع الشرائح السعرية
        """
        pricings = self.search([('active', '=', True)], order='km_from asc')
        return [{
            'id': p.id,
            'name': p.name,
            'km_from': p.km_from,
            'km_to': p.km_to if not p.is_unlimited else '∞',
            'price': p.price,
            'distance_range': p.distance_range,
            'extra_charge': p.extra_charge_per_100km if p.is_unlimited else 0,
        } for p in pricings]
    
    @api.constrains('km_from', 'km_to')
    def _check_no_overlap(self):
        """التحقق من عدم تداخل الشرائح"""
        for record in self:
            domain = [
                ('id', '!=', record.id),
                ('active', '=', True),
            ]
            overlapping = self.search(domain)
            for other in overlapping:
                # التحقق من التداخل
                if (record.km_from <= other.km_to and record.km_to >= other.km_from):
                    raise ValidationError(_(
                        'Pricing overlap detected!\n'
                        'This pricing (%.0f-%.0f km) overlaps with "%s" (%.0f-%.0f km)'
                    ) % (record.km_from, record.km_to, other.name, other.km_from, other.km_to))


class TourPricingLine(models.Model):
    """
    سطر تفصيلي في جدول التسعير (للعرض والتقارير)
    """
    _name = 'tour.pricing.line'
    _description = 'Tour Pricing Line'
    _auto = False  # نموذج للعرض فقط
    
    # سيتم استخدامه في التقارير والواجهات
    pass


class TourWaitingTimeRate(models.Model):
    """
    معدل سعر وقت الانتظار
    
    المعدل: 10€ لكل ساعة = 0.1667€ لكل دقيقة
    """
    _name = 'tour.waiting.time.rate'
    _description = 'Waiting Time Rate'
    _rec_name = 'name'
    
    name = fields.Char(
        string='Name',
        required=True,
        default='Standard Rate'
    )
    
    rate_per_hour = fields.Float(
        string='Rate per Hour (€)',
        required=True,
        digits=(10, 2),
        default=10.0,
        help='معدل السعر بالساعة'
    )
    
    rate_per_minute = fields.Float(
        string='Rate per Minute (€)',
        compute='_compute_rate_per_minute',
        store=True,
        digits=(10, 4),
        help='معدل السعر بالدقيقة'
    )
    
    active = fields.Boolean(
        string='Active',
        default=True
    )
    
    company_id = fields.Many2one(
        'res.company',
        string='Company',
        default=lambda self: self.env.company
    )
    
    date_from = fields.Date(
        string='Valid From',
        default=fields.Date.today()
    )
    
    date_to = fields.Date(
        string='Valid To'
    )
    
    @api.depends('rate_per_hour')
    def _compute_rate_per_minute(self):
        """حساب معدل السعر بالدقيقة"""
        for record in self:
            record.rate_per_minute = record.rate_per_hour / 60.0
    
    @api.model
    def get_current_rate(self):
        """
        الحصول على المعدل الحالي
        
        Returns:
            float: معدل السعر بالدقيقة
        """
        today = fields.Date.today()
        rate = self.search([
            ('active', '=', True),
            ('date_from', '<=', today),
            '|',
            ('date_to', '=', False),
            ('date_to', '>=', today),
        ], limit=1, order='date_from desc')
        
        if not rate:
            # إنشاء معدل افتراضي
            rate = self.create({
                'name': 'Standard Rate',
                'rate_per_hour': 10.0,
            })
        
        return rate.rate_per_minute
    
    @api.model
    def calculate_waiting_cost(self, minutes):
        """
        حساب تكلفة وقت الانتظار
        
        Args:
            minutes (int): عدد الدقائق
            
        Returns:
            float: التكلفة باليورو
        """
        rate = self.get_current_rate()
        return round(minutes * rate, 2)
