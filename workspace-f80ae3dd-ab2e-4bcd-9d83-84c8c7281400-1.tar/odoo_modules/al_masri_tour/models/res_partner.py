# -*- coding: utf-8 -*-
"""
================================================================================
Res Partner Extension - توسيع نموذج الشركاء
================================================================================

إضافة حقول إضافية للعملاء المتعاملين مع خدمة نقل المركبات

================================================================================
"""

from odoo import models, fields, api, _
import logging

_logger = logging.getLogger(__name__)


class ResPartner(models.Model):
    """
    توسيع نموذج الشركاء (العملاء)
    
    يضيف:
    - حقول خاصة بنقل المركبات
    - إحصائيات التعامل
    - إعدادات الخصم
    """
    _inherit = 'res.partner'
    
    # ==================== حقول نقل المركبات ====================
    
    is_tour_customer = fields.Boolean(
        string='Tour Customer',
        default=False,
        help='هل هذا العميل يتعامل مع خدمة نقل المركبات'
    )
    
    customer_code = fields.Char(
        string='Customer Code',
        size=20,
        copy=False,
        help='رمز العميل'
    )
    
    # ==================== إعدادات الخصم ====================
    
    default_discount = fields.Integer(
        string='Default Discount (%)',
        default=0,
        help='نسبة الخصم الافتراضية لهذا العميل'
    )
    
    discount_reason = fields.Char(
        string='Discount Reason',
        help='سبب الخصم الخاص'
    )
    
    has_special_pricing = fields.Boolean(
        string='Has Special Pricing',
        default=False,
        help='هل للعميل أسعار خاصة'
    )
    
    special_pricing_notes = fields.Text(
        string='Special Pricing Notes',
        help='ملاحظات الأسعار الخاصة'
    )
    
    # ==================== معلومات الفواتير ====================
    
    invoice_email = fields.Char(
        string='Invoice Email',
        help='بريد إرسال الفواتير'
    )
    
    invoice_contact = fields.Char(
        string='Invoice Contact',
        help='جهة اتصال الفواتير'
    )
    
    payment_terms_days = fields.Integer(
        string='Payment Terms (Days)',
        default=14,
        help='شروط الدفع بالأيام'
    )
    
    # ==================== الإحصائيات ====================
    
    tour_count = fields.Integer(
        string='Total Tours',
        compute='_compute_tour_statistics',
        store=True
    )
    
    tour_distance_total = fields.Float(
        string='Total Distance (km)',
        compute='_compute_tour_statistics',
        store=True,
        digits=(12, 2)
    )
    
    tour_revenue_total = fields.Float(
        string='Total Revenue (€)',
        compute='_compute_tour_statistics',
        store=True,
        digits=(12, 2)
    )
    
    invoice_count = fields.Integer(
        string='Total Invoices',
        compute='_compute_invoice_statistics',
        store=True
    )
    
    last_tour_date = fields.Date(
        string='Last Tour Date',
        compute='_compute_tour_statistics',
        store=True
    )
    
    last_invoice_date = fields.Date(
        string='Last Invoice Date',
        compute='_compute_invoice_statistics',
        store=True
    )
    
    # ==================== العلاقات ====================
    
    tour_ids = fields.One2many(
        'tour.tour',
        'partner_id',
        string='Tours'
    )
    
    invoice_ids = fields.One2many(
        'tour.invoice',
        'partner_id',
        string='Invoices'
    )
    
    # ==================== الطرق المحسوبة ====================
    
    @api.depends('tour_ids', 'tour_ids.state', 'tour_ids.distance', 'tour_ids.total_amount', 'tour_ids.date')
    def _compute_tour_statistics(self):
        """حساب إحصائيات الرحلات"""
        for partner in self:
            tours = partner.tour_ids.filtered(lambda t: t.state in ['completed', 'invoiced'])
            partner.tour_count = len(tours)
            partner.tour_distance_total = sum(tours.mapped('distance'))
            partner.tour_revenue_total = sum(tours.mapped('total_amount'))
            
            if tours:
                partner.last_tour_date = max(tours.mapped('date'))
            else:
                partner.last_tour_date = False
    
    @api.depends('invoice_ids', 'invoice_ids.state', 'invoice_ids.total_amount', 'invoice_ids.invoice_date')
    def _compute_invoice_statistics(self):
        """حساب إحصائيات الفواتير"""
        for partner in self:
            invoices = partner.invoice_ids.filtered(lambda i: i.state != 'cancelled')
            partner.invoice_count = len(invoices)
            
            if invoices:
                partner.last_invoice_date = max(invoices.mapped('invoice_date'))
            else:
                partner.last_invoice_date = False
    
    # ==================== الطرق ====================
    
    def action_view_tours(self):
        """عرض الرحلات"""
        self.ensure_one()
        return {
            'name': _('Tours'),
            'type': 'ir.actions.act_window',
            'res_model': 'tour.tour',
            'view_mode': 'tree,form',
            'domain': [('partner_id', '=', self.id)],
            'context': {'default_partner_id': self.id},
        }
    
    def action_view_invoices(self):
        """عرض الفواتير"""
        self.ensure_one()
        return {
            'name': _('Invoices'),
            'type': 'ir.actions.act_window',
            'res_model': 'tour.invoice',
            'view_mode': 'tree,form',
            'domain': [('partner_id', '=', self.id)],
            'context': {'default_partner_id': self.id},
        }
    
    @api.model
    def get_customer_for_invoice(self, customer_code):
        """
        الحصول على العميل من الرمز
        
        Args:
            customer_code (str): رمز العميل
            
        Returns:
            record: سجل العميل أو False
        """
        return self.search([
            ('customer_code', '=', customer_code),
            ('is_tour_customer', '=', True),
        ], limit=1)


class ResCompany(models.Model):
    """
    توسيع نموذج الشركة
    
    يضيف معلومات الشركة الخاصة بنقل المركبات
    """
    _inherit = 'res.company'
    
    # ==================== معلومات الشركة ====================
    
    company_owner = fields.Char(
        string='Owner Name',
        default='Majd Alddin Almasri',
        help='اسم مالك الشركة'
    )
    
    # ==================== معلومات البنك ====================
    
    tour_bank_holder = fields.Char(
        string='Bank Account Holder',
        default='Majd Alddin Almasri'
    )
    
    tour_bank_name = fields.Char(
        string='Bank Name',
        default='Sparkasse Bochum'
    )
    
    tour_bank_iban = fields.Char(
        string='IBAN',
        default='DE79 4305 0001 0007 4331 39'
    )
    
    tour_bank_bic = fields.Char(
        string='BIC',
        default='WELADED1BOC'
    )
    
    # ==================== معلومات ضريبية ====================
    
    tour_tax_number = fields.Char(
        string='Tax Number (Steuernummer)',
        default='314/5002/8490'
    )
    
    # ==================== إعدادات الفوترة ====================
    
    tour_invoice_prefix = fields.Char(
        string='Invoice Number Prefix',
        default='#'
    )
    
    tour_default_tax_rate = fields.Float(
        string='Default Tax Rate (%)',
        default=19.0
    )
    
    tour_waiting_rate = fields.Float(
        string='Waiting Rate (€/hour)',
        default=10.0,
        help='معدل سعر وقت الانتظار بالساعة'
    )
