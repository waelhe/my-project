# -*- coding: utf-8 -*-
"""
================================================================================
Tour Invoice Model - نموذج الفاتورة (Odoo 19.0)
================================================================================

إدارة فواتير نقل المركبات

================================================================================
"""

from odoo import models, fields, api, _
from odoo.exceptions import ValidationError, UserError
from odoo.tools import format_date, format_amount
from datetime import date, timedelta
import logging

_logger = logging.getLogger(__name__)


class TourInvoice(models.Model):
    """
    نموذج الفاتورة
    
    فاتورة تحتوي على عدة رحلات لعميل واحد
    """
    _name = 'tour.invoice'
    _description = 'Tour Invoice'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'invoice_date desc, name desc'
    _rec_name = 'name'
    
    # ==================== الحقول الأساسية ====================
    
    name = fields.Char(
        string='Invoice Number',
        required=True,
        copy=False,
        readonly=True,
        default=lambda self: _('New'),
        tracking=True
    )
    
    invoice_date = fields.Date(
        string='Invoice Date',
        required=True,
        default=fields.Date.today,
        tracking=True,
        index=True
    )
    
    # ==================== الفترة ====================
    
    period_type = fields.Selection([
        ('leistung', 'LEISTUNGSZEITRAUM'),
        ('auslage', 'AUSLAGENZEITRAUM'),
    ], string='Period Type',
        default='leistung',
        required=True,
        tracking=True
    )
    
    period_label = fields.Char(
        string='Period Label',
        compute='_compute_period_label',
        store=True
    )
    
    date_from = fields.Date(
        string='From Date',
        required=True,
        tracking=True
    )
    
    date_to = fields.Date(
        string='To Date',
        required=True,
        tracking=True
    )
    
    period_value = fields.Char(
        string='Period Value',
        compute='_compute_period_value',
        store=True
    )
    
    # ==================== العميل ====================
    
    partner_id = fields.Many2one(
        'res.partner',
        string='Customer',
        required=True,
        tracking=True,
        domain=['|', ('is_company', '=', True), ('parent_id', '!=', False)]
    )
    
    # ==================== أسطر الفاتورة ====================
    
    line_ids = fields.One2many(
        'tour.invoice.line',
        'invoice_id',
        string='Invoice Lines',
        copy=True
    )
    
    # ==================== المجاميع ====================
    
    subtotal = fields.Float(
        string='Subtotal (€)',
        compute='_compute_totals',
        store=True,
        digits=(12, 2)
    )
    
    net_amount = fields.Float(
        string='Net Amount (€)',
        compute='_compute_totals',
        store=True,
        digits=(12, 2),
        help='Nettobetrag'
    )
    
    tax_rate = fields.Float(
        string='Tax Rate (%)',
        default=19.0,
        required=True,
        digits=(5, 2)
    )
    
    tax_amount = fields.Float(
        string='Tax Amount (€)',
        compute='_compute_totals',
        store=True,
        digits=(12, 2),
        help='Umsatzsteuer 19%'
    )
    
    total_amount = fields.Float(
        string='Total Amount (€)',
        compute='_compute_totals',
        store=True,
        digits=(12, 2),
        help='Gesamtbetrag'
    )
    
    # ==================== المبالغ للعرض ====================
    
    net_amount_display = fields.Char(
        string='Net Amount (Display)',
        compute='_compute_amounts_display',
        store=True
    )
    
    tax_amount_display = fields.Char(
        string='Tax Amount (Display)',
        compute='_compute_amounts_display',
        store=True
    )
    
    total_amount_display = fields.Char(
        string='Total Amount (Display)',
        compute='_compute_amounts_display',
        store=True
    )
    
    # ==================== الحالة ====================
    
    state = fields.Selection([
        ('draft', 'Draft'),
        ('confirmed', 'Confirmed'),
        ('sent', 'Sent'),
        ('paid', 'Paid'),
        ('cancelled', 'Cancelled'),
    ], string='Status',
        default='draft',
        tracking=True,
        index=True
    )
    
    # ==================== التكامل مع Odoo Accounting ====================
    
    account_move_id = fields.Many2one(
        'account.move',
        string='Accounting Invoice',
        readonly=True,
        tracking=True
    )
    
    payment_state = fields.Selection(
        related='account_move_id.payment_state',
        string='Payment Status'
    )
    
    # ==================== الرحلات ====================
    
    tour_ids = fields.One2many(
        'tour.tour',
        'invoice_id',
        string='Tours'
    )
    
    tour_count = fields.Integer(
        string='Tour Count',
        compute='_compute_tour_count',
        store=True
    )
    
    # ==================== معلومات الشركة ====================
    
    company_id = fields.Many2one(
        'res.company',
        string='Company',
        default=lambda self: self.env.company,
        required=True
    )
    
    currency_id = fields.Many2one(
        'res.currency',
        related='company_id.currency_id',
        string='Currency'
    )
    
    # ==================== معلومات المرسل ====================
    
    sender_name = fields.Char(
        string='Sender Name',
        related='company_id.name',
        store=True
    )
    
    sender_street = fields.Char(
        string='Sender Street',
        related='company_id.street',
        store=True
    )
    
    sender_zip = fields.Char(
        string='Sender ZIP',
        related='company_id.zip',
        store=True
    )
    
    sender_city = fields.Char(
        string='Sender City',
        related='company_id.city',
        store=True
    )
    
    sender_country = fields.Char(
        string='Sender Country',
        related='company_id.country_id.name',
        store=True
    )
    
    tax_number = fields.Char(
        string='Tax Number',
        related='company_id.vat',
        store=True
    )
    
    # ==================== معلومات المستلم ====================
    
    recipient_name = fields.Char(
        string='Recipient Name',
        related='partner_id.name',
        store=True
    )
    
    recipient_street = fields.Char(
        string='Recipient Street',
        related='partner_id.street',
        store=True
    )
    
    recipient_zip = fields.Char(
        string='Recipient ZIP',
        related='partner_id.zip',
        store=True
    )
    
    recipient_city = fields.Char(
        string='Recipient City',
        related='partner_id.city',
        store=True
    )
    
    recipient_country = fields.Char(
        string='Recipient Country',
        related='partner_id.country_id.name',
        store=True
    )
    
    # ==================== معلومات البنك ====================
    
    bank_account_holder = fields.Char(
        string='Account Holder',
        default='Majd Alddin Almasri'
    )
    
    bank_name = fields.Char(
        string='Bank Name',
        default='Sparkasse Bochum'
    )
    
    bank_iban = fields.Char(
        string='IBAN',
        default='DE79 4305 0001 0007 4331 39'
    )
    
    bank_bic = fields.Char(
        string='BIC',
        default='WELADED1BOC'
    )
    
    # ==================== ملاحظات ====================
    
    notes = fields.Text(
        string='Notes'
    )
    
    internal_notes = fields.Text(
        string='Internal Notes'
    )
    
    # ==================== القيود ====================
    
    _sql_constraints = [
        (
            'name_unique',
            'UNIQUE(name)',
            'Invoice number must be unique!'
        ),
    ]
    
    # ==================== الطرق المحسوبة ====================
    
    @api.depends('period_type')
    def _compute_period_label(self):
        """حساب تسمية الفترة"""
        for invoice in self:
            invoice.period_label = dict(self._fields['period_type'].selection).get(
                invoice.period_type, 'LEISTUNGSZEITRAUM'
            )
    
    @api.depends('date_from', 'date_to')
    def _compute_period_value(self):
        """حساب قيمة الفترة للعرض"""
        for invoice in self:
            if invoice.date_from and invoice.date_to:
                # التنسيق: DD.MM. - DD.MM.YYYY
                from_str = invoice.date_from.strftime('%d.%m.')
                to_str = invoice.date_to.strftime('%d.%m.%Y')
                invoice.period_value = f"{from_str} - {to_str}"
            else:
                invoice.period_value = ''
    
    @api.depends('line_ids', 'line_ids.total_amount', 'period_type')
    def _compute_totals(self):
        """
        حساب المجاميع
        
        القاعدة 5: حساب الضريبة والمجاميع
        """
        for invoice in self:
            if invoice.period_type == 'leistung':
                # LEISTUNGSZEITRAUM: الضريبة تُحسب في النهاية
                invoice.net_amount = sum(invoice.line_ids.mapped('total_amount'))
                invoice.tax_amount = round(invoice.net_amount * invoice.tax_rate / 100, 2)
                invoice.total_amount = invoice.net_amount + invoice.tax_amount
            else:
                # AUSLAGENZEITRAUM: الضريبة محسوبة مسبقاً
                invoice.net_amount = sum(invoice.line_ids.mapped('price_amount'))
                invoice.tax_amount = sum(invoice.line_ids.mapped('tax_amount'))
                invoice.total_amount = sum(invoice.line_ids.mapped('total_amount'))
            
            invoice.subtotal = invoice.net_amount
    
    @api.depends('net_amount', 'tax_amount', 'total_amount')
    def _compute_amounts_display(self):
        """حساب المبالغ للعرض بالتنسيق الألماني"""
        for invoice in self:
            invoice.net_amount_display = invoice.format_german(invoice.net_amount)
            invoice.tax_amount_display = invoice.format_german(invoice.tax_amount)
            invoice.total_amount_display = invoice.format_german(invoice.total_amount)
    
    @api.depends('tour_ids')
    def _compute_tour_count(self):
        """حساب عدد الرحلات"""
        for invoice in self:
            invoice.tour_count = len(invoice.tour_ids)
    
    # ==================== إنشاء الرقم التسلسلي ====================
    
    @api.model_create_multi
    def create(self, vals_list):
        """إنشاء رقم تسلسلي تلقائي"""
        for vals in vals_list:
            if vals.get('name', _('New')) == _('New'):
                vals['name'] = self.env['ir.sequence'].next_by_code('tour.invoice') or _('New')
        return super().create(vals_list)
    
    # ==================== الطرق ====================
    
    def format_german(self, number):
        """
        تنسيق رقم بالطريقة الألمانية
        
        القاعدة 6: نقطة للآلاف، فاصلة للعشريات
        مثال: 1234.56 → "1.234,56"
        """
        formatted = f"{number:,.2f}"
        return formatted.replace(',', 'X').replace('.', ',').replace('X', '.')
    
    def action_confirm(self):
        """تأكيد الفاتورة"""
        for invoice in self:
            if not invoice.line_ids:
                raise UserError(_('Cannot confirm an invoice without lines!'))
        
        self.write({'state': 'confirmed'})
    
    def action_send(self):
        """إرسال الفاتورة"""
        self.write({'state': 'sent'})
    
    def action_paid(self):
        """تحديد الفاتورة كمدفوعة"""
        self.write({'state': 'paid'})
    
    def action_cancel(self):
        """إلغاء الفاتورة"""
        for invoice in self:
            # إلغاء ربط الرحلات
            invoice.tour_ids.write({'invoice_id': False, 'is_invoiced': False})
        
        self.write({'state': 'cancelled'})
    
    def action_print(self):
        """طباعة الفاتورة"""
        self.ensure_one()
        return self.env.ref('al_masri_tour.report_tour_invoice').report_action(self)
    
    def action_create_account_invoice(self):
        """إنشاء فاتورة محاسبية في Odoo"""
        self.ensure_one()
        
        if self.account_move_id:
            raise UserError(_('Accounting invoice already exists!'))
        
        # إنشاء الفاتورة المحاسبية
        move_lines = []
        for line in self.line_ids:
            move_lines.append((0, 0, {
                'name': line.description,
                'quantity': 1,
                'price_unit': line.total_amount,
                'tax_ids': [(6, 0, [self.env.ref('l10n_de.tax_19').id])],
            }))
        
        move = self.env['account.move'].create({
            'move_type': 'out_invoice',
            'partner_id': self.partner_id.id,
            'invoice_date': self.invoice_date,
            'invoice_line_ids': move_lines,
        })
        
        self.write({'account_move_id': move.id})
        
        return {
            'name': _('Accounting Invoice'),
            'type': 'ir.actions.act_window',
            'res_model': 'account.move',
            'res_id': move.id,
            'view_mode': 'form',
        }
    
    @api.model
    def create_invoice_from_tours(self, partner_id, date_from, date_to, period_type='leistung'):
        """
        إنشاء فاتورة من رحلات محددة
        
        Args:
            partner_id (int): معرف العميل
            date_from (date): من تاريخ
            date_to (date): إلى تاريخ
            period_type (str): نوع الفترة
            
        Returns:
            record: الفاتورة الجديدة
        """
        # البحث عن الرحلات
        tours = self.env['tour.tour'].get_tours_for_invoice(partner_id, date_from, date_to)
        
        if not tours:
            raise UserError(_('No completed tours found for this period!'))
        
        # إنشاء الفاتورة
        invoice = self.create({
            'partner_id': partner_id,
            'date_from': date_from,
            'date_to': date_to,
            'period_type': period_type,
        })
        
        # إنشاء أسطر الفاتورة
        for idx, tour in enumerate(tours, 1):
            line_data = tour.get_invoice_line_data()
            line_data['invoice_id'] = invoice.id
            line_data['sequence'] = idx
            
            self.env['tour.invoice.line'].create(line_data)
            
            # ربط الرحلة بالفاتورة
            tour.write({
                'invoice_id': invoice.id,
                'is_invoiced': True,
                'state': 'invoiced',
            })
        
        return invoice
    
    def name_get(self):
        """عرض اسم الفاتورة"""
        result = []
        for invoice in self:
            name = f"{invoice.name}"
            if invoice.partner_id:
                name += f" - {invoice.partner_id.name}"
            if invoice.total_amount:
                name += f" ({invoice.total_amount_display} €)"
            result.append((invoice.id, name))
        return result


class TourInvoiceLine(models.Model):
    """
    سطر الفاتورة
    
    يمثل رحلة واحدة في الفاتورة
    """
    _name = 'tour.invoice.line'
    _description = 'Tour Invoice Line'
    _order = 'sequence, id'
    
    # ==================== الحقول الأساسية ====================
    
    invoice_id = fields.Many2one(
        'tour.invoice',
        string='Invoice',
        required=True,
        ondelete='cascade'
    )
    
    sequence = fields.Integer(
        string='#',
        default=1
    )
    
    tour_id = fields.Many2one(
        'tour.tour',
        string='Tour',
        ondelete='set null'
    )
    
    tour_nr = fields.Char(
        string='Tour NR.',
        required=True
    )
    
    # ==================== الوصف ====================
    
    description = fields.Text(
        string='Description',
        required=True,
        help='BESCHREIBUNG'
    )
    
    # ==================== المسافة ====================
    
    distance_display = fields.Char(
        string='Distance (Display)',
        help='STRECKE (KM) - للعرض بالتنسيق الألماني'
    )
    
    distance = fields.Float(
        string='Distance (km)',
        digits=(10, 2)
    )
    
    # ==================== الأسعار ====================
    
    base_price = fields.Float(
        string='Base Price (€)',
        digits=(10, 2)
    )
    
    waiting_minutes = fields.Integer(
        string='Waiting Time (min)',
        default=0
    )
    
    waiting_cost = fields.Float(
        string='Waiting Cost (€)',
        digits=(10, 2)
    )
    
    price_amount = fields.Float(
        string='Price (€)',
        digits=(10, 2),
        help='PREIS - السعر قبل الخصم'
    )
    
    # ==================== الخصم ====================
    
    discount_percent = fields.Integer(
        string='Discount (%)',
        default=0
    )
    
    discount_amount = fields.Float(
        string='Discount Amount (€)',
        digits=(10, 2)
    )
    
    discount_display = fields.Char(
        string='Discount (Display)',
        compute='_compute_discount_display',
        store=True
    )
    
    # ==================== المبالغ ====================
    
    tax_amount = fields.Float(
        string='Tax Amount (€)',
        digits=(10, 2),
        help='USt. - للفواتير من نوع AUSLAGENZEITRAUM'
    )
    
    total_amount = fields.Float(
        string='Total Amount (€)',
        digits=(10, 2),
        help='BETRAG'
    )
    
    # ==================== للعرض ====================
    
    price_display = fields.Char(
        string='Price (Display)',
        compute='_compute_price_display',
        store=True
    )
    
    total_display = fields.Char(
        string='Total (Display)',
        compute='_compute_total_display',
        store=True
    )
    
    # ==================== شركة ====================
    
    company_id = fields.Many2one(
        'res.company',
        related='invoice_id.company_id',
        store=True
    )
    
    currency_id = fields.Many2one(
        'res.currency',
        related='invoice_id.currency_id'
    )
    
    # ==================== الطرق المحسوبة ====================
    
    @api.depends('discount_percent')
    def _compute_discount_display(self):
        """حساب عرض الخصم"""
        for line in self:
            if line.discount_percent > 0:
                line.discount_display = f"{line.discount_percent}%"
            else:
                line.discount_display = "—"
    
    @api.depends('price_amount')
    def _compute_price_display(self):
        """حساب عرض السعر"""
        for line in self:
            if line.invoice_id:
                line.price_display = line.invoice_id.format_german(line.price_amount)
            else:
                formatted = f"{line.price_amount:,.2f}"
                line.price_display = formatted.replace(',', 'X').replace('.', ',').replace('X', '.')
    
    @api.depends('total_amount')
    def _compute_total_display(self):
        """حساب عرض المجموع"""
        for line in self:
            if line.invoice_id:
                line.total_display = line.invoice_id.format_german(line.total_amount)
            else:
                formatted = f"{line.total_amount:,.2f}"
                line.total_display = formatted.replace(',', 'X').replace('.', ',').replace('X', '.')
    
    # ==================== الطرق ====================
    
    def format_german(self, number):
        """تنسيق رقم بالطريقة الألمانية"""
        formatted = f"{number:,.2f}"
        return formatted.replace(',', 'X').replace('.', ',').replace('X', '.')
    
    @api.onchange('tour_id')
    def _onchange_tour_id(self):
        """تحديث البيانات من الرحلة"""
        if self.tour_id:
            data = self.tour_id.get_invoice_line_data()
            self.tour_nr = data.get('tour_nr', '')
            self.description = data.get('description', '')
            self.distance_display = data.get('distance_display', '')
            self.distance = data.get('distance', 0)
            self.base_price = data.get('base_price', 0)
            self.waiting_minutes = data.get('waiting_minutes', 0)
            self.waiting_cost = data.get('waiting_cost', 0)
            self.price_amount = data.get('price_amount', 0)
            self.discount_percent = data.get('discount_percent', 0)
            self.discount_amount = data.get('discount_amount', 0)
            self.total_amount = data.get('total_amount', 0)
