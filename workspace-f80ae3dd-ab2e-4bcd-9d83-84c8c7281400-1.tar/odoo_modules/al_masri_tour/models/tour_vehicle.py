# -*- coding: utf-8 -*-
"""
================================================================================
Tour Vehicle Model - نموذج المركبات
================================================================================

إدارة المركبات المستخدمة في نقل السيارات (الشاحنات والمقطورات)

================================================================================
"""

from odoo import models, fields, api, _
from odoo.exceptions import ValidationError
import logging

_logger = logging.getLogger(__name__)


class TourVehicle(models.Model):
    """
    نموذج المركبة (شاحنة نقل السيارات)
    
    يمكن أن تكون:
    - شاحنة مفردة
    - مقطورة
    - مجموعة شاحنة + مقطورة
    """
    _name = 'tour.vehicle'
    _description = 'Tour Vehicle'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'name asc'
    _rec_name = 'name'
    
    # ==================== الحقول الأساسية ====================
    
    name = fields.Char(
        string='Vehicle Name',
        required=True,
        tracking=True
    )
    
    code = fields.Char(
        string='Vehicle Code',
        required=True,
        size=20,
        copy=False,
        tracking=True,
        help='رمز فريد للمركبة'
    )
    
    license_plate = fields.Char(
        string='License Plate',
        required=True,
        tracking=True,
        help='رقم اللوحة'
    )
    
    # ==================== نوع المركبة ====================
    
    vehicle_type = fields.Selection([
        ('truck', 'Truck (LKW)'),
        ('trailer', 'Trailer (Anhänger)'),
        ('combo', 'Truck + Trailer Combo'),
    ], string='Vehicle Type',
        default='truck',
        required=True,
        tracking=True
    )
    
    # ==================== مواصفات المركبة ====================
    
    brand = fields.Char(
        string='Brand',
        tracking=True,
        help='العلامة التجارية'
    )
    
    model = fields.Char(
        string='Model',
        tracking=True
    )
    
    year = fields.Integer(
        string='Year',
        tracking=True
    )
    
    color = fields.Char(
        string='Color',
        tracking=True
    )
    
    vin = fields.Char(
        string='VIN',
        size=17,
        tracking=True,
        help='رقم الهيكل (17 حرف)'
    )
    
    # ==================== السعة ====================
    
    max_cars = fields.Integer(
        string='Max Cars Capacity',
        default=1,
        tracking=True,
        help='الحد الأقصى لعدد السيارات'
    )
    
    max_weight_kg = fields.Float(
        string='Max Weight (kg)',
        digits=(10, 2),
        tracking=True,
        help='الحد الأقصى للوزن بالكيلوجرام'
    )
    
    length_m = fields.Float(
        string='Length (m)',
        digits=(5, 2),
        tracking=True,
        help='الطول بالأمتار'
    )
    
    # ==================== معلومات التسجيل ====================
    
    registration_date = fields.Date(
        string='Registration Date',
        tracking=True
    )
    
    inspection_expiry = fields.Date(
        string='Inspection Expiry (HU/AU)',
        tracking=True,
        help='تاريخ انتهاء الفحص التقني'
    )
    
    insurance_expiry = fields.Date(
        string='Insurance Expiry',
        tracking=True
    )
    
    insurance_company = fields.Char(
        string='Insurance Company',
        tracking=True
    )
    
    insurance_number = fields.Char(
        string='Insurance Number',
        tracking=True
    )
    
    # ==================== الحالة ====================
    
    state = fields.Selection([
        ('available', 'Available'),
        ('in_use', 'In Use'),
        ('maintenance', 'Maintenance'),
        ('out_of_service', 'Out of Service'),
    ], string='Status',
        default='available',
        tracking=True
    )
    
    active = fields.Boolean(
        string='Active',
        default=True
    )
    
    # ==================== العلاقات ====================
    
    driver_id = fields.Many2one(
        'tour.driver',
        string='Assigned Driver',
        tracking=True,
        help='السائق المعين للمركبة'
    )
    
    trailer_id = fields.Many2one(
        'tour.vehicle',
        string='Attached Trailer',
        domain=[('vehicle_type', '=', 'trailer')],
        tracking=True,
        help='المقطورة المرفقة'
    )
    
    tour_ids = fields.One2many(
        'tour.tour',
        'vehicle_id',
        string='Tours'
    )
    
    company_id = fields.Many2one(
        'res.company',
        string='Company',
        default=lambda self: self.env.company
    )
    
    # ==================== الإحصائيات ====================
    
    total_tours = fields.Integer(
        string='Total Tours',
        compute='_compute_statistics',
        store=True
    )
    
    total_distance = fields.Float(
        string='Total Distance (km)',
        compute='_compute_statistics',
        store=True,
        digits=(12, 2)
    )
    
    last_tour_date = fields.Date(
        string='Last Tour Date',
        compute='_compute_statistics',
        store=True
    )
    
    # ==================== الصور ====================
    
    image_1920 = fields.Image(
        string='Photo',
        max_width=1920,
        max_height=1920
    )
    
    image_128 = fields.Image(
        string='Small Photo',
        related='image_1920',
        max_width=128,
        max_height=128,
        store=True
    )
    
    # ==================== ملاحظات ====================
    
    notes = fields.Text(
        string='Notes'
    )
    
    # ==================== القيود ====================
    
    _sql_constraints = [
        (
            'code_unique',
            'UNIQUE(code)',
            'Vehicle code must be unique!'
        ),
        (
            'license_plate_unique',
            'UNIQUE(license_plate)',
            'License plate must be unique!'
        ),
    ]
    
    # ==================== الطرق المحسوبة ====================
    
    @api.depends('tour_ids', 'tour_ids.state', 'tour_ids.distance', 'tour_ids.date')
    def _compute_statistics(self):
        """حساب الإحصائيات"""
        for vehicle in self:
            tours = vehicle.tour_ids.filtered(lambda t: t.state == 'completed')
            vehicle.total_tours = len(tours)
            vehicle.total_distance = sum(tours.mapped('distance'))
            
            if tours:
                vehicle.last_tour_date = max(tours.mapped('date'))
            else:
                vehicle.last_tour_date = False
    
    # ==================== الطرق ====================
    
    def action_set_available(self):
        """تعيين الحالة إلى متاح"""
        self.write({'state': 'available'})
    
    def action_set_in_use(self):
        """تعيين الحالة إلى قيد الاستخدام"""
        self.write({'state': 'in_use'})
    
    def action_set_maintenance(self):
        """تعيين الحالة إلى صيانة"""
        self.write({'state': 'maintenance'})
    
    def action_set_out_of_service(self):
        """تعيين الحالة إلى خارج الخدمة"""
        self.write({'state': 'out_of_service', 'active': False})
    
    @api.model
    def get_available_vehicles(self, vehicle_type=None):
        """
        الحصول على المركبات المتاحة
        
        Args:
            vehicle_type (str): نوع المركبة المطلوبة
            
        Returns:
            recordset: المركبات المتاحة
        """
        domain = [
            ('state', '=', 'available'),
            ('active', '=', True),
        ]
        if vehicle_type:
            domain.append(('vehicle_type', '=', vehicle_type))
        return self.search(domain)
    
    def name_get(self):
        """طريقة عرض اسم المركبة"""
        result = []
        for vehicle in self:
            name = f"{vehicle.name} ({vehicle.license_plate})"
            result.append((vehicle.id, name))
        return result
    
    @api.constrains('inspection_expiry')
    def _check_inspection_validity(self):
        """التحقق من صلاحية الفحص"""
        for vehicle in self:
            if vehicle.inspection_expiry and vehicle.inspection_expiry < fields.Date.today():
                raise ValidationError(_(
                    'Vehicle %s inspection has expired on %s!'
                ) % (vehicle.name, vehicle.inspection_expiry))
    
    @api.constrains('insurance_expiry')
    def _check_insurance_validity(self):
        """التحقق من صلاحية التأمين"""
        for vehicle in self:
            if vehicle.insurance_expiry and vehicle.insurance_expiry < fields.Date.today():
                raise ValidationError(_(
                    'Vehicle %s insurance has expired on %s!'
                ) % (vehicle.name, vehicle.insurance_expiry))
    
    @api.constrains('vin')
    def _check_vin_format(self):
        """التحقق من تنسيق رقم الهيكل"""
        import re
        for vehicle in self:
            if vehicle.vin and len(vehicle.vin) == 17:
                # رقم الهيكل يجب أن يكون 17 حرف (أرقام وحروف باستثناء I, O, Q)
                if not re.match(r'^[A-HJ-NPR-Z0-9]{17}$', vehicle.vin):
                    raise ValidationError(_(
                        'Invalid VIN format. Must be 17 characters (letters and numbers, excluding I, O, Q).'
                    ))


class TourVehicleMaintenance(models.Model):
    """
    سجلات صيانة المركبات
    """
    _name = 'tour.vehicle.maintenance'
    _description = 'Vehicle Maintenance Record'
    _order = 'date desc'
    _rec_name = 'name'
    
    name = fields.Char(
        string='Reference',
        required=True,
        copy=False,
        readonly=True,
        default=lambda self: _('New')
    )
    
    vehicle_id = fields.Many2one(
        'tour.vehicle',
        string='Vehicle',
        required=True
    )
    
    date = fields.Date(
        string='Date',
        required=True,
        default=fields.Date.today
    )
    
    maintenance_type = fields.Selection([
        ('routine', 'Routine Maintenance'),
        ('repair', 'Repair'),
        ('inspection', 'Inspection'),
        ('tire_change', 'Tire Change'),
        ('oil_change', 'Oil Change'),
        ('other', 'Other'),
    ], string='Maintenance Type',
        default='routine',
        required=True
    )
    
    description = fields.Text(
        string='Description',
        required=True
    )
    
    cost = fields.Float(
        string='Cost (€)',
        digits=(10, 2)
    )
    
    odometer = fields.Integer(
        string='Odometer (km)'
    )
    
    workshop = fields.Char(
        string='Workshop'
    )
    
    next_maintenance_date = fields.Date(
        string='Next Maintenance Date'
    )
    
    next_maintenance_odometer = fields.Integer(
        string='Next Maintenance Odometer'
    )
    
    state = fields.Selection([
        ('planned', 'Planned'),
        ('in_progress', 'In Progress'),
        ('completed', 'Completed'),
    ], string='Status',
        default='planned'
    )
    
    notes = fields.Text(
        string='Notes'
    )
    
    company_id = fields.Many2one(
        'res.company',
        string='Company',
        default=lambda self: self.env.company
    )
    
    @api.model_create_multi
    def create(self, vals_list):
        """إنشاء رقم مرجعي تلقائي"""
        for vals in vals_list:
            if vals.get('name', _('New')) == _('New'):
                vals['name'] = self.env['ir.sequence'].next_by_code(
                    'tour.vehicle.maintenance'
                ) or _('New')
        return super().create(vals_list)
    
    def action_complete(self):
        """إكمال الصيانة"""
        self.write({'state': 'completed'})
