# -*- coding: utf-8 -*-
"""
================================================================================
Tour Model - نموذج الرحلة (Odoo 19.0)
================================================================================

النموذج الأساسي لإدارة رحلات نقل المركبات

يحتوي على:
- بيانات الرحلة الأساسية
- حسابات الأسعار (القواعد الستة)
- إدارة الحالات
- التكامل مع الفواتير

================================================================================
"""

from odoo import models, fields, api, _
from odoo.exceptions import ValidationError, UserError
from odoo.tools import format_date
from datetime import timedelta
import logging
import re

_logger = logging.getLogger(__name__)


class TourTour(models.Model):
    """
    نموذج الرحلة
    
    يمثل رحلة نقل مركبة واحدة من موقع إلى آخر
    """
    _name = 'tour.tour'
    _description = 'Vehicle Transport Tour'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'date desc, name desc'
    _rec_name = 'name'
    
    # ==================== الحقول الأساسية ====================
    
    name = fields.Char(
        string='Tour Number',
        required=True,
        copy=False,
        readonly=True,
        default=lambda self: _('New'),
        tracking=True
    )
    
    tour_nr = fields.Char(
        string='Tour NR.',
        required=True,
        copy=False,
        tracking=True,
        help='رقم الرحلة المرجعي'
    )
    
    date = fields.Date(
        string='Date',
        required=True,
        default=fields.Date.today,
        tracking=True,
        index=True
    )
    
    # ==================== العميل ====================
    
    partner_id = fields.Many2one(
        'res.partner',
        string='Customer',
        required=True,
        tracking=True,
        domain=[('is_tour_customer', '=', True)],
        help='العميل (شركة أو فرد)'
    )
    
    partner_contact_id = fields.Many2one(
        'res.partner',
        string='Contact Person',
        domain=[('parent_id', '=', False)]
    )
    
    # ==================== مواقع الرحلة ====================
    
    pickup_location = fields.Char(
        string='Pickup Location (VON)',
        tracking=True,
        help='موقع الاستلام'
    )
    
    pickup_zip = fields.Char(
        string='Pickup ZIP'
    )
    
    pickup_city = fields.Char(
        string='Pickup City'
    )
    
    pickup_country_id = fields.Many2one(
        'res.country',
        string='Pickup Country',
        default=lambda self: self.env.ref('base.de', raise_if_not_found=False)
    )
    
    delivery_location = fields.Char(
        string='Delivery Location (AN)',
        tracking=True,
        help='موقع التسليم'
    )
    
    delivery_zip = fields.Char(
        string='Delivery ZIP'
    )
    
    delivery_city = fields.Char(
        string='Delivery City'
    )
    
    delivery_country_id = fields.Many2one(
        'res.country',
        string='Delivery Country',
        default=lambda self: self.env.ref('base.de', raise_if_not_found=False)
    )
    
    # ==================== المسافة والسعر ====================
    
    distance_raw = fields.Char(
        string='Distance (Raw)',
        tracking=True,
        help='المسافة الخام من النظام (مثل "1 237,43")'
    )
    
    distance = fields.Float(
        string='Distance (km)',
        compute='_compute_distance',
        store=True,
        digits=(10, 2),
        help='المسافة الفعلية بالكيلومتر'
    )
    
    distance_display = fields.Char(
        string='Distance (Display)',
        compute='_compute_distance_display',
        store=True,
        help='المسافة للعرض بالتنسيق الألماني'
    )
    
    # ==================== الأسعار ====================
    
    base_price = fields.Float(
        string='Base Price (€)',
        compute='_compute_base_price',
        store=True,
        digits=(10, 2),
        help='السعر الأساسي من جدول التسعير'
    )
    
    pricing_id = fields.Many2one(
        'tour.pricing',
        string='Pricing Tier',
        compute='_compute_pricing',
        store=True,
        help='شريحة التسعير المستخدمة'
    )
    
    # ==================== وقت الانتظار ====================
    
    waiting_minutes = fields.Integer(
        string='Waiting Time (min)',
        default=0,
        tracking=True,
        help='وقت الانتظار بالدقائق'
    )
    
    waiting_rate = fields.Float(
        string='Waiting Rate (€/min)',
        compute='_compute_waiting_rate',
        store=True,
        digits=(10, 4),
        help='معدل سعر الانتظار (10€/ساعة = 0.1667€/دقيقة)'
    )
    
    waiting_cost = fields.Float(
        string='Waiting Cost (€)',
        compute='_compute_waiting_cost',
        store=True,
        digits=(10, 2),
        help='تكلفة وقت الانتظار'
    )
    
    waiting_description = fields.Char(
        string='Waiting Description',
        tracking=True,
        help='وصف سبب الانتظار'
    )
    
    # ==================== الخصومات ====================
    
    discount_percent = fields.Integer(
        string='Discount (%)',
        default=0,
        tracking=True,
        help='نسبة الخصم (عادة 50%)'
    )
    
    discount_reason = fields.Char(
        string='Discount Reason',
        tracking=True,
        help='سبب الخصم'
    )
    
    discount_amount = fields.Float(
        string='Discount Amount (€)',
        compute='_compute_discount_amount',
        store=True,
        digits=(10, 2),
        help='قيمة الخصم'
    )
    
    # ==================== المبالغ ====================
    
    price_before_discount = fields.Float(
        string='Price Before Discount (€)',
        compute='_compute_price_before_discount',
        store=True,
        digits=(10, 2),
        help='السعر قبل الخصم'
    )
    
    price_amount = fields.Float(
        string='Price (€)',
        compute='_compute_price_amount',
        store=True,
        digits=(10, 2),
        help='السعر للعرض في الفاتورة'
    )
    
    total_amount = fields.Float(
        string='Total Amount (€)',
        compute='_compute_total_amount',
        store=True,
        digits=(10, 2),
        help='المبلغ الإجمالي (بعد الخصم)'
    )
    
    # ==================== الوصف ====================
    
    description = fields.Text(
        string='Description',
        tracking=True,
        help='وصف الرحلة (BESCHREIBUNG)'
    )
    
    customer_name = fields.Char(
        string='Customer Name',
        tracking=True,
        help='اسم العميل في الوصف'
    )
    
    additional_info = fields.Char(
        string='Additional Info',
        tracking=True,
        help='معلومات إضافية'
    )
    
    description_full = fields.Char(
        string='Full Description',
        compute='_compute_description_full',
        store=True,
        help='الوصف الكامل للعرض'
    )
    
    # ==================== السائق والمركبة ====================
    
    driver_id = fields.Many2one(
        'tour.driver',
        string='Driver',
        tracking=True
    )
    
    vehicle_id = fields.Many2one(
        'tour.vehicle',
        string='Vehicle',
        tracking=True
    )
    
    # ==================== المركبة المنقولة ====================
    
    transported_vehicle_brand = fields.Char(
        string='Vehicle Brand',
        tracking=True,
        help='ماركة المركبة المنقولة'
    )
    
    transported_vehicle_model = fields.Char(
        string='Vehicle Model',
        tracking=True,
        help='موديل المركبة المنقولة'
    )
    
    transported_vehicle_plate = fields.Char(
        string='Vehicle Plate',
        tracking=True,
        help='رقم لوحة المركبة المنقولة'
    )
    
    transported_vehicle_vin = fields.Char(
        string='Vehicle VIN',
        size=17,
        tracking=True,
        help='رقم هيكل المركبة المنقولة'
    )
    
    # ==================== الحالة ====================
    
    state = fields.Selection([
        ('draft', 'Draft'),
        ('confirmed', 'Confirmed'),
        ('in_progress', 'In Progress'),
        ('completed', 'Completed'),
        ('invoiced', 'Invoiced'),
        ('cancelled', 'Cancelled'),
    ], string='Status',
        default='draft',
        tracking=True,
        index=True
    )
    
    # ==================== الفاتورة ====================
    
    invoice_id = fields.Many2one(
        'tour.invoice',
        string='Invoice',
        readonly=True,
        tracking=True
    )
    
    invoice_line_id = fields.Many2one(
        'tour.invoice.line',
        string='Invoice Line',
        readonly=True
    )
    
    is_invoiced = fields.Boolean(
        string='Is Invoiced',
        compute='_compute_is_invoiced',
        store=True
    )
    
    # ==================== التقييم ====================
    
    rating = fields.Integer(
        string='Rating',
        default=5,
        tracking=True,
        help='تقييم الرحلة (1-5)'
    )
    
    feedback = fields.Text(
        string='Customer Feedback'
    )
    
    # ==================== التواريخ ====================
    
    pickup_time = fields.Datetime(
        string='Pickup Time',
        tracking=True
    )
    
    delivery_time = fields.Datetime(
        string='Delivery Time',
        tracking=True
    )
    
    actual_duration = fields.Float(
        string='Actual Duration (hours)',
        compute='_compute_actual_duration',
        store=True,
        digits=(5, 2)
    )
    
    # ==================== علاقات ====================
    
    company_id = fields.Many2one(
        'res.company',
        string='Company',
        default=lambda self: self.env.company
    )
    
    currency_id = fields.Many2one(
        'res.currency',
        related='company_id.currency_id',
        string='Currency'
    )
    
    # ==================== ملاحظات ====================
    
    notes = fields.Text(
        string='Internal Notes'
    )
    
    active = fields.Boolean(
        string='Active',
        default=True
    )
    
    # ==================== القيود ====================
    
    _sql_constraints = [
        (
            'tour_nr_unique',
            'UNIQUE(tour_nr)',
            'Tour number must be unique!'
        ),
        (
            'rating_range',
            'CHECK(rating >= 1 AND rating <= 5)',
            'Rating must be between 1 and 5!'
        ),
    ]
    
    # ==================== الطرق المحسوبة ====================
    
    @api.depends('distance_raw')
    def _compute_distance(self):
        """
        حساب المسافة الفعلية
        
        القاعدة 1: معالجة الرقم "1"
        - حذف "1 " أو "1." من بداية المسافة
        - تحويل التنسيق الألماني إلى رقم
        
        مثال:
        "1 237,43" → 237.43 km (ليس 1237.43!)
        """
        for tour in self:
            if tour.distance_raw:
                km_str = tour.distance_raw.strip()
                
                # حذف الرقم "1" من البداية
                if km_str.startswith('1 '):
                    km_str = km_str[2:]
                elif km_str.startswith('1.'):
                    km_str = km_str[2:]
                
                # تحويل التنسيق الألماني
                km_str = km_str.replace('.', '').replace(',', '.')
                
                try:
                    tour.distance = float(km_str)
                except ValueError:
                    tour.distance = 0.0
            else:
                tour.distance = 0.0
    
    @api.depends('distance')
    def _compute_distance_display(self):
        """
        حساب المسافة للعرض
        
        إضافة "1." للتنسيق الألماني
        مثال: 237.43 → "1.237,43"
        """
        for tour in self:
            if tour.distance:
                formatted = f"{tour.distance:,.2f}".replace(',', 'X').replace('.', ',').replace('X', '.')
                tour.distance_display = f"1.{formatted}"
            else:
                tour.distance_display = ''
    
    @api.depends('distance')
    def _compute_pricing(self):
        """
        تحديد شريحة التسعير
        
        القاعدة 2: جدول التسعير المتدرج
        """
        Pricing = self.env['tour.pricing']
        for tour in self:
            if tour.distance > 0:
                tour.pricing_id = Pricing.search([
                    ('km_from', '<=', tour.distance),
                    ('km_to', '>=', tour.distance),
                    ('active', '=', True),
                ], limit=1)
            else:
                tour.pricing_id = False
    
    @api.depends('pricing_id', 'distance')
    def _compute_base_price(self):
        """
        حساب السعر الأساسي
        
        القاعدة 2: جدول التسعير المتدرج
        للمسافات فوق 650 كم: 185€ + 20€/100كم
        """
        for tour in self:
            if tour.pricing_id:
                pricing = tour.pricing_id
                
                if pricing.is_unlimited and tour.distance > pricing.km_from:
                    extra_km = tour.distance - pricing.km_from
                    extra_charge = (extra_km / 100) * pricing.extra_charge_per_100km
                    tour.base_price = pricing.price + extra_charge
                else:
                    tour.base_price = pricing.price
            else:
                tour.base_price = self.env['tour.pricing'].get_price_for_distance(tour.distance)
    
    @api.depends('waiting_minutes')
    def _compute_waiting_rate(self):
        """
        حساب معدل سعر الانتظار
        
        القاعدة 3: 10€/ساعة = 0.1667€/دقيقة
        """
        rate = self.env['tour.waiting.time.rate'].get_current_rate()
        for tour in self:
            tour.waiting_rate = rate
    
    @api.depends('waiting_minutes', 'waiting_rate')
    def _compute_waiting_cost(self):
        """
        حساب تكلفة وقت الانتظار
        
        القاعدة 3: دقائق × 0.1667€
        """
        for tour in self:
            tour.waiting_cost = round(tour.waiting_minutes * tour.waiting_rate, 2)
    
    @api.depends('base_price', 'waiting_cost')
    def _compute_price_before_discount(self):
        """
        حساب السعر قبل الخصم
        
        السعر الأساسي + وقت الانتظار
        """
        for tour in self:
            tour.price_before_discount = tour.base_price + tour.waiting_cost
    
    @api.depends('price_before_discount', 'discount_percent')
    def _compute_discount_amount(self):
        """حساب قيمة الخصم"""
        for tour in self:
            tour.discount_amount = round(
                tour.price_before_discount * tour.discount_percent / 100, 2
            )
    
    @api.depends('price_before_discount', 'discount_percent')
    def _compute_price_amount(self):
        """السعر للعرض في الفاتورة (قبل الخصم)"""
        for tour in self:
            tour.price_amount = tour.price_before_discount
    
    @api.depends('price_before_discount', 'discount_percent')
    def _compute_total_amount(self):
        """
        حساب المبلغ الإجمالي
        
        القاعدة 4: الخصم يُطبّق بعد وقت الانتظار
        """
        for tour in self:
            if tour.discount_percent > 0:
                tour.total_amount = round(
                    tour.price_before_discount * (1 - tour.discount_percent / 100), 2
                )
            else:
                tour.total_amount = tour.price_before_discount
    
    @api.depends('customer_name', 'waiting_minutes', 'waiting_description', 'additional_info')
    def _compute_description_full(self):
        """حساب الوصف الكامل للفاتورة"""
        for tour in self:
            parts = []
            
            if tour.customer_name:
                parts.append(tour.customer_name)
            
            if tour.waiting_minutes > 0:
                wz_text = f"+{tour.waiting_minutes} MIN WZ"
                if tour.waiting_description:
                    wz_text += f" {tour.waiting_description}"
                parts.append(wz_text)
            
            if tour.additional_info:
                parts.append(tour.additional_info)
            
            tour.description_full = '\n'.join(parts)
    
    @api.depends('invoice_id')
    def _compute_is_invoiced(self):
        """تحديد ما إذا كانت الرحلة مفوترة"""
        for tour in self:
            tour.is_invoiced = bool(tour.invoice_id)
    
    @api.depends('pickup_time', 'delivery_time')
    def _compute_actual_duration(self):
        """حساب المدة الفعلية"""
        for tour in self:
            if tour.pickup_time and tour.delivery_time:
                delta = tour.delivery_time - tour.pickup_time
                tour.actual_duration = delta.total_seconds() / 3600
            else:
                tour.actual_duration = 0.0
    
    # ==================== إنشاء الرقم التسلسلي ====================
    
    @api.model_create_multi
    def create(self, vals_list):
        """إنشاء رقم تسلسلي تلقائي"""
        for vals in vals_list:
            if vals.get('name', _('New')) == _('New'):
                vals['name'] = self.env['ir.sequence'].next_by_code('tour.tour') or _('New')
        return super().create(vals_list)
    
    # ==================== أزرار الإجراءات ====================
    
    def action_confirm(self):
        """تأكيد الرحلة"""
        self.write({'state': 'confirmed'})
    
    def action_start(self):
        """بدء الرحلة"""
        for tour in self:
            if tour.driver_id:
                tour.driver_id.action_set_on_tour()
            if tour.vehicle_id:
                tour.vehicle_id.action_set_in_use()
        
        self.write({
            'state': 'in_progress',
            'pickup_time': fields.Datetime.now(),
        })
    
    def action_complete(self):
        """إكمال الرحلة"""
        for tour in self:
            if tour.driver_id:
                tour.driver_id.action_set_available()
            if tour.vehicle_id:
                tour.vehicle_id.action_set_available()
        
        self.write({
            'state': 'completed',
            'delivery_time': fields.Datetime.now(),
        })
    
    def action_cancel(self):
        """إلغاء الرحلة"""
        for tour in self:
            if tour.state == 'invoiced':
                raise UserError(_('Cannot cancel a tour that has been invoiced!'))
            
            if tour.driver_id:
                tour.driver_id.action_set_available()
            if tour.vehicle_id:
                tour.vehicle_id.action_set_available()
        
        self.write({'state': 'cancelled'})
    
    def action_reset_to_draft(self):
        """إعادة إلى مسودة"""
        self.write({'state': 'draft'})
    
    # ==================== طرق المساعدة ====================
    
    def get_invoice_line_data(self):
        """
        الحصول على بيانات سطر الفاتورة
        
        Returns:
            dict: بيانات سطر الفاتورة
        """
        self.ensure_one()
        
        return {
            'tour_id': self.id,
            'tour_nr': self.tour_nr,
            'description': self.description_full,
            'distance_display': self.distance_display,
            'distance': self.distance,
            'base_price': self.base_price,
            'waiting_minutes': self.waiting_minutes,
            'waiting_cost': self.waiting_cost,
            'price_amount': self.price_amount,
            'discount_percent': self.discount_percent,
            'discount_amount': self.discount_amount,
            'total_amount': self.total_amount,
        }
    
    def format_german(self, number):
        """
        تنسيق رقم بالطريقة الألمانية
        
        القاعدة 6: نقطة للآلاف، فاصلة للعشريات
        مثال: 1234.56 → "1.234,56"
        """
        formatted = f"{number:,.2f}"
        return formatted.replace(',', 'X').replace('.', ',').replace('X', '.')
    
    @api.model
    def get_tours_for_invoice(self, partner_id, date_from, date_to):
        """
        الحصول على الرحلات لإنشاء فاتورة
        
        Args:
            partner_id (int): معرف العميل
            date_from (date): من تاريخ
            date_to (date): إلى تاريخ
            
        Returns:
            recordset: الرحلات المؤهلة للفوترة
        """
        return self.search([
            ('partner_id', '=', partner_id),
            ('date', '>=', date_from),
            ('date', '<=', date_to),
            ('state', '=', 'completed'),
            ('is_invoiced', '=', False),
        ])
    
    def name_get(self):
        """عرض اسم الرحلة"""
        result = []
        for tour in self:
            name = f"{tour.tour_nr}"
            if tour.partner_id:
                name += f" - {tour.partner_id.name}"
            if tour.distance:
                name += f" ({tour.distance:.0f} km)"
            result.append((tour.id, name))
        return result
