# -*- coding: utf-8 -*-
"""
================================================================================
Al Masri Models Init
================================================================================
"""

from . import tour_pricing
from . import tour_driver
from . import tour_vehicle
from . import tour_tour
from . import tour_invoice
from . import res_partner
