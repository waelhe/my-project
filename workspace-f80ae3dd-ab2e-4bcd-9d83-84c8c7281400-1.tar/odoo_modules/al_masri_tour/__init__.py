# -*- coding: utf-8 -*-
"""
================================================================================
Al Masri Fahrzeugüberführung - Main Init File (Odoo 19.0)
================================================================================
"""

from . import models
from . import wizard
from . import reports


def post_init_hook(env):
    """
    يتم تنفيذ هذه الدالة بعد تثبيت الموديول مباشرة
    
    الوظائف:
    - إنشاء تسلسل أرقام الرحلات
    - إنشاء تسلسل أرقام الفواتير
    - تعيين البيانات الافتراضية
    """
    from odoo import SUPERUSER_ID
    
    # إنشاء تسلسل أرقام الرحلات
    env['ir.sequence'].sudo().create({
        'name': 'Tour Sequence',
        'code': 'tour.tour',
        'prefix': 'TOUR%(y)s%(month)s-',
        'padding': 5,
        'number_next': 1,
        'number_increment': 1,
        'company_id': env.company.id,
    })
    
    # إنشاء تسلسل أرقام الفواتير
    env['ir.sequence'].sudo().create({
        'name': 'Tour Invoice Sequence',
        'code': 'tour.invoice',
        'prefix': '#',
        'padding': 1,
        'number_next': 1,
        'number_increment': 1,
        'company_id': env.company.id,
    })
    
    # إنشاء مستخدم النظام الأساسي إذا لم يكن موجوداً
    env['tour.driver'].sudo().create({
        'name': 'System',
        'code': 'SYS',
        'active': False,
    })
