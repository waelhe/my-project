'use client';

import { useSession, signOut } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { useCallback } from 'react';

export function useAuth() {
  const { data: session, status } = useSession();
  const router = useRouter();

  const isAuthenticated = status === 'authenticated';
  const isLoading = status === 'loading';
  const user = session?.user;

  const isAdmin = user?.role === 'admin';
  const isBusinessOwner = user?.role === 'business_owner';

  const logout = useCallback(async () => {
    await signOut({ redirect: false });
    router.push('/');
    router.refresh();
  }, [router]);

  const requireAuth = useCallback(() => {
    if (!isLoading && !isAuthenticated) {
      router.push('/login');
      return false;
    }
    return true;
  }, [isLoading, isAuthenticated, router]);

  const requireAdmin = useCallback(() => {
    if (!isLoading && !isAdmin) {
      router.push('/');
      return false;
    }
    return true;
  }, [isLoading, isAdmin, router]);

  return {
    user,
    status,
    isAuthenticated,
    isLoading,
    isAdmin,
    isBusinessOwner,
    logout,
    requireAuth,
    requireAdmin,
  };
}
