'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import {
  Home,
  ShoppingCart,
  Building2,
  BookOpen,
  Users,
  Menu,
} from 'lucide-react';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from '@/components/ui/sheet';
import { TrendingUp, Moon, PlusCircle, Heart, User, Settings } from 'lucide-react';

const mainNavItems = [
  { href: '/', label: 'الرئيسية', icon: Home },
  { href: '/marketplace', label: 'السوق', icon: ShoppingCart },
  { href: '/real-estate', label: 'العقارات', icon: Building2 },
  { href: '/directory', label: 'الدليل', icon: BookOpen },
  { href: '/community', label: 'المجتمع', icon: Users },
];

const moreNavItems = [
  { href: '/market-prices', label: 'أسعار السوق', icon: TrendingUp },
  { href: '/islamic', label: 'مواقيت الصلاة', icon: Moon },
  { href: '/add', label: 'أضف إعلان', icon: PlusCircle },
  { href: '/favorites', label: 'المفضلة', icon: Heart },
  { href: '/profile', label: 'حسابي', icon: User },
  { href: '/settings', label: 'الإعدادات', icon: Settings },
];

export function BottomNav() {
  const pathname = usePathname();

  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 z-50 bg-background border-t safe-area-bottom">
      <div className="flex items-center justify-around h-16">
        {mainNavItems.map((item) => {
          const isActive = pathname === item.href;
          const Icon = item.icon;
          return (
            <Link
              key={item.href}
              href={item.href}
              className={`flex flex-col items-center justify-center w-full h-full ${
                isActive
                  ? 'text-primary'
                  : 'text-muted-foreground hover:text-foreground'
              }`}
            >
              <Icon className="h-5 w-5" />
              <span className="text-xs mt-1">{item.label}</span>
            </Link>
          );
        })}

        {/* More Menu */}
        <Sheet>
          <SheetTrigger asChild>
            <button className="flex flex-col items-center justify-center w-full h-full text-muted-foreground hover:text-foreground">
              <Menu className="h-5 w-5" />
              <span className="text-xs mt-1">المزيد</span>
            </button>
          </SheetTrigger>
          <SheetContent side="bottom" className="h-[60vh] rounded-t-2xl">
            <SheetHeader>
              <SheetTitle className="text-center">المزيد</SheetTitle>
            </SheetHeader>
            <div className="grid grid-cols-3 gap-4 mt-8">
              {moreNavItems.map((item) => {
                const Icon = item.icon;
                return (
                  <Link
                    key={item.href}
                    href={item.href}
                    className="flex flex-col items-center justify-center gap-2 p-4 rounded-xl bg-muted/50 hover:bg-muted transition-colors"
                  >
                    <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center">
                      <Icon className="h-6 w-6 text-primary" />
                    </div>
                    <span className="text-sm">{item.label}</span>
                  </Link>
                );
              })}
            </div>
          </SheetContent>
        </Sheet>
      </div>
    </nav>
  );
}
