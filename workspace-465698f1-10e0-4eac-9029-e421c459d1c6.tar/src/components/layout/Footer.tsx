'use client';

import Link from 'next/link';
import {
  Facebook,
  Instagram,
  Twitter,
  Phone,
  Mail,
  MapPin,
  Heart,
} from 'lucide-react';
import { Separator } from '@/components/ui/separator';

const quickLinks = [
  { href: '/marketplace', label: 'سوق المستعمل' },
  { href: '/real-estate', label: 'العقارات' },
  { href: '/directory', label: 'دليل الفعاليات' },
  { href: '/community', label: 'منتدى المجتمع' },
];

const serviceLinks = [
  { href: '/market-prices', label: 'أسعار السوق' },
  { href: '/islamic', label: 'مواقيت الصلاة' },
  { href: '/emergency', label: 'أرقام الطوارئ' },
  { href: '/pharmacies', label: 'الصيدليات المناوبة' },
];

export function Footer() {
  return (
    <footer className="hidden md:block bg-muted/50 border-t mt-auto">
      <div className="container px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Logo & Description */}
          <div className="space-y-4">
            <Link href="/" className="flex items-center gap-2">
              <div className="h-10 w-10 rounded-lg bg-primary flex items-center justify-center">
                <span className="text-primary-foreground font-bold text-xl">ق</span>
              </div>
              <div>
                <span className="font-bold text-lg block">قدسيا بلس</span>
                <span className="text-xs text-muted-foreground">نبض الضاحية</span>
              </div>
            </Link>
            <p className="text-sm text-muted-foreground">
              منصة خدمية اجتماعية تجارية مخصصة لسكان ضاحية قدسيا. نساعدك في العثور على
              ما تحتاجه في منطقتك.
            </p>
            <div className="flex items-center gap-3">
              <a
                href="https://facebook.com"
                target="_blank"
                rel="noopener noreferrer"
                className="h-9 w-9 rounded-full bg-muted flex items-center justify-center hover:bg-primary hover:text-primary-foreground transition-colors"
              >
                <Facebook className="h-4 w-4" />
              </a>
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noopener noreferrer"
                className="h-9 w-9 rounded-full bg-muted flex items-center justify-center hover:bg-primary hover:text-primary-foreground transition-colors"
              >
                <Instagram className="h-4 w-4" />
              </a>
              <a
                href="https://twitter.com"
                target="_blank"
                rel="noopener noreferrer"
                className="h-9 w-9 rounded-full bg-muted flex items-center justify-center hover:bg-primary hover:text-primary-foreground transition-colors"
              >
                <Twitter className="h-4 w-4" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="font-semibold mb-4">روابط سريعة</h3>
            <ul className="space-y-2">
              {quickLinks.map((link) => (
                <li key={link.href}>
                  <Link
                    href={link.href}
                    className="text-sm text-muted-foreground hover:text-primary transition-colors"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Services */}
          <div>
            <h3 className="font-semibold mb-4">خدمات</h3>
            <ul className="space-y-2">
              {serviceLinks.map((link) => (
                <li key={link.href}>
                  <Link
                    href={link.href}
                    className="text-sm text-muted-foreground hover:text-primary transition-colors"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="font-semibold mb-4">تواصل معنا</h3>
            <ul className="space-y-3">
              <li className="flex items-center gap-2 text-sm text-muted-foreground">
                <MapPin className="h-4 w-4 text-primary" />
                ضاحية قدسيا، سوريا
              </li>
              <li className="flex items-center gap-2 text-sm text-muted-foreground">
                <Phone className="h-4 w-4 text-primary" />
                <a href="tel:+963111234567" className="hover:text-primary transition-colors">
                  +963 11 123 4567
                </a>
              </li>
              <li className="flex items-center gap-2 text-sm text-muted-foreground">
                <Mail className="h-4 w-4 text-primary" />
                <a href="mailto:info@qudsayaplus.com" className="hover:text-primary transition-colors">
                  info@qudsayaplus.com
                </a>
              </li>
            </ul>
          </div>
        </div>

        <Separator className="my-8" />

        <div className="flex flex-col md:flex-row items-center justify-between gap-4 text-sm text-muted-foreground">
          <p>
            © {new Date().getFullYear()} قدسيا بلس. جميع الحقوق محفوظة.
          </p>
          <p className="flex items-center gap-1">
            صُنع بـ
            <Heart className="h-4 w-4 text-red-500 fill-red-500" />
            في ضاحية قدسيا
          </p>
          <div className="flex items-center gap-4">
            <Link href="/privacy" className="hover:text-primary transition-colors">
              سياسة الخصوصية
            </Link>
            <Link href="/terms" className="hover:text-primary transition-colors">
              الشروط والأحكام
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
