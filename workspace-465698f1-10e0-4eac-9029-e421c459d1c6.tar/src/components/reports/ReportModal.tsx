'use client';

import { useState } from 'react';
import { AlertTriangle, Loader2 } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';

interface ReportModalProps {
  reportedType: 'user' | 'marketplace_item' | 'real_estate' | 'listing' | 'post';
  reportedId: string;
  trigger?: React.ReactNode;
}

const REPORT_REASONS = [
  { value: 'inappropriate', label: 'محتوى غير لائق' },
  { value: 'spam', label: 'بريد مزعج / إعلان كاذب' },
  { value: 'scam', label: 'احتيال أو نصب' },
  { value: 'duplicate', label: 'محتوى مكرر' },
  { value: 'wrong_category', label: 'تصنيف خاطئ' },
  { value: 'expired', label: 'محتوى منتهي الصلاحية' },
  { value: 'other', label: 'سبب آخر' },
];

export function ReportModal({ reportedType, reportedId, trigger }: ReportModalProps) {
  const [open, setOpen] = useState(false);
  const [reason, setReason] = useState('');
  const [description, setDescription] = useState('');
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  const handleSubmit = async () => {
    if (!reason) {
      toast({
        variant: 'destructive',
        title: 'خطأ',
        description: 'يرجى اختيار سبب البلاغ',
      });
      return;
    }

    setLoading(true);
    try {
      const res = await fetch('/api/reports', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          reportedType,
          reportedId,
          reason,
          description: description.trim() || undefined,
        }),
      });

      if (res.ok) {
        toast({
          title: 'تم إرسال البلاغ',
          description: 'شكراً لك، سيتم مراجعة البلاغ من قبل الإدارة',
        });
        setOpen(false);
        setReason('');
        setDescription('');
      } else {
        const data = await res.json();
        toast({
          variant: 'destructive',
          title: 'خطأ',
          description: data.error || 'فشل إرسال البلاغ',
        });
      }
    } catch (error) {
      console.error('Error submitting report:', error);
      toast({
        variant: 'destructive',
        title: 'خطأ',
        description: 'حدث خطأ أثناء إرسال البلاغ',
      });
    } finally {
      setLoading(false);
    }
  };

  const getTypeLabel = () => {
    switch (reportedType) {
      case 'user':
        return 'المستخدم';
      case 'marketplace_item':
        return 'الإعلان';
      case 'real_estate':
        return 'العقار';
      case 'listing':
        return 'الفعالية التجارية';
      case 'post':
        return 'المنشور';
      default:
        return 'المحتوى';
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {trigger || (
          <Button variant="ghost" size="sm" className="text-destructive">
            <AlertTriangle className="h-4 w-4 ml-2" />
            إبلاغ
          </Button>
        )}
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <AlertTriangle className="h-5 w-5 text-destructive" />
            الإبلاغ عن {getTypeLabel()}
          </DialogTitle>
          <DialogDescription>
            يرجى اختيار سبب البلاغ وإضافة تفاصيل إن لزم الأمر
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label>سبب البلاغ *</Label>
            <Select value={reason} onValueChange={setReason}>
              <SelectTrigger>
                <SelectValue placeholder="اختر سبب البلاغ" />
              </SelectTrigger>
              <SelectContent>
                {REPORT_REASONS.map((r) => (
                  <SelectItem key={r.value} value={r.value}>
                    {r.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>تفاصيل إضافية (اختياري)</Label>
            <Textarea
              placeholder="أضف تفاصيل حول البلاغ..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={3}
            />
          </div>
        </div>

        <div className="flex justify-end gap-2">
          <Button variant="outline" onClick={() => setOpen(false)}>
            إلغاء
          </Button>
          <Button
            variant="destructive"
            onClick={handleSubmit}
            disabled={loading}
          >
            {loading ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              'إرسال البلاغ'
            )}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
