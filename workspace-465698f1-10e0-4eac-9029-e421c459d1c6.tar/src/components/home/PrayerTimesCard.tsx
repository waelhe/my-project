'use client';

import { useState, useEffect, useMemo, useSyncExternalStore } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Moon, Clock, MapPin } from 'lucide-react';

// Prayer times for Qudsaya
const prayerTimes = [
  { name: 'الفجر', time: '04:52', icon: '🌙' },
  { name: 'الشروق', time: '06:17', icon: '🌅' },
  { name: 'الظهر', time: '12:42', icon: '☀️' },
  { name: 'العصر', time: '16:27', icon: '🌤️' },
  { name: 'المغرب', time: '19:07', icon: '🌅' },
  { name: 'العشاء', time: '20:32', icon: '🌙' },
];

// Helper function to get next prayer
const getNextPrayer = (currentTime: Date) => {
  const now = currentTime.getHours() * 60 + currentTime.getMinutes();
  for (const prayer of prayerTimes) {
    const [hours, minutes] = prayer.time.split(':').map(Number);
    const prayerMinutes = hours * 60 + minutes;
    if (prayerMinutes > now) {
      return { ...prayer, timeRemaining: prayerMinutes - now };
    }
  }
  // Calculate time until first prayer tomorrow
  const fajrMinutes = 4 * 60 + 52;
  const tomorrowMinutes = 24 * 60 - now + fajrMinutes;
  return { ...prayerTimes[0], timeRemaining: tomorrowMinutes };
};

// Custom hook for client-side Only Rendering
const emptySubscribe = () => () => {};
const getSnapshot = () => true;
const getServerSnapshot = () => false;

export function PrayerTimesCard() {
  const isClient = useSyncExternalStore(emptySubscribe, getSnapshot, getServerSnapshot);
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 60000); // Update Every Minute

    return () => clearInterval(timer);
  }, []);

  const nextPrayer = useMemo(() => getNextPrayer(currentTime), [currentTime]);

  // Use Default Prayer During SSR to Avoid Hydration Mismatch
  const displayPrayer = isClient ? nextPrayer : prayerTimes[0];

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-base flex items-center gap-2">
          <Moon className="h-4 w-4 text-primary" />
          مواقيت الصلاة
        </CardTitle>
      </CardHeader>
      <CardContent>
        {/* Next Prayer Highlight */}
        <div className="bg-primary/10 rounded-xl p-4 mb-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs text-muted-foreground">الصلاة القادمة</p>
              <p className="text-lg font-bold">{displayPrayer.name}</p>
            </div>
            <div className="text-left">
              <p className="text-2xl font-bold text-primary">{displayPrayer.time}</p>
              <div className="flex items-center gap-1 text-xs text-muted-foreground">
                <MapPin className="h-3 w-3" />
                ضاحية قدسيا
              </div>
            </div>
          </div>
        </div>

        {/* All Prayer Times */}
        <div className="grid grid-cols-3 gap-2">
          {prayerTimes.map((prayer) => (
            <div
              key={prayer.name}
              className={`text-center p-2 rounded-lg ${
                isClient && prayer.name === nextPrayer.name
                  ? 'bg-primary text-primary-foreground'
                  : 'bg-muted'
              }`}
            >
              <span className="text-lg">{prayer.icon}</span>
              <p className="text-xs font-medium mt-1">{prayer.name}</p>
              <p
                className={`text-xs ${
                  isClient && prayer.name === nextPrayer.name
                    ? 'text-primary-foreground'
                    : 'text-muted-foreground'
                }`}
              >
                {prayer.time}
              </p>
            </div>
          ))}
        </div>

        {/* Date */}
        <div className="mt-4 text-center text-xs text-muted-foreground">
          <p>الأحد 15 رمضان 1446</p>
          <p>15 آذار 2025</p>
        </div>
      </CardContent>
    </Card>
  );
}
