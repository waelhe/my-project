'use client';

import Link from 'next/link';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import {
  Phone,
  Flame,
  Siren,
  Heart,
  Zap,
  Droplets,
  Shield,
} from 'lucide-react';

const emergencyContacts = [
  { name: 'الإسعاف', number: '110', icon: Heart, color: 'text-red-500' },
  { name: 'الإطفاء', number: '113', icon: Flame, color: 'text-orange-500' },
  { name: 'الشرطة', number: '112', icon: Shield, color: 'text-blue-500' },
  { name: 'الكهرباء', number: '115', icon: Zap, color: 'text-yellow-500' },
  { name: 'المياه', number: '117', icon: Droplets, color: 'text-cyan-500' },
];

export function EmergencyContacts() {
  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-base flex items-center gap-2">
          <Siren className="h-4 w-4 text-red-500" />
          أرقام الطوارئ
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-2">
          {emergencyContacts.map((contact) => {
            const Icon = contact.icon;
            return (
              <a
                key={contact.name}
                href={`tel:${contact.number}`}
                className="flex items-center justify-between p-2 rounded-lg hover:bg-muted transition-colors"
              >
                <div className="flex items-center gap-3">
                  <Icon className={`h-4 w-4 ${contact.color}`} />
                  <span className="text-sm">{contact.name}</span>
                </div>
                <span className="font-bold text-primary">{contact.number}</span>
              </a>
            );
          })}
        </div>

        <Link href="/emergency">
          <Button variant="outline" className="w-full mt-4">
            <Phone className="h-4 w-4 ml-2" />
            جميع أرقام الطوارئ
          </Button>
        </Link>
      </CardContent>
    </Card>
  );
}
