'use client';

import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { AlertTriangle, Megaphone, Calendar, Info } from 'lucide-react';

const newsItems = [
  {
    id: 1,
    type: 'alert',
    title: 'انقطاع الكهرباء في الجزيرة الثالثة حتى الساعة 6 مساءً',
    icon: AlertTriangle,
  },
  {
    id: 2,
    type: 'announcement',
    title: 'البلدية: بدء أعمال تعبيد شارع النخيل الأسبوع القادم',
    icon: Megaphone,
  },
  {
    id: 3,
    type: 'event',
    title: 'معرض العائلة السورية يوم الجمعة في مجمع الضاحية',
    icon: Calendar,
  },
  {
    id: 4,
    type: 'info',
    title: 'افتتاح فرع جديد لسوق التوفير قرب الجامع الكبير',
    icon: Info,
  },
];

const typeConfig = {
  alert: {
    bg: 'bg-red-500',
    text: 'عاجل',
  },
  announcement: {
    bg: 'bg-primary',
    text: 'إعلان',
  },
  event: {
    bg: 'bg-purple-500',
    text: 'فعالية',
  },
  info: {
    bg: 'bg-cyan-500',
    text: 'جديد',
  },
};

export function NewsMarquee() {
  return (
    <section className="bg-muted/50 border-y">
      <div className="container px-4 py-3">
        <div className="overflow-hidden">
          <div className="flex items-center gap-8 animate-marquee whitespace-nowrap">
            {[...newsItems, ...newsItems].map((item, index) => {
              const config = typeConfig[item.type as keyof typeof typeConfig];
              const Icon = item.icon;

              return (
                <div
                  key={`${item.id}-${index}`}
                  className="flex items-center gap-3"
                >
                  <Badge className={`${config.bg} text-white gap-1`}>
                    <Icon className="h-3 w-3" />
                    {config.text}
                  </Badge>
                  <span className="text-sm">{item.title}</span>
                  <span className="text-muted-foreground mx-4">•</span>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
