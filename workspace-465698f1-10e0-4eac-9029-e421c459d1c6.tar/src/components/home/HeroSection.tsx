'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Image from 'next/image';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Search,
  MapPin,
  ChevronLeft,
  ChevronRight,
  Plus,
  Sparkles,
} from 'lucide-react';

const heroSlides = [
  {
    title: 'سوق المستعمل',
    description: 'بع واشترِ بأمان في ضاحيتك',
    image: '/images/categories/marketplace.png',
    color: 'from-orange-500/30 to-amber-500/30',
    link: '/marketplace',
  },
  {
    title: 'عقارات الضاحية',
    description: 'شقق، محلات، وأراضٍ للبيع والإيجار',
    image: '/images/categories/real-estate.png',
    color: 'from-emerald-500/30 to-teal-500/30',
    link: '/real-estate',
  },
  {
    title: 'دليل الفعاليات',
    description: 'اكتشف المحلات والخدمات حولك',
    image: '/images/categories/directory.png',
    color: 'from-purple-500/30 to-pink-500/30',
    link: '/directory',
  },
  {
    title: 'مجتمعنا',
    description: 'تواصل مع جيرانك وشارك أفكارك',
    image: '/images/categories/community.png',
    color: 'from-blue-500/30 to-cyan-500/30',
    link: '/community',
  },
];

const popularSearches = [
  { term: 'شقة للإيجار', icon: '🏠' },
  { term: 'سيارة مستعملة', icon: '🚗' },
  { term: 'صيدلية مناوبة', icon: '💊' },
  { term: 'طبيب أسنان', icon: '🦷' },
  { term: 'أثاث منزلية', icon: '🛋️' },
];

export function HeroSection() {
  const router = useRouter();
  const [searchQuery, setSearchQuery] = useState('');
  const [currentSlide, setCurrentSlide] = useState(0);

  // Auto-rotate slides
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev === heroSlides.length - 1 ? 0 : prev + 1));
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      router.push(`/marketplace?search=${encodeURIComponent(searchQuery)}`);
    }
  };

  return (
    <section className="relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0">
        <Image
          src="/images/hero-bg.png"
          alt="Qudsaya"
          fill
          className="object-cover opacity-20"
          priority
        />
        <div className="absolute inset-0 bg-gradient-to-b from-background via-background/95 to-background" />
      </div>

      {/* Animated Gradient Orbs */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -right-40 w-96 h-96 bg-primary/20 rounded-full blur-3xl animate-pulse" />
        <div className="absolute -bottom-40 -left-40 w-96 h-96 bg-emerald-500/20 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }} />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-purple-500/10 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '2s' }} />
      </div>

      <div className="container relative px-4 py-8 md:py-12">
        {/* Location Badge */}
        <div className="flex items-center justify-center gap-2 mb-8">
          <div className="flex items-center gap-2 px-5 py-2.5 bg-primary/10 backdrop-blur-sm rounded-full text-sm border border-primary/20 shadow-lg">
            <MapPin className="h-4 w-4 text-primary" />
            <span className="font-semibold">ضاحية قدسيا</span>
            <span className="text-muted-foreground">• سوريا</span>
          </div>
        </div>

        {/* Main Content */}
        <div className="max-w-4xl mx-auto">
          {/* Title */}
          <div className="text-center mb-8">
            <h1 className="text-3xl md:text-5xl font-bold mb-3 bg-gradient-to-l from-primary via-emerald-500 to-primary bg-clip-text text-transparent">
              قدسيا بلس
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground">
              نبض الضاحية - منصتك المحلية الشاملة
            </p>
          </div>

          {/* Search Bar */}
          <div className="bg-card/80 backdrop-blur-sm rounded-2xl p-4 shadow-xl border mb-6">
            <form onSubmit={handleSearch} className="flex gap-3">
              <div className="relative flex-1">
                <Search className="absolute right-4 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                <Input
                  placeholder="ابحث عن منتج، عقار، خدمة..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pr-12 h-12 text-lg bg-background/50"
                />
              </div>
              <Button type="submit" size="lg" className="h-12 px-8">
                بحث
              </Button>
            </form>

            {/* Popular Searches */}
            <div className="mt-4">
              <p className="text-xs text-muted-foreground mb-2 flex items-center gap-1">
                <Sparkles className="h-3 w-3" />
                الأكثر بحثاً:
              </p>
              <div className="flex flex-wrap gap-2">
                {popularSearches.map((item) => (
                  <button
                    key={item.term}
                    onClick={() => setSearchQuery(item.term)}
                    className="text-sm px-3 py-1.5 bg-muted/80 hover:bg-muted rounded-full hover:shadow-md transition-all flex items-center gap-1.5"
                  >
                    <span>{item.icon}</span>
                    {item.term}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Hero Slider */}
          <div className="relative rounded-2xl overflow-hidden shadow-2xl border bg-card">
            <div className="relative h-64 md:h-72">
              {heroSlides.map((slide, index) => (
                <div
                  key={index}
                  className={`absolute inset-0 transition-all duration-700 ease-in-out ${
                    index === currentSlide
                      ? 'opacity-100 scale-100'
                      : 'opacity-0 scale-105'
                  }`}
                >
                  <div className={`absolute inset-0 bg-gradient-to-br ${slide.color}`} />
                  <div className="absolute inset-0 flex items-center">
                    <div className="flex-1 p-6 md:p-10">
                      <h2 className="text-2xl md:text-4xl font-bold mb-2">{slide.title}</h2>
                      <p className="text-muted-foreground text-lg mb-4">{slide.description}</p>
                      <Button
                        onClick={() => router.push(slide.link)}
                        className="gap-2"
                      >
                        استكشف الآن
                        <ChevronLeft className="h-4 w-4" />
                      </Button>
                    </div>
                    <div className="hidden md:block flex-1 relative h-full">
                      <Image
                        src={slide.image}
                        alt={slide.title}
                        fill
                        className="object-contain p-6 drop-shadow-2xl"
                      />
                    </div>
                  </div>
                </div>
              ))}

              {/* Navigation Arrows */}
              <button
                onClick={() =>
                  setCurrentSlide((prev) =>
                    prev === 0 ? heroSlides.length - 1 : prev - 1
                  )
                }
                className="absolute left-3 top-1/2 -translate-y-1/2 h-10 w-10 rounded-full bg-background/90 backdrop-blur-sm flex items-center justify-center hover:bg-background shadow-lg transition-all hover:scale-110"
              >
                <ChevronLeft className="h-5 w-5" />
              </button>
              <button
                onClick={() =>
                  setCurrentSlide((prev) =>
                    prev === heroSlides.length - 1 ? 0 : prev + 1
                  )
                }
                className="absolute right-3 top-1/2 -translate-y-1/2 h-10 w-10 rounded-full bg-background/90 backdrop-blur-sm flex items-center justify-center hover:bg-background shadow-lg transition-all hover:scale-110"
              >
                <ChevronRight className="h-5 w-5" />
              </button>

              {/* Dots */}
              <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2">
                {heroSlides.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => setCurrentSlide(index)}
                    className={`h-2.5 rounded-full transition-all ${
                      index === currentSlide
                        ? 'w-8 bg-primary'
                        : 'w-2.5 bg-primary/30 hover:bg-primary/50'
                    }`}
                  />
                ))}
              </div>
            </div>
          </div>

          {/* Quick Add Button */}
          <div className="flex justify-center mt-8">
            <Button
              size="lg"
              className="gap-3 shadow-xl hover:shadow-2xl transition-shadow text-lg px-8 py-6 rounded-full"
              onClick={() => router.push('/marketplace?new=true')}
            >
              <Plus className="h-5 w-5" />
              أضف إعلانك مجاناً
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}
