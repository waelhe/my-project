'use client';

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Sun, Cloud, Wind, Droplets, Thermometer } from 'lucide-react';

// Weather data for Qudsaya - would normally come from an API
const weatherData = {
  current: {
    temp: 22,
    condition: 'مشمس',
    icon: '☀️',
    humidity: 45,
    wind: 12,
  },
  forecast: [
    { day: 'غداً', temp: 24, icon: '⛅' },
    { day: 'الثلاثاء', temp: 23, icon: '☀️' },
    { day: 'الأربعاء', temp: 21, icon: '🌧️' },
  ],
};

export function WeatherCard() {
  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-base flex items-center gap-2">
          <Sun className="h-4 w-4 text-amber-500" />
          الطقس اليوم
        </CardTitle>
      </CardHeader>
      <CardContent>
        {/* Current Weather */}
        <div className="flex items-center justify-between mb-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-4xl">{weatherData.current.icon}</span>
              <div>
                <p className="text-3xl font-bold">{weatherData.current.temp}°</p>
                <p className="text-sm text-muted-foreground">
                  {weatherData.current.condition}
                </p>
              </div>
            </div>
          </div>
          <div className="text-left text-sm text-muted-foreground">
            <p className="flex items-center gap-1">
              <Droplets className="h-3 w-3" />
              {weatherData.current.humidity}%
            </p>
            <p className="flex items-center gap-1">
              <Wind className="h-3 w-3" />
              {weatherData.current.wind} كم/س
            </p>
          </div>
        </div>

        {/* Forecast */}
        <div className="grid grid-cols-3 gap-2">
          {weatherData.forecast.map((day) => (
            <div
              key={day.day}
              className="text-center p-2 bg-muted rounded-lg"
            >
              <p className="text-xs text-muted-foreground">{day.day}</p>
              <span className="text-xl">{day.icon}</span>
              <p className="text-sm font-medium">{day.temp}°</p>
            </div>
          ))}
        </div>

        {/* Location */}
        <p className="text-xs text-center text-muted-foreground mt-4">
          ضاحية قدسيا، ريف دمشق
        </p>
      </CardContent>
    </Card>
  );
}
