'use client';

import Link from 'next/link';
import Image from 'next/image';
import { Card, CardContent } from '@/components/ui/card';
import {
  ShoppingCart,
  Building2,
  BookOpen,
  Users,
  TrendingUp,
  Moon,
  Pill,
  Car,
  Phone,
  Utensils,
  ArrowLeft,
} from 'lucide-react';

const quickAccessItems = [
  {
    title: 'سوق المستعمل',
    description: 'بع واشترِ',
    icon: ShoppingCart,
    image: '/images/categories/marketplace.png',
    href: '/marketplace',
    gradient: 'from-orange-500 to-amber-500',
    count: 156,
  },
  {
    title: 'العقارات',
    description: 'بيع وإيجار',
    icon: Building2,
    image: '/images/categories/real-estate.png',
    href: '/real-estate',
    gradient: 'from-emerald-500 to-teal-500',
    count: 89,
  },
  {
    title: 'دليل الفعاليات',
    description: 'محلات وخدمات',
    icon: BookOpen,
    image: '/images/categories/directory.png',
    href: '/directory',
    gradient: 'from-purple-500 to-pink-500',
    count: 234,
  },
  {
    title: 'المجتمع',
    description: 'تواصل مع الجيران',
    icon: Users,
    image: '/images/categories/community.png',
    href: '/community',
    gradient: 'from-blue-500 to-cyan-500',
    count: null,
  },
];

const secondaryItems = [
  {
    title: 'أسعار السوق',
    description: 'أسعار اليوم',
    icon: TrendingUp,
    href: '/market-prices',
    color: 'bg-cyan-500',
  },
  {
    title: 'إسلامي',
    description: 'مواقيت الصلاة',
    icon: Moon,
    href: '/islamic',
    color: 'bg-indigo-500',
  },
  {
    title: 'صيدليات مناوبة',
    description: 'متاحة الآن',
    icon: Pill,
    href: '/pharmacies',
    color: 'bg-red-500',
    badge: '3',
  },
  {
    title: 'مواصلات',
    description: 'سيارات وسرافيس',
    icon: Car,
    href: '/transport',
    color: 'bg-amber-500',
  },
  {
    title: 'مطاعم',
    description: 'توصيل وجبات',
    icon: Utensils,
    href: '/directory?category=restaurants',
    color: 'bg-rose-500',
  },
  {
    title: 'طوارئ',
    description: 'أرقام هامة',
    icon: Phone,
    href: '/emergency',
    color: 'bg-red-600',
  },
];

export function QuickAccess() {
  return (
    <section className="container px-4 py-6">
      {/* Main Categories - Featured */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        {quickAccessItems.map((item) => (
          <Link
            key={item.href}
            href={item.href}
            className="group relative overflow-hidden rounded-2xl bg-card border shadow-sm hover:shadow-xl transition-all duration-300 hover:-translate-y-1"
          >
            {/* Background Image */}
            <div className="absolute inset-0 opacity-10 group-hover:opacity-20 transition-opacity">
              <Image
                src={item.image}
                alt=""
                fill
                className="object-cover"
              />
            </div>

            {/* Gradient Overlay */}
            <div className={`absolute inset-0 bg-gradient-to-br ${item.gradient} opacity-0 group-hover:opacity-10 transition-opacity`} />

            <div className="relative p-5">
              {/* Icon */}
              <div className={`h-14 w-14 rounded-2xl bg-gradient-to-br ${item.gradient} flex items-center justify-center mb-4 shadow-lg group-hover:scale-110 transition-transform`}>
                <item.icon className="h-7 w-7 text-white" />
              </div>

              {/* Content */}
              <h3 className="font-bold text-lg mb-1">{item.title}</h3>
              <p className="text-sm text-muted-foreground mb-2">{item.description}</p>

              {/* Footer */}
              <div className="flex items-center justify-between">
                {item.count && (
                  <span className="text-xs font-medium text-primary">
                    {item.count} إعلان
                  </span>
                )}
                <ArrowLeft className="h-4 w-4 text-muted-foreground group-hover:text-primary group-hover:-translate-x-1 transition-all" />
              </div>

              {/* Badge */}
              {item.count && (
                <div className="absolute top-3 left-3 px-2 py-1 rounded-full bg-primary/10 text-primary text-xs font-medium backdrop-blur-sm">
                  {item.count}
                </div>
              )}
            </div>
          </Link>
        ))}
      </div>

      {/* Secondary Items */}
      <Card className="border-0 shadow-md">
        <CardContent className="p-4">
          <div className="grid grid-cols-3 sm:grid-cols-6 gap-3">
            {secondaryItems.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className="group flex flex-col items-center p-3 rounded-xl hover:bg-muted/80 transition-colors"
              >
                <div className="relative">
                  <div className={`h-12 w-12 rounded-xl ${item.color} flex items-center justify-center mb-2 shadow-md group-hover:scale-110 transition-transform`}>
                    <item.icon className="h-6 w-6 text-white" />
                  </div>
                  {item.badge && (
                    <span className="absolute -top-1 -left-1 min-w-[20px] h-5 px-1 rounded-full bg-destructive text-destructive-foreground text-xs flex items-center justify-center font-bold">
                      {item.badge}
                    </span>
                  )}
                </div>
                <span className="text-xs font-medium text-center">{item.title}</span>
                <span className="text-[10px] text-muted-foreground">{item.description}</span>
              </Link>
            ))}
          </div>
        </CardContent>
      </Card>
    </section>
  );
}
