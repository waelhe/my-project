'use client';

import Link from 'next/link';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselPrevious,
  CarouselNext,
} from '@/components/ui/carousel';
import {
  Heart,
  MessageSquare,
  Eye,
  MapPin,
  Clock,
  ChevronLeft,
} from 'lucide-react';

const featuredItems = [
  {
    id: 1,
    type: 'marketplace',
    title: 'iPhone 13 Pro Max - ممتاز',
    price: '8,500,000',
    currency: 'ل.س',
    image: '/images/iphone.jpg',
    neighborhood: 'الجزيرة الأولى',
    timeAgo: 'منذ ساعتين',
    views: 124,
    isFeatured: true,
  },
  {
    id: 2,
    type: 'real_estate',
    title: 'شقة 140م للبيع - الجزيرة الثانية',
    price: '450,000,000',
    currency: 'ل.س',
    image: '/images/apartment.jpg',
    neighborhood: 'الجزيرة الثانية',
    timeAgo: 'منذ يوم',
    views: 89,
    isFeatured: true,
  },
  {
    id: 3,
    type: 'marketplace',
    title: 'غسالة سامسونج 8 كيلو',
    price: '2,800,000',
    currency: 'ل.س',
    image: '/images/washer.jpg',
    neighborhood: 'شارع النخيل',
    timeAgo: 'منذ 3 ساعات',
    views: 56,
    isFeatured: false,
  },
  {
    id: 4,
    type: 'real_estate',
    title: 'محل تجاري للإيجار - موقع ممتاز',
    price: '500,000',
    currency: 'ل.س/شهر',
    image: '/images/shop.jpg',
    neighborhood: 'الشارع الرئيسي',
    timeAgo: 'منذ يومين',
    views: 234,
    isFeatured: true,
  },
  {
    id: 5,
    type: 'marketplace',
    title: 'أثاث غرفة نوم كاملة',
    price: '4,200,000',
    currency: 'ل.س',
    image: '/images/furniture.jpg',
    neighborhood: 'الجزيرة الأولى',
    timeAgo: 'منذ 5 ساعات',
    views: 78,
    isFeatured: false,
  },
];

const directoryItems = [
  {
    id: 1,
    name: 'مطعم البيت السوري',
    category: 'مطاعم',
    rating: 4.5,
    reviews: 124,
    image: '/images/restaurant.jpg',
    neighborhood: 'الشارع الرئيسي',
    isOpen: true,
  },
  {
    id: 2,
    name: 'عيادة الدكتور أحمد الأسنان',
    category: 'أطباء',
    rating: 4.8,
    reviews: 89,
    image: '/images/clinic.jpg',
    neighborhood: 'الجزيرة الثانية',
    isOpen: true,
  },
  {
    id: 3,
    name: 'صيدلية الشفاء',
    category: 'صيدليات',
    rating: 4.6,
    reviews: 156,
    image: '/images/pharmacy.jpg',
    neighborhood: 'الجزيرة الأولى',
    isOpen: true,
    isOnDuty: true,
  },
  {
    id: 4,
    name: 'مركز التجميل للسيدات',
    category: 'تجميل',
    rating: 4.9,
    reviews: 234,
    image: '/images/beauty.jpg',
    neighborhood: 'شارع النخيل',
    isOpen: false,
  },
];

export function FeaturedSection() {
  return (
    <div className="space-y-6">
      {/* Featured Listings */}
      <Card>
        <CardHeader className="pb-3 flex flex-row items-center justify-between">
          <CardTitle className="text-base">إعلانات مميزة</CardTitle>
          <Link href="/marketplace">
            <Button variant="ghost" size="sm" className="text-primary">
              عرض الكل
              <ChevronLeft className="h-4 w-4 mr-1" />
            </Button>
          </Link>
        </CardHeader>
        <CardContent>
          <Carousel
            opts={{
              align: 'start',
              loop: true,
            }}
            className="w-full"
          >
            <CarouselContent className="-ml-4">
              {featuredItems.map((item) => (
                <CarouselItem key={item.id} className="pl-4 basis-1/2 md:basis-1/3 lg:basis-1/4">
                  <Link href={`/${item.type === 'real_estate' ? 'real-estate' : 'marketplace'}/${item.id}`}>
                    <div className="group relative rounded-xl overflow-hidden border bg-card hover:shadow-lg transition-all">
                      {/* Image */}
                      <div className="relative h-32 bg-muted">
                        <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
                        {item.isFeatured && (
                          <Badge className="absolute top-2 right-2 bg-amber-500 text-white">
                            مميز
                          </Badge>
                        )}
                        <div className="absolute bottom-2 right-2 flex items-center gap-1 text-white text-xs">
                          <Eye className="h-3 w-3" />
                          {item.views}
                        </div>
                      </div>

                      {/* Content */}
                      <div className="p-3">
                        <h3 className="font-medium text-sm line-clamp-1 group-hover:text-primary transition-colors">
                          {item.title}
                        </h3>
                        <p className="text-primary font-bold text-sm mt-1">
                          {item.price} {item.currency}
                        </p>
                        <div className="flex items-center gap-2 mt-2 text-xs text-muted-foreground">
                          <span className="flex items-center gap-1">
                            <MapPin className="h-3 w-3" />
                            {item.neighborhood}
                          </span>
                          <span className="flex items-center gap-1">
                            <Clock className="h-3 w-3" />
                            {item.timeAgo}
                          </span>
                        </div>
                      </div>
                    </div>
                  </Link>
                </CarouselItem>
              ))}
            </CarouselContent>
            <CarouselPrevious className="-right-4 left-auto" />
            <CarouselNext className="-left-4 right-auto" />
          </Carousel>
        </CardContent>
      </Card>

      {/* Directory Section */}
      <Card>
        <CardHeader className="pb-3 flex flex-row items-center justify-between">
          <CardTitle className="text-base">محلات وخدمات مميزة</CardTitle>
          <Link href="/directory">
            <Button variant="ghost" size="sm" className="text-primary">
              عرض الكل
              <ChevronLeft className="h-4 w-4 mr-1" />
            </Button>
          </Link>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {directoryItems.map((item) => (
              <Link key={item.id} href={`/directory/${item.id}`}>
                <div className="group flex items-center gap-4 p-3 rounded-xl border hover:bg-muted/50 transition-colors">
                  <Avatar className="h-14 w-14 rounded-xl">
                    <AvatarImage src={item.image} alt={item.name} />
                    <AvatarFallback className="rounded-xl">{item.name[0]}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <h3 className="font-medium text-sm group-hover:text-primary transition-colors">
                        {item.name}
                      </h3>
                      {item.isOnDuty && (
                        <Badge variant="destructive" className="text-xs">
                          مناوبة
                        </Badge>
                      )}
                    </div>
                    <p className="text-xs text-muted-foreground">{item.category}</p>
                    <div className="flex items-center gap-3 mt-1">
                      <span className="flex items-center gap-1 text-xs">
                        <span className="text-amber-500">★</span>
                        {item.rating} ({item.reviews})
                      </span>
                      <span
                        className={`text-xs flex items-center gap-1 ${
                          item.isOpen ? 'text-green-600' : 'text-red-500'
                        }`}
                      >
                        <span
                          className={`h-2 w-2 rounded-full ${
                            item.isOpen ? 'bg-green-500' : 'bg-red-500'
                          }`}
                        />
                        {item.isOpen ? 'مفتوح' : 'مغلق'}
                      </span>
                    </div>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
