'use client';

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  Zap,
  Droplets,
  Wifi,
  Fuel,
  CheckCircle,
  XCircle,
  AlertCircle,
} from 'lucide-react';

// This would normally come from the database
const services = [
  {
    id: 'electricity',
    name: 'الكهرباء',
    icon: Zap,
    status: 'partial',
    message: 'مقطوعة في الجزيرة الثالثة',
    affectedAreas: ['الجزيرة الثالثة', 'شارع النخيل'],
  },
  {
    id: 'water',
    name: 'المياه',
    icon: Droplets,
    status: 'available',
    message: 'متوفرة في جميع المناطق',
    affectedAreas: [],
  },
  {
    id: 'internet',
    name: 'الإنترنت',
    icon: Wifi,
    status: 'available',
    message: 'الخدمة مستقرة',
    affectedAreas: [],
  },
  {
    id: 'fuel',
    name: 'الوقود',
    icon: Fuel,
    status: 'available',
    message: 'متوفر في المحطات',
    affectedAreas: [],
  },
];

const statusConfig = {
  available: {
    color: 'bg-green-500',
    textColor: 'text-green-600',
    bgColor: 'bg-green-50 dark:bg-green-950',
    icon: CheckCircle,
    label: 'متوفر',
  },
  unavailable: {
    color: 'bg-red-500',
    textColor: 'text-red-600',
    bgColor: 'bg-red-50 dark:bg-red-950',
    icon: XCircle,
    label: 'غير متوفر',
  },
  partial: {
    color: 'bg-yellow-500',
    textColor: 'text-yellow-600',
    bgColor: 'bg-yellow-50 dark:bg-yellow-950',
    icon: AlertCircle,
    label: 'جزئي',
  },
  maintenance: {
    color: 'bg-orange-500',
    textColor: 'text-orange-600',
    bgColor: 'bg-orange-50 dark:bg-orange-950',
    icon: AlertCircle,
    label: 'صيانة',
  },
};

export function ServicesStatus() {
  return (
    <section className="container px-4 py-4">
      <Card className="overflow-hidden">
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <div className="h-2 w-2 rounded-full bg-primary animate-pulse" />
            حالة الخدمات اليوم
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {services.map((service) => {
              const config = statusConfig[service.status as keyof typeof statusConfig];
              const Icon = service.icon;
              const StatusIcon = config.icon;

              return (
                <div
                  key={service.id}
                  className={`p-3 rounded-xl ${config.bgColor} border transition-all hover:shadow-md`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className={`p-2 rounded-lg bg-background`}>
                      <Icon className={`h-4 w-4 ${config.textColor}`} />
                    </div>
                    <Badge
                      variant="secondary"
                      className={`text-xs ${config.textColor} bg-background`}
                    >
                      {config.label}
                    </Badge>
                  </div>
                  <h3 className="font-semibold text-sm mb-1">{service.name}</h3>
                  <p className="text-xs text-muted-foreground line-clamp-1">
                    {service.message}
                  </p>
                  {service.affectedAreas.length > 0 && (
                    <div className="mt-2 flex flex-wrap gap-1">
                      {service.affectedAreas.slice(0, 2).map((area) => (
                        <span
                          key={area}
                          className="text-xs px-2 py-0.5 bg-background rounded-full"
                        >
                          {area}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </section>
  );
}
