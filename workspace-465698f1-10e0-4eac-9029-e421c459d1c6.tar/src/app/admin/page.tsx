'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useSession } from 'next-auth/react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import {
  Users,
  ShoppingCart,
  Building2,
  BookOpen,
  TrendingUp,
  AlertCircle,
  Settings,
  Bell,
  Plus,
  Edit,
  Trash2,
  Check,
  X,
  Zap,
  Droplets,
  Wifi,
  Fuel,
  Loader2,
  LogOut,
  ArrowRight,
} from 'lucide-react';
import { toast } from 'sonner';

// Types
interface ServiceStatus {
  id: string;
  service: string;
  nameAr: string;
  status: string;
  message: string | null;
  affectedAreas: string[];
}

interface NewsItem {
  id: string;
  title: string;
  type: string;
  isBreaking: boolean;
  status: string;
  createdAt: string;
}

interface Stats {
  users: number;
  marketplaceItems: number;
  realEstates: number;
  directoryListings: number;
}

const neighborhoods = [
  'الجزيرة الأولى',
  'الجزيرة الثانية',
  'الجزيرة الثالثة',
  'شارع النخيل',
  'الشارع الرئيسي',
];

export default function AdminPage() {
  const { data: session, status } = useSession();
  const router = useRouter();
  
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState<Stats>({
    users: 0,
    marketplaceItems: 0,
    realEstates: 0,
    directoryListings: 0,
  });
  const [services, setServices] = useState<ServiceStatus[]>([]);
  const [pendingItems, setPendingItems] = useState<any[]>([]);
  const [newsItems, setNewsItems] = useState<NewsItem[]>([]);
  
  // Form states
  const [electricityStatus, setElectricityStatus] = useState('available');
  const [electricityMessage, setElectricityMessage] = useState('');
  const [electricityAreas, setElectricityAreas] = useState<string[]>([]);
  
  const [waterStatus, setWaterStatus] = useState('available');
  const [waterMessage, setWaterMessage] = useState('');
  const [waterAreas, setWaterAreas] = useState<string[]>([]);
  
  const [newNews, setNewNews] = useState({
    title: '',
    content: '',
    type: 'news',
    isBreaking: false,
  });

  // Check authentication
  useEffect(() => {
    if (status === 'unauthenticated') {
      router.push('/login?callbackUrl=/admin');
    } else if (status === 'authenticated' && session?.user?.role !== 'admin') {
      router.push('/');
    } else if (status === 'authenticated') {
      fetchData();
    }
  }, [status, session, router]);

  const fetchData = async () => {
    try {
      setLoading(true);
      
      // Fetch stats
      const statsRes = await fetch('/api/admin/stats');
      if (statsRes.ok) {
        const data = await statsRes.json();
        setStats(data);
      }
      
      // Fetch services status
      const servicesRes = await fetch('/api/services-status');
      if (servicesRes.ok) {
        const data = await servicesRes.json();
        setServices(data);
        
        // Set form values
        const electricity = data.find((s: ServiceStatus) => s.service === 'electricity');
        if (electricity) {
          setElectricityStatus(electricity.status);
          setElectricityMessage(electricity.message || '');
          setElectricityAreas(electricity.affectedAreas || []);
        }
        
        const water = data.find((s: ServiceStatus) => s.service === 'water');
        if (water) {
          setWaterStatus(water.status);
          setWaterMessage(water.message || '');
          setWaterAreas(water.affectedAreas || []);
        }
      }
      
      // Fetch pending items
      const pendingRes = await fetch('/api/admin/pending');
      if (pendingRes.ok) {
        const data = await pendingRes.json();
        setPendingItems(data);
      }
      
      // Fetch news
      const newsRes = await fetch('/api/news');
      if (newsRes.ok) {
        const data = await newsRes.json();
        setNewsItems(data.slice(0, 10));
      }
    } catch (error) {
      console.error('Error fetching admin data:', error);
      toast.error('حدث خطأ في تحميل البيانات');
    } finally {
      setLoading(false);
    }
  };

  const updateServiceStatus = async (service: string, statusData: {
    status: string;
    message?: string;
    affectedAreas?: string[];
  }) => {
    try {
      const res = await fetch('/api/admin/services', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ service, ...statusData }),
      });
      
      if (res.ok) {
        toast.success('تم تحديث حالة الخدمة');
        fetchData();
      } else {
        toast.error('حدث خطأ في تحديث الحالة');
      }
    } catch {
      toast.error('حدث خطأ في تحديث الحالة');
    }
  };

  const createNews = async () => {
    if (!newNews.title.trim()) {
      toast.error('يرجى إدخال عنوان الخبر');
      return;
    }
    
    try {
      const res = await fetch('/api/admin/news', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newNews),
      });
      
      if (res.ok) {
        toast.success('تم نشر الخبر بنجاح');
        setNewNews({ title: '', content: '', type: 'news', isBreaking: false });
        fetchData();
      } else {
        toast.error('حدث خطأ في نشر الخبر');
      }
    } catch {
      toast.error('حدث خطأ في نشر الخبر');
    }
  };

  const toggleArea = (areas: string[], setAreas: (a: string[]) => void, area: string) => {
    if (areas.includes(area)) {
      setAreas(areas.filter(a => a !== area));
    } else {
      setAreas([...areas, area]);
    }
  };

  if (status === 'loading' || loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (status === 'unauthenticated' || session?.user?.role !== 'admin') {
    return null;
  }

  return (
    <div className="container px-4 py-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold">لوحة التحكم</h1>
          <p className="text-muted-foreground">مرحباً، {session?.user?.name}</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="icon" onClick={() => router.push('/')}>
            <ArrowRight className="h-4 w-4" />
          </Button>
          <Button variant="outline" size="icon">
            <Bell className="h-4 w-4" />
          </Button>
          <Button variant="outline" size="icon">
            <Settings className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">المستخدمين</p>
                <p className="text-2xl font-bold">{stats.users}</p>
              </div>
              <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
                <Users className="h-5 w-5 text-primary" />
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">إعلانات السوق</p>
                <p className="text-2xl font-bold">{stats.marketplaceItems}</p>
              </div>
              <div className="h-10 w-10 rounded-lg bg-orange-500/10 flex items-center justify-center">
                <ShoppingCart className="h-5 w-5 text-orange-500" />
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">العقارات</p>
                <p className="text-2xl font-bold">{stats.realEstates}</p>
              </div>
              <div className="h-10 w-10 rounded-lg bg-emerald-500/10 flex items-center justify-center">
                <Building2 className="h-5 w-5 text-emerald-500" />
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">الفعاليات</p>
                <p className="text-2xl font-bold">{stats.directoryListings}</p>
              </div>
              <div className="h-10 w-10 rounded-lg bg-purple-500/10 flex items-center justify-center">
                <BookOpen className="h-5 w-5 text-purple-500" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="services" className="w-full">
        <TabsList className="grid w-full grid-cols-4 mb-6">
          <TabsTrigger value="services">الخدمات</TabsTrigger>
          <TabsTrigger value="news">الأخبار</TabsTrigger>
          <TabsTrigger value="pending">المراجعة</TabsTrigger>
          <TabsTrigger value="prices">الأسعار</TabsTrigger>
        </TabsList>

        {/* Services Status Tab */}
        <TabsContent value="services">
          <div className="grid md:grid-cols-2 gap-6">
            {/* Electricity Status */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Zap className="h-5 w-5 text-yellow-500" />
                  حالة الكهرباء
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>الحالة</Label>
                  <Select value={electricityStatus} onValueChange={setElectricityStatus}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="available">متوفرة</SelectItem>
                      <SelectItem value="unavailable">مقطوعة</SelectItem>
                      <SelectItem value="partial">مقطوعة جزئياً</SelectItem>
                      <SelectItem value="maintenance">صيانة</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>المناطق المتأثرة</Label>
                  <div className="flex flex-wrap gap-2">
                    {neighborhoods.map((area) => (
                      <label key={area} className="flex items-center gap-2 text-sm">
                        <input
                          type="checkbox"
                          className="rounded"
                          checked={electricityAreas.includes(area)}
                          onChange={() => toggleArea(electricityAreas, setElectricityAreas, area)}
                        />
                        {area}
                      </label>
                    ))}
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>رسالة إضافية</Label>
                  <Textarea
                    placeholder="مثال: متوقع العودة الساعة 6 مساءً"
                    value={electricityMessage}
                    onChange={(e) => setElectricityMessage(e.target.value)}
                    rows={2}
                  />
                </div>

                <Button 
                  className="w-full"
                  onClick={() => updateServiceStatus('electricity', {
                    status: electricityStatus,
                    message: electricityMessage,
                    affectedAreas: electricityAreas,
                  })}
                >
                  <Check className="h-4 w-4 ml-2" />
                  حفظ التغييرات
                </Button>
              </CardContent>
            </Card>

            {/* Water Status */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Droplets className="h-5 w-5 text-blue-500" />
                  حالة المياه
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>الحالة</Label>
                  <Select value={waterStatus} onValueChange={setWaterStatus}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="available">متوفرة</SelectItem>
                      <SelectItem value="unavailable">مقطوعة</SelectItem>
                      <SelectItem value="partial">مقطوعة جزئياً</SelectItem>
                      <SelectItem value="maintenance">صيانة</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>المناطق المتأثرة</Label>
                  <div className="flex flex-wrap gap-2">
                    {neighborhoods.map((area) => (
                      <label key={area} className="flex items-center gap-2 text-sm">
                        <input
                          type="checkbox"
                          className="rounded"
                          checked={waterAreas.includes(area)}
                          onChange={() => toggleArea(waterAreas, setWaterAreas, area)}
                        />
                        {area}
                      </label>
                    ))}
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>رسالة إضافية</Label>
                  <Textarea
                    placeholder="رسالة إضافية..."
                    value={waterMessage}
                    onChange={(e) => setWaterMessage(e.target.value)}
                    rows={2}
                  />
                </div>

                <Button 
                  className="w-full"
                  onClick={() => updateServiceStatus('water', {
                    status: waterStatus,
                    message: waterMessage,
                    affectedAreas: waterAreas,
                  })}
                >
                  <Check className="h-4 w-4 ml-2" />
                  حفظ التغييرات
                </Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* News Tab */}
        <TabsContent value="news">
          <div className="grid md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>إضافة خبر/إعلان</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>النوع</Label>
                    <Select 
                      value={newNews.type} 
                      onValueChange={(v) => setNewNews({...newNews, type: v})}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="news">خبر</SelectItem>
                        <SelectItem value="announcement">إعلان</SelectItem>
                        <SelectItem value="alert">تنبيه</SelectItem>
                        <SelectItem value="event">فعالية</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-2">
                    <Label>عاجل</Label>
                    <div className="flex items-center gap-2 pt-2">
                      <Switch
                        checked={newNews.isBreaking}
                        onCheckedChange={(v) => setNewNews({...newNews, isBreaking: v})}
                      />
                      <span className="text-sm">خبر عاجل</span>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>العنوان</Label>
                  <Input
                    placeholder="عنوان الخبر..."
                    value={newNews.title}
                    onChange={(e) => setNewNews({...newNews, title: e.target.value})}
                  />
                </div>

                <div className="space-y-2">
                  <Label>التفاصيل</Label>
                  <Textarea
                    placeholder="تفاصيل الخبر..."
                    value={newNews.content}
                    onChange={(e) => setNewNews({...newNews, content: e.target.value})}
                    rows={4}
                  />
                </div>

                <Button className="w-full" onClick={createNews}>
                  <Plus className="h-4 w-4 ml-2" />
                  نشر الخبر
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>آخر الأخبار</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 max-h-96 overflow-y-auto">
                  {newsItems.map((item) => (
                    <div key={item.id} className="flex items-start justify-between p-3 rounded-lg border">
                      <div>
                        <div className="flex items-center gap-2 mb-1">
                          <Badge variant={item.isBreaking ? 'destructive' : 'secondary'}>
                            {item.isBreaking ? 'عاجل' : item.type}
                          </Badge>
                        </div>
                        <p className="text-sm font-medium">{item.title}</p>
                        <p className="text-xs text-muted-foreground">
                          {new Date(item.createdAt).toLocaleDateString('ar-SY')}
                        </p>
                      </div>
                      <div className="flex gap-1">
                        <Button size="icon" variant="ghost">
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button size="icon" variant="ghost" className="text-red-500">
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Pending Items Tab */}
        <TabsContent value="pending">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <AlertCircle className="h-5 w-5 text-amber-500" />
                عناصر بانتظار المراجعة ({pendingItems.length})
              </CardTitle>
            </CardHeader>
            <CardContent>
              {pendingItems.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  لا توجد عناصر بانتظار المراجعة
                </div>
              ) : (
                <div className="space-y-4">
                  {pendingItems.map((item) => (
                    <div
                      key={item.id}
                      className="flex items-center justify-between p-4 rounded-lg border"
                    >
                      <div>
                        <div className="flex items-center gap-2 mb-1">
                          <Badge variant="outline">
                            {item.type === 'marketplace' ? 'سوق' : 
                             item.type === 'real_estate' ? 'عقار' : 'دليل'}
                          </Badge>
                          <span className="font-medium">{item.title}</span>
                        </div>
                        <p className="text-sm text-muted-foreground">
                          {item.user} • {new Date(item.createdAt).toLocaleDateString('ar-SY')}
                        </p>
                      </div>
                      <div className="flex gap-2">
                        <Button size="sm" variant="outline" className="text-green-600">
                          <Check className="h-4 w-4" />
                        </Button>
                        <Button size="sm" variant="outline" className="text-red-600">
                          <X className="h-4 w-4" />
                        </Button>
                        <Button size="sm" variant="outline">
                          <Edit className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Prices Tab */}
        <TabsContent value="prices">
          <Card>
            <CardHeader>
              <CardTitle>تحديث أسعار السوق</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground mb-4">
                اختر الفئة لتحديث الأسعار
              </p>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {['خضروات', 'فواكه', 'لحوم', 'ألبان'].map((category) => (
                  <Button key={category} variant="outline" className="h-auto py-4">
                    <div className="text-center">
                      <TrendingUp className="h-6 w-6 mx-auto mb-2" />
                      <span>{category}</span>
                    </div>
                  </Button>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
