'use client';

import { useState } from 'react';
import Link from 'next/link';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import {
  MessageSquare,
  HelpCircle,
  Package,
  Car,
  ThumbsUp,
  Clock,
  User,
  Plus,
  Search,
  Pin,
} from 'lucide-react';

const categoryLabels: Record<string, string> = {
  discussion: 'نقاش',
  question: 'سؤال',
  lost_found: 'مفقودات',
  carpool: 'توصيلة',
  recommendation: 'توصية',
};

const categoryColors: Record<string, string> = {
  discussion: 'bg-blue-500',
  question: 'bg-amber-500',
  lost_found: 'bg-red-500',
  carpool: 'bg-green-500',
  recommendation: 'bg-purple-500',
};

// Sample posts
const samplePosts = [
  {
    id: '1',
    title: 'هل يعرف أحد مكان بيع بطاريات سيارات موثوق؟',
    content: 'أحتاج بطارية جديدة للسيارة، أين يمكنني إيجاد بطاريات أصلية بسعر معقول؟',
    category: 'question',
    author: 'أحمد محمد',
    neighborhood: 'الجزيرة الأولى',
    timeAgo: 'منذ ساعتين',
    views: 124,
    comments: 15,
    likes: 8,
    isPinned: false,
  },
  {
    id: '2',
    title: 'تم العثور على محفظة في شارع النخيل',
    content: 'عثرت على محفظة تحتوي على هوية وبطاقات، الرجاء التواصل مع صاحبها على الرقم...',
    category: 'lost_found',
    author: 'محمد علي',
    neighborhood: 'شارع النخيل',
    timeAgo: 'منذ 3 ساعات',
    views: 89,
    comments: 12,
    likes: 25,
    isPinned: true,
  },
  {
    id: '3',
    title: 'توصيلة إلى دمشق صباحاً',
    content: 'سائق متجه إلى دمشق غداً صباحاً الساعة 7، من يرغب بالمشاركة؟',
    category: 'carpool',
    author: 'خالد أحمد',
    neighborhood: 'الجزيرة الثانية',
    timeAgo: 'منذ 5 ساعات',
    views: 67,
    comments: 8,
    likes: 5,
    isPinned: false,
  },
  {
    id: '4',
    title: 'أفضل طبيب أسنان في الضاحية؟',
    content: 'أبحث عن طبيب أسنان جيد ومحترم، هل يمكنكم التوصية بأحد؟',
    category: 'recommendation',
    author: 'سارة محمد',
    neighborhood: 'الجزيرة الثالثة',
    timeAgo: 'منذ يوم',
    views: 234,
    comments: 45,
    likes: 18,
    isPinned: false,
  },
  {
    id: '5',
    title: 'نقاش: الوضع الخدمي في الضاحية',
    content: 'ما رأيكم في الوضع الخدمي الحالي؟ الكهرباء والمياه والطرقات...',
    category: 'discussion',
    author: 'يوسف عبدالله',
    neighborhood: 'الشارع الرئيسي',
    timeAgo: 'منذ يومين',
    views: 456,
    comments: 89,
    likes: 45,
    isPinned: false,
  },
];

export default function CommunityPage() {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  const filteredPosts = samplePosts.filter((post) => {
    if (selectedCategory && post.category !== selectedCategory) return false;
    if (searchQuery && !post.title.includes(searchQuery)) return false;
    return true;
  });

  const sortedPosts = [...filteredPosts].sort((a, b) => {
    if (a.isPinned && !b.isPinned) return -1;
    if (!a.isPinned && b.isPinned) return 1;
    return 0;
  });

  return (
    <div className="container px-4 py-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold">منتدى المجتمع</h1>
          <p className="text-muted-foreground">تواصل مع جيرانك في الضاحية</p>
        </div>
        <Button className="gap-2">
          <Plus className="h-4 w-4" />
          منشور جديد
        </Button>
      </div>

      {/* Category Pills */}
      <div className="flex gap-2 overflow-x-auto pb-4 mb-4 scrollbar-hide">
        <Button
          variant={selectedCategory === null ? 'default' : 'outline'}
          size="sm"
          onClick={() => setSelectedCategory(null)}
        >
          الكل
        </Button>
        {Object.entries(categoryLabels).map(([id, name]) => (
          <Button
            key={id}
            variant={selectedCategory === id ? 'default' : 'outline'}
            size="sm"
            onClick={() => setSelectedCategory(id)}
            className="whitespace-nowrap"
          >
            {name}
          </Button>
        ))}
      </div>

      {/* Search */}
      <div className="relative mb-6">
        <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="ابحث في المنتدى..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="pr-10"
        />
      </div>

      {/* Posts */}
      <div className="space-y-4">
        {sortedPosts.map((post) => (
          <Link key={post.id} href={`/community/${post.id}`}>
            <Card className={`overflow-hidden hover:shadow-lg transition-shadow ${post.isPinned ? 'border-primary' : ''}`}>
              <CardContent className="p-4">
                <div className="flex items-start gap-3">
                  <Avatar className="h-10 w-10">
                    <AvatarFallback>{post.author[0]}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-medium text-sm">{post.author}</span>
                      <span className="text-xs text-muted-foreground">{post.timeAgo}</span>
                      {post.isPinned && (
                        <Pin className="h-4 w-4 text-primary" />
                      )}
                    </div>

                    <h3 className="font-semibold mb-1">{post.title}</h3>
                    <p className="text-sm text-muted-foreground line-clamp-2 mb-3">
                      {post.content}
                    </p>

                    <div className="flex items-center gap-4">
                      <Badge className={`${categoryColors[post.category]} text-white text-xs`}>
                        {categoryLabels[post.category]}
                      </Badge>
                      <span className="text-xs text-muted-foreground flex items-center gap-1">
                        <Clock className="h-3 w-3" />
                        {post.neighborhood}
                      </span>
                    </div>

                    <div className="flex items-center gap-4 mt-3 text-sm text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <MessageSquare className="h-4 w-4" />
                        {post.comments}
                      </span>
                      <span className="flex items-center gap-1">
                        <ThumbsUp className="h-4 w-4" />
                        {post.likes}
                      </span>
                      <span className="flex items-center gap-1">
                        <User className="h-4 w-4" />
                        {post.views}
                      </span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>

      {sortedPosts.length === 0 && (
        <div className="text-center py-12">
          <p className="text-muted-foreground">لا توجد منشورات</p>
        </div>
      )}
    </div>
  );
}
