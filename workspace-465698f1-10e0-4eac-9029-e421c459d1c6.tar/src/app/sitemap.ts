import { MetadataRoute } from 'next';
import { db } from '@/lib/db';

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const baseUrl = process.env.NEXT_PUBLIC_URL || 'https://qudsaya-plus.vercel.app';

  // الصفحات الثابتة
  const staticPages: MetadataRoute.Sitemap = [
    {
      url: baseUrl,
      lastModified: new Date(),
      changeFrequency: 'daily',
      priority: 1,
    },
    {
      url: `${baseUrl}/marketplace`,
      lastModified: new Date(),
      changeFrequency: 'hourly',
      priority: 0.9,
    },
    {
      url: `${baseUrl}/real-estate`,
      lastModified: new Date(),
      changeFrequency: 'hourly',
      priority: 0.9,
    },
    {
      url: `${baseUrl}/directory`,
      lastModified: new Date(),
      changeFrequency: 'daily',
      priority: 0.8,
    },
    {
      url: `${baseUrl}/community`,
      lastModified: new Date(),
      changeFrequency: 'hourly',
      priority: 0.8,
    },
    {
      url: `${baseUrl}/market-prices`,
      lastModified: new Date(),
      changeFrequency: 'daily',
      priority: 0.7,
    },
    {
      url: `${baseUrl}/islamic`,
      lastModified: new Date(),
      changeFrequency: 'daily',
      priority: 0.6,
    },
    {
      url: `${baseUrl}/login`,
      lastModified: new Date(),
      changeFrequency: 'monthly',
      priority: 0.5,
    },
    {
      url: `${baseUrl}/register`,
      lastModified: new Date(),
      changeFrequency: 'monthly',
      priority: 0.5,
    },
  ];

  try {
    // صفحات سوق المستعمل
    const marketplaceItems = await db.marketplaceItem.findMany({
      where: { status: 'active' },
      select: { id: true, updatedAt: true },
      take: 100,
    });

    const marketplacePages: MetadataRoute.Sitemap = marketplaceItems.map((item) => ({
      url: `${baseUrl}/marketplace/${item.id}`,
      lastModified: item.updatedAt,
      changeFrequency: 'weekly' as const,
      priority: 0.6,
    }));

    // صفحات العقارات
    const realEstates = await db.realEstate.findMany({
      where: { status: 'active' },
      select: { id: true, updatedAt: true },
      take: 100,
    });

    const realEstatePages: MetadataRoute.Sitemap = realEstates.map((item) => ({
      url: `${baseUrl}/real-estate/${item.id}`,
      lastModified: item.updatedAt,
      changeFrequency: 'weekly' as const,
      priority: 0.6,
    }));

    // صفحات دليل الفعاليات
    const directoryListings = await db.directoryListing.findMany({
      where: { status: 'active' },
      select: { id: true, updatedAt: true },
      take: 100,
    });

    const directoryPages: MetadataRoute.Sitemap = directoryListings.map((item) => ({
      url: `${baseUrl}/directory/${item.id}`,
      lastModified: item.updatedAt,
      changeFrequency: 'monthly' as const,
      priority: 0.5,
    }));

    return [...staticPages, ...marketplacePages, ...realEstatePages, ...directoryPages];
  } catch (error) {
    console.error('Error generating sitemap:', error);
    return staticPages;
  }
}
