'use client';

import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  TrendingUp,
  TrendingDown,
  Minus,
  RefreshCw,
  Clock,
} from 'lucide-react';

const priceCategories = [
  { id: 'vegetables', name: 'خضروات', icon: '🥬' },
  { id: 'fruits', name: 'فواكه', icon: '🍎' },
  { id: 'meat', name: 'لحوم', icon: '🥩' },
  { id: 'dairy', name: 'ألبان', icon: '🥛' },
  { id: 'gold', name: 'ذهب', icon: '💰' },
];

const priceData: Record<string, Array<{ name: string; unit: string; currentPrice: number; previousPrice: number; change: number }>> = {
  vegetables: [
    { name: 'طماطم', unit: 'كغ', currentPrice: 3500, previousPrice: 3000, change: 16.7 },
    { name: 'بطاطا', unit: 'كغ', currentPrice: 2500, previousPrice: 2500, change: 0 },
    { name: 'بصل', unit: 'كغ', currentPrice: 2000, previousPrice: 2200, change: -9.1 },
    { name: 'خيار', unit: 'كغ', currentPrice: 3000, previousPrice: 2800, change: 7.1 },
    { name: 'باذنجان', unit: 'كغ', currentPrice: 2500, previousPrice: 2300, change: 8.7 },
    { name: 'فلفل', unit: 'كغ', currentPrice: 4500, previousPrice: 4000, change: 12.5 },
  ],
  fruits: [
    { name: 'تفاح', unit: 'كغ', currentPrice: 5000, previousPrice: 4500, change: 11.1 },
    { name: 'موز', unit: 'كغ', currentPrice: 6000, previousPrice: 6000, change: 0 },
    { name: 'برتقال', unit: 'كغ', currentPrice: 3000, previousPrice: 3500, change: -14.3 },
    { name: 'عنب', unit: 'كغ', currentPrice: 8000, previousPrice: 7500, change: 6.7 },
    { name: 'بطيخ', unit: 'كغ', currentPrice: 1500, previousPrice: 1800, change: -16.7 },
  ],
  meat: [
    { name: 'لحم بقري', unit: 'كغ', currentPrice: 85000, previousPrice: 80000, change: 6.3 },
    { name: 'لحم غنم', unit: 'كغ', currentPrice: 120000, previousPrice: 115000, change: 4.3 },
    { name: 'دجاج', unit: 'كغ', currentPrice: 25000, previousPrice: 24000, change: 4.2 },
    { name: 'سمك', unit: 'كغ', currentPrice: 50000, previousPrice: 48000, change: 4.2 },
  ],
  dairy: [
    { name: 'حليب طازج', unit: 'لتر', currentPrice: 5000, previousPrice: 4500, change: 11.1 },
    { name: 'جبنة بيضاء', unit: 'كغ', currentPrice: 35000, previousPrice: 35000, change: 0 },
    { name: 'لبن', unit: 'كغ', currentPrice: 12000, previousPrice: 11000, change: 9.1 },
    { name: 'بيض', unit: '30 حبة', currentPrice: 15000, previousPrice: 14000, change: 7.1 },
  ],
  gold: [
    { name: 'ذهب عيار 24', unit: 'غ', currentPrice: 850000, previousPrice: 820000, change: 3.7 },
    { name: 'ذهب عيار 21', unit: 'غ', currentPrice: 750000, previousPrice: 720000, change: 4.2 },
    { name: 'ذهب عيار 18', unit: 'غ', currentPrice: 640000, previousPrice: 620000, change: 3.2 },
    { name: 'فضة', unit: 'غ', currentPrice: 12000, previousPrice: 11500, change: 4.3 },
  ],
};

export default function MarketPricesPage() {
  const [selectedCategory, setSelectedCategory] = useState('vegetables');
  const [lastUpdated] = useState(new Date().toLocaleString('ar-SY'));

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('ar-SY').format(price);
  };

  const getTrendIcon = (change: number) => {
    if (change > 0) return <TrendingUp className="h-4 w-4 text-red-500" />;
    if (change < 0) return <TrendingDown className="h-4 w-4 text-green-500" />;
    return <Minus className="h-4 w-4 text-muted-foreground" />;
  };

  const getTrendColor = (change: number) => {
    if (change > 0) return 'text-red-500';
    if (change < 0) return 'text-green-500';
    return 'text-muted-foreground';
  };

  return (
    <div className="container px-4 py-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold">أسعار السوق</h1>
          <p className="text-muted-foreground">أسعار محدثة يومياً للسلب الأساسية</p>
        </div>
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <Clock className="h-4 w-4" />
          آخر تحديث: {lastUpdated}
        </div>
      </div>

      {/* Category Tabs */}
      <Tabs defaultValue="vegetables" className="w-full" onValueChange={setSelectedCategory}>
        <TabsList className="flex flex-wrap h-auto gap-2 bg-transparent">
          {priceCategories.map((cat) => (
            <TabsTrigger
              key={cat.id}
              value={cat.id}
              className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground px-4 py-2"
            >
              {cat.icon} {cat.name}
            </TabsTrigger>
          ))}
        </TabsList>

        {Object.entries(priceData).map(([categoryId, items]) => (
          <TabsContent key={categoryId} value={categoryId} className="mt-6">
            <Card>
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg flex items-center gap-2">
                    {priceCategories.find((c) => c.id === categoryId)?.icon}
                    {priceCategories.find((c) => c.id === categoryId)?.name}
                  </CardTitle>
                  <Button variant="outline" size="sm" className="gap-1">
                    <RefreshCw className="h-4 w-4" />
                    تحديث
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="text-right">السلعة</TableHead>
                        <TableHead className="text-right">الوحدة</TableHead>
                        <TableHead className="text-right">السعر السابق</TableHead>
                        <TableHead className="text-right">السعر الحالي</TableHead>
                        <TableHead className="text-right">التغيير</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {items.map((item) => (
                        <TableRow key={item.name}>
                          <TableCell className="font-medium">{item.name}</TableCell>
                          <TableCell>{item.unit}</TableCell>
                          <TableCell className="text-muted-foreground">
                            {formatPrice(item.previousPrice)} ل.س
                          </TableCell>
                          <TableCell className="font-bold">
                            {formatPrice(item.currentPrice)} ل.س
                          </TableCell>
                          <TableCell>
                            <div className={`flex items-center gap-1 ${getTrendColor(item.change)}`}>
                              {getTrendIcon(item.change)}
                              <span>{item.change.toFixed(1)}%</span>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>

                {/* Summary */}
                <div className="mt-4 p-4 bg-muted/50 rounded-lg">
                  <div className="flex flex-wrap gap-4 justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground">متوسط التغيير</p>
                      <p className={`text-lg font-bold ${getTrendColor(
                        items.reduce((acc, item) => acc + item.change, 0) / items.length
                      )}`}>
                        {(items.reduce((acc, item) => acc + item.change, 0) / items.length).toFixed(1)}%
                      </p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">أعلى ارتفاع</p>
                      <p className="text-lg font-bold text-red-500">
                        +{Math.max(...items.map((i) => i.change)).toFixed(1)}%
                      </p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">أعلى انخفاض</p>
                      <p className="text-lg font-bold text-green-500">
                        {Math.min(...items.map((i) => i.change)).toFixed(1)}%
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
}
