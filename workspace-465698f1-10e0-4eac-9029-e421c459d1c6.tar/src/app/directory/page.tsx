'use client';

import { useState } from 'react';
import Link from 'next/link';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import {
  Search,
  MapPin,
  Phone,
  MessageCircle,
  Star,
  Clock,
  Plus,
  Heart,
} from 'lucide-react';

const categories = [
  { id: 'restaurants', name: 'مطاعم', icon: '🍽️' },
  { id: 'clinics', name: 'عيادات', icon: '🏥' },
  { id: 'pharmacies', name: 'صيدليات', icon: '💊' },
  { id: 'shops', name: 'محلات', icon: '🏪' },
  { id: 'services', name: 'خدمات', icon: '🔧' },
  { id: 'beauty', name: 'تجميل', icon: '💄' },
  { id: 'education', name: 'تعليم', icon: '📚' },
  { id: 'sports', name: 'رياضة', icon: '⚽' },
];

const neighborhoods = [
  'الجزيرة الأولى',
  'الجزيرة الثانية',
  'الجزيرة الثالثة',
  'شارع النخيل',
  'الشارع الرئيسي',
];

// Sample listings
const sampleListings = [
  {
    id: '1',
    name: 'مطعم البيت السوري',
    category: 'restaurants',
    neighborhood: 'الشارع الرئيسي',
    rating: 4.5,
    reviews: 124,
    isOpen: true,
    isOnDuty: false,
    phone: '0111234567',
    whatsapp: '963911234567',
    address: 'الشارع الرئيسي، قرب الجامع',
    workingHours: '10:00 - 23:00',
    image: null,
  },
  {
    id: '2',
    name: 'عيادة الدكتور أحمد الأسنان',
    category: 'clinics',
    neighborhood: 'الجزيرة الثانية',
    rating: 4.8,
    reviews: 89,
    isOpen: true,
    isOnDuty: false,
    phone: '0112345678',
    whatsapp: '963912345678',
    address: 'الجزيرة الثانية، شارع النخيل',
    workingHours: '09:00 - 20:00',
    image: null,
  },
  {
    id: '3',
    name: 'صيدلية الشفاء',
    category: 'pharmacies',
    neighborhood: 'الجزيرة الأولى',
    rating: 4.6,
    reviews: 156,
    isOpen: true,
    isOnDuty: true,
    phone: '0113456789',
    whatsapp: '963913456789',
    address: 'الجزيرة الأولى، قرب الجامع الكبير',
    workingHours: '08:00 - 23:00',
    image: null,
  },
  {
    id: '4',
    name: 'مركز التجميل للسيدات',
    category: 'beauty',
    neighborhood: 'شارع النخيل',
    rating: 4.9,
    reviews: 234,
    isOpen: false,
    isOnDuty: false,
    phone: '0114567890',
    whatsapp: '963914567890',
    address: 'شارع النخيل، بناية الأمان',
    workingHours: '09:00 - 21:00',
    image: null,
  },
  {
    id: '5',
    name: 'محل الخضار والفواكه',
    category: 'shops',
    neighborhood: 'الجزيرة الثالثة',
    rating: 4.3,
    reviews: 67,
    isOpen: true,
    isOnDuty: false,
    phone: '0115678901',
    whatsapp: null,
    address: 'الجزيرة الثالثة، السوق',
    workingHours: '07:00 - 22:00',
    image: null,
  },
  {
    id: '6',
    name: 'مركز تعليم اللغات',
    category: 'education',
    neighborhood: 'الجزيرة الأولى',
    rating: 4.7,
    reviews: 98,
    isOpen: true,
    isOnDuty: false,
    phone: '0116789012',
    whatsapp: '963916789012',
    address: 'الجزيرة الأولى، قرب المدرسة',
    workingHours: '09:00 - 20:00',
    image: null,
  },
];

export default function DirectoryPage() {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [selectedNeighborhood, setSelectedNeighborhood] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  const filteredListings = sampleListings.filter((listing) => {
    if (selectedCategory && listing.category !== selectedCategory) return false;
    if (selectedNeighborhood && listing.neighborhood !== selectedNeighborhood) return false;
    if (searchQuery && !listing.name.includes(searchQuery)) return false;
    return true;
  });

  const getCategoryInfo = (categoryId: string) => {
    return categories.find((c) => c.id === categoryId) || { name: categoryId, icon: '📍' };
  };

  return (
    <div className="container px-4 py-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold">دليل الفعاليات</h1>
          <p className="text-muted-foreground">محلات، خدمات، ومهنيون في ضاحيتك</p>
        </div>
        <Button className="gap-2">
          <Plus className="h-4 w-4" />
          أضف فعاليتك
        </Button>
      </div>

      {/* Category Pills */}
      <div className="flex gap-2 overflow-x-auto pb-4 mb-4 scrollbar-hide">
        <Button
          variant={selectedCategory === null ? 'default' : 'outline'}
          size="sm"
          onClick={() => setSelectedCategory(null)}
        >
          الكل
        </Button>
        {categories.map((cat) => (
          <Button
            key={cat.id}
            variant={selectedCategory === cat.id ? 'default' : 'outline'}
            size="sm"
            onClick={() => setSelectedCategory(cat.id)}
            className="whitespace-nowrap"
          >
            {cat.icon} {cat.name}
          </Button>
        ))}
      </div>

      {/* Filters */}
      <Card className="mb-6">
        <CardContent className="p-4">
          <div className="flex flex-wrap gap-4">
            <div className="relative flex-1 min-w-[200px]">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="ابحث عن محل أو خدمة..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pr-10"
              />
            </div>
            <Select value={selectedNeighborhood || 'all'} onValueChange={(v) => setSelectedNeighborhood(v === 'all' ? null : v)}>
              <SelectTrigger className="w-[150px]">
                <SelectValue placeholder="المنطقة" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">كل المناطق</SelectItem>
                {neighborhoods.map((n) => (
                  <SelectItem key={n} value={n}>
                    {n}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Listings Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredListings.map((listing) => {
          const categoryInfo = getCategoryInfo(listing.category);

          return (
            <Link key={listing.id} href={`/directory/${listing.id}`}>
              <Card className="overflow-hidden hover:shadow-lg transition-shadow">
                <CardContent className="p-4">
                  <div className="flex gap-4">
                    <Avatar className="h-16 w-16 rounded-xl">
                      <AvatarImage src={listing.image || ''} alt={listing.name} />
                      <AvatarFallback className="rounded-xl text-2xl">
                        {categoryInfo.icon}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between">
                        <div>
                          <div className="flex items-center gap-2">
                            <h3 className="font-medium">{listing.name}</h3>
                            {listing.isOnDuty && (
                              <Badge variant="destructive" className="text-xs">
                                مناوبة
                              </Badge>
                            )}
                          </div>
                          <p className="text-sm text-muted-foreground">{categoryInfo.name}</p>
                        </div>
                        <Button variant="ghost" size="icon" className="shrink-0">
                          <Heart className="h-4 w-4" />
                        </Button>
                      </div>

                      <div className="flex items-center gap-3 mt-2">
                        <span className="flex items-center gap-1 text-sm">
                          <Star className="h-4 w-4 text-amber-500 fill-amber-500" />
                          {listing.rating}
                          <span className="text-muted-foreground">({listing.reviews})</span>
                        </span>
                        <span
                          className={`text-sm flex items-center gap-1 ${
                            listing.isOpen ? 'text-green-600' : 'text-red-500'
                          }`}
                        >
                          <span
                            className={`h-2 w-2 rounded-full ${
                              listing.isOpen ? 'bg-green-500' : 'bg-red-500'
                            }`}
                          />
                          {listing.isOpen ? 'مفتوح' : 'مغلق'}
                        </span>
                      </div>

                      <div className="flex items-center gap-3 mt-2 text-sm text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <MapPin className="h-3 w-3" />
                          {listing.neighborhood}
                        </span>
                        <span className="flex items-center gap-1">
                          <Clock className="h-3 w-3" />
                          {listing.workingHours}
                        </span>
                      </div>

                      <div className="flex gap-2 mt-3">
                        <Button size="sm" variant="outline" className="gap-1">
                          <Phone className="h-3 w-3" />
                          اتصال
                        </Button>
                        {listing.whatsapp && (
                          <Button size="sm" variant="outline" className="gap-1">
                            <MessageCircle className="h-3 w-3" />
                            واتساب
                          </Button>
                        )}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </Link>
          );
        })}
      </div>

      {filteredListings.length === 0 && (
        <div className="text-center py-12">
          <p className="text-muted-foreground">لا توجد نتائج</p>
        </div>
      )}
    </div>
  );
}
