'use client';

import { useState, useEffect } from 'react';
import { useParams, useRouter } from 'next/navigation';
import Link from 'next/link';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Separator } from '@/components/ui/separator';
import { Carousel, CarouselContent, CarouselItem, CarouselPrevious, CarouselNext } from '@/components/ui/carousel';
import {
  MapPin,
  Clock,
  Eye,
  Heart,
  Share2,
  Phone,
  MessageCircle,
  ChevronRight,
  Loader2,
  AlertCircle,
  User,
  Calendar,
  Tag,
} from 'lucide-react';

// أنواع حالة المنتج
const conditionLabels: Record<string, { label: string; color: string }> = {
  new: { label: 'جديد', color: 'bg-green-500' },
  like_new: { label: 'مثل جديد', color: 'bg-emerald-500' },
  good: { label: 'جيد', color: 'bg-blue-500' },
  fair: { label: 'مقبول', color: 'bg-yellow-500' },
  needs_repair: { label: 'يحتاج إصلاح', color: 'bg-red-500' },
};

export default function MarketplaceItemPage() {
  const params = useParams();
  const router = useRouter();
  const id = params?.id as string;

  const [item, setItem] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    if (id) {
      fetchItem();
    }
  }, [id]);

  const fetchItem = async () => {
    try {
      setLoading(true);
      const response = await fetch(`/api/marketplace/${id}`);
      const data = await response.json();

      if (data.success) {
        setItem(data.data);
      } else {
        setError(data.error || 'لم يتم العثور على الإعلان');
      }
    } catch (err) {
      setError('حدث خطأ في تحميل البيانات');
    } finally {
      setLoading(false);
    }
  };

  const formatPrice = (price: number, currency: string) => {
    const formatted = new Intl.NumberFormat('ar-SY').format(price);
    return currency === 'SYP' ? `${formatted} ل.س` : formatted;
  };

  const shareItem = async () => {
    if (navigator.share) {
      await navigator.share({
        title: item.title,
        text: item.description,
        url: window.location.href,
      });
    }
  };

  const openWhatsApp = () => {
    if (item?.whatsappNumber || item?.seller?.phone) {
      const phone = item.whatsappNumber || item.seller.phone;
      const message = encodeURIComponent(`مرحباً، أنا مهتم بالإعلان: ${item.title}`);
      window.open(`https://wa.me/${phone}?text=${message}`, '_blank');
    }
  };

  const callPhone = () => {
    if (item?.contactPhone || item?.seller?.phone) {
      window.location.href = `tel:${item.contactPhone || item.seller.phone}`;
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (error || !item) {
    return (
      <div className="container px-4 py-12">
        <Card className="max-w-md mx-auto">
          <CardContent className="p-6 text-center">
            <AlertCircle className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
            <h2 className="text-xl font-bold mb-2">الإعلان غير موجود</h2>
            <p className="text-muted-foreground mb-4">{error || 'قد يكون الإعلان قد حُذف أو غير متاح'}</p>
            <Button onClick={() => router.push('/marketplace')}>
              العودة للسوق
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const images = item.images || [];
  const condition = conditionLabels[item.condition] || conditionLabels.good;

  return (
    <div className="container px-4 py-6">
      {/* Breadcrumb */}
      <nav className="flex items-center gap-2 text-sm mb-6 text-muted-foreground">
        <Link href="/" className="hover:text-primary">الرئيسية</Link>
        <ChevronRight className="h-4 w-4" />
        <Link href="/marketplace" className="hover:text-primary">السوق</Link>
        <ChevronRight className="h-4 w-4" />
        <span className="text-foreground">{item.title}</span>
      </nav>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Content */}
        <div className="lg:col-span-2 space-y-6">
          {/* Images */}
          <Card className="overflow-hidden">
            {images.length > 0 ? (
              <Carousel className="w-full">
                <CarouselContent>
                  {images.map((img: string, index: number) => (
                    <CarouselItem key={index}>
                      <div className="aspect-video bg-muted flex items-center justify-center">
                        <img
                          src={img}
                          alt={`${item.title} - صورة ${index + 1}`}
                          className="w-full h-full object-cover"
                        />
                      </div>
                    </CarouselItem>
                  ))}
                </CarouselContent>
                {images.length > 1 && (
                  <>
                    <CarouselPrevious />
                    <CarouselNext />
                  </>
                )}
              </Carousel>
            ) : (
              <div className="aspect-video bg-muted flex items-center justify-center">
                <span className="text-6xl opacity-20">📦</span>
              </div>
            )}
          </Card>

          {/* Details */}
          <Card>
            <CardHeader>
              <div className="flex items-start justify-between gap-4">
                <div>
                  <Badge className={`${condition.color} text-white mb-2`}>
                    {condition.label}
                  </Badge>
                  <CardTitle className="text-2xl">{item.title}</CardTitle>
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" size="icon" onClick={shareItem}>
                    <Share2 className="h-4 w-4" />
                  </Button>
                  <Button variant="outline" size="icon">
                    <Heart className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {/* Price */}
              <div className="mb-4">
                {item.price ? (
                  <p className="text-3xl font-bold text-primary">
                    {formatPrice(item.price, item.currency)}
                  </p>
                ) : (
                  <p className="text-xl text-muted-foreground">السعر عند الاتصال</p>
                )}
                {item.isNegotiable && (
                  <p className="text-sm text-muted-foreground">قابل للتفاوض</p>
                )}
              </div>

              {/* Stats */}
              <div className="flex flex-wrap gap-4 text-sm text-muted-foreground mb-6">
                <span className="flex items-center gap-1">
                  <MapPin className="h-4 w-4" />
                  {item.neighborhood || 'غير محدد'}
                </span>
                <span className="flex items-center gap-1">
                  <Clock className="h-4 w-4" />
                  {new Date(item.createdAt).toLocaleDateString('ar-SY', {
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric',
                  })}
                </span>
                <span className="flex items-center gap-1">
                  <Eye className="h-4 w-4" />
                  {item.viewCount || 0} مشاهدة
                </span>
              </div>

              <Separator className="my-4" />

              {/* Description */}
              <div>
                <h3 className="font-semibold mb-2">الوصف</h3>
                <p className="text-muted-foreground whitespace-pre-wrap">
                  {item.description || 'لا يوجد وصف'}
                </p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Seller Info */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base">معلومات البائع</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-3 mb-4">
                <Avatar className="h-12 w-12">
                  <AvatarImage src={item.seller?.avatar} />
                  <AvatarFallback>
                    <User className="h-6 w-6" />
                  </AvatarFallback>
                </Avatar>
                <div>
                  <p className="font-medium">
                    {item.seller?.displayName || 
                     `${item.seller?.firstName || ''} ${item.seller?.lastName || ''}`}
                  </p>
                  <p className="text-sm text-muted-foreground">
                    <Calendar className="h-3 w-3 inline ml-1" />
                    عضو منذ {new Date(item.seller?.createdAt).toLocaleDateString('ar-SY', {
                      year: 'numeric',
                      month: 'short',
                    })}
                  </p>
                </div>
              </div>

              {/* Contact Buttons */}
              <div className="space-y-2">
                <Button className="w-full gap-2" onClick={openWhatsApp}>
                  <MessageCircle className="h-4 w-4" />
                  تواصل عبر واتساب
                </Button>
                {item.showPhone && (
                  <Button variant="outline" className="w-full gap-2" onClick={callPhone}>
                    <Phone className="h-4 w-4" />
                    اتصال هاتفي
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Safety Tips */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                <AlertCircle className="h-4 w-4 text-amber-500" />
                نصائح السلامة
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="text-sm text-muted-foreground space-y-2">
                <li>• التقِ بالبائع في مكان عام</li>
                <li>• افحص المنتج قبل الشراء</li>
                <li>• لا ترسل أموالاً مقدماً</li>
                <li>• احتفظ بسجل المحادثات</li>
              </ul>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
