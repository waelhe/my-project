'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Search,
  Grid3X3,
  List,
  MapPin,
  Clock,
  Eye,
  Heart,
  Plus,
  Phone,
  MessageCircle,
  TrendingUp,
  Package,
  Sparkles,
  ChevronLeft,
} from 'lucide-react';

const categories = [
  { id: 'electronics', name: 'إلكترونيات', icon: '📱', image: '/images/categories/electronics.png' },
  { id: 'cars', name: 'سيارات', icon: '🚗', image: '/images/categories/cars.png' },
  { id: 'furniture', name: 'أثاث', icon: '🛋️', image: '/images/categories/furniture.png' },
  { id: 'appliances', name: 'أجهزة منزلية', icon: '📺', image: '/images/categories/appliances.png' },
  { id: 'clothes', name: 'ملابس', icon: '👕', image: '/images/categories/clothes.png' },
  { id: 'books', name: 'كتب', icon: '📚', image: '/images/categories/books.png' },
  { id: 'sports', name: 'رياضة', icon: '⚽', image: '/images/categories/sports.png' },
  { id: 'kids', name: 'أطفال', icon: '🧸', image: '/images/categories/kids.png' },
  { id: 'other', name: 'أخرى', icon: '📦', image: '/images/categories/other.png' },
];

const neighborhoods = [
  'الجزيرة الأولى',
  'الجزيرة الثانية',
  'الجزيرة الثالثة',
  'الجزيرة الرابعة',
  'الجزيرة الخامسة',
  'شارع النخيل',
  'الشارع الرئيسي',
];

const sampleItems = [
  {
    id: '1',
    title: 'iPhone 13 Pro Max - ممتاز',
    price: 8500000,
    currency: 'ل.س',
    neighborhood: 'الجزيرة الأولى',
    timeAgo: 'منذ ساعتين',
    views: 124,
    condition: 'like_new',
    category: 'electronics',
    isNegotiable: true,
    isFeatured: true,
    image: '/images/placeholders/product.png',
  },
  {
    id: '2',
    title: 'غسالة سامسونج 8 كيلو',
    price: 2800000,
    currency: 'ل.س',
    neighborhood: 'شارع النخيل',
    timeAgo: 'منذ 3 ساعات',
    views: 56,
    condition: 'good',
    category: 'appliances',
    isNegotiable: true,
    image: null,
  },
  {
    id: '3',
    title: 'أثاث غرفة نوم كاملة',
    price: 4200000,
    currency: 'ل.س',
    neighborhood: 'الجزيرة الثانية',
    timeAgo: 'منذ 5 ساعات',
    views: 78,
    condition: 'good',
    category: 'furniture',
    isNegotiable: true,
    image: null,
  },
  {
    id: '4',
    title: 'سيارة هيونداي النترا 2020',
    price: 85000000,
    currency: 'ل.س',
    neighborhood: 'الشارع الرئيسي',
    timeAgo: 'منذ يوم',
    views: 234,
    condition: 'excellent',
    category: 'cars',
    isNegotiable: true,
    isFeatured: true,
    image: null,
  },
  {
    id: '5',
    title: 'لابتوب HP Core i7',
    price: 12000000,
    currency: 'ل.س',
    neighborhood: 'الجزيرة الثالثة',
    timeAgo: 'منذ يومين',
    views: 189,
    condition: 'good',
    category: 'electronics',
    isNegotiable: false,
    image: null,
  },
  {
    id: '6',
    title: 'دراجة نارية هوندا 125',
    price: 15000000,
    currency: 'ل.س',
    neighborhood: 'الجزيرة الأولى',
    timeAgo: 'منذ 3 أيام',
    views: 145,
    condition: 'good',
    category: 'cars',
    isNegotiable: true,
    image: null,
  },
];

const conditionLabels: Record<string, string> = {
  new: 'جديد',
  like_new: 'مثل جديد',
  good: 'جيد',
  fair: 'مقبول',
  needs_repair: 'يحتاج إصلاح',
};

const conditionColors: Record<string, string> = {
  new: 'bg-emerald-500',
  like_new: 'bg-green-500',
  good: 'bg-blue-500',
  fair: 'bg-amber-500',
  needs_repair: 'bg-red-500',
};

export default function MarketplacePage() {
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [selectedNeighborhood, setSelectedNeighborhood] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [favorites, setFavorites] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Simulate loading
    const timer = setTimeout(() => setLoading(false), 500);
    return () => clearTimeout(timer);
  }, []);

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('ar-SY').format(price);
  };

  const toggleFavorite = (id: string) => {
    setFavorites((prev) =>
      prev.includes(id) ? prev.filter((f) => f !== id) : [...prev, id]
    );
  };

  const filteredItems = sampleItems.filter((item) => {
    if (selectedCategory && item.category !== selectedCategory) return false;
    if (selectedNeighborhood && item.neighborhood !== selectedNeighborhood) return false;
    if (searchQuery && !item.title.includes(searchQuery)) return false;
    return true;
  });

  const featuredItems = filteredItems.filter((item) => item.isFeatured);
  const regularItems = filteredItems.filter((item) => !item.isFeatured);

  return (
    <div className="min-h-screen bg-gradient-to-b from-background via-background to-muted/30">
      {/* Hero Section */}
      <div className="relative bg-gradient-to-br from-orange-500/10 via-amber-500/5 to-transparent pb-6">
        <div className="container px-4 pt-6">
          {/* Header */}
          <div className="flex items-center justify-between mb-6">
            <div>
              <h1 className="text-2xl md:text-3xl font-bold">سوق المستعمل</h1>
              <p className="text-muted-foreground flex items-center gap-2">
                <TrendingUp className="h-4 w-4 text-primary" />
                {sampleItems.length} إعلان متاح
              </p>
            </div>
            <Button className="gap-2 shadow-lg hover:shadow-xl transition-shadow">
              <Plus className="h-4 w-4" />
              <span className="hidden sm:inline">أضف إعلان</span>
            </Button>
          </div>

          {/* Categories */}
          <div className="flex gap-2 overflow-x-auto pb-4 scrollbar-hide -mx-4 px-4">
            <Button
              variant={selectedCategory === null ? 'default' : 'outline'}
              size="sm"
              onClick={() => setSelectedCategory(null)}
              className="shrink-0"
            >
              الكل
            </Button>
            {categories.map((cat) => (
              <Button
                key={cat.id}
                variant={selectedCategory === cat.id ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSelectedCategory(cat.id)}
                className="shrink-0 gap-2"
              >
                <span>{cat.icon}</span>
                {cat.name}
              </Button>
            ))}
          </div>
        </div>
      </div>

      <div className="container px-4 py-4">
        {/* Filters */}
        <Card className="mb-6 shadow-md border-0">
          <CardContent className="p-4">
            <div className="flex flex-wrap gap-3">
              <div className="flex-1 min-w-[200px]">
                <div className="relative">
                  <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="ابحث عن منتج..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pr-10 bg-background"
                  />
                </div>
              </div>
              <Select value={selectedNeighborhood || 'all'} onValueChange={(v) => setSelectedNeighborhood(v === 'all' ? null : v)}>
                <SelectTrigger className="w-[160px] bg-background">
                  <SelectValue placeholder="المنطقة" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">كل المناطق</SelectItem>
                  {neighborhoods.map((n) => (
                    <SelectItem key={n} value={n}>
                      {n}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <div className="flex gap-1 bg-muted p-1 rounded-lg">
                <Button
                  variant={viewMode === 'grid' ? 'default' : 'ghost'}
                  size="icon"
                  onClick={() => setViewMode('grid')}
                  className="h-8 w-8"
                >
                  <Grid3X3 className="h-4 w-4" />
                </Button>
                <Button
                  variant={viewMode === 'list' ? 'default' : 'ghost'}
                  size="icon"
                  onClick={() => setViewMode('list')}
                  className="h-8 w-8"
                >
                  <List className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Featured Items */}
        {featuredItems.length > 0 && (
          <div className="mb-6">
            <div className="flex items-center gap-2 mb-4">
              <Sparkles className="h-5 w-5 text-amber-500" />
              <h2 className="text-lg font-bold">إعلانات مميزة</h2>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {featuredItems.map((item) => (
                <Link key={item.id} href={`/marketplace/${item.id}`}>
                  <Card className="overflow-hidden hover:shadow-xl transition-all duration-300 hover:-translate-y-1 border-amber-200 dark:border-amber-900/50 bg-gradient-to-br from-amber-50/50 to-orange-50/50 dark:from-amber-950/20 dark:to-orange-950/20">
                    <div className="relative h-40 bg-muted">
                      {item.image ? (
                        <Image
                          src={item.image}
                          alt={item.title}
                          fill
                          className="object-cover"
                        />
                      ) : (
                        <div className="absolute inset-0 flex items-center justify-center bg-gradient-to-br from-muted to-muted/50">
                          <Package className="h-12 w-12 text-muted-foreground/30" />
                        </div>
                      )}
                      <Badge className={`absolute top-2 right-2 ${conditionColors[item.condition]} text-white`}>
                        {conditionLabels[item.condition]}
                      </Badge>
                      <Badge className="absolute top-2 left-2 bg-amber-500 text-white">
                        <Sparkles className="h-3 w-3 ml-1" />
                        مميز
                      </Badge>
                    </div>
                    <CardContent className="p-3">
                      <h3 className="font-medium text-sm line-clamp-2 mb-2">{item.title}</h3>
                      <p className="text-primary font-bold">
                        {formatPrice(item.price)} {item.currency}
                      </p>
                      {item.isNegotiable && (
                        <p className="text-xs text-muted-foreground">قابل للتفاوض</p>
                      )}
                      <div className="flex items-center justify-between mt-2 text-xs text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <MapPin className="h-3 w-3" />
                          {item.neighborhood}
                        </span>
                        <span className="flex items-center gap-1">
                          <Eye className="h-3 w-3" />
                          {item.views}
                        </span>
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              ))}
            </div>
          </div>
        )}

        {/* Regular Items */}
        <div className="flex items-center gap-2 mb-4">
          <Package className="h-5 w-5 text-muted-foreground" />
          <h2 className="text-lg font-bold">جميع الإعلانات</h2>
          <Badge variant="secondary">{regularItems.length}</Badge>
        </div>

        {loading ? (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {[...Array(6)].map((_, i) => (
              <Card key={i} className="overflow-hidden">
                <Skeleton className="h-40 w-full" />
                <CardContent className="p-3 space-y-2">
                  <Skeleton className="h-4 w-full" />
                  <Skeleton className="h-4 w-2/3" />
                  <Skeleton className="h-3 w-1/2" />
                </CardContent>
              </Card>
            ))}
          </div>
        ) : viewMode === 'grid' ? (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {regularItems.map((item) => (
              <Link key={item.id} href={`/marketplace/${item.id}`}>
                <Card className="overflow-hidden hover:shadow-lg transition-all duration-300 hover:-translate-y-1 group">
                  <div className="relative h-40 bg-muted">
                    {item.image ? (
                      <Image
                        src={item.image}
                        alt={item.title}
                        fill
                        className="object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                    ) : (
                      <div className="absolute inset-0 flex items-center justify-center bg-gradient-to-br from-muted to-muted/50">
                        <Package className="h-12 w-12 text-muted-foreground/30" />
                      </div>
                    )}
                    <Badge className={`absolute top-2 right-2 ${conditionColors[item.condition]} text-white`}>
                      {conditionLabels[item.condition]}
                    </Badge>
                    <button
                      onClick={(e) => {
                        e.preventDefault();
                        toggleFavorite(item.id);
                      }}
                      className="absolute bottom-2 left-2 h-8 w-8 rounded-full bg-background/90 backdrop-blur-sm flex items-center justify-center hover:bg-background shadow-md transition-colors"
                    >
                      <Heart
                        className={`h-4 w-4 transition-colors ${
                          favorites.includes(item.id)
                            ? 'fill-red-500 text-red-500'
                            : 'text-muted-foreground'
                        }`}
                      />
                    </button>
                  </div>
                  <CardContent className="p-3">
                    <h3 className="font-medium text-sm line-clamp-2 mb-2">{item.title}</h3>
                    <p className="text-primary font-bold">
                      {formatPrice(item.price)} {item.currency}
                    </p>
                    {item.isNegotiable && (
                      <p className="text-xs text-muted-foreground">قابل للتفاوض</p>
                    )}
                    <div className="flex items-center justify-between mt-2 text-xs text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <MapPin className="h-3 w-3" />
                        {item.neighborhood}
                      </span>
                      <span className="flex items-center gap-1">
                        <Eye className="h-3 w-3" />
                        {item.views}
                      </span>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        ) : (
          <div className="space-y-3">
            {regularItems.map((item) => (
              <Link key={item.id} href={`/marketplace/${item.id}`}>
                <Card className="overflow-hidden hover:shadow-lg transition-shadow">
                  <CardContent className="p-4">
                    <div className="flex gap-4">
                      <div className="w-28 h-28 bg-muted rounded-xl shrink-0 overflow-hidden relative">
                        {item.image ? (
                          <Image
                            src={item.image}
                            alt={item.title}
                            fill
                            className="object-cover"
                          />
                        ) : (
                          <div className="absolute inset-0 flex items-center justify-center">
                            <Package className="h-10 w-10 text-muted-foreground/30" />
                          </div>
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between">
                          <div>
                            <h3 className="font-semibold text-lg">{item.title}</h3>
                            <p className="text-primary font-bold text-xl">
                              {formatPrice(item.price)} {item.currency}
                              {item.isNegotiable && (
                                <span className="text-xs text-muted-foreground font-normal mr-2">
                                  (قابل للتفاوض)
                                </span>
                              )}
                            </p>
                          </div>
                          <Badge className={`${conditionColors[item.condition]} text-white`}>
                            {conditionLabels[item.condition]}
                          </Badge>
                        </div>
                        <div className="flex items-center gap-4 mt-2 text-sm text-muted-foreground">
                          <span className="flex items-center gap-1">
                            <MapPin className="h-3 w-3" />
                            {item.neighborhood}
                          </span>
                          <span className="flex items-center gap-1">
                            <Clock className="h-3 w-3" />
                            {item.timeAgo}
                          </span>
                          <span className="flex items-center gap-1">
                            <Eye className="h-3 w-3" />
                            {item.views}
                          </span>
                        </div>
                        <div className="flex gap-2 mt-3">
                          <Button size="sm" variant="outline" className="gap-1">
                            <Phone className="h-3 w-3" />
                            اتصال
                          </Button>
                          <Button size="sm" variant="outline" className="gap-1">
                            <MessageCircle className="h-3 w-3" />
                            واتساب
                          </Button>
                          <Button
                            size="sm"
                            variant="ghost"
                            className="gap-1"
                            onClick={(e) => {
                              e.preventDefault();
                              toggleFavorite(item.id);
                            }}
                          >
                            <Heart
                              className={`h-4 w-4 ${
                                favorites.includes(item.id)
                                  ? 'fill-red-500 text-red-500'
                                  : ''
                              }`}
                            />
                            حفظ
                          </Button>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        )}

        {filteredItems.length === 0 && (
          <div className="text-center py-16">
            <Package className="h-16 w-16 mx-auto text-muted-foreground/30 mb-4" />
            <p className="text-muted-foreground text-lg">لا توجد نتائج</p>
            <p className="text-sm text-muted-foreground mt-2">جرب تغيير معايير البحث</p>
          </div>
        )}
      </div>
    </div>
  );
}
