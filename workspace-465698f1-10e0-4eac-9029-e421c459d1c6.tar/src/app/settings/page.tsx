'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import {
  User,
  Bell,
  MapPin,
  Globe,
  Save,
  Loader2,
  ArrowRight,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import { useToast } from '@/hooks/use-toast';

interface UserSettings {
  id: string;
  firstName: string;
  lastName: string;
  displayName: string | null;
  email: string | null;
  phone: string | null;
  avatar: string | null;
  bio: string | null;
  neighborhood: string | null;
  preferredLanguage: string;
  notificationSettings: {
    messages: boolean;
    favorites: boolean;
    comments: boolean;
    reviews: boolean;
    news: boolean;
    priceAlerts: boolean;
  };
}

const NEIGHBORHOODS = [
  'الجزيرة الأولى',
  'الجزيرة الثانية',
  'الجزيرة الثالثة',
  'الجزيرة الرابعة',
  'الجزيرة الخامسة',
  'الجزيرة السادسة',
  'الجزيرة السابعة',
  'الجزيرة الثامنة',
  'الحضر',
  'المرج',
  'أخرى',
];

export default function SettingsPage() {
  const router = useRouter();
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [settings, setSettings] = useState<UserSettings | null>(null);

  // Form state
  const [displayName, setDisplayName] = useState('');
  const [bio, setBio] = useState('');
  const [neighborhood, setNeighborhood] = useState('');
  const [preferredLanguage, setPreferredLanguage] = useState('ar');
  const [notificationSettings, setNotificationSettings] = useState({
    messages: true,
    favorites: true,
    comments: true,
    reviews: true,
    news: true,
    priceAlerts: true,
  });

  useEffect(() => {
    fetchSettings();
  }, []);

  const fetchSettings = async () => {
    try {
      const res = await fetch('/api/user/settings');
      if (res.ok) {
        const data = await res.json();
        setSettings(data);
        setDisplayName(data.displayName || '');
        setBio(data.bio || '');
        setNeighborhood(data.neighborhood || '');
        setPreferredLanguage(data.preferredLanguage || 'ar');
        setNotificationSettings(data.notificationSettings || notificationSettings);
      } else if (res.status === 401) {
        router.push('/login');
      }
    } catch (error) {
      console.error('Error fetching settings:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      const res = await fetch('/api/user/settings', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          displayName,
          bio,
          neighborhood,
          preferredLanguage,
          notificationSettings,
        }),
      });

      if (res.ok) {
        toast({
          title: 'تم الحفظ',
          description: 'تم تحديث الإعدادات بنجاح',
        });
      } else {
        toast({
          variant: 'destructive',
          title: 'خطأ',
          description: 'فشل حفظ الإعدادات',
        });
      }
    } catch (error) {
      console.error('Error saving settings:', error);
      toast({
        variant: 'destructive',
        title: 'خطأ',
        description: 'حدث خطأ أثناء الحفظ',
      });
    } finally {
      setSaving(false);
    }
  };

  const updateNotificationSetting = (key: string, value: boolean) => {
    setNotificationSettings((prev) => ({
      ...prev,
      [key]: value,
    }));
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!settings) {
    return (
      <div className="container py-6">
        <div className="text-center py-16">
          <p className="text-muted-foreground">يرجى تسجيل الدخول للوصول للإعدادات</p>
          <Button asChild className="mt-4">
            <a href="/login">تسجيل الدخول</a>
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="container max-w-2xl py-6">
      <div className="flex items-center gap-4 mb-6">
        <Button
          variant="ghost"
          size="icon"
          onClick={() => router.back()}
        >
          <ArrowRight className="h-5 w-5" />
        </Button>
        <h1 className="text-2xl font-bold">الإعدادات</h1>
      </div>

      <div className="space-y-6">
        {/* Profile Settings */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <User className="h-5 w-5" />
              الملف الشخصي
            </CardTitle>
            <CardDescription>
              قم بتحديث معلومات ملفك الشخصي
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>الاسم الأول</Label>
                <Input value={settings.firstName} disabled />
              </div>
              <div className="space-y-2">
                <Label>اسم العائلة</Label>
                <Input value={settings.lastName} disabled />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="displayName">الاسم المعروض</Label>
              <Input
                id="displayName"
                placeholder="اختياري"
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="bio">نبذة عني</Label>
              <Textarea
                id="bio"
                placeholder="اكتب نبذة عن نفسك..."
                value={bio}
                onChange={(e) => setBio(e.target.value)}
                rows={3}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="neighborhood">الحي / المنطقة</Label>
              <Select value={neighborhood} onValueChange={setNeighborhood}>
                <SelectTrigger>
                  <SelectValue placeholder="اختر الحي" />
                </SelectTrigger>
                <SelectContent>
                  {NEIGHBORHOODS.map((n) => (
                    <SelectItem key={n} value={n}>
                      {n}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Language Settings */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Globe className="h-5 w-5" />
              اللغة والموقع
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <Label>اللغة المفضلة</Label>
              <Select value={preferredLanguage} onValueChange={setPreferredLanguage}>
                <SelectTrigger className="w-full md:w-64">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="ar">العربية</SelectItem>
                  <SelectItem value="en">English</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Notification Settings */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Bell className="h-5 w-5" />
              الإشعارات
            </CardTitle>
            <CardDescription>
              اختر الإشعارات التي تريد تلقيها
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium">الرسائل</p>
                  <p className="text-sm text-muted-foreground">
                    إشعارات الرسائل الجديدة
                  </p>
                </div>
                <Switch
                  checked={notificationSettings.messages}
                  onCheckedChange={(v) => updateNotificationSetting('messages', v)}
                />
              </div>

              <Separator />

              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium">المفضلة</p>
                  <p className="text-sm text-muted-foreground">
                    عندما يضيف شخص إعلانك للمفضلة
                  </p>
                </div>
                <Switch
                  checked={notificationSettings.favorites}
                  onCheckedChange={(v) => updateNotificationSetting('favorites', v)}
                />
              </div>

              <Separator />

              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium">التعليقات</p>
                  <p className="text-sm text-muted-foreground">
                    تعليقات على منشوراتك
                  </p>
                </div>
                <Switch
                  checked={notificationSettings.comments}
                  onCheckedChange={(v) => updateNotificationSetting('comments', v)}
                />
              </div>

              <Separator />

              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium">التقييمات</p>
                  <p className="text-sm text-muted-foreground">
                    تقييمات جديدة على نشاطك التجاري
                  </p>
                </div>
                <Switch
                  checked={notificationSettings.reviews}
                  onCheckedChange={(v) => updateNotificationSetting('reviews', v)}
                />
              </div>

              <Separator />

              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium">الأخبار والتنبيهات</p>
                  <p className="text-sm text-muted-foreground">
                    أخبار وتحديثات المنصة
                  </p>
                </div>
                <Switch
                  checked={notificationSettings.news}
                  onCheckedChange={(v) => updateNotificationSetting('news', v)}
                />
              </div>

              <Separator />

              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium">تنبيهات الأسعار</p>
                  <p className="text-sm text-muted-foreground">
                    تغييرات في أسعار المنتجات المهمة
                  </p>
                </div>
                <Switch
                  checked={notificationSettings.priceAlerts}
                  onCheckedChange={(v) => updateNotificationSetting('priceAlerts', v)}
                />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Save Button */}
        <div className="flex justify-end">
          <Button onClick={handleSave} disabled={saving}>
            {saving ? (
              <Loader2 className="h-4 w-4 animate-spin ml-2" />
            ) : (
              <Save className="h-4 w-4 ml-2" />
            )}
            حفظ الإعدادات
          </Button>
        </div>
      </div>
    </div>
  );
}
