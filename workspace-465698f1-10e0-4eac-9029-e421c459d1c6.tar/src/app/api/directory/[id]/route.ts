import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { db } from '@/lib/db';
import { z } from 'zod';

// مخطط التحديث
const updateListingSchema = z.object({
  name: z.string().min(3).optional(),
  description: z.string().min(10).optional(),
  phone: z.string().optional(),
  phone2: z.string().optional(),
  whatsapp: z.string().optional(),
  email: z.string().email().optional().or(z.literal('')),
  website: z.string().url().optional().or(z.literal('')),
  neighborhood: z.string().optional(),
  address: z.string().optional(),
  workingHours: z.record(z.unknown()).optional(),
  isOpen24h: z.boolean().optional(),
  isOnDuty: z.boolean().optional(),
  specialties: z.array(z.string()).optional(),
  services: z.array(z.string()).optional(),
  products: z.array(z.string()).optional(),
  priceRange: z.enum(['low', 'medium', 'high']).optional(),
  logo: z.string().optional(),
  coverImage: z.string().optional(),
  gallery: z.array(z.string()).optional(),
  status: z.enum(['pending', 'active', 'suspended', 'closed']).optional(),
  isFeatured: z.boolean().optional(),
});

// GET - جلب فعالية واحدة بالتفاصيل
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;

    const listing = await db.directoryListing.findUnique({
      where: { id },
      include: {
        category: {
          select: { id: true, name: true, nameAr: true, slug: true },
        },
        reviews: {
          include: {
            author: {
              select: {
                id: true,
                firstName: true,
                lastName: true,
                displayName: true,
                avatar: true,
              },
            },
          },
          orderBy: { createdAt: 'desc' },
          take: 20,
        },
        owner: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            displayName: true,
            phone: true,
            neighborhood: true,
          },
        },
      },
    });

    if (!listing || listing.deletedAt) {
      return NextResponse.json(
        { success: false, error: 'الفعالية غير موجودة' },
        { status: 404 }
      );
    }

    // زيادة عداد المشاهدات
    await db.directoryListing.update({
      where: { id },
      data: { viewCount: { increment: 1 } },
    }).catch(() => {});

    // تحويل البيانات
    const formattedListing = {
      ...listing,
      workingHours: listing.workingHours ? JSON.parse(listing.workingHours) : null,
      specialties: listing.specialties ? JSON.parse(listing.specialties) : [],
      services: listing.services ? JSON.parse(listing.services) : [],
      products: listing.products ? JSON.parse(listing.products) : [],
      gallery: listing.gallery ? JSON.parse(listing.gallery) : [],
    };

    // حساب التقييم
    const ratings = listing.reviews?.map(r => r.rating) || [];
    const avgRating = ratings.length > 0 
      ? ratings.reduce((a, b) => a + b, 0) / ratings.length 
      : null;

    return NextResponse.json({
      success: true,
      data: {
        ...formattedListing,
        avgRating,
        reviewCount: ratings.length,
      },
    });
  } catch (error) {
    console.error('Error fetching directory listing:', error);
    return NextResponse.json(
      { success: false, error: 'حدث خطأ في جلب البيانات' },
      { status: 500 }
    );
  }
}

// PUT - تحديث فعالية
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.id) {
      return NextResponse.json(
        { success: false, error: 'يجب تسجيل الدخول أولاً' },
        { status: 401 }
      );
    }

    const { id } = await params;
    const body = await request.json();
    const validatedData = updateListingSchema.parse(body);

    // التحقق من الملكية
    const existingListing = await db.directoryListing.findUnique({
      where: { id },
      select: { ownerId: true },
    });

    if (!existingListing) {
      return NextResponse.json(
        { success: false, error: 'الفعالية غير موجودة' },
        { status: 404 }
      );
    }

    // فقط صاحب الفعالية أو المدير يمكنه التعديل
    if (existingListing.ownerId !== session.user.id && session.user.role !== 'admin') {
      return NextResponse.json(
        { success: false, error: 'غير مصرح لك بتعديل هذه الفعالية' },
        { status: 403 }
      );
    }

    // بناء بيانات التحديث
    const updateData: Record<string, unknown> = {};
    
    const simpleFields = [
      'name', 'description', 'phone', 'phone2', 'whatsapp', 'email', 'website',
      'neighborhood', 'address', 'isOpen24h', 'isOnDuty', 'priceRange',
      'logo', 'coverImage', 'status', 'isFeatured'
    ];

    simpleFields.forEach(field => {
      if (validatedData[field as keyof typeof validatedData] !== undefined) {
        updateData[field] = validatedData[field as keyof typeof validatedData];
      }
    });

    // JSON fields
    if (validatedData.workingHours) updateData.workingHours = JSON.stringify(validatedData.workingHours);
    if (validatedData.specialties) updateData.specialties = JSON.stringify(validatedData.specialties);
    if (validatedData.services) updateData.services = JSON.stringify(validatedData.services);
    if (validatedData.products) updateData.products = JSON.stringify(validatedData.products);
    if (validatedData.gallery) updateData.gallery = JSON.stringify(validatedData.gallery);

    const listing = await db.directoryListing.update({
      where: { id },
      data: updateData,
    });

    // تسجيل النشاط
    await db.auditLog.create({
      data: {
        userId: session.user.id,
        action: 'update_directory_listing',
        entityType: 'directory_listing',
        entityId: id,
        newValue: JSON.stringify(validatedData),
      },
    }).catch(() => {});

    return NextResponse.json({
      success: true,
      data: listing,
    });
  } catch (error) {
    console.error('Error updating directory listing:', error);
    
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { success: false, error: error.errors[0].message },
        { status: 400 }
      );
    }
    
    return NextResponse.json(
      { success: false, error: 'حدث خطأ في تحديث الفعالية' },
      { status: 500 }
    );
  }
}

// DELETE - حذف فعالية (soft delete)
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.id) {
      return NextResponse.json(
        { success: false, error: 'يجب تسجيل الدخول أولاً' },
        { status: 401 }
      );
    }

    const { id } = await params;

    // التحقق من الملكية
    const existingListing = await db.directoryListing.findUnique({
      where: { id },
      select: { ownerId: true },
    });

    if (!existingListing) {
      return NextResponse.json(
        { success: false, error: 'الفعالية غير موجودة' },
        { status: 404 }
      );
    }

    // فقط صاحب الفعالية أو المدير يمكنه الحذف
    if (existingListing.ownerId !== session.user.id && session.user.role !== 'admin') {
      return NextResponse.json(
        { success: false, error: 'غير مصرح لك بحذف هذه الفعالية' },
        { status: 403 }
      );
    }

    // Soft delete
    await db.directoryListing.update({
      where: { id },
      data: {
        status: 'deleted',
        deletedAt: new Date(),
      },
    });

    // تسجيل النشاط
    await db.auditLog.create({
      data: {
        userId: session.user.id,
        action: 'delete_directory_listing',
        entityType: 'directory_listing',
        entityId: id,
      },
    }).catch(() => {});

    return NextResponse.json({
      success: true,
      message: 'تم حذف الفعالية بنجاح',
    });
  } catch (error) {
    console.error('Error deleting directory listing:', error);
    return NextResponse.json(
      { success: false, error: 'حدث خطأ في حذف الفعالية' },
      { status: 500 }
    );
  }
}
