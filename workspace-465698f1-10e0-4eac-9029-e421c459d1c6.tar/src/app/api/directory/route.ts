import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { db } from '@/lib/db';
import { z } from 'zod';

// مخطط إنشاء فعالية
const createListingSchema = z.object({
  name: z.string().min(3, 'الاسم يجب أن يكون 3 أحرف على الأقل'),
  nameAr: z.string().optional(),
  description: z.string().min(10, 'الوصف يجب أن يكون 10 أحرف على الأقل').optional(),
  type: z.enum(['shop', 'service', 'professional', 'restaurant', 'pharmacy', 'clinic', 'beauty', 'education', 'other']),
  categoryId: z.string().optional(),
  phone: z.string().optional(),
  phone2: z.string().optional(),
  whatsapp: z.string().optional(),
  email: z.string().email().optional().or(z.literal('')),
  website: z.string().url().optional().or(z.literal('')),
  facebook: z.string().optional(),
  instagram: z.string().optional(),
  neighborhood: z.string().optional(),
  address: z.string().optional(),
  landmark: z.string().optional(),
  latitude: z.number().optional(),
  longitude: z.number().optional(),
  workingHours: z.record(z.unknown()).optional(),
  isOpen24h: z.boolean().default(false),
  isOnDuty: z.boolean().default(false),
  specialties: z.array(z.string()).optional(),
  services: z.array(z.string()).optional(),
  products: z.array(z.string()).optional(),
  priceRange: z.enum(['low', 'medium', 'high']).optional(),
  logo: z.string().optional(),
  coverImage: z.string().optional(),
  gallery: z.array(z.string()).optional(),
});

// GET - جلب جميع الفعاليات
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const type = searchParams.get('type');
    const category = searchParams.get('category');
    const neighborhood = searchParams.get('neighborhood');
    const isOnDuty = searchParams.get('isOnDuty');
    const search = searchParams.get('search');
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '20');
    const skip = (page - 1) * limit;

    // بناء شروط البحث
    const where: Record<string, unknown> = {
      status: 'active',
      deletedAt: null,
    };

    if (type) where.type = type;
    if (category) where.category = { slug: category };
    if (neighborhood) where.neighborhood = neighborhood;
    if (isOnDuty === 'true') where.isOnDuty = true;

    if (search) {
      where.OR = [
        { name: { contains: search } },
        { nameAr: { contains: search } },
        { description: { contains: search } },
      ];
    }

    // جلب البيانات
    const [listings, total] = await Promise.all([
      db.directoryListing.findMany({
        where,
        include: {
          category: {
            select: { id: true, name: true, nameAr: true, slug: true },
          },
          reviews: {
            select: { rating: true },
            take: 100,
          },
        },
        orderBy: [
          { isFeatured: 'desc' },
          { ratingAverage: 'desc' },
          { createdAt: 'desc' },
        ],
        skip,
        take: limit,
      }),
      db.directoryListing.count({ where }),
    ]);

    // حساب التقييم
    const listingsWithRating = listings.map(listing => {
      const ratings = listing.reviews?.map(r => r.rating) || [];
      const avgRating = ratings.length > 0 
        ? ratings.reduce((a, b) => a + b, 0) / ratings.length 
        : null;

      return {
        ...listing,
        avgRating,
        reviewCount: ratings.length,
        reviews: undefined, // إزالة التفاصيل
      };
    });

    return NextResponse.json({
      success: true,
      data: listingsWithRating,
      meta: {
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit),
      },
    });
  } catch (error) {
    console.error('Error fetching directory listings:', error);
    return NextResponse.json(
      { success: false, error: 'حدث خطأ في جلب البيانات' },
      { status: 500 }
    );
  }
}

// POST - إنشاء فعالية جديدة
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    // يمكن إضافة فعالية بدون تسجيل (سيتم مراجعتها)
    const body = await request.json();
    const validatedData = createListingSchema.parse(body);

    // إنشاء slug
    const slug = validatedData.name
      .toLowerCase()
      .replace(/[^\w\s-]/g, '')
      .replace(/\s+/g, '-')
      .substring(0, 50) + '-' + Date.now().toString(36);

    const listing = await db.directoryListing.create({
      data: {
        ownerId: session?.user?.id || null,
        name: validatedData.name,
        nameAr: validatedData.nameAr || validatedData.name,
        description: validatedData.description || null,
        slug,
        type: validatedData.type,
        categoryId: validatedData.categoryId || null,
        phone: validatedData.phone || null,
        phone2: validatedData.phone2 || null,
        whatsapp: validatedData.whatsapp || null,
        email: validatedData.email || null,
        website: validatedData.website || null,
        facebook: validatedData.facebook || null,
        instagram: validatedData.instagram || null,
        neighborhood: validatedData.neighborhood || null,
        address: validatedData.address || null,
        landmark: validatedData.landmark || null,
        latitude: validatedData.latitude || null,
        longitude: validatedData.longitude || null,
        workingHours: validatedData.workingHours ? JSON.stringify(validatedData.workingHours) : null,
        isOpen24h: validatedData.isOpen24h,
        isOnDuty: validatedData.isOnDuty,
        specialties: validatedData.specialties ? JSON.stringify(validatedData.specialties) : null,
        services: validatedData.services ? JSON.stringify(validatedData.services) : null,
        products: validatedData.products ? JSON.stringify(validatedData.products) : null,
        priceRange: validatedData.priceRange || null,
        logo: validatedData.logo || null,
        coverImage: validatedData.coverImage || null,
        gallery: validatedData.gallery ? JSON.stringify(validatedData.gallery) : null,
        status: session?.user?.id ? 'active' : 'pending',
      },
    });

    // تسجيل النشاط
    if (session?.user?.id) {
      await db.auditLog.create({
        data: {
          userId: session.user.id,
          action: 'create_directory_listing',
          entityType: 'directory_listing',
          entityId: listing.id,
          newValue: JSON.stringify(validatedData),
        },
      }).catch(() => {});
    }

    return NextResponse.json({
      success: true,
      data: listing,
    });
  } catch (error) {
    console.error('Error creating directory listing:', error);
    
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { success: false, error: error.errors[0].message },
        { status: 400 }
      );
    }
    
    return NextResponse.json(
      { success: false, error: 'حدث خطأ في إنشاء الفعالية' },
      { status: 500 }
    );
  }
}
