import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { db } from '@/lib/db';

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session || session.user.role !== 'admin') {
      return NextResponse.json(
        { success: false, error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const [users, marketplaceItems, realEstates, directoryListings] = await Promise.all([
      db.user.count({ where: { status: 'active' } }),
      db.marketplaceItem.count({ where: { status: 'active' } }),
      db.realEstate.count({ where: { status: 'active' } }),
      db.directoryListing.count({ where: { status: 'active' } }),
    ]);

    return NextResponse.json({
      users,
      marketplaceItems,
      realEstates,
      directoryListings,
    });
  } catch (error) {
    console.error('Error fetching stats:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to fetch stats' },
      { status: 500 }
    );
  }
}
