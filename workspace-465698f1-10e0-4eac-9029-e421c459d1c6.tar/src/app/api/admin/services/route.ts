import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { db } from '@/lib/db';

export async function PUT(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session || session.user.role !== 'admin') {
      return NextResponse.json(
        { success: false, error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const body = await request.json();
    const { service, status, message, affectedAreas } = body;

    if (!service || !status) {
      return NextResponse.json(
        { success: false, error: 'Service and status are required' },
        { status: 400 }
      );
    }

    const validStatuses = ['available', 'unavailable', 'partial', 'maintenance'];
    if (!validStatuses.includes(status)) {
      return NextResponse.json(
        { success: false, error: 'Invalid status' },
        { status: 400 }
      );
    }

    // Service names in Arabic
    const serviceNames: Record<string, string> = {
      electricity: 'الكهرباء',
      water: 'المياه',
      internet: 'الإنترنت',
      fuel: 'الوقود',
    };

    // Upsert service status
    const serviceStatus = await db.serviceStatus.upsert({
      where: { service },
      update: {
        status,
        message: message || null,
        affectedAreas: affectedAreas || [],
        nameAr: serviceNames[service] || service,
      },
      create: {
        service,
        nameAr: serviceNames[service] || service,
        status,
        message: message || null,
        affectedAreas: affectedAreas || [],
      },
    });

    // Create audit log
    await db.auditLog.create({
      data: {
        userId: session.user.id,
        action: 'update_service_status',
        entityType: 'service',
        entityId: service,
        newValue: JSON.stringify({ status, message, affectedAreas }),
      },
    });

    return NextResponse.json({
      success: true,
      data: serviceStatus,
    });
  } catch (error) {
    console.error('Error updating service status:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to update service status' },
      { status: 500 }
    );
  }
}
