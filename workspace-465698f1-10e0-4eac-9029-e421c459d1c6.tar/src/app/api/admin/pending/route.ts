import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { db } from '@/lib/db';

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session || session.user.role !== 'admin') {
      return NextResponse.json(
        { success: false, error: 'Unauthorized' },
        { status: 401 }
      );
    }

    // Get pending marketplace items
    const pendingMarketplace = await db.marketplaceItem.findMany({
      where: { status: 'draft' },
      include: {
        seller: {
          select: { firstName: true, lastName: true },
        },
      },
      take: 10,
      orderBy: { createdAt: 'desc' },
    });

    // Get pending real estate
    const pendingRealEstate = await db.realEstate.findMany({
      where: { status: 'draft' },
      include: {
        owner: {
          select: { firstName: true, lastName: true },
        },
      },
      take: 10,
      orderBy: { createdAt: 'desc' },
    });

    // Get pending directory listings
    const pendingDirectory = await db.directoryListing.findMany({
      where: { status: 'pending' },
      include: {
        owner: {
          select: { firstName: true, lastName: true },
        },
      },
      take: 10,
      orderBy: { createdAt: 'desc' },
    });

    // Combine and format
    const pendingItems = [
      ...pendingMarketplace.map(item => ({
        id: item.id,
        type: 'marketplace',
        title: item.title,
        user: item.seller ? `${item.seller.firstName} ${item.seller.lastName}` : 'غير معروف',
        createdAt: item.createdAt,
      })),
      ...pendingRealEstate.map(item => ({
        id: item.id,
        type: 'real_estate',
        title: item.title,
        user: item.owner ? `${item.owner.firstName} ${item.owner.lastName}` : 'غير معروف',
        createdAt: item.createdAt,
      })),
      ...pendingDirectory.map(item => ({
        id: item.id,
        type: 'directory',
        title: item.name,
        user: item.owner ? `${item.owner.firstName} ${item.owner.lastName}` : 'غير معروف',
        createdAt: item.createdAt,
      })),
    ].sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());

    return NextResponse.json(pendingItems);
  } catch (error) {
    console.error('Error fetching pending items:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to fetch pending items' },
      { status: 500 }
    );
  }
}
