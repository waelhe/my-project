import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { db } from '@/lib/db';

// GET - جلب قائمة المفضلة
export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.id) {
      return NextResponse.json(
        { success: false, error: 'يجب تسجيل الدخول أولاً' },
        { status: 401 }
      );
    }

    const { searchParams } = new URL(request.url);
    const type = searchParams.get('type'); // marketplace, real_estate, directory

    // بناء شروط البحث
    const where: Record<string, unknown> = {
      userId: session.user.id,
    };

    if (type) where.itemType = type;

    const favorites = await db.favorite.findMany({
      where,
      orderBy: { createdAt: 'desc' },
    });

    // جلب تفاصيل العناصر المفضلة
    const result = await Promise.all(
      favorites.map(async (fav) => {
        let item = null;

        switch (fav.itemType) {
          case 'marketplace':
            item = await db.marketplaceItem.findUnique({
              where: { id: fav.itemId },
              select: {
                id: true,
                title: true,
                price: true,
                currency: true,
                neighborhood: true,
                images: true,
                status: true,
                createdAt: true,
              },
            });
            break;

          case 'real_estate':
            item = await db.realEstate.findUnique({
              where: { id: fav.itemId },
              select: {
                id: true,
                title: true,
                price: true,
                currency: true,
                type: true,
                listingType: true,
                neighborhood: true,
                area: true,
                images: true,
                status: true,
                createdAt: true,
              },
            });
            break;

          case 'directory':
            item = await db.directoryListing.findUnique({
              where: { id: fav.itemId },
              select: {
                id: true,
                name: true,
                type: true,
                neighborhood: true,
                logo: true,
                ratingAverage: true,
                ratingCount: true,
                status: true,
              },
            });
            break;
        }

        if (!item || item.status === 'deleted') {
          // حذف المفضلة إذا كان العنصر محذوفاً
          await db.favorite.delete({ where: { id: fav.id } });
          return null;
        }

        return {
          favoriteId: fav.id,
          itemType: fav.itemType,
          addedAt: fav.createdAt,
          item: {
            ...item,
            images: item.images ? JSON.parse(item.images) : [],
          },
        };
      })
    );

    // إزالة العناصر المحذوفة
    const validFavorites = result.filter(Boolean);

    return NextResponse.json({
      success: true,
      data: validFavorites,
      meta: {
        total: validFavorites.length,
        byType: {
          marketplace: validFavorites.filter(f => f?.itemType === 'marketplace').length,
          real_estate: validFavorites.filter(f => f?.itemType === 'real_estate').length,
          directory: validFavorites.filter(f => f?.itemType === 'directory').length,
        },
      },
    });
  } catch (error) {
    console.error('Error fetching favorites:', error);
    return NextResponse.json(
      { success: false, error: 'حدث خطأ في جلب المفضلة' },
      { status: 500 }
    );
  }
}

// POST - إضافة للمفضلة
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.id) {
      return NextResponse.json(
        { success: false, error: 'يجب تسجيل الدخول أولاً' },
        { status: 401 }
      );
    }

    const body = await request.json();
    const { itemType, itemId } = body;

    if (!itemType || !itemId) {
      return NextResponse.json(
        { success: false, error: 'يجب تحديد نوع العنصر ومعرفه' },
        { status: 400 }
      );
    }

    // التحقق من صحة النوع
    const validTypes = ['marketplace', 'real_estate', 'directory'];
    if (!validTypes.includes(itemType)) {
      return NextResponse.json(
        { success: false, error: 'نوع العنصر غير صالح' },
        { status: 400 }
      );
    }

    // التحقق من عدم وجود المفضلة مسبقاً
    const existing = await db.favorite.findFirst({
      where: {
        userId: session.user.id,
        itemType,
        itemId,
      },
    });

    if (existing) {
      return NextResponse.json({
        success: true,
        data: existing,
        message: 'العنصر موجود مسبقاً في المفضلة',
      });
    }

    // إنشاء المفضلة
    const favorite = await db.favorite.create({
      data: {
        userId: session.user.id,
        itemType,
        itemId,
      },
    });

    // تحديث عداد المفضلة في العنصر
    const updateModel = itemType === 'marketplace' 
      ? db.marketplaceItem
      : itemType === 'real_estate'
        ? db.realEstate
        : db.directoryListing;

    await updateModel.update({
      where: { id: itemId },
      data: { favoriteCount: { increment: 1 } },
    }).catch(() => {});

    return NextResponse.json({
      success: true,
      data: favorite,
    });
  } catch (error) {
    console.error('Error adding to favorites:', error);
    return NextResponse.json(
      { success: false, error: 'حدث خطأ في إضافة المفضلة' },
      { status: 500 }
    );
  }
}

// DELETE - إزالة من المفضلة
export async function DELETE(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.id) {
      return NextResponse.json(
        { success: false, error: 'يجب تسجيل الدخول أولاً' },
        { status: 401 }
      );
    }

    const { searchParams } = new URL(request.url);
    const itemType = searchParams.get('itemType');
    const itemId = searchParams.get('itemId');
    const favoriteId = searchParams.get('id');

    let favorite;

    if (favoriteId) {
      favorite = await db.favorite.findUnique({
        where: { id: favoriteId },
      });
    } else if (itemType && itemId) {
      favorite = await db.favorite.findFirst({
        where: {
          userId: session.user.id,
          itemType,
          itemId,
        },
      });
    }

    if (!favorite) {
      return NextResponse.json(
        { success: false, error: 'العنصر غير موجود في المفضلة' },
        { status: 404 }
      );
    }

    // التحقق من الملكية
    if (favorite.userId !== session.user.id) {
      return NextResponse.json(
        { success: false, error: 'غير مصرح لك بإزالة هذا العنصر' },
        { status: 403 }
      );
    }

    // حذف المفضلة
    await db.favorite.delete({
      where: { id: favorite.id },
    });

    // تحديث عداد المفضلة
    const updateModel = favorite.itemType === 'marketplace' 
      ? db.marketplaceItem
      : favorite.itemType === 'real_estate'
        ? db.realEstate
        : db.directoryListing;

    await updateModel.update({
      where: { id: favorite.itemId },
      data: { favoriteCount: { decrement: 1 } },
    }).catch(() => {});

    return NextResponse.json({
      success: true,
      message: 'تم إزالة العنصر من المفضلة',
    });
  } catch (error) {
    console.error('Error removing from favorites:', error);
    return NextResponse.json(
      { success: false, error: 'حدث خطأ في إزالة المفضلة' },
      { status: 500 }
    );
  }
}
