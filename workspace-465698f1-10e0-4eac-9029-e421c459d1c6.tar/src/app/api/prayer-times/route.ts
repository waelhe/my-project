import { NextResponse } from 'next/server';

// Prayer times calculation for Qudsaya, Syria
// This is a simplified calculation - in production, you'd use a proper Islamic prayer time library
export async function GET() {
  try {
    const today = new Date();
    const now = today.getHours() * 60 + today.getMinutes();
    
    // Qudsaya coordinates: 33.5755° N, 36.0800° E
    // Prayer times for Qudsaya (approximate)
    const prayers = [
      { name: 'الفجر', nameEn: 'Fajr', time: '04:52' },
      { name: 'الشروق', nameEn: 'Sunrise', time: '06:17' },
      { name: 'الظهر', nameEn: 'Dhuhr', time: '12:42' },
      { name: 'العصر', nameEn: 'Asr', time: '16:27' },
      { name: 'المغرب', nameEn: 'Maghrib', time: '19:07' },
      { name: 'العشاء', nameEn: 'Isha', time: '20:32' },
    ];
    
    // Find next prayer
    let nextPrayer = prayers[0]; // Default to Fajr
    for (const prayer of prayers) {
      const [hours, minutes] = prayer.time.split(':').map(Number);
      const prayerMinutes = hours * 60 + minutes;
      if (prayerMinutes > now) {
        nextPrayer = prayer;
        break;
      }
    }
    
    // Calculate Hijri date (approximate)
    const hijriDate = getHijriDate(today);
    
    return NextResponse.json({
      date: today.toISOString().split('T')[0],
      hijriDate,
      location: {
        name: 'ضاحية قدسيا',
        latitude: 33.5755,
        longitude: 36.0800,
      },
      prayers,
      nextPrayer,
    });
  } catch (error) {
    console.error('Error calculating prayer times:', error);
    return NextResponse.json(
      { error: 'Failed to calculate prayer times' },
      { status: 500 }
    );
  }
}

// Approximate Hijri date calculation
function getHijriDate(date: Date): { day: number; month: string; year: number; monthNumber: number } {
  const hijriMonths = [
    'محرم', 'صفر', 'ربيع الأول', 'ربيع الثاني',
    'جمادى الأولى', 'جمادى الآخرة', 'رجب', 'شعبان',
    'رمضان', 'شوال', 'ذو القعدة', 'ذو الحجة'
  ];
  
  // Simple approximation (not accurate for all dates)
  // In production, use a proper Hijri calendar library
  const gregorianYear = date.getFullYear();
  const gregorianMonth = date.getMonth();
  const gregorianDay = date.getDate();
  
  // Approximate Hijri year
  const hijriYear = Math.floor((gregorianYear - 622) * 1.030684);
  
  // Approximate day and month (simplified)
  const dayOfYear = Math.floor((date.getTime() - new Date(gregorianYear, 0, 0).getTime()) / 86400000);
  const hijriDayOfYear = Math.floor(dayOfYear * 0.967); // Hijri year is shorter
  
  const hijriMonth = Math.floor(hijriDayOfYear / 30) % 12;
  const hijriDay = (hijriDayOfYear % 30) + 1;
  
  return {
    day: hijriDay,
    month: hijriMonths[hijriMonth],
    monthNumber: hijriMonth + 1,
    year: hijriYear,
  };
}
