import { NextRequest, NextResponse } from 'next/server';
import { hash } from 'bcryptjs';
import { db } from '@/lib/db';
import { z } from 'zod';

const registerSchema = z.object({
  firstName: z.string().min(2, 'الاسم الأول يجب أن يكون حرفين على الأقل'),
  lastName: z.string().min(2, 'اسم العائلة يجب أن يكون حرفين على الأقل'),
  phone: z.string().regex(/^09\d{8}$/, 'رقم الهاتف غير صالح'),
  email: z.string().email('البريد الإلكتروني غير صالح').optional().or(z.literal('')),
  password: z.string().min(6, 'كلمة المرور يجب أن تكون 6 أحرف على الأقل'),
  neighborhood: z.string().optional(),
});

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    
    // Validate input
    const validatedData = registerSchema.parse(body);
    
    // Check if user already exists
    const existingUser = await db.user.findFirst({
      where: {
        OR: [
          { phone: validatedData.phone },
          ...(validatedData.email ? [{ email: validatedData.email }] : []),
        ],
      },
    });
    
    if (existingUser) {
      return NextResponse.json(
        { success: false, error: 'رقم الهاتف أو البريد الإلكتروني مستخدم بالفعل' },
        { status: 400 }
      );
    }
    
    // Hash password
    const passwordHash = await hash(validatedData.password, 12);
    
    // Create user
    const user = await db.user.create({
      data: {
        firstName: validatedData.firstName,
        lastName: validatedData.lastName,
        displayName: `${validatedData.firstName} ${validatedData.lastName}`,
        phone: validatedData.phone,
        email: validatedData.email || null,
        passwordHash,
        neighborhood: validatedData.neighborhood,
        status: 'active',
        role: 'user',
        phoneVerifiedAt: new Date(), // Auto-verify for now (in production, would send OTP)
      },
    });
    
    return NextResponse.json({
      success: true,
      data: {
        id: user.id,
        name: user.displayName,
        phone: user.phone,
      },
    });
  } catch (error) {
    console.error('Registration error:', error);
    
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { success: false, error: error.errors[0].message },
        { status: 400 }
      );
    }
    
    return NextResponse.json(
      { success: false, error: 'حدث خطأ أثناء إنشاء الحساب' },
      { status: 500 }
    );
  }
}
