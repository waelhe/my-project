import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { db } from '@/lib/db';

// جلب التقارير (للمسؤولين)
export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession();
    
    if (!session?.user?.email) {
      return NextResponse.json({ error: 'غير مصرح' }, { status: 401 });
    }

    const user = await db.user.findUnique({
      where: { email: session.user.email },
    });

    if (!user || user.role !== 'admin') {
      return NextResponse.json({ error: 'غير مصرح' }, { status: 403 });
    }

    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '20');
    const status = searchParams.get('status');
    const type = searchParams.get('type');

    const where = {
      ...(status && { status }),
      ...(type && { reportedType: type }),
    };

    const [reports, total] = await Promise.all([
      db.report.findMany({
        where,
        include: {
          reporter: {
            select: { id: true, firstName: true, lastName: true, email: true },
          },
        },
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
      }),
      db.report.count({ where }),
    ]);

    // إحصائيات
    const stats = await db.report.groupBy({
      by: ['status'],
      _count: true,
    });

    return NextResponse.json({
      reports,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
      stats,
    });
  } catch (error) {
    console.error('Error fetching reports:', error);
    return NextResponse.json(
      { error: 'حدث خطأ أثناء جلب التقارير' },
      { status: 500 }
    );
  }
}

// إنشاء تقرير جديد
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession();
    
    if (!session?.user?.email) {
      return NextResponse.json({ error: 'غير مصرح' }, { status: 401 });
    }

    const user = await db.user.findUnique({
      where: { email: session.user.email },
    });

    if (!user) {
      return NextResponse.json({ error: 'المستخدم غير موجود' }, { status: 404 });
    }

    const body = await request.json();
    const { reportedType, reportedId, reason, description } = body;

    if (!reportedType || !reportedId || !reason) {
      return NextResponse.json(
        { error: 'نوع البلاغ والمعرف والسبب مطلوبون' },
        { status: 400 }
      );
    }

    // التحقق من عدم وجود بلاغ سابق من نفس المستخدم
    const existingReport = await db.report.findFirst({
      where: {
        reporterId: user.id,
        reportedType,
        reportedId,
        status: 'pending',
      },
    });

    if (existingReport) {
      return NextResponse.json(
        { error: 'لديك بلاغ سابق على هذا العنصر قيد المراجعة' },
        { status: 400 }
      );
    }

    const report = await db.report.create({
      data: {
        reporterId: user.id,
        reportedType,
        reportedId,
        reason,
        description,
      },
    });

    return NextResponse.json(report, { status: 201 });
  } catch (error) {
    console.error('Error creating report:', error);
    return NextResponse.json(
      { error: 'حدث خطأ أثناء إنشاء البلاغ' },
      { status: 500 }
    );
  }
}
