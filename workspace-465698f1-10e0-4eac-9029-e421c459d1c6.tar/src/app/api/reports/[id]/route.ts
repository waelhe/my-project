import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { db } from '@/lib/db';

// تحديث حالة البلاغ (للمسؤولين)
export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const session = await getServerSession();
    
    if (!session?.user?.email) {
      return NextResponse.json({ error: 'غير مصرح' }, { status: 401 });
    }

    const user = await db.user.findUnique({
      where: { email: session.user.email },
    });

    if (!user || user.role !== 'admin') {
      return NextResponse.json({ error: 'غير مصرح' }, { status: 403 });
    }

    const { id } = await params;
    const body = await request.json();
    const { status, action, notes } = body;

    const report = await db.report.findUnique({
      where: { id },
    });

    if (!report) {
      return NextResponse.json({ error: 'البلاغ غير موجود' }, { status: 404 });
    }

    const updatedReport = await db.report.update({
      where: { id },
      data: {
        status,
        action,
        notes,
        reviewedBy: user.id,
        reviewedAt: new Date(),
      },
    });

    // تنفيذ الإجراء إذا كان محدداً
    if (action === 'delete_item') {
      // حذف العنصر المبلغ عنه
      switch (report.reportedType) {
        case 'marketplace_item':
          await db.marketplaceItem.update({
            where: { id: report.reportedId },
            data: { status: 'deleted' },
          });
          break;
        case 'real_estate':
          await db.realEstate.update({
            where: { id: report.reportedId },
            data: { status: 'deleted' },
          });
          break;
        case 'post':
          await db.communityPost.update({
            where: { id: report.reportedId },
            data: { status: 'deleted' },
          });
          break;
        case 'listing':
          await db.directoryListing.update({
            where: { id: report.reportedId },
            data: { status: 'deleted' },
          });
          break;
      }
    }

    // إشعار المبلغ
    if (status === 'resolved') {
      await db.notification.create({
        data: {
          userId: report.reporterId,
          type: 'system',
          title: 'تم مراجعة بلاغك',
          body: `تم ${action === 'delete_item' ? 'حذف' : 'معالجة'} المحتوى المبلغ عنه`,
        },
      });
    }

    return NextResponse.json(updatedReport);
  } catch (error) {
    console.error('Error updating report:', error);
    return NextResponse.json(
      { error: 'حدث خطأ أثناء تحديث البلاغ' },
      { status: 500 }
    );
  }
}

// حذف بلاغ
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const session = await getServerSession();
    
    if (!session?.user?.email) {
      return NextResponse.json({ error: 'غير مصرح' }, { status: 401 });
    }

    const user = await db.user.findUnique({
      where: { email: session.user.email },
    });

    if (!user || user.role !== 'admin') {
      return NextResponse.json({ error: 'غير مصرح' }, { status: 403 });
    }

    const { id } = await params;

    await db.report.delete({
      where: { id },
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error deleting report:', error);
    return NextResponse.json(
      { error: 'حدث خطأ أثناء حذف البلاغ' },
      { status: 500 }
    );
  }
}
