import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET() {
  try {
    const pharmacies = await db.pharmacy.findMany({
      where: { status: 'active' },
      orderBy: { isOnDuty: 'desc' },
    });

    // If no pharmacies exist, return default data
    if (pharmacies.length === 0) {
      return NextResponse.json([
        {
          id: '1',
          name: 'صيدلية الشفاء',
          nameAr: 'صيدلية الشفاء',
          neighborhood: 'الجزيرة الأولى',
          address: 'قرب الجامع الكبير',
          phone: '0111234567',
          whatsapp: '963911234567',
          isOnDuty: true,
          workingHours: {
            open: '08:00',
            close: '23:00',
          },
        },
        {
          id: '2',
          name: 'صيدلية النور',
          nameAr: 'صيدلية النور',
          neighborhood: 'الجزيرة الثانية',
          address: 'الشارع الرئيسي',
          phone: '0112345678',
          whatsapp: '963912345678',
          isOnDuty: false,
          workingHours: {
            open: '09:00',
            close: '22:00',
          },
        },
        {
          id: '3',
          name: 'صيدلية الأمل',
          nameAr: 'صيدلية الأمل',
          neighborhood: 'الجزيرة الثالثة',
          address: 'قرب مدرسة الأمل',
          phone: '0113456789',
          whatsapp: '963913456789',
          isOnDuty: false,
          workingHours: {
            open: '08:30',
            close: '21:30',
          },
        },
        {
          id: '4',
          name: 'صيدلية الحكيم',
          nameAr: 'صيدلية الحكيم',
          neighborhood: 'شارع النخيل',
          address: 'قرب عيادة الحكيم',
          phone: '0114567890',
          whatsapp: '963914567890',
          isOnDuty: false,
          workingHours: {
            open: '09:00',
            close: '22:00',
          },
        },
      ]);
    }

    return NextResponse.json(pharmacies);
  } catch (error) {
    console.error('Error fetching pharmacies:', error);
    return NextResponse.json(
      { error: 'Failed to fetch pharmacies' },
      { status: 500 }
    );
  }
}
