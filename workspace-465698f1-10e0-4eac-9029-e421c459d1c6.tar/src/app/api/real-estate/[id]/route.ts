import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { db } from '@/lib/db';
import { z } from 'zod';

// مخطط التحديث
const updateRealEstateSchema = z.object({
  title: z.string().min(5).optional(),
  description: z.string().min(20).optional(),
  type: z.enum(['apartment', 'villa', 'land', 'shop', 'office', 'warehouse']).optional(),
  listingType: z.enum(['sale', 'rent', 'wanted']).optional(),
  price: z.number().positive().optional(),
  currency: z.string().optional(),
  isNegotiable: z.boolean().optional(),
  neighborhood: z.string().optional(),
  area: z.number().positive().optional(),
  bedrooms: z.number().int().min(0).optional(),
  bathrooms: z.number().int().min(0).optional(),
  livingRooms: z.number().int().min(0).optional(),
  balconies: z.number().int().min(0).optional(),
  floorNumber: z.number().int().optional(),
  totalFloors: z.number().int().optional(),
  buildingAge: z.number().int().min(0).optional(),
  furnishing: z.enum(['unfurnished', 'semi_furnished', 'furnished']).optional(),
  hasParking: z.boolean().optional(),
  hasElevator: z.boolean().optional(),
  hasGenerator: z.boolean().optional(),
  hasWaterTank: z.boolean().optional(),
  hasSolarHeater: z.boolean().optional(),
  hasAC: z.boolean().optional(),
  hasHeating: z.boolean().optional(),
  condition: z.enum(['excellent', 'good', 'needs_renovation', 'under_construction']).optional(),
  images: z.array(z.string()).optional(),
  contactPhone: z.string().optional(),
  whatsappNumber: z.string().optional(),
  showPhone: z.boolean().optional(),
  status: z.enum(['draft', 'active', 'rented', 'sold', 'expired']).optional(),
});

// GET - جلب عقار واحد بالتفاصيل
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;

    const realEstate = await db.realEstate.findUnique({
      where: { id },
      include: {
        owner: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            displayName: true,
            phone: true,
            neighborhood: true,
            avatar: true,
            createdAt: true,
          },
        },
      },
    });

    if (!realEstate || realEstate.deletedAt) {
      return NextResponse.json(
        { success: false, error: 'العقار غير موجود' },
        { status: 404 }
      );
    }

    // زيادة عداد المشاهدات
    await db.realEstate.update({
      where: { id },
      data: { viewCount: { increment: 1 } },
    }).catch(() => {});

    // تحويل الصور من JSON
    const images = realEstate.images ? JSON.parse(realEstate.images) : [];

    // تنسيق البيانات
    const formattedData = {
      ...realEstate,
      images,
      // ميزات العقار
      features: {
        hasParking: realEstate.hasParking,
        hasElevator: realEstate.hasElevator,
        hasGenerator: realEstate.hasGenerator,
        hasWaterTank: realEstate.hasWaterTank,
        hasSolarHeater: realEstate.hasSolarHeater,
        hasAC: realEstate.hasAC,
        hasHeating: realEstate.hasHeating,
      },
      // تفاصيل الموقع
      location: {
        neighborhood: realEstate.neighborhood,
        street: realEstate.street,
        buildingNumber: realEstate.buildingNumber,
        floor: realEstate.floor,
        coordinates: realEstate.latitude && realEstate.longitude 
          ? { lat: realEstate.latitude, lng: realEstate.longitude }
          : null,
      },
    };

    return NextResponse.json({
      success: true,
      data: formattedData,
    });
  } catch (error) {
    console.error('Error fetching real estate:', error);
    return NextResponse.json(
      { success: false, error: 'حدث خطأ في جلب البيانات' },
      { status: 500 }
    );
  }
}

// PUT - تحديث عقار
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.id) {
      return NextResponse.json(
        { success: false, error: 'يجب تسجيل الدخول أولاً' },
        { status: 401 }
      );
    }

    const { id } = await params;
    const body = await request.json();
    const validatedData = updateRealEstateSchema.parse(body);

    // التحقق من ملكية العقار
    const existingItem = await db.realEstate.findUnique({
      where: { id },
      select: { ownerId: true },
    });

    if (!existingItem) {
      return NextResponse.json(
        { success: false, error: 'العقار غير موجود' },
        { status: 404 }
      );
    }

    // فقط صاحب العقار أو المدير يمكنه التعديل
    if (existingItem.ownerId !== session.user.id && session.user.role !== 'admin') {
      return NextResponse.json(
        { success: false, error: 'غير مصرح لك بتعديل هذا العقار' },
        { status: 403 }
      );
    }

    // بناء بيانات التحديث
    const updateData: Record<string, unknown> = {};
    
    const fields = [
      'title', 'description', 'type', 'listingType', 'price', 'currency',
      'isNegotiable', 'neighborhood', 'area', 'bedrooms', 'bathrooms',
      'livingRooms', 'balconies', 'floorNumber', 'totalFloors', 'buildingAge',
      'furnishing', 'hasParking', 'hasElevator', 'hasGenerator', 'hasWaterTank',
      'hasSolarHeater', 'hasAC', 'hasHeating', 'condition', 'contactPhone',
      'whatsappNumber', 'showPhone', 'status'
    ];

    fields.forEach(field => {
      if (validatedData[field as keyof typeof validatedData] !== undefined) {
        updateData[field] = validatedData[field as keyof typeof validatedData];
      }
    });

    if (validatedData.images) {
      updateData.images = JSON.stringify(validatedData.images);
    }

    const realEstate = await db.realEstate.update({
      where: { id },
      data: updateData,
      include: {
        owner: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            phone: true,
          },
        },
      },
    });

    // تسجيل النشاط
    await db.auditLog.create({
      data: {
        userId: session.user.id,
        action: 'update_real_estate',
        entityType: 'real_estate',
        entityId: id,
        newValue: JSON.stringify(validatedData),
      },
    }).catch(() => {});

    return NextResponse.json({
      success: true,
      data: realEstate,
    });
  } catch (error) {
    console.error('Error updating real estate:', error);
    
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { success: false, error: error.errors[0].message },
        { status: 400 }
      );
    }
    
    return NextResponse.json(
      { success: false, error: 'حدث خطأ في تحديث العقار' },
      { status: 500 }
    );
  }
}

// DELETE - حذف عقار (soft delete)
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.id) {
      return NextResponse.json(
        { success: false, error: 'يجب تسجيل الدخول أولاً' },
        { status: 401 }
      );
    }

    const { id } = await params;

    // التحقق من ملكية العقار
    const existingItem = await db.realEstate.findUnique({
      where: { id },
      select: { ownerId: true },
    });

    if (!existingItem) {
      return NextResponse.json(
        { success: false, error: 'العقار غير موجود' },
        { status: 404 }
      );
    }

    // فقط صاحب العقار أو المدير يمكنه الحذف
    if (existingItem.ownerId !== session.user.id && session.user.role !== 'admin') {
      return NextResponse.json(
        { success: false, error: 'غير مصرح لك بحذف هذا العقار' },
        { status: 403 }
      );
    }

    // Soft delete
    await db.realEstate.update({
      where: { id },
      data: {
        status: 'deleted',
        deletedAt: new Date(),
      },
    });

    // تسجيل النشاط
    await db.auditLog.create({
      data: {
        userId: session.user.id,
        action: 'delete_real_estate',
        entityType: 'real_estate',
        entityId: id,
      },
    }).catch(() => {});

    return NextResponse.json({
      success: true,
      message: 'تم حذف العقار بنجاح',
    });
  } catch (error) {
    console.error('Error deleting real estate:', error);
    return NextResponse.json(
      { success: false, error: 'حدث خطأ في حذف العقار' },
      { status: 500 }
    );
  }
}
