import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { db } from '@/lib/db';
import { z } from 'zod';

// مخطط إنشاء عقار
const createRealEstateSchema = z.object({
  title: z.string().min(5, 'العنوان يجب أن يكون 5 أحرف على الأقل'),
  description: z.string().min(20, 'الوصف يجب أن يكون 20 حرف على الأقل').optional(),
  type: z.enum(['apartment', 'villa', 'land', 'shop', 'office', 'warehouse']),
  listingType: z.enum(['sale', 'rent', 'wanted']),
  price: z.number().positive('السعر يجب أن يكون رقم موجب').optional(),
  currency: z.string().default('SYP'),
  pricePerMeter: z.number().positive().optional(),
  isNegotiable: z.boolean().default(true),
  neighborhood: z.string().optional(),
  street: z.string().optional(),
  buildingNumber: z.string().optional(),
  floor: z.string().optional(),
  latitude: z.number().optional(),
  longitude: z.number().optional(),
  area: z.number().positive('المساحة يجب أن تكون رقم موجب').optional(),
  bedrooms: z.number().int().min(0).optional(),
  bathrooms: z.number().int().min(0).optional(),
  livingRooms: z.number().int().min(0).optional(),
  balconies: z.number().int().min(0).optional(),
  floorNumber: z.number().int().optional(),
  totalFloors: z.number().int().optional(),
  buildingAge: z.number().int().min(0).optional(),
  furnishing: z.enum(['unfurnished', 'semi_furnished', 'furnished']).default('unfurnished'),
  hasParking: z.boolean().default(false),
  hasElevator: z.boolean().default(false),
  hasGenerator: z.boolean().default(false),
  hasWaterTank: z.boolean().default(false),
  hasSolarHeater: z.boolean().default(false),
  hasAC: z.boolean().default(false),
  hasHeating: z.boolean().default(false),
  condition: z.enum(['excellent', 'good', 'needs_renovation', 'under_construction']).default('good'),
  images: z.array(z.string()).optional(),
  contactPhone: z.string().optional(),
  whatsappNumber: z.string().optional(),
  showPhone: z.boolean().default(true),
  availableFrom: z.string().optional(),
});

// GET - جلب جميع العقارات
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const type = searchParams.get('type');
    const listingType = searchParams.get('listingType');
    const neighborhood = searchParams.get('neighborhood');
    const minPrice = searchParams.get('minPrice');
    const maxPrice = searchParams.get('maxPrice');
    const minArea = searchParams.get('minArea');
    const maxArea = searchParams.get('maxArea');
    const bedrooms = searchParams.get('bedrooms');
    const search = searchParams.get('search');
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '20');
    const skip = (page - 1) * limit;

    // بناء شروط البحث
    const where: Record<string, unknown> = {
      status: 'active',
      deletedAt: null,
    };

    if (type) where.type = type;
    if (listingType) where.listingType = listingType;
    if (neighborhood) where.neighborhood = neighborhood;
    if (bedrooms) where.bedrooms = { gte: parseInt(bedrooms) };

    if (minPrice || maxPrice) {
      where.price = {};
      if (minPrice) (where.price as Record<string, number>).gte = parseFloat(minPrice);
      if (maxPrice) (where.price as Record<string, number>).lte = parseFloat(maxPrice);
    }

    if (minArea || maxArea) {
      where.area = {};
      if (minArea) (where.area as Record<string, number>).gte = parseFloat(minArea);
      if (maxArea) (where.area as Record<string, number>).lte = parseFloat(maxArea);
    }

    if (search) {
      where.OR = [
        { title: { contains: search } },
        { description: { contains: search } },
      ];
    }

    // جلب البيانات
    const [items, total] = await Promise.all([
      db.realEstate.findMany({
        where,
        include: {
          owner: {
            select: {
              id: true,
              firstName: true,
              lastName: true,
              phone: true,
              neighborhood: true,
            },
          },
        },
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit,
      }),
      db.realEstate.count({ where }),
    ]);

    // تحويل الصور من JSON
    const itemsWithImages = items.map(item => ({
      ...item,
      images: item.images ? JSON.parse(item.images) : [],
    }));

    return NextResponse.json({
      success: true,
      data: itemsWithImages,
      meta: {
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit),
      },
    });
  } catch (error) {
    console.error('Error fetching real estate:', error);
    return NextResponse.json(
      { success: false, error: 'حدث خطأ في جلب البيانات' },
      { status: 500 }
    );
  }
}

// POST - إنشاء عقار جديد
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.id) {
      return NextResponse.json(
        { success: false, error: 'يجب تسجيل الدخول أولاً' },
        { status: 401 }
      );
    }

    const body = await request.json();
    const validatedData = createRealEstateSchema.parse(body);

    const realEstate = await db.realEstate.create({
      data: {
        ownerId: session.user.id,
        title: validatedData.title,
        description: validatedData.description || null,
        type: validatedData.type,
        listingType: validatedData.listingType,
        price: validatedData.price || null,
        currency: validatedData.currency,
        pricePerMeter: validatedData.pricePerMeter || null,
        isNegotiable: validatedData.isNegotiable,
        neighborhood: validatedData.neighborhood || session.user.neighborhood,
        street: validatedData.street || null,
        buildingNumber: validatedData.buildingNumber || null,
        floor: validatedData.floor || null,
        latitude: validatedData.latitude || null,
        longitude: validatedData.longitude || null,
        area: validatedData.area || null,
        bedrooms: validatedData.bedrooms || null,
        bathrooms: validatedData.bathrooms || null,
        livingRooms: validatedData.livingRooms || null,
        balconies: validatedData.balconies || null,
        floorNumber: validatedData.floorNumber || null,
        totalFloors: validatedData.totalFloors || null,
        buildingAge: validatedData.buildingAge || null,
        furnishing: validatedData.furnishing,
        hasParking: validatedData.hasParking,
        hasElevator: validatedData.hasElevator,
        hasGenerator: validatedData.hasGenerator,
        hasWaterTank: validatedData.hasWaterTank,
        hasSolarHeater: validatedData.hasSolarHeater,
        hasAC: validatedData.hasAC,
        hasHeating: validatedData.hasHeating,
        condition: validatedData.condition,
        images: validatedData.images ? JSON.stringify(validatedData.images) : null,
        contactPhone: validatedData.contactPhone || session.user.phone,
        whatsappNumber: validatedData.whatsappNumber || session.user.phone,
        showPhone: validatedData.showPhone,
        availableFrom: validatedData.availableFrom ? new Date(validatedData.availableFrom) : null,
        status: 'active',
        publishedAt: new Date(),
      },
      include: {
        owner: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            phone: true,
          },
        },
      },
    });

    // تسجيل النشاط
    await db.auditLog.create({
      data: {
        userId: session.user.id,
        action: 'create_real_estate',
        entityType: 'real_estate',
        entityId: realEstate.id,
        newValue: JSON.stringify(validatedData),
      },
    }).catch(() => {});

    return NextResponse.json({
      success: true,
      data: realEstate,
    });
  } catch (error) {
    console.error('Error creating real estate:', error);
    
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { success: false, error: error.errors[0].message },
        { status: 400 }
      );
    }
    
    return NextResponse.json(
      { success: false, error: 'حدث خطأ في إنشاء الإعلان' },
      { status: 500 }
    );
  }
}
