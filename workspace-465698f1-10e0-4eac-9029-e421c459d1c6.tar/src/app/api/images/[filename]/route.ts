import { NextRequest, NextResponse } from 'next/server';
import { readFile, stat } from 'fs/promises';
import { existsSync } from 'fs';
import path from 'path';

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ filename: string }> }
) {
  try {
    const { filename } = await params;
    
    // استخراج المسار من URL
    const url = new URL(request.url);
    const pathParts = url.pathname.split('/api/images/')[1];
    
    if (!pathParts) {
      return new NextResponse('Image not found', { status: 404 });
    }

    // بناء المسار الكامل
    const filePath = path.join(process.cwd(), 'uploads', pathParts);

    // التحقق من وجود الملف
    if (!existsSync(filePath)) {
      return new NextResponse('Image not found', { status: 404 });
    }

    // قراءة الملف
    const fileBuffer = await readFile(filePath);
    
    // تحديد نوع الملف
    const ext = path.extname(filePath).toLowerCase();
    const contentType: Record<string, string> = {
      '.jpg': 'image/jpeg',
      '.jpeg': 'image/jpeg',
      '.png': 'image/png',
      '.webp': 'image/webp',
      '.gif': 'image/gif',
    };

    const fileStat = await stat(filePath);

    // إرجاع الصورة مع headers للكاش
    return new NextResponse(fileBuffer, {
      headers: {
        'Content-Type': contentType[ext] || 'application/octet-stream',
        'Content-Length': fileStat.size.toString(),
        'Cache-Control': 'public, max-age=31536000, immutable',
      },
    });
  } catch (error) {
    console.error('Error serving image:', error);
    return new NextResponse('Error loading image', { status: 500 });
  }
}
