import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET() {
  try {
    const news = await db.newsItem.findMany({
      where: {
        status: 'active',
        OR: [
          { expiresAt: null },
          { expiresAt: { gt: new Date() } },
        ],
      },
      orderBy: [
        { isBreaking: 'desc' },
        { priority: 'desc' },
        { publishedAt: 'desc' },
      ],
      take: 10,
    });

    // If no news exist, return default data
    if (news.length === 0) {
      return NextResponse.json([
        {
          id: '1',
          type: 'alert',
          title: 'انقطاع الكهرباء في الجزيرة الثالثة حتى الساعة 6 مساءً',
          isBreaking: true,
        },
        {
          id: '2',
          type: 'announcement',
          title: 'البلدية: بدء أعمال تعبيد شارع النخيل الأسبوع القادم',
          isBreaking: false,
        },
        {
          id: '3',
          type: 'event',
          title: 'معرض العائلة السورية يوم الجمعة في مجمع الضاحية',
          isBreaking: false,
        },
        {
          id: '4',
          type: 'info',
          title: 'افتتاح فرع جديد لسوق التوفير قرب الجامع الكبير',
          isBreaking: false,
        },
      ]);
    }

    return NextResponse.json(news);
  } catch (error) {
    console.error('Error fetching news:', error);
    return NextResponse.json(
      { error: 'Failed to fetch news' },
      { status: 500 }
    );
  }
}
