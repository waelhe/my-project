import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { db } from '@/lib/db';

// جلب جميع المحادثات للمستخدم
export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession();
    
    if (!session?.user?.email) {
      return NextResponse.json({ error: 'غير مصرح' }, { status: 401 });
    }

    const user = await db.user.findUnique({
      where: { email: session.user.email },
    });

    if (!user) {
      return NextResponse.json({ error: 'المستخدم غير موجود' }, { status: 404 });
    }

    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '20');

    const conversations = await db.conversation.findMany({
      where: {
        OR: [
          { participant1Id: user.id },
          { participant2Id: user.id },
        ],
        status: 'active',
      },
      include: {
        participant1: {
          select: { id: true, firstName: true, lastName: true, avatar: true },
        },
        participant2: {
          select: { id: true, firstName: true, lastName: true, avatar: true },
        },
        messages: {
          take: 1,
          orderBy: { createdAt: 'desc' },
        },
        _count: {
          select: {
            messages: {
              where: {
                senderId: { not: user.id },
                isRead: false,
              },
            },
          },
        },
      },
      orderBy: { lastMessageAt: 'desc' },
      skip: (page - 1) * limit,
      take: limit,
    });

    // تنسيق البيانات
    const formattedConversations = conversations.map((conv) => {
      const otherParticipant = conv.participant1Id === user.id 
        ? conv.participant2 
        : conv.participant1;
      
      return {
        id: conv.id,
        participant: otherParticipant,
        lastMessage: conv.messages[0] || null,
        unreadCount: conv._count.messages,
        itemType: conv.itemType,
        itemId: conv.itemId,
        lastMessageAt: conv.lastMessageAt,
        createdAt: conv.createdAt,
      };
    });

    // حساب إجمالي الرسائل غير المقروءة
    const totalUnread = formattedConversations.reduce(
      (sum, conv) => sum + conv.unreadCount,
      0
    );

    return NextResponse.json({
      conversations: formattedConversations,
      totalUnread,
      pagination: {
        page,
        limit,
      },
    });
  } catch (error) {
    console.error('Error fetching conversations:', error);
    return NextResponse.json(
      { error: 'حدث خطأ أثناء جلب المحادثات' },
      { status: 500 }
    );
  }
}

// إنشاء محادثة جديدة
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession();
    
    if (!session?.user?.email) {
      return NextResponse.json({ error: 'غير مصرح' }, { status: 401 });
    }

    const user = await db.user.findUnique({
      where: { email: session.user.email },
    });

    if (!user) {
      return NextResponse.json({ error: 'المستخدم غير موجود' }, { status: 404 });
    }

    const body = await request.json();
    const { participantId, itemType, itemId, initialMessage } = body;

    if (!participantId) {
      return NextResponse.json({ error: 'معرف المشارك مطلوب' }, { status: 400 });
    }

    if (participantId === user.id) {
      return NextResponse.json({ error: 'لا يمكن إنشاء محادثة مع نفسك' }, { status: 400 });
    }

    // التحقق من وجود المحادثة مسبقاً
    const existingConversation = await db.conversation.findFirst({
      where: {
        OR: [
          { participant1Id: user.id, participant2Id: participantId },
          { participant1Id: participantId, participant2Id: user.id },
        ],
        ...(itemType && itemId && { itemType, itemId }),
      },
    });

    if (existingConversation) {
      // إرجاع المحادثة الموجودة
      return NextResponse.json(existingConversation);
    }

    // إنشاء محادثة جديدة
    const conversation = await db.conversation.create({
      data: {
        participant1Id: user.id,
        participant2Id: participantId,
        itemType,
        itemId,
      },
    });

    // إضافة الرسالة الأولية إن وجدت
    if (initialMessage) {
      await db.message.create({
        data: {
          conversationId: conversation.id,
          senderId: user.id,
          content: initialMessage,
        },
      });

      await db.conversation.update({
        where: { id: conversation.id },
        data: { lastMessageAt: new Date() },
      });
    }

    return NextResponse.json(conversation, { status: 201 });
  } catch (error) {
    console.error('Error creating conversation:', error);
    return NextResponse.json(
      { error: 'حدث خطأ أثناء إنشاء المحادثة' },
      { status: 500 }
    );
  }
}
