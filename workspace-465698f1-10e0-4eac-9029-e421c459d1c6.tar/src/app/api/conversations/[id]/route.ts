import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { db } from '@/lib/db';

// جلب محادثة محددة مع الرسائل
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const session = await getServerSession();
    
    if (!session?.user?.email) {
      return NextResponse.json({ error: 'غير مصرح' }, { status: 401 });
    }

    const user = await db.user.findUnique({
      where: { email: session.user.email },
    });

    if (!user) {
      return NextResponse.json({ error: 'المستخدم غير موجود' }, { status: 404 });
    }

    const { id } = await params;
    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '50');

    const conversation = await db.conversation.findUnique({
      where: { id },
      include: {
        participant1: {
          select: { id: true, firstName: true, lastName: true, avatar: true },
        },
        participant2: {
          select: { id: true, firstName: true, lastName: true, avatar: true },
        },
      },
    });

    if (!conversation) {
      return NextResponse.json({ error: 'المحادثة غير موجودة' }, { status: 404 });
    }

    // التحقق من أن المستخدم مشارك في المحادثة
    if (
      conversation.participant1Id !== user.id &&
      conversation.participant2Id !== user.id
    ) {
      return NextResponse.json({ error: 'غير مصرح' }, { status: 403 });
    }

    // جلب الرسائل
    const messages = await db.message.findMany({
      where: { conversationId: id },
      orderBy: { createdAt: 'desc' },
      skip: (page - 1) * limit,
      take: limit,
    });

    // تحديد الرسائل كمقروءة
    await db.message.updateMany({
      where: {
        conversationId: id,
        senderId: { not: user.id },
        isRead: false,
      },
      data: {
        isRead: true,
        readAt: new Date(),
      },
    });

    // تحديد المشارك الآخر
    const otherParticipant = conversation.participant1Id === user.id
      ? conversation.participant2
      : conversation.participant1;

    return NextResponse.json({
      conversation: {
        id: conversation.id,
        participant: otherParticipant,
        itemType: conversation.itemType,
        itemId: conversation.itemId,
        status: conversation.status,
        createdAt: conversation.createdAt,
      },
      messages: messages.reverse(),
      hasMore: messages.length === limit,
    });
  } catch (error) {
    console.error('Error fetching conversation:', error);
    return NextResponse.json(
      { error: 'حدث خطأ أثناء جلب المحادثة' },
      { status: 500 }
    );
  }
}

// حذف/أرشفة محادثة
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const session = await getServerSession();
    
    if (!session?.user?.email) {
      return NextResponse.json({ error: 'غير مصرح' }, { status: 401 });
    }

    const user = await db.user.findUnique({
      where: { email: session.user.email },
    });

    if (!user) {
      return NextResponse.json({ error: 'المستخدم غير موجود' }, { status: 404 });
    }

    const { id } = await params;

    const conversation = await db.conversation.findUnique({
      where: { id },
    });

    if (!conversation) {
      return NextResponse.json({ error: 'المحادثة غير موجودة' }, { status: 404 });
    }

    // التحقق من الصلاحيات
    if (
      conversation.participant1Id !== user.id &&
      conversation.participant2Id !== user.id &&
      user.role !== 'admin'
    ) {
      return NextResponse.json({ error: 'غير مصرح' }, { status: 403 });
    }

    // تحديث حالة المحادثة بدلاً من حذفها
    await db.conversation.update({
      where: { id },
      data: { status: 'deleted' },
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error deleting conversation:', error);
    return NextResponse.json(
      { error: 'حدث خطأ أثناء حذف المحادثة' },
      { status: 500 }
    );
  }
}
