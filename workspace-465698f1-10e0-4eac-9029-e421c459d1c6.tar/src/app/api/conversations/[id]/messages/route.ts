import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { db } from '@/lib/db';

// إرسال رسالة جديدة
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const session = await getServerSession();
    
    if (!session?.user?.email) {
      return NextResponse.json({ error: 'غير مصرح' }, { status: 401 });
    }

    const user = await db.user.findUnique({
      where: { email: session.user.email },
    });

    if (!user) {
      return NextResponse.json({ error: 'المستخدم غير موجود' }, { status: 404 });
    }

    const { id: conversationId } = await params;
    const body = await request.json();
    const { content, attachments } = body;

    if (!content && !attachments) {
      return NextResponse.json({ error: 'محتوى الرسالة مطلوب' }, { status: 400 });
    }

    // التحقق من المحادثة
    const conversation = await db.conversation.findUnique({
      where: { id: conversationId },
    });

    if (!conversation) {
      return NextResponse.json({ error: 'المحادثة غير موجودة' }, { status: 404 });
    }

    // التحقق من المشاركة
    if (
      conversation.participant1Id !== user.id &&
      conversation.participant2Id !== user.id
    ) {
      return NextResponse.json({ error: 'غير مصرح' }, { status: 403 });
    }

    // إنشاء الرسالة
    const message = await db.message.create({
      data: {
        conversationId,
        senderId: user.id,
        content: content || '',
        attachments: attachments ? JSON.stringify(attachments) : null,
      },
      include: {
        sender: {
          select: { id: true, firstName: true, lastName: true, avatar: true },
        },
      },
    });

    // تحديث وقت آخر رسالة في المحادثة
    await db.conversation.update({
      where: { id: conversationId },
      data: { lastMessageAt: new Date() },
    });

    // إنشاء إشعار للمستلم
    const recipientId = conversation.participant1Id === user.id
      ? conversation.participant2Id
      : conversation.participant1Id;

    await db.notification.create({
      data: {
        userId: recipientId,
        type: 'message',
        title: 'رسالة جديدة',
        body: `${user.firstName}: ${content?.substring(0, 50) || 'مرفق'}...`,
        entityType: 'conversation',
        entityId: conversationId,
      },
    });

    return NextResponse.json(message, { status: 201 });
  } catch (error) {
    console.error('Error sending message:', error);
    return NextResponse.json(
      { error: 'حدث خطأ أثناء إرسال الرسالة' },
      { status: 500 }
    );
  }
}
