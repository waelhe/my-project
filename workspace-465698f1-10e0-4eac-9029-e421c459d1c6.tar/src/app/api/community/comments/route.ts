import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { db } from '@/lib/db';
import { z } from 'zod';

// مخطط إنشاء تعليق
const createCommentSchema = z.object({
  postId: z.string().min(1),
  content: z.string().min(1, 'التعليق لا يمكن أن يكون فارغاً').max(1000),
  parentId: z.string().optional(),
  images: z.array(z.string()).optional(),
});

// GET - جلب التعليقات
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const postId = searchParams.get('postId');
    
    if (!postId) {
      return NextResponse.json(
        { success: false, error: 'يجب تحديد المنشور' },
        { status: 400 }
      );
    }

    const comments = await db.communityComment.findMany({
      where: {
        postId,
        status: 'active',
        deletedAt: null,
      },
      include: {
        author: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            displayName: true,
            avatar: true,
          },
        },
        replies: {
          where: { status: 'active' },
          include: {
            author: {
              select: {
                id: true,
                firstName: true,
                lastName: true,
                displayName: true,
                avatar: true,
              },
            },
          },
          orderBy: { createdAt: 'asc' },
        },
      },
      where: {
        parentId: null, // فقط التعليقات الرئيسية
      },
      orderBy: { createdAt: 'desc' },
    });

    // تنسيق البيانات
    const formattedComments = comments.map(comment => ({
      ...comment,
      images: comment.images ? JSON.parse(comment.images) : [],
      replies: comment.replies?.map((reply: typeof comment) => ({
        ...reply,
        images: reply.images ? JSON.parse(reply.images) : [],
      })),
    }));

    return NextResponse.json({
      success: true,
      data: formattedComments,
    });
  } catch (error) {
    console.error('Error fetching comments:', error);
    return NextResponse.json(
      { success: false, error: 'حدث خطأ في جلب التعليقات' },
      { status: 500 }
    );
  }
}

// POST - إنشاء تعليق
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.id) {
      return NextResponse.json(
        { success: false, error: 'يجب تسجيل الدخول أولاً' },
        { status: 401 }
      );
    }

    const body = await request.json();
    const validatedData = createCommentSchema.parse(body);

    // التحقق من وجود المنشور
    const post = await db.communityPost.findUnique({
      where: { id: validatedData.postId },
      select: { id: true, authorId: true },
    });

    if (!post) {
      return NextResponse.json(
        { success: false, error: 'المنشور غير موجود' },
        { status: 404 }
      );
    }

    // إنشاء التعليق
    const comment = await db.communityComment.create({
      data: {
        postId: validatedData.postId,
        authorId: session.user.id,
        content: validatedData.content,
        parentId: validatedData.parentId || null,
        images: validatedData.images ? JSON.stringify(validatedData.images) : null,
        status: 'active',
      },
      include: {
        author: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            displayName: true,
            avatar: true,
          },
        },
      },
    });

    // تحديث عداد التعليقات في المنشور
    await db.communityPost.update({
      where: { id: validatedData.postId },
      data: { commentCount: { increment: 1 } },
    }).catch(() => {});

    return NextResponse.json({
      success: true,
      data: {
        ...comment,
        images: comment.images ? JSON.parse(comment.images) : [],
      },
    });
  } catch (error) {
    console.error('Error creating comment:', error);
    
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { success: false, error: error.errors[0].message },
        { status: 400 }
      );
    }
    
    return NextResponse.json(
      { success: false, error: 'حدث خطأ في إنشاء التعليق' },
      { status: 500 }
    );
  }
}

// DELETE - حذف تعليق
export async function DELETE(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.id) {
      return NextResponse.json(
        { success: false, error: 'يجب تسجيل الدخول أولاً' },
        { status: 401 }
      );
    }

    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');

    if (!id) {
      return NextResponse.json(
        { success: false, error: 'يجب تحديد التعليق' },
        { status: 400 }
      );
    }

    // التحقق من الملكية
    const comment = await db.communityComment.findUnique({
      where: { id },
      select: { authorId: true, postId: true },
    });

    if (!comment) {
      return NextResponse.json(
        { success: false, error: 'التعليق غير موجود' },
        { status: 404 }
      );
    }

    if (comment.authorId !== session.user.id && session.user.role !== 'admin') {
      return NextResponse.json(
        { success: false, error: 'غير مصرح لك بحذف هذا التعليق' },
        { status: 403 }
      );
    }

    // Soft delete
    await db.communityComment.update({
      where: { id },
      data: {
        status: 'deleted',
        deletedAt: new Date(),
      },
    });

    // تحديث عداد التعليقات
    await db.communityPost.update({
      where: { id: comment.postId },
      data: { commentCount: { decrement: 1 } },
    }).catch(() => {});

    return NextResponse.json({
      success: true,
      message: 'تم حذف التعليق بنجاح',
    });
  } catch (error) {
    console.error('Error deleting comment:', error);
    return NextResponse.json(
      { success: false, error: 'حدث خطأ في حذف التعليق' },
      { status: 500 }
    );
  }
}
