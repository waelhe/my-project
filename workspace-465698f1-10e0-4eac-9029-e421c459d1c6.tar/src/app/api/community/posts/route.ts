import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { db } from '@/lib/db';
import { z } from 'zod';

// مخطط إنشاء منشور
const createPostSchema = z.object({
  title: z.string().min(5, 'العنوان يجب أن يكون 5 أحرف على الأقل').max(200),
  content: z.string().min(10, 'المحتوى يجب أن يكون 10 أحرف على الأقل'),
  categoryId: z.string().optional(),
  type: z.enum(['discussion', 'question', 'lost_found', 'carpool', 'recommendation', 'announcement']).default('discussion'),
  images: z.array(z.string()).optional(),
  tags: z.array(z.string()).optional(),
});

// GET - جلب المنشورات
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const category = searchParams.get('category');
    const type = searchParams.get('type');
    const neighborhood = searchParams.get('neighborhood');
    const search = searchParams.get('search');
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '10');
    const skip = (page - 1) * limit;

    // بناء شروط البحث
    const where: Record<string, unknown> = {
      status: 'active',
      deletedAt: null,
    };

    if (type) where.type = type;
    if (neighborhood) {
      where.author = { neighborhood };
    }
    if (category) where.categoryId = category;

    if (search) {
      where.OR = [
        { title: { contains: search } },
        { content: { contains: search } },
      ];
    }

    // جلب البيانات
    const [posts, total] = await Promise.all([
      db.communityPost.findMany({
        where,
        include: {
          author: {
            select: {
              id: true,
              firstName: true,
              lastName: true,
              displayName: true,
              avatar: true,
              neighborhood: true,
            },
          },
          category: {
            select: { id: true, name: true, nameAr: true, color: true },
          },
          _count: {
            select: { comments: true, likes: true },
          },
        },
        orderBy: [
          { isPinned: 'desc' },
          { isFeatured: 'desc' },
          { createdAt: 'desc' },
        ],
        skip,
        take: limit,
      }),
      db.communityPost.count({ where }),
    ]);

    // تنسيق البيانات
    const formattedPosts = posts.map(post => ({
      ...post,
      images: post.images ? JSON.parse(post.images) : [],
      tags: post.tags ? JSON.parse(post.tags) : [],
      commentCount: post._count?.comments || 0,
      likeCount: post._count?.likes || 0,
      _count: undefined,
    }));

    return NextResponse.json({
      success: true,
      data: formattedPosts,
      meta: {
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit),
      },
    });
  } catch (error) {
    console.error('Error fetching community posts:', error);
    return NextResponse.json(
      { success: false, error: 'حدث خطأ في جلب المنشورات' },
      { status: 500 }
    );
  }
}

// POST - إنشاء منشور جديد
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.id) {
      return NextResponse.json(
        { success: false, error: 'يجب تسجيل الدخول أولاً' },
        { status: 401 }
      );
    }

    const body = await request.json();
    const validatedData = createPostSchema.parse(body);

    const post = await db.communityPost.create({
      data: {
        authorId: session.user.id,
        categoryId: validatedData.categoryId || null,
        title: validatedData.title,
        content: validatedData.content,
        type: validatedData.type,
        images: validatedData.images ? JSON.stringify(validatedData.images) : null,
        tags: validatedData.tags ? JSON.stringify(validatedData.tags) : null,
        status: 'active',
      },
      include: {
        author: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            displayName: true,
            avatar: true,
            neighborhood: true,
          },
        },
      },
    });

    // تسجيل النشاط
    await db.auditLog.create({
      data: {
        userId: session.user.id,
        action: 'create_community_post',
        entityType: 'community_post',
        entityId: post.id,
        newValue: JSON.stringify(validatedData),
      },
    }).catch(() => {});

    return NextResponse.json({
      success: true,
      data: {
        ...post,
        images: post.images ? JSON.parse(post.images) : [],
        tags: post.tags ? JSON.parse(post.tags) : [],
        commentCount: 0,
        likeCount: 0,
      },
    });
  } catch (error) {
    console.error('Error creating community post:', error);
    
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { success: false, error: error.errors[0].message },
        { status: 400 }
      );
    }
    
    return NextResponse.json(
      { success: false, error: 'حدث خطأ في إنشاء المنشور' },
      { status: 500 }
    );
  }
}
