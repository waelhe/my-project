import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET() {
  try {
    const categories = await db.marketPriceCategory.findMany({
      where: { isActive: true },
      include: {
        items: {
          where: { categoryId: undefined },
        },
      },
      orderBy: { sortOrder: 'asc' },
    });

    // If no categories exist, return default data
    if (categories.length === 0) {
      return NextResponse.json([
        {
          id: 'vegetables',
          name: 'خضروات',
          nameAr: 'خضروات',
          slug: 'vegetables',
          items: [
            { name: 'طماطم', nameAr: 'طماطم', unit: 'كغ', currentPrice: 3500, previousPrice: 3000, trend: 'up' },
            { name: 'بطاطا', nameAr: 'بطاطا', unit: 'كغ', currentPrice: 2500, previousPrice: 2500, trend: 'stable' },
            { name: 'بصل', nameAr: 'بصل', unit: 'كغ', currentPrice: 2000, previousPrice: 2200, trend: 'down' },
            { name: 'خيار', nameAr: 'خيار', unit: 'كغ', currentPrice: 3000, previousPrice: 2800, trend: 'up' },
          ],
        },
        {
          id: 'fruits',
          name: 'فواكه',
          nameAr: 'فواكه',
          slug: 'fruits',
          items: [
            { name: 'تفاح', nameAr: 'تفاح', unit: 'كغ', currentPrice: 5000, previousPrice: 4500, trend: 'up' },
            { name: 'موز', nameAr: 'موز', unit: 'كغ', currentPrice: 6000, previousPrice: 6000, trend: 'stable' },
            { name: 'برتقال', nameAr: 'برتقال', unit: 'كغ', currentPrice: 3000, previousPrice: 3500, trend: 'down' },
          ],
        },
        {
          id: 'meat',
          name: 'لحوم',
          nameAr: 'لحوم',
          slug: 'meat',
          items: [
            { name: 'لحم بقري', nameAr: 'لحم بقري', unit: 'كغ', currentPrice: 85000, previousPrice: 80000, trend: 'up' },
            { name: 'لحم غنم', nameAr: 'لحم غنم', unit: 'كغ', currentPrice: 120000, previousPrice: 115000, trend: 'up' },
            { name: 'دجاج', nameAr: 'دجاج', unit: 'كغ', currentPrice: 25000, previousPrice: 24000, trend: 'up' },
          ],
        },
        {
          id: 'dairy',
          name: 'ألبان',
          nameAr: 'ألبان',
          slug: 'dairy',
          items: [
            { name: 'حليب', nameAr: 'حليب', unit: 'لتر', currentPrice: 5000, previousPrice: 4500, trend: 'up' },
            { name: 'جبنة', nameAr: 'جبنة', unit: 'كغ', currentPrice: 35000, previousPrice: 35000, trend: 'stable' },
            { name: 'لبن', nameAr: 'لبن', unit: 'كغ', currentPrice: 12000, previousPrice: 11000, trend: 'up' },
          ],
        },
      ]);
    }

    return NextResponse.json(categories);
  } catch (error) {
    console.error('Error fetching market prices:', error);
    return NextResponse.json(
      { error: 'Failed to fetch market prices' },
      { status: 500 }
    );
  }
}
