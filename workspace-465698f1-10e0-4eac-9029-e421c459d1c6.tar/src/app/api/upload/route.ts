import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { writeFile, mkdir } from 'fs/promises';
import { existsSync } from 'fs';
import path from 'path';
import { v4 as uuidv4 } from 'uuid';

// أنواع الملفات المسموحة
const ALLOWED_TYPES = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
const MAX_SIZE = 5 * 1024 * 1024; // 5MB

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.id) {
      return NextResponse.json(
        { success: false, error: 'يجب تسجيل الدخول أولاً' },
        { status: 401 }
      );
    }

    const formData = await request.formData();
    const file = formData.get('file') as File;
    const folder = formData.get('folder') as string || 'general';

    if (!file) {
      return NextResponse.json(
        { success: false, error: 'لم يتم اختيار ملف' },
        { status: 400 }
      );
    }

    // التحقق من نوع الملف
    if (!ALLOWED_TYPES.includes(file.type)) {
      return NextResponse.json(
        { success: false, error: 'نوع الملف غير مسموح. الأنواع المسموحة: JPEG, PNG, WebP, GIF' },
        { status: 400 }
      );
    }

    // التحقق من حجم الملف
    if (file.size > MAX_SIZE) {
      return NextResponse.json(
        { success: false, error: 'حجم الملف كبير جداً. الحد الأقصى 5MB' },
        { status: 400 }
      );
    }

    // إنشاء اسم فريد للملف
    const ext = file.name.split('.').pop() || 'jpg';
    const fileName = `${uuidv4()}.${ext}`;
    const relativePath = `${folder}/${fileName}`;
    const uploadDir = path.join(process.cwd(), 'uploads', folder);
    const filePath = path.join(uploadDir, fileName);

    // إنشاء المجلد إذا لم يكن موجوداً
    if (!existsSync(uploadDir)) {
      await mkdir(uploadDir, { recursive: true });
    }

    // حفظ الملف
    const bytes = await file.arrayBuffer();
    const buffer = Buffer.from(bytes);
    await writeFile(filePath, buffer);

    // إرجاع رابط الصورة
    const imageUrl = `/api/images/${relativePath}`;

    return NextResponse.json({
      success: true,
      data: {
        url: imageUrl,
        fileName,
        size: file.size,
        type: file.type,
      },
    });
  } catch (error) {
    console.error('Error uploading file:', error);
    return NextResponse.json(
      { success: false, error: 'حدث خطأ أثناء رفع الملف' },
      { status: 500 }
    );
  }
}

// رفع عدة صور
export async function PUT(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.id) {
      return NextResponse.json(
        { success: false, error: 'يجب تسجيل الدخول أولاً' },
        { status: 401 }
      );
    }

    const formData = await request.formData();
    const files = formData.getAll('files') as File[];
    const folder = formData.get('folder') as string || 'general';

    if (!files || files.length === 0) {
      return NextResponse.json(
        { success: false, error: 'لم يتم اختيار ملفات' },
        { status: 400 }
      );
    }

    const uploadDir = path.join(process.cwd(), 'uploads', folder);
    if (!existsSync(uploadDir)) {
      await mkdir(uploadDir, { recursive: true });
    }

    const uploadedFiles: { url: string; fileName: string; size: number }[] = [];

    for (const file of files) {
      // التحقق من نوع الملف
      if (!ALLOWED_TYPES.includes(file.type)) {
        continue; // تخطي الملفات غير المسموحة
      }

      // التحقق من حجم الملف
      if (file.size > MAX_SIZE) {
        continue; // تخطي الملفات الكبيرة
      }

      const ext = file.name.split('.').pop() || 'jpg';
      const fileName = `${uuidv4()}.${ext}`;
      const filePath = path.join(uploadDir, fileName);

      const bytes = await file.arrayBuffer();
      const buffer = Buffer.from(bytes);
      await writeFile(filePath, buffer);

      uploadedFiles.push({
        url: `/api/images/${folder}/${fileName}`,
        fileName,
        size: file.size,
      });
    }

    return NextResponse.json({
      success: true,
      data: uploadedFiles,
      meta: {
        total: files.length,
        uploaded: uploadedFiles.length,
      },
    });
  } catch (error) {
    console.error('Error uploading files:', error);
    return NextResponse.json(
      { success: false, error: 'حدث خطأ أثناء رفع الملفات' },
      { status: 500 }
    );
  }
}
