import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { db } from '@/lib/db';
import { z } from 'zod';

// مخطط إنشاء تقييم
const createReviewSchema = z.object({
  listingId: z.string().min(1, 'يجب تحديد الفعالية'),
  rating: z.number().int().min(1).max(5, 'التقييم يجب أن يكون بين 1 و 5'),
  comment: z.string().max(500, 'التعليق لا يجب أن يتجاوز 500 حرف').optional(),
});

// GET - جلب التقييمات
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const listingId = searchParams.get('listingId');
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '10');
    const skip = (page - 1) * limit;

    if (!listingId) {
      return NextResponse.json(
        { success: false, error: 'يجب تحديد الفعالية' },
        { status: 400 }
      );
    }

    const [reviews, total] = await Promise.all([
      db.review.findMany({
        where: {
          listingId,
          status: 'active',
        },
        include: {
          author: {
            select: {
              id: true,
              firstName: true,
              lastName: true,
              displayName: true,
              avatar: true,
            },
          },
        },
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit,
      }),
      db.review.count({
        where: { listingId, status: 'active' },
      }),
    ]);

    // إحصائيات التقييم
    const stats = await db.review.aggregate({
      where: { listingId, status: 'active' },
      _avg: { rating: true },
      _count: { _all: true },
    });

    // توزيع التقييمات
    const distribution = await db.review.groupBy({
      by: ['rating'],
      where: { listingId, status: 'active' },
      _count: { rating: true },
    });

    const ratingDistribution = [5, 4, 3, 2, 1].map(rating => ({
      rating,
      count: distribution.find(d => d.rating === rating)?._count.rating || 0,
    }));

    return NextResponse.json({
      success: true,
      data: reviews,
      meta: {
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit),
        averageRating: stats._avg.rating || 0,
        totalReviews: stats._count._all,
        distribution: ratingDistribution,
      },
    });
  } catch (error) {
    console.error('Error fetching reviews:', error);
    return NextResponse.json(
      { success: false, error: 'حدث خطأ في جلب التقييمات' },
      { status: 500 }
    );
  }
}

// POST - إنشاء تقييم جديد
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.id) {
      return NextResponse.json(
        { success: false, error: 'يجب تسجيل الدخول أولاً' },
        { status: 401 }
      );
    }

    const body = await request.json();
    const validatedData = createReviewSchema.parse(body);

    // التحقق من وجود الفعالية
    const listing = await db.directoryListing.findUnique({
      where: { id: validatedData.listingId },
      select: { id: true },
    });

    if (!listing) {
      return NextResponse.json(
        { success: false, error: 'الفعالية غير موجودة' },
        { status: 404 }
      );
    }

    // التحقق من عدم وجود تقييم سابق
    const existingReview = await db.review.findFirst({
      where: {
        listingId: validatedData.listingId,
        authorId: session.user.id,
      },
    });

    if (existingReview) {
      return NextResponse.json(
        { success: false, error: 'لقد قمت بتقييم هذه الفعالية مسبقاً' },
        { status: 400 }
      );
    }

    // إنشاء التقييم
    const review = await db.review.create({
      data: {
        authorId: session.user.id,
        listingId: validatedData.listingId,
        rating: validatedData.rating,
        comment: validatedData.comment || null,
        status: 'active',
      },
      include: {
        author: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            displayName: true,
            avatar: true,
          },
        },
      },
    });

    // تحديث متوسط التقييم في الفعالية
    const stats = await db.review.aggregate({
      where: { listingId: validatedData.listingId, status: 'active' },
      _avg: { rating: true },
      _count: { _all: true },
    });

    await db.directoryListing.update({
      where: { id: validatedData.listingId },
      data: {
        ratingAverage: stats._avg.rating,
        ratingCount: stats._count._all,
      },
    }).catch(() => {});

    // تسجيل النشاط
    await db.auditLog.create({
      data: {
        userId: session.user.id,
        action: 'create_review',
        entityType: 'review',
        entityId: review.id,
        newValue: JSON.stringify(validatedData),
      },
    }).catch(() => {});

    return NextResponse.json({
      success: true,
      data: review,
    });
  } catch (error) {
    console.error('Error creating review:', error);
    
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { success: false, error: error.errors[0].message },
        { status: 400 }
      );
    }
    
    return NextResponse.json(
      { success: false, error: 'حدث خطأ في إنشاء التقييم' },
      { status: 500 }
    );
  }
}
