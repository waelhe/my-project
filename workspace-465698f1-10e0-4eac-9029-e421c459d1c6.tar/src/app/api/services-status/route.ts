import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET() {
  try {
    const services = await db.serviceStatus.findMany({
      orderBy: { createdAt: 'asc' },
    });

    // If no services exist, return default data
    if (services.length === 0) {
      return NextResponse.json([
        {
          id: 'electricity',
          service: 'electricity',
          nameAr: 'الكهرباء',
          status: 'partial',
          message: 'مقطوعة في الجزيرة الثالثة',
          affectedAreas: ['الجزيرة الثالثة', 'شارع النخيل'],
        },
        {
          id: 'water',
          service: 'water',
          nameAr: 'المياه',
          status: 'available',
          message: 'متوفرة في جميع المناطق',
          affectedAreas: [],
        },
        {
          id: 'internet',
          service: 'internet',
          nameAr: 'الإنترنت',
          status: 'available',
          message: 'الخدمة مستقرة',
          affectedAreas: [],
        },
        {
          id: 'fuel',
          service: 'fuel',
          nameAr: 'الوقود',
          status: 'available',
          message: 'متوفر في المحطات',
          affectedAreas: [],
        },
      ]);
    }

    return NextResponse.json(services);
  } catch (error) {
    console.error('Error fetching services status:', error);
    return NextResponse.json(
      { error: 'Failed to fetch services status' },
      { status: 500 }
    );
  }
}
