import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { db } from '@/lib/db';

// جلب إعدادات المستخدم
export async function GET() {
  try {
    const session = await getServerSession();
    
    if (!session?.user?.email) {
      return NextResponse.json({ error: 'غير مصرح' }, { status: 401 });
    }

    const user = await db.user.findUnique({
      where: { email: session.user.email },
      select: {
        id: true,
        firstName: true,
        lastName: true,
        displayName: true,
        email: true,
        phone: true,
        avatar: true,
        bio: true,
        neighborhood: true,
        preferredLanguage: true,
        notificationSettings: true,
      },
    });

    if (!user) {
      return NextResponse.json({ error: 'المستخدم غير موجود' }, { status: 404 });
    }

    // تحليل إعدادات الإشعارات
    let notificationSettings = {
      messages: true,
      favorites: true,
      comments: true,
      reviews: true,
      news: true,
      priceAlerts: true,
    };

    if (user.notificationSettings) {
      try {
        notificationSettings = JSON.parse(user.notificationSettings);
      } catch {
        // استخدام الإعدادات الافتراضية
      }
    }

    return NextResponse.json({
      ...user,
      notificationSettings,
    });
  } catch (error) {
    console.error('Error fetching settings:', error);
    return NextResponse.json(
      { error: 'حدث خطأ أثناء جلب الإعدادات' },
      { status: 500 }
    );
  }
}

// تحديث إعدادات المستخدم
export async function PATCH(request: NextRequest) {
  try {
    const session = await getServerSession();
    
    if (!session?.user?.email) {
      return NextResponse.json({ error: 'غير مصرح' }, { status: 401 });
    }

    const user = await db.user.findUnique({
      where: { email: session.user.email },
    });

    if (!user) {
      return NextResponse.json({ error: 'المستخدم غير موجود' }, { status: 404 });
    }

    const body = await request.json();
    const {
      displayName,
      bio,
      neighborhood,
      preferredLanguage,
      notificationSettings,
    } = body;

    const updateData: Record<string, unknown> = {};

    if (displayName !== undefined) updateData.displayName = displayName;
    if (bio !== undefined) updateData.bio = bio;
    if (neighborhood !== undefined) updateData.neighborhood = neighborhood;
    if (preferredLanguage !== undefined) updateData.preferredLanguage = preferredLanguage;
    if (notificationSettings !== undefined) {
      updateData.notificationSettings = JSON.stringify(notificationSettings);
    }

    const updatedUser = await db.user.update({
      where: { id: user.id },
      data: updateData,
      select: {
        id: true,
        firstName: true,
        lastName: true,
        displayName: true,
        email: true,
        phone: true,
        avatar: true,
        bio: true,
        neighborhood: true,
        preferredLanguage: true,
        notificationSettings: true,
      },
    });

    return NextResponse.json(updatedUser);
  } catch (error) {
    console.error('Error updating settings:', error);
    return NextResponse.json(
      { error: 'حدث خطأ أثناء تحديث الإعدادات' },
      { status: 500 }
    );
  }
}
