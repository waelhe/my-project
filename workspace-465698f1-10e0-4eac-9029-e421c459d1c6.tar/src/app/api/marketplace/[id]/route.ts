import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { db } from '@/lib/db';
import { z } from 'zod';

// مخطط التحديث
const updateItemSchema = z.object({
  title: z.string().min(5).optional(),
  description: z.string().min(10).optional(),
  price: z.number().positive().optional(),
  currency: z.string().optional(),
  isNegotiable: z.boolean().optional(),
  condition: z.enum(['new', 'like_new', 'good', 'fair', 'needs_repair']).optional(),
  categoryId: z.string().optional(),
  neighborhood: z.string().optional(),
  contactPhone: z.string().optional(),
  whatsappNumber: z.string().optional(),
  showPhone: z.boolean().optional(),
  images: z.array(z.string()).optional(),
  status: z.enum(['draft', 'active', 'sold', 'expired']).optional(),
});

// GET - جلب عنصر واحد بالتفاصيل
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;

    const item = await db.marketplaceItem.findUnique({
      where: { id },
      include: {
        seller: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            displayName: true,
            phone: true,
            neighborhood: true,
            avatar: true,
            createdAt: true,
          },
        },
        category: {
          select: { id: true, name: true, nameAr: true, slug: true },
        },
      },
    });

    if (!item || item.deletedAt) {
      return NextResponse.json(
        { success: false, error: 'الإعلان غير موجود' },
        { status: 404 }
      );
    }

    // زيادة عداد المشاهدات
    await db.marketplaceItem.update({
      where: { id },
      data: { viewCount: { increment: 1 } },
    }).catch(() => {});

    // تحويل الصور من JSON
    const images = item.images ? JSON.parse(item.images) : [];

    return NextResponse.json({
      success: true,
      data: {
        ...item,
        images,
      },
    });
  } catch (error) {
    console.error('Error fetching marketplace item:', error);
    return NextResponse.json(
      { success: false, error: 'حدث خطأ في جلب البيانات' },
      { status: 500 }
    );
  }
}

// PUT - تحديث عنصر
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.id) {
      return NextResponse.json(
        { success: false, error: 'يجب تسجيل الدخول أولاً' },
        { status: 401 }
      );
    }

    const { id } = await params;
    const body = await request.json();
    const validatedData = updateItemSchema.parse(body);

    // التحقق من ملكية الإعلان
    const existingItem = await db.marketplaceItem.findUnique({
      where: { id },
      select: { sellerId: true },
    });

    if (!existingItem) {
      return NextResponse.json(
        { success: false, error: 'الإعلان غير موجود' },
        { status: 404 }
      );
    }

    // فقط صاحب الإعلان أو المدير يمكنه التعديل
    if (existingItem.sellerId !== session.user.id && session.user.role !== 'admin') {
      return NextResponse.json(
        { success: false, error: 'غير مصرح لك بتعديل هذا الإعلان' },
        { status: 403 }
      );
    }

    // تحديث الإعلان
    const updateData: Record<string, unknown> = {};
    if (validatedData.title) updateData.title = validatedData.title;
    if (validatedData.description) updateData.description = validatedData.description;
    if (validatedData.price !== undefined) updateData.price = validatedData.price;
    if (validatedData.currency) updateData.currency = validatedData.currency;
    if (validatedData.isNegotiable !== undefined) updateData.isNegotiable = validatedData.isNegotiable;
    if (validatedData.condition) updateData.condition = validatedData.condition;
    if (validatedData.neighborhood) updateData.neighborhood = validatedData.neighborhood;
    if (validatedData.contactPhone) updateData.contactPhone = validatedData.contactPhone;
    if (validatedData.whatsappNumber) updateData.whatsappNumber = validatedData.whatsappNumber;
    if (validatedData.showPhone !== undefined) updateData.showPhone = validatedData.showPhone;
    if (validatedData.images) updateData.images = JSON.stringify(validatedData.images);
    if (validatedData.status) updateData.status = validatedData.status;

    const item = await db.marketplaceItem.update({
      where: { id },
      data: updateData,
      include: {
        seller: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            phone: true,
          },
        },
      },
    });

    // تسجيل النشاط
    await db.auditLog.create({
      data: {
        userId: session.user.id,
        action: 'update_marketplace_item',
        entityType: 'marketplace_item',
        entityId: id,
        newValue: JSON.stringify(validatedData),
      },
    }).catch(() => {});

    return NextResponse.json({
      success: true,
      data: item,
    });
  } catch (error) {
    console.error('Error updating marketplace item:', error);
    
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { success: false, error: error.errors[0].message },
        { status: 400 }
      );
    }
    
    return NextResponse.json(
      { success: false, error: 'حدث خطأ في تحديث الإعلان' },
      { status: 500 }
    );
  }
}

// DELETE - حذف عنصر (soft delete)
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.id) {
      return NextResponse.json(
        { success: false, error: 'يجب تسجيل الدخول أولاً' },
        { status: 401 }
      );
    }

    const { id } = await params;

    // التحقق من ملكية الإعلان
    const existingItem = await db.marketplaceItem.findUnique({
      where: { id },
      select: { sellerId: true },
    });

    if (!existingItem) {
      return NextResponse.json(
        { success: false, error: 'الإعلان غير موجود' },
        { status: 404 }
      );
    }

    // فقط صاحب الإعلان أو المدير يمكنه الحذف
    if (existingItem.sellerId !== session.user.id && session.user.role !== 'admin') {
      return NextResponse.json(
        { success: false, error: 'غير مصرح لك بحذف هذا الإعلان' },
        { status: 403 }
      );
    }

    // Soft delete
    await db.marketplaceItem.update({
      where: { id },
      data: {
        status: 'deleted',
        deletedAt: new Date(),
      },
    });

    // تسجيل النشاط
    await db.auditLog.create({
      data: {
        userId: session.user.id,
        action: 'delete_marketplace_item',
        entityType: 'marketplace_item',
        entityId: id,
      },
    }).catch(() => {});

    return NextResponse.json({
      success: true,
      message: 'تم حذف الإعلان بنجاح',
    });
  } catch (error) {
    console.error('Error deleting marketplace item:', error);
    return NextResponse.json(
      { success: false, error: 'حدث خطأ في حذف الإعلان' },
      { status: 500 }
    );
  }
}
