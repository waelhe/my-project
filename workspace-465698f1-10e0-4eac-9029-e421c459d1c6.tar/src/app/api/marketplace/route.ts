import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { db } from '@/lib/db';
import { z } from 'zod';

// مخطط التحقق من البيانات
const createItemSchema = z.object({
  title: z.string().min(5, 'العنوان يجب أن يكون 5 أحرف على الأقل'),
  description: z.string().min(10, 'الوصف يجب أن يكون 10 أحرف على الأقل').optional(),
  price: z.number().positive('السعر يجب أن يكون رقم موجب').optional(),
  currency: z.string().default('SYP'),
  isNegotiable: z.boolean().default(true),
  condition: z.enum(['new', 'like_new', 'good', 'fair', 'needs_repair']).default('good'),
  categoryId: z.string().optional(),
  neighborhood: z.string().optional(),
  contactPhone: z.string().optional(),
  whatsappNumber: z.string().optional(),
  showPhone: z.boolean().default(true),
  images: z.array(z.string()).optional(),
});

// GET - جلب جميع العناصر
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const category = searchParams.get('category');
    const neighborhood = searchParams.get('neighborhood');
    const minPrice = searchParams.get('minPrice');
    const maxPrice = searchParams.get('maxPrice');
    const condition = searchParams.get('condition');
    const search = searchParams.get('search');
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '20');
    const skip = (page - 1) * limit;

    // بناء شروط البحث
    const where: any = {
      status: 'active',
      deletedAt: null,
    };

    if (category) {
      where.category = { slug: category };
    }

    if (neighborhood) {
      where.neighborhood = neighborhood;
    }

    if (condition) {
      where.condition = condition;
    }

    if (minPrice || maxPrice) {
      where.price = {};
      if (minPrice) where.price.gte = parseFloat(minPrice);
      if (maxPrice) where.price.lte = parseFloat(maxPrice);
    }

    if (search) {
      where.OR = [
        { title: { contains: search } },
        { description: { contains: search } },
      ];
    }

    // جلب البيانات
    const [items, total] = await Promise.all([
      db.marketplaceItem.findMany({
        where,
        include: {
          seller: {
            select: {
              id: true,
              firstName: true,
              lastName: true,
              phone: true,
              neighborhood: true,
            },
          },
          category: {
            select: { id: true, name: true, nameAr: true, slug: true },
          },
        },
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit,
      }),
      db.marketplaceItem.count({ where }),
    ]);

    return NextResponse.json({
      success: true,
      data: items,
      meta: {
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit),
      },
    });
  } catch (error) {
    console.error('Error fetching marketplace items:', error);
    return NextResponse.json(
      { success: false, error: 'حدث خطأ في جلب البيانات' },
      { status: 500 }
    );
  }
}

// POST - إنشاء عنصر جديد
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.id) {
      return NextResponse.json(
        { success: false, error: 'يجب تسجيل الدخول أولاً' },
        { status: 401 }
      );
    }

    const body = await request.json();
    const validatedData = createItemSchema.parse(body);

    const item = await db.marketplaceItem.create({
      data: {
        sellerId: session.user.id,
        title: validatedData.title,
        description: validatedData.description || null,
        price: validatedData.price || null,
        currency: validatedData.currency,
        isNegotiable: validatedData.isNegotiable,
        condition: validatedData.condition,
        neighborhood: validatedData.neighborhood || session.user.neighborhood,
        contactPhone: validatedData.contactPhone || session.user.phone,
        whatsappNumber: validatedData.whatsappNumber || session.user.phone,
        showPhone: validatedData.showPhone,
        images: validatedData.images ? JSON.stringify(validatedData.images) : null,
        status: 'active',
        publishedAt: new Date(),
      },
      include: {
        seller: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            phone: true,
          },
        },
      },
    });

    // تسجيل النشاط
    await db.auditLog.create({
      data: {
        userId: session.user.id,
        action: 'create_marketplace_item',
        entityType: 'marketplace_item',
        entityId: item.id,
        newValue: JSON.stringify(validatedData),
      },
    }).catch(() => {});

    return NextResponse.json({
      success: true,
      data: item,
    });
  } catch (error) {
    console.error('Error creating marketplace item:', error);
    
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { success: false, error: error.errors[0].message },
        { status: 400 }
      );
    }
    
    return NextResponse.json(
      { success: false, error: 'حدث خطأ في إنشاء الإعلان' },
      { status: 500 }
    );
  }
}
