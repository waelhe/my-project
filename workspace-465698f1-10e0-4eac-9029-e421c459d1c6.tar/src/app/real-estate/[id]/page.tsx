'use client';

import { useState, useEffect } from 'react';
import { useParams, useRouter } from 'next/navigation';
import Link from 'next/link';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Separator } from '@/components/ui/separator';
import { Carousel, CarouselContent, CarouselItem, CarouselPrevious, CarouselNext } from '@/components/ui/carousel';
import {
  MapPin,
  Clock,
  Eye,
  Heart,
  Share2,
  Phone,
  MessageCircle,
  ChevronRight,
  Loader2,
  AlertCircle,
  User,
  Calendar,
  Bed,
  Bath,
  Maximize,
  Building2,
  Check,
  X,
  ParkingCircle,
  ArrowUpFromLine,
  Zap,
  Droplets,
  Sun,
  Wind,
  Thermometer,
} from 'lucide-react';

// أنواع العقارات
const typeLabels: Record<string, string> = {
  apartment: 'شقة',
  villa: 'فيلا',
  land: 'أرض',
  shop: 'محل تجاري',
  office: 'مكتب',
  warehouse: 'مستودع',
};

const listingTypeLabels: Record<string, { label: string; color: string }> = {
  sale: { label: 'للبيع', color: 'bg-emerald-500' },
  rent: { label: 'للإيجار', color: 'bg-blue-500' },
  wanted: { label: 'مطلوب', color: 'bg-amber-500' },
};

const conditionLabels: Record<string, string> = {
  excellent: 'ممتاز',
  good: 'جيد',
  needs_renovation: 'يحتاج ترميم',
  under_construction: 'قيد الإنشاء',
};

const furnishingLabels: Record<string, string> = {
  unfurnished: 'غير مفروش',
  semi_furnished: 'نصف مفروش',
  furnished: 'مفروش بالكامل',
};

export default function RealEstateDetailPage() {
  const params = useParams();
  const router = useRouter();
  const id = params?.id as string;

  const [property, setProperty] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    if (id) {
      fetchProperty();
    }
  }, [id]);

  const fetchProperty = async () => {
    try {
      setLoading(true);
      const response = await fetch(`/api/real-estate/${id}`);
      const data = await response.json();

      if (data.success) {
        setProperty(data.data);
      } else {
        setError(data.error || 'لم يتم العثور على العقار');
      }
    } catch (err) {
      setError('حدث خطأ في تحميل البيانات');
    } finally {
      setLoading(false);
    }
  };

  const formatPrice = (price: number, currency: string, listingType: string) => {
    if (!price) return 'السعر عند الاتصال';
    const formatted = new Intl.NumberFormat('ar-SY').format(price);
    const suffix = listingType === 'rent' ? '/شهر' : '';
    return currency === 'SYP' ? `${formatted} ل.س${suffix}` : `${formatted}${suffix}`;
  };

  const shareProperty = async () => {
    if (navigator.share) {
      await navigator.share({
        title: property.title,
        text: property.description,
        url: window.location.href,
      });
    }
  };

  const openWhatsApp = () => {
    if (property?.whatsappNumber || property?.owner?.phone) {
      const phone = property.whatsappNumber || property.owner.phone;
      const message = encodeURIComponent(`مرحباً، أنا مهتم بالعقار: ${property.title}`);
      window.open(`https://wa.me/${phone}?text=${message}`, '_blank');
    }
  };

  const callPhone = () => {
    if (property?.contactPhone || property?.owner?.phone) {
      window.location.href = `tel:${property.contactPhone || property.owner.phone}`;
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (error || !property) {
    return (
      <div className="container px-4 py-12">
        <Card className="max-w-md mx-auto">
          <CardContent className="p-6 text-center">
            <AlertCircle className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
            <h2 className="text-xl font-bold mb-2">العقار غير موجود</h2>
            <p className="text-muted-foreground mb-4">{error || 'قد يكون العقار قد حُذف أو غير متاح'}</p>
            <Button onClick={() => router.push('/real-estate')}>
              العودة للعقارات
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const images = property.images || [];
  const listingType = listingTypeLabels[property.listingType] || listingTypeLabels.sale;

  // الميزات
  const features = [
    { icon: ParkingCircle, label: 'موقف سيارات', value: property.hasParking },
    { icon: ArrowUpFromLine, label: 'مصعد', value: property.hasElevator },
    { icon: Zap, label: 'مولد كهرباء', value: property.hasGenerator },
    { icon: Droplets, label: 'خزان مياه', value: property.hasWaterTank },
    { icon: Sun, label: 'سخان شمسي', value: property.hasSolarHeater },
    { icon: Wind, label: 'تكييف', value: property.hasAC },
    { icon: Thermometer, label: 'تدفئة', value: property.hasHeating },
  ];

  return (
    <div className="container px-4 py-6">
      {/* Breadcrumb */}
      <nav className="flex items-center gap-2 text-sm mb-6 text-muted-foreground">
        <Link href="/" className="hover:text-primary">الرئيسية</Link>
        <ChevronRight className="h-4 w-4" />
        <Link href="/real-estate" className="hover:text-primary">العقارات</Link>
        <ChevronRight className="h-4 w-4" />
        <span className="text-foreground">{property.title}</span>
      </nav>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Content */}
        <div className="lg:col-span-2 space-y-6">
          {/* Images */}
          <Card className="overflow-hidden">
            {images.length > 0 ? (
              <Carousel className="w-full">
                <CarouselContent>
                  {images.map((img: string, index: number) => (
                    <CarouselItem key={index}>
                      <div className="aspect-video bg-muted flex items-center justify-center">
                        <img
                          src={img}
                          alt={`${property.title} - صورة ${index + 1}`}
                          className="w-full h-full object-cover"
                        />
                      </div>
                    </CarouselItem>
                  ))}
                </CarouselContent>
                {images.length > 1 && (
                  <>
                    <CarouselPrevious />
                    <CarouselNext />
                  </>
                )}
              </Carousel>
            ) : (
              <div className="aspect-video bg-muted flex items-center justify-center">
                <Building2 className="h-24 w-24 opacity-20" />
              </div>
            )}
          </Card>

          {/* Property Details */}
          <Card>
            <CardHeader>
              <div className="flex items-start justify-between gap-4">
                <div>
                  <div className="flex gap-2 mb-2">
                    <Badge className={`${listingType.color} text-white`}>
                      {listingType.label}
                    </Badge>
                    <Badge variant="secondary">
                      {typeLabels[property.type]}
                    </Badge>
                  </div>
                  <CardTitle className="text-2xl">{property.title}</CardTitle>
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" size="icon" onClick={shareProperty}>
                    <Share2 className="h-4 w-4" />
                  </Button>
                  <Button variant="outline" size="icon">
                    <Heart className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {/* Price */}
              <div className="mb-6">
                {property.price ? (
                  <>
                    <p className="text-3xl font-bold text-primary">
                      {formatPrice(property.price, property.currency, property.listingType)}
                    </p>
                    {property.pricePerMeter && (
                      <p className="text-sm text-muted-foreground">
                        ({new Intl.NumberFormat('ar-SY').format(property.pricePerMeter)} ل.س/م²)
                      </p>
                    )}
                  </>
                ) : (
                  <p className="text-xl text-muted-foreground">السعر عند الاتصال</p>
                )}
                {property.isNegotiable && (
                  <p className="text-sm text-muted-foreground">قابل للتفاوض</p>
                )}
              </div>

              {/* Quick Stats */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-6">
                {property.area && (
                  <div className="flex items-center gap-2 p-3 bg-muted rounded-lg">
                    <Maximize className="h-5 w-5 text-primary" />
                    <div>
                      <p className="text-xs text-muted-foreground">المساحة</p>
                      <p className="font-medium">{property.area} م²</p>
                    </div>
                  </div>
                )}
                {property.bedrooms !== null && (
                  <div className="flex items-center gap-2 p-3 bg-muted rounded-lg">
                    <Bed className="h-5 w-5 text-primary" />
                    <div>
                      <p className="text-xs text-muted-foreground">غرف نوم</p>
                      <p className="font-medium">{property.bedrooms}</p>
                    </div>
                  </div>
                )}
                {property.bathrooms !== null && (
                  <div className="flex items-center gap-2 p-3 bg-muted rounded-lg">
                    <Bath className="h-5 w-5 text-primary" />
                    <div>
                      <p className="text-xs text-muted-foreground">حمامات</p>
                      <p className="font-medium">{property.bathrooms}</p>
                    </div>
                  </div>
                )}
                {property.floorNumber !== null && (
                  <div className="flex items-center gap-2 p-3 bg-muted rounded-lg">
                    <Building2 className="h-5 w-5 text-primary" />
                    <div>
                      <p className="text-xs text-muted-foreground">الطابق</p>
                      <p className="font-medium">{property.floorNumber} / {property.totalFloors}</p>
                    </div>
                  </div>
                )}
              </div>

              {/* Location */}
              <div className="mb-6">
                <h3 className="font-semibold mb-2">الموقع</h3>
                <p className="flex items-center gap-2 text-muted-foreground">
                  <MapPin className="h-4 w-4" />
                  {property.neighborhood}
                  {property.street && `، ${property.street}`}
                  {property.buildingNumber && `، بناية ${property.buildingNumber}`}
                </p>
              </div>

              <Separator className="my-4" />

              {/* Description */}
              <div>
                <h3 className="font-semibold mb-2">الوصف</h3>
                <p className="text-muted-foreground whitespace-pre-wrap">
                  {property.description || 'لا يوجد وصف'}
                </p>
              </div>

              {/* Features */}
              <div className="mt-6">
                <h3 className="font-semibold mb-3">المميزات</h3>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                  {features.map((feature) => {
                    const Icon = feature.icon;
                    return (
                      <div
                        key={feature.label}
                        className={`flex items-center gap-2 p-2 rounded-lg ${
                          feature.value ? 'bg-primary/10 text-primary' : 'bg-muted text-muted-foreground'
                        }`}
                      >
                        <Icon className="h-4 w-4" />
                        <span className="text-sm">{feature.label}</span>
                        {feature.value ? (
                          <Check className="h-4 w-4 mr-auto" />
                        ) : (
                          <X className="h-4 w-4 mr-auto opacity-50" />
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Additional Details */}
              <div className="mt-6 grid grid-cols-2 gap-4 text-sm">
                {property.furnishing && (
                  <div>
                    <span className="text-muted-foreground">التأثيث: </span>
                    <span className="font-medium">{furnishingLabels[property.furnishing]}</span>
                  </div>
                )}
                {property.condition && (
                  <div>
                    <span className="text-muted-foreground">الحالة: </span>
                    <span className="font-medium">{conditionLabels[property.condition]}</span>
                  </div>
                )}
                {property.buildingAge !== null && (
                  <div>
                    <span className="text-muted-foreground">عمر البناء: </span>
                    <span className="font-medium">{property.buildingAge} سنة</span>
                  </div>
                )}
                {property.availableFrom && (
                  <div>
                    <span className="text-muted-foreground">متاح من: </span>
                    <span className="font-medium">
                      {new Date(property.availableFrom).toLocaleDateString('ar-SY')}
                    </span>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Owner Info */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base">معلومات المالك</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-3 mb-4">
                <Avatar className="h-12 w-12">
                  <AvatarImage src={property.owner?.avatar} />
                  <AvatarFallback>
                    <User className="h-6 w-6" />
                  </AvatarFallback>
                </Avatar>
                <div>
                  <p className="font-medium">
                    {property.owner?.displayName || 
                     `${property.owner?.firstName || ''} ${property.owner?.lastName || ''}`}
                  </p>
                  <p className="text-sm text-muted-foreground">
                    <Calendar className="h-3 w-3 inline ml-1" />
                    عضو منذ {new Date(property.owner?.createdAt).toLocaleDateString('ar-SY', {
                      year: 'numeric',
                      month: 'short',
                    })}
                  </p>
                </div>
              </div>

              {/* Contact Buttons */}
              <div className="space-y-2">
                <Button className="w-full gap-2" onClick={openWhatsApp}>
                  <MessageCircle className="h-4 w-4" />
                  تواصل عبر واتساب
                </Button>
                {property.showPhone && (
                  <Button variant="outline" className="w-full gap-2" onClick={callPhone}>
                    <Phone className="h-4 w-4" />
                    اتصال هاتفي
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Stats */}
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground flex items-center gap-1">
                  <Eye className="h-4 w-4" />
                  المشاهدات
                </span>
                <span className="font-medium">{property.viewCount || 0}</span>
              </div>
            </CardContent>
          </Card>

          {/* Safety Tips */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                <AlertCircle className="h-4 w-4 text-amber-500" />
                نصائح السلامة
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="text-sm text-muted-foreground space-y-2">
                <li>• قم بزيارة العقار قبل الدفع</li>
                <li>• تحقق من صحة الوثائق</li>
                <li>• لا تدفع أي مبالغ مقدماً</li>
                <li>• احتفظ بنسخ من المحادثات</li>
              </ul>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
