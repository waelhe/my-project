# Qudsaya Plus (نبض الضاحية) - Architecture Document

## 1. نظرة عامة (Overview)

### 1.1 الهدف
منصة ويب خدمية، اجتماعية، وتجارية مخصصة جغرافياً لسكان منطقة "ضاحية قدسيا" في سوريا.

### 1.2 النمط المعماري
**Modular Monolith** مع فصل الاهتمامات (Separation of Concerns) بين:
- **Core Layer**: الكيانات والقواعد الأساسية
- **Application Layer**: حالات الاستخدام والخدمات
- **Infrastructure Layer**: قاعدة البيانات والواجهات الخارجية
- **Presentation Layer**: واجهة المستخدم (Next.js App Router)

---

## 2. هيكل المشروع (Project Structure)

```
src/
├── app/                          # Next.js App Router
│   ├── (auth)/                   # Auth routes group
│   │   ├── login/
│   │   ├── register/
│   │   └── verify/
│   ├── (dashboard)/              # Protected dashboard routes
│   │   ├── dashboard/
│   │   ├── favorites/
│   │   └── messages/
│   ├── admin/                    # Admin panel (role-protected)
│   ├── api/                      # API routes
│   │   ├── auth/
│   │   ├── marketplace/
│   │   ├── real-estate/
│   │   ├── directory/
│   │   ├── community/
│   │   ├── market-prices/
│   │   ├── services/
│   │   └── upload/
│   ├── community/
│   ├── directory/
│   ├── islamic/
│   ├── marketplace/
│   ├── market-prices/
│   ├── real-estate/
│   ├── layout.tsx
│   └── page.tsx
│
├── components/
│   ├── ui/                       # shadcn/ui components
│   ├── layout/                   # Layout components
│   ├── home/                     # Home page components
│   ├── marketplace/              # Marketplace components
│   ├── real-estate/              # Real estate components
│   ├── directory/                # Directory components
│   ├── community/                # Community components
│   ├── admin/                    # Admin components
│   └── shared/                   # Shared components
│
├── lib/
│   ├── db.ts                     # Prisma client
│   ├── utils.ts                  # Utility functions
│   ├── auth.ts                   # NextAuth configuration
│   ├── validations/              # Zod schemas
│   └── constants/                # App constants
│
├── hooks/                        # Custom React hooks
│
└── types/                        # TypeScript types
```

---

## 3. الكيانات الأساسية (Core Entities)

### 3.1 المستخدمون (Users)
```prisma
User {
  id, email, phone, passwordHash
  firstName, lastName, displayName, avatar
  neighborhood, status, role
  // role: user | admin | business_owner
}
```

### 3.2 سوق المستعمل (Marketplace)
```prisma
MarketplaceItem {
  id, sellerId, categoryId
  title, description, price, currency
  condition, status, images
  contactPhone, whatsappNumber
  neighborhood
}
```

### 3.3 العقارات (Real Estate)
```prisma
RealEstate {
  id, ownerId
  title, type, listingType
  price, neighborhood, area
  bedrooms, bathrooms, amenities
  images, status
}
```

### 3.4 دليل الفعاليات (Directory)
```prisma
DirectoryListing {
  id, ownerId, categoryId
  name, type, description
  phone, whatsapp, address
  workingHours, rating
}
```

### 3.5 المجتمع (Community)
```prisma
CommunityPost {
  id, authorId, categoryId
  title, content, type
  // type: discussion | question | lost_found | carpool
}
```

---

## 4. نظام المصادقة (Authentication)

### 4.1 الاستراتيجية
- **NextAuth.js v4** مع JWT strategy
- **Phone Authentication**: OTP verification
- **Google OAuth**: Optional social login
- **Protected Routes**: Middleware-based protection

### 4.2 Protected Routes
```typescript
// Middleware protection
const protectedRoutes = [
  '/dashboard',
  '/favorites',
  '/messages',
  '/admin',      // + role check
  '/api/listings', // POST, PUT, DELETE
]
```

### 4.3 Role-Based Access
```typescript
const rolePermissions = {
  user: ['read', 'create_listing', 'comment'],
  business_owner: ['read', 'create_listing', 'comment', 'verify_business'],
  admin: ['read', 'write', 'delete', 'manage_users', 'manage_content']
}
```

---

## 5. API Design

### 5.1 RESTful Endpoints

#### Marketplace
```
GET    /api/marketplace           # List items (public)
GET    /api/marketplace/:id       # Get item (public)
POST   /api/marketplace           # Create item (auth required)
PUT    /api/marketplace/:id       # Update item (owner only)
DELETE /api/marketplace/:id       # Delete item (owner/admin)
```

#### Real Estate
```
GET    /api/real-estate           # List properties
GET    /api/real-estate/:id       # Get property
POST   /api/real-estate           # Create property (auth)
PUT    /api/real-estate/:id       # Update property
DELETE /api/real-estate/:id       # Delete property
```

#### Directory
```
GET    /api/directory             # List businesses
GET    /api/directory/:id         # Get business
POST   /api/directory             # Create listing (auth)
POST   /api/directory/:id/review  # Add review (auth)
```

### 5.2 Response Format
```typescript
// Success
{ success: true, data: {...}, meta: { total, page, limit } }

// Error
{ success: false, error: { code, message, details } }
```

---

## 6. الميزات الأساسية (Core Features)

### 6.1 رفع الصور (Image Upload)
- **Storage**: Local filesystem with CDN-ready paths
- **Formats**: JPEG, PNG, WebP
- **Max Size**: 5MB per image
- **Processing**: Sharp for optimization
- **Path**: `/uploads/{entity}/{id}/{filename}`

### 6.2 WhatsApp Integration
```typescript
const whatsappLink = `https://wa.me/${phoneNumber}?text=${encodedMessage}`;
```

### 6.3 Offline Support (PWA)
- Service Worker for caching
- IndexedDB for local data
- Background sync for pending actions

---

## 7. SEO Optimization

### 7.1 Meta Tags
```typescript
export const metadata: Metadata = {
  title: 'Item Title | Qudsaya Plus',
  description: 'Item description...',
  openGraph: {
    title, description, images, type
  },
  twitter: { card: 'summary_large_image' }
}
```

### 7.2 Structured Data (JSON-LD)
```json
{
  "@context": "https://schema.org",
  "@type": "Product",
  "name": "Item name",
  "description": "...",
  "offers": {
    "@type": "Offer",
    "price": "1000000",
    "priceCurrency": "SYP"
  }
}
```

---

## 8. الأداء (Performance)

### 8.1 Caching Strategy
- **Static Pages**: ISR with revalidation
- **API Responses**: In-memory cache for hot data
- **Images**: Responsive images with next/image

### 8.2 Database Optimization
- Indexes on frequently queried fields
- Pagination for list endpoints
- Soft delete for data recovery

---

## 9. الأمان (Security)

### 9.1 Input Validation
- Zod schemas for all API inputs
- XSS protection via React
- CSRF protection via NextAuth

### 9.2 Rate Limiting
- API rate limits per IP/user
- Auth rate limiting for brute-force protection

---

## 10. Extensibility Points

### 10.1 Adding New Entity
1. Define Prisma model
2. Create API routes
3. Add UI components
4. Add navigation links

### 10.2 Adding New Feature
1. Identify affected modules
2. Create feature branch
3. Implement with tests
4. Update documentation

---

## 11. Deployment

### 11.1 Environment Variables
```env
DATABASE_URL="file:./dev.db"
NEXTAUTH_SECRET="secret"
NEXTAUTH_URL="http://localhost:3000"
```

### 11.2 Build Commands
```bash
bun run db:push    # Push schema to database
bun run build      # Build for production
bun run start      # Start production server
```

---

## 12. Future Considerations

- **Real-time messaging**: WebSocket support
- **Push notifications**: Web Push API
- **Analytics**: User behavior tracking
- **Multi-language**: Full i18n support
- **Mobile App**: React Native with shared API
