'use client'

import { NavigationProvider, useNavigation } from '@/shared/contexts/NavigationContext'
import { AuthProvider, useAuth } from '@/shared/contexts/AuthContext'
import { BookingProvider } from '@/shared/contexts/BookingContext'
import { FavoritesProvider } from '@/shared/contexts/FavoritesContext'
import { ThemeProvider } from '@/shared/contexts/ThemeContext'
import { MessagesProvider } from '@/shared/contexts/MessagesContext'
import { NotificationsProvider } from '@/shared/contexts/NotificationsContext'
import { AuthModalProvider, useAuthModal } from '@/shared/contexts/AuthModalContext'
import { Header } from '@/shared/components/Header'
import { Footer } from '@/shared/components/Footer'
import { HomeView } from '@/features/home'
import { CommunityView } from '@/features/community'
import { AccommodationsView } from '@/features/accommodations'
import { HostReviewsView } from '@/features/reviews'
import { ProfileView } from '@/features/profile'
import { AccommodationDetailsView } from '@/features/accommodation-details'
import { BookingView } from '@/features/booking'
import { HostDashboardView } from '@/features/host-dashboard'
import { MessagesView } from '@/features/messages'
import { AdminDashboardView } from '@/features/admin'
import { TransportsView } from '@/features/transports'
import { ToursView } from '@/features/tours'
import { BusinessView } from '@/features/business'
import { TourismAgent } from '@/components/tourism/TourismAgent'
import { AuthModal } from '@/components/auth/AuthModal'
import { Toaster } from 'sonner'

// Global Auth Modal controlled by AuthModalContext
function GlobalAuthModal() {
  const { isOpen, defaultRole, closeAuthModal } = useAuthModal()
  
  const handleOpenChange = (open: boolean) => {
    if (!open) {
      closeAuthModal()
    }
  }
  
  return (
    <AuthModal 
      open={isOpen} 
      onOpenChange={handleOpenChange}
      defaultRole={defaultRole}
    />
  )
}

function AppContent() {
  const { currentPage, pageParams } = useNavigation()
  const { isAuthenticated } = useAuth()

  const renderPage = () => {
    switch (currentPage) {
      // Auth Pages
      case 'profile':
        return <ProfileView />
      
      // Accommodation Pages
      case 'accommodations':
        return <AccommodationsView />
      case 'accommodation-details':
        return <AccommodationDetailsView />
      
      // Booking Pages
      case 'booking':
        return <BookingView />
      
      // Community Pages
      case 'community':
      case 'community-post':
        return <CommunityView />
      
      // Review Pages
      case 'host-reviews':
        return <HostReviewsView />
      
      // Host Dashboard
      case 'host-dashboard':
        return <HostDashboardView />
      
      // Messages
      case 'messages':
        return <MessagesView />
      
      // Admin Dashboard
      case 'admin-dashboard':
        return <AdminDashboardView />
      
      // Services
      case 'transports':
        return <TransportsView />
      case 'tours':
        return <ToursView />
      case 'business':
        return <BusinessView />
      
      // Home (default)
      case 'home':
      default:
        return <HomeView />
    }
  }

  // Pages that should not show header/footer
  const isFullPage = false

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      {!isFullPage && <Header />}
      <div className={`flex-1 ${!isFullPage ? 'pt-16' : ''}`}>
        {renderPage()}
      </div>
      {!isFullPage && <Footer />}
      <TourismAgent />
      <GlobalAuthModal />
      <Toaster position="top-center" richColors />
    </div>
  )
}

export default function DayfApp() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <FavoritesProvider>
          <BookingProvider>
            <MessagesProvider>
              <NotificationsProvider>
                <AuthModalProvider>
                  <NavigationProvider>
                    <AppContent />
                  </NavigationProvider>
                </AuthModalProvider>
              </NotificationsProvider>
            </MessagesProvider>
          </BookingProvider>
        </FavoritesProvider>
      </AuthProvider>
    </ThemeProvider>
  )
}
