// ═══════════════════════════════════════════════════════════════════════════
// Become Host API
// واجهة التسجيل كمضيف
// ═══════════════════════════════════════════════════════════════════════════

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { cookies } from 'next/headers'

/**
 * POST - Register current user as a host
 * تسجيل المستخدم الحالي كمضيف
 */
export async function POST(request: NextRequest) {
  try {
    // Get session token from cookie
    const cookieStore = await cookies()
    const sessionToken = cookieStore.get('session_token')?.value

    if (!sessionToken) {
      return NextResponse.json(
        { success: false, error: 'يرجى تسجيل الدخول أولاً' },
        { status: 401 }
      )
    }

    // Find session
    const session = await db.session.findUnique({
      where: { token: sessionToken },
      include: { user: true }
    })

    if (!session || session.expiresAt < new Date()) {
      return NextResponse.json(
        { success: false, error: 'الجلسة منتهية، يرجى تسجيل الدخول مجدداً' },
        { status: 401 }
      )
    }

    // Parse request body
    const body = await request.json()
    const { businessName, businessNameAr, businessType, phone, email, city, commercialReg, description } = body

    // Validate required fields
    if (!businessNameAr) {
      return NextResponse.json(
        { success: false, error: 'اسم النشاط التجاري بالعربية مطلوب' },
        { status: 400 }
      )
    }

    // Update user to become a host
    const updatedUser = await db.user.update({
      where: { id: session.userId },
      data: {
        role: 'HOST',
        businessName: businessName || null,
        businessNameAr: businessNameAr,
        businessType: businessType || 'individual',
        commercialReg: commercialReg || null,
        city: city || session.user.city,
        isVerified: true
      }
    })

    // Create notification for admin
    await db.notification.create({
      data: {
        type: 'host',
        titleAr: `مضيف جديد: ${businessNameAr}`,
        titleEn: `New Host: ${businessName}`,
        bodyAr: `${session.user.nameAr || session.user.name || 'مستخدم جديد'} سجل كمضيف`,
        bodyEn: `${session.user.name || 'New user'} registered as a host`,
        userId: session.userId
      }
    })

    return NextResponse.json({
      success: true,
      user: {
        id: updatedUser.id,
        phone: updatedUser.phone,
        email: updatedUser.email,
        name: updatedUser.name,
        nameAr: updatedUser.nameAr,
        avatar: updatedUser.avatar,
        role: updatedUser.role,
        status: updatedUser.status,
        isVerified: updatedUser.isVerified,
        businessName: updatedUser.businessName,
        businessNameAr: updatedUser.businessNameAr,
        businessType: updatedUser.businessType,
        city: updatedUser.city
      }
    })

  } catch (error) {
    console.error('Become host error:', error)
    return NextResponse.json(
      { success: false, error: 'حدث خطأ في التسجيل' },
      { status: 500 }
    )
  }
}
