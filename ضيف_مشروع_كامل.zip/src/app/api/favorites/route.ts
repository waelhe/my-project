import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { validateSession, getSessionToken } from '@/lib/session'

// GET /api/favorites - Get user favorites
export async function GET(request: NextRequest) {
  try {
    // Get session from cookie
    const token = getSessionToken(request)
    
    if (!token) {
      // Return empty favorites for guests
      return NextResponse.json({ favorites: [] })
    }

    const { valid, user } = await validateSession(token)
    
    if (!valid || !user) {
      return NextResponse.json({ favorites: [] })
    }

    const favorites = await db.favorite.findMany({
      where: { userId: user.id },
      include: {
        accommodation: {
          select: {
            id: true,
            titleAr: true,
            coverImage: true,
            basePrice: true,
            rating: true,
            city: {
              select: { nameAr: true }
            }
          }
        }
      },
      orderBy: { createdAt: 'desc' }
    })

    return NextResponse.json({ favorites })
  } catch (error) {
    console.error('Error fetching favorites:', error)
    return NextResponse.json(
      { error: 'حدث خطأ أثناء جلب المفضلة' },
      { status: 500 }
    )
  }
}

// POST /api/favorites - Add to favorites
export async function POST(request: NextRequest) {
  try {
    const token = getSessionToken(request)
    
    if (!token) {
      return NextResponse.json(
        { error: 'يرجى تسجيل الدخول' },
        { status: 401 }
      )
    }

    const { valid, user } = await validateSession(token)
    
    if (!valid || !user) {
      return NextResponse.json(
        { error: 'يرجى تسجيل الدخول' },
        { status: 401 }
      )
    }

    const body = await request.json()
    const { accommodationId } = body

    if (!accommodationId) {
      return NextResponse.json(
        { error: 'معرف الإقامة مطلوب' },
        { status: 400 }
      )
    }

    // Check if already favorited
    const existing = await db.favorite.findUnique({
      where: {
        userId_accommodationId: {
          userId: user.id,
          accommodationId
        }
      }
    })

    if (existing) {
      return NextResponse.json({ favorite: existing })
    }

    // Add to favorites
    const favorite = await db.favorite.create({
      data: {
        userId: user.id,
        accommodationId
      },
      include: {
        accommodation: {
          select: {
            id: true,
            titleAr: true,
            coverImage: true,
            basePrice: true,
            rating: true,
            city: {
              select: { nameAr: true }
            }
          }
        }
      }
    })

    return NextResponse.json({ favorite })
  } catch (error) {
    console.error('Error adding favorite:', error)
    return NextResponse.json(
      { error: 'حدث خطأ أثناء إضافة للمفضلة' },
      { status: 500 }
    )
  }
}

// DELETE /api/favorites - Remove from favorites
export async function DELETE(request: NextRequest) {
  try {
    const token = getSessionToken(request)
    
    if (!token) {
      return NextResponse.json(
        { error: 'يرجى تسجيل الدخول' },
        { status: 401 }
      )
    }

    const { valid, user } = await validateSession(token)
    
    if (!valid || !user) {
      return NextResponse.json(
        { error: 'يرجى تسجيل الدخول' },
        { status: 401 }
      )
    }

    const { searchParams } = new URL(request.url)
    const accommodationId = searchParams.get('accommodationId')

    if (!accommodationId) {
      return NextResponse.json(
        { error: 'معرف الإقامة مطلوب' },
        { status: 400 }
      )
    }

    await db.favorite.deleteMany({
      where: {
        userId: user.id,
        accommodationId
      }
    })

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Error removing favorite:', error)
    return NextResponse.json(
      { error: 'حدث خطأ أثناء إزالة من المفضلة' },
      { status: 500 }
    )
  }
}
