// ═══════════════════════════════════════════════════════════════════════════
// Accommodation Reviews API
// واجهة تقييمات مكان الإقامة
// ═══════════════════════════════════════════════════════════════════════════

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

interface RouteParams {
  params: Promise<{ id: string }>
}

/**
 * GET - Get reviews for an accommodation
 * الحصول على تقييمات مكان الإقامة
 */
export async function GET(request: NextRequest, { params }: RouteParams) {
  try {
    const { id } = await params
    const { searchParams } = new URL(request.url)
    const limit = parseInt(searchParams.get('limit') || '10')
    const offset = parseInt(searchParams.get('offset') || '0')

    // Check if accommodation exists
    const accommodation = await db.accommodation.findUnique({
      where: { id },
      select: { id: true }
    })

    if (!accommodation) {
      return NextResponse.json(
        { success: false, error: 'مكان الإقامة غير موجود' },
        { status: 404 }
      )
    }

    // Get reviews
    const reviews = await db.review.findMany({
      where: {
        accommodationId: id
      },
      include: {
        user: {
          select: {
            id: true,
            name: true,
            nameAr: true,
            avatar: true
          }
        }
      },
      orderBy: {
        createdAt: 'desc'
      },
      take: limit,
      skip: offset
    })

    // Get total count
    const totalCount = await db.review.count({
      where: {
        accommodationId: id
      }
    })

    // Calculate average ratings
    const ratingStats = await db.review.aggregate({
      where: {
        accommodationId: id
      },
      _avg: {
        rating: true,
        cleanliness: true,
        location: true,
        value: true,
        communication: true,
        checkIn: true
      }
    })

    return NextResponse.json({
      success: true,
      reviews,
      pagination: {
        total: totalCount,
        limit,
        offset,
        hasMore: offset + limit < totalCount
      },
      stats: {
        averageRating: ratingStats._avg.rating || 0,
        averageCleanliness: ratingStats._avg.cleanliness || 0,
        averageLocation: ratingStats._avg.location || 0,
        averageValue: ratingStats._avg.value || 0,
        averageCommunication: ratingStats._avg.communication || 0,
        averageCheckIn: ratingStats._avg.checkIn || 0
      }
    })

  } catch (error) {
    console.error('Get reviews error:', error)
    return NextResponse.json(
      { success: false, error: 'حدث خطأ في جلب التقييمات' },
      { status: 500 }
    )
  }
}
