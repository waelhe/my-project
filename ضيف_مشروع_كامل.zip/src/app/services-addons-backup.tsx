// هذا الملف يحتوي على الإضافات التي تم حذفها من page.tsx
// (النقل، السياحة، الأعمال) - يمكنك إضافتها لاحقاً عند الحاجة

// ==================== Services Section Addons ====================
// أضف هذه للـ services array في ServicesSection:
const additionalServices = [
  { icon: "Car", title: "النقل", description: "سيارات مع أو بدون سائق، باصات، وخدمات نقل آمنة", color: "bg-emerald-500", page: "transport" },
  { icon: "Compass", title: "السياحة", description: "جولات سياحية، معالم تاريخية، سياحة علاجية وسياحة حرب", color: "bg-sky-500", page: "tours" },
  { icon: "Building2", title: "الأعمال", description: "فرص استثمارية، خدمات للأعمال، وشراكات تجارية", color: "bg-violet-500", page: "business" }
]

// ==================== PageType Additions ====================
// أضف هذه للـ PageType type:
type AdditionalPageTypes = 
  | 'transport'
  | 'transport-detail'
  | 'tours'
  | 'tour-detail'
  | 'business'
  | 'business-detail'

// ==================== Transport View ====================
function TransportView() {
  const { navigate } = useNavigation()
  const [transports, setTransports] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetch('/api/transports')
      .then(res => res.json())
      .then(data => setTransports(data.transports || []))
      .catch(console.error)
      .finally(() => setLoading(false))
  }, [])

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="container mx-auto px-4">
        <h1 className="text-3xl font-bold text-gray-900 mb-6">النقل والمواصلات</h1>
        {loading ? (
          <div className="grid md:grid-cols-3 gap-6">
            {[1, 2, 3].map(i => <SkeletonCard key={i} className="h-48" />)}
          </div>
        ) : (
          <div className="grid md:grid-cols-3 gap-6">
            {transports.map((t: any) => (
              <Card key={t.id} className="cursor-pointer hover:shadow-lg" onClick={() => navigate('transport-detail', { id: t.id })}>
                <CardContent className="p-4">
                  <h3 className="font-bold">{t.titleAr}</h3>
                  <p className="text-emerald-600 font-bold mt-2">{t.basePrice?.toLocaleString()} ل.س</p>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}

function TransportDetailView() {
  return <div className="min-h-screen bg-gray-50 flex items-center justify-center"><p className="text-gray-500">تفاصيل المركبة</p></div>
}

// ==================== Tours View ====================
function ToursView() {
  const { navigate } = useNavigation()
  const [tours, setTours] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetch('/api/tours')
      .then(res => res.json())
      .then(data => setTours(data.tours || []))
      .catch(console.error)
      .finally(() => setLoading(false))
  }, [])

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="container mx-auto px-4">
        <h1 className="text-3xl font-bold text-gray-900 mb-6">الجولات السياحية</h1>
        {loading ? (
          <div className="grid md:grid-cols-3 gap-6">
            {[1, 2, 3].map(i => <SkeletonCard key={i} className="h-48" />)}
          </div>
        ) : (
          <div className="grid md:grid-cols-3 gap-6">
            {tours.map((t: any) => (
              <Card key={t.id} className="cursor-pointer hover:shadow-lg" onClick={() => navigate('tour-detail', { id: t.id })}>
                <CardContent className="p-4">
                  <h3 className="font-bold">{t.titleAr}</h3>
                  <p className="text-sky-600 font-bold mt-2">{t.basePrice?.toLocaleString()} ل.س</p>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}

function TourDetailView() {
  return <div className="min-h-screen bg-gray-50 flex items-center justify-center"><p className="text-gray-500">تفاصيل الجولة</p></div>
}

// ==================== Business View ====================
function BusinessView() {
  const { navigate } = useNavigation()
  const [listings, setListings] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetch('/api/business')
      .then(res => res.json())
      .then(data => setListings(data.listings || []))
      .catch(console.error)
      .finally(() => setLoading(false))
  }, [])

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="container mx-auto px-4">
        <h1 className="text-3xl font-bold text-gray-900 mb-6">الأعمال والاستثمار</h1>
        {loading ? (
          <div className="grid md:grid-cols-3 gap-6">
            {[1, 2, 3].map(i => <SkeletonCard key={i} className="h-48" />)}
          </div>
        ) : (
          <div className="grid md:grid-cols-3 gap-6">
            {listings.map((b: any) => (
              <Card key={b.id} className="cursor-pointer hover:shadow-lg" onClick={() => navigate('business-detail', { id: b.id })}>
                <CardContent className="p-4">
                  <h3 className="font-bold">{b.titleAr}</h3>
                  <p className="text-violet-600 font-bold mt-2">{b.price?.toLocaleString()} ل.س</p>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}

function BusinessDetailView() {
  return <div className="min-h-screen bg-gray-50 flex items-center justify-center"><p className="text-gray-500">تفاصيل فرصة الأعمال</p></div>
}

// ==================== RenderPage Cases ====================
// أضف هذه للـ renderPage switch:
/*
      case 'transport':
        return <TransportView />
      case 'transport-detail':
        return <TransportDetailView />
      case 'tours':
        return <ToursView />
      case 'tour-detail':
        return <TourDetailView />
      case 'business':
        return <BusinessView />
      case 'business-detail':
        return <BusinessDetailView />
*/
