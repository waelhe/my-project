'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Textarea } from '@/components/ui/textarea'
import { 
  LayoutDashboard, Home, Calendar, Star, CreditCard, Plus, 
  ChevronLeft, Eye, Edit, Trash2, Check, X, Clock, TrendingUp,
  Users, DollarSign, Loader2, MessageCircle, ArrowLeft, User,
  Building, Phone, Mail, FileText, Shield
} from 'lucide-react'
import { useNavigation } from '@/shared/contexts/NavigationContext'
import { useAuth } from '@/shared/contexts/AuthContext'
import { useAuthModal } from '@/shared/contexts/AuthModalContext'
import { BOOKING_STATUS_LABELS, BookingStatus } from '@/shared/types'
import { toast } from 'sonner'

// ==================== Host Registration Form ====================

function HostRegistrationForm() {
  const { navigate } = useNavigation()
  const { user, refreshUser, isAuthenticated } = useAuth()
  const { openAuthModal } = useAuthModal()
  const [loading, setLoading] = useState(false)
  const [formData, setFormData] = useState({
    businessName: '',
    businessNameAr: '',
    businessType: 'individual',
    phone: user?.phone || '',
    email: user?.email || '',
    city: '',
    commercialReg: '',
    description: ''
  })

  // Update form when user logs in
  useEffect(() => {
    if (user) {
      setFormData(prev => ({
        ...prev,
        phone: user.phone || prev.phone,
        email: user.email || prev.email
      }))
    }
  }, [user])

  // If not authenticated, redirect to home and open auth modal
  useEffect(() => {
    if (!isAuthenticated) {
      openAuthModal('HOST')
      navigate('home')
    }
  }, [isAuthenticated, openAuthModal, navigate])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    if (!formData.businessNameAr) {
      toast.error('يرجى إدخال اسم النشاط التجاري')
      return
    }

    setLoading(true)
    try {
      const res = await fetch('/api/auth/become-host', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
      })

      const data = await res.json()

      if (res.ok) {
        toast.success('تم تسجيلك كمضيف بنجاح!')
        await refreshUser()
      } else {
        toast.error(data.error || 'حدث خطأ في التسجيل')
      }
    } catch (error) {
      console.error('Host registration error:', error)
      toast.error('حدث خطأ في التسجيل')
    } finally {
      setLoading(false)
    }
  }

  // Show loading while checking auth
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-amber-500" />
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-amber-500 to-orange-500 text-white py-8">
        <div className="container mx-auto px-4">
          <Button variant="ghost" className="text-white mb-4" onClick={() => navigate('home')}>
            <ArrowLeft className="w-4 h-4 ml-2" />
            العودة للرئيسية
          </Button>
          <h1 className="text-2xl md:text-3xl font-bold">التسجيل كمضيف</h1>
          <p className="text-white/80">انضم إلى منصة ضيف وابدأ باستقبال الضيوف</p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8 max-w-2xl">
        {/* Host Registration Form */}
        <Card className="border-0 shadow-xl">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Building className="w-5 h-5 text-amber-500" />
              معلومات النشاط التجاري
            </CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Business Name */}
              <div className="space-y-2">
                <Label htmlFor="businessNameAr">اسم النشاط التجاري (بالعربية) *</Label>
                <Input
                  id="businessNameAr"
                  value={formData.businessNameAr}
                  onChange={(e) => setFormData({ ...formData, businessNameAr: e.target.value })}
                  placeholder="مثال: فندق النخيل"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="businessName">اسم النشاط التجاري (بالإنجليزية)</Label>
                <Input
                  id="businessName"
                  value={formData.businessName}
                  onChange={(e) => setFormData({ ...formData, businessName: e.target.value })}
                  placeholder="Example: Palm Hotel"
                />
              </div>

              {/* Business Type */}
              <div className="space-y-2">
                <Label htmlFor="businessType">نوع النشاط *</Label>
                <Select value={formData.businessType} onValueChange={(value) => setFormData({ ...formData, businessType: value })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="individual">فرد (شخص طبيعي)</SelectItem>
                    <SelectItem value="company">شركة / مؤسسة</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Contact Info */}
              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="phone">رقم الهاتف *</Label>
                  <div className="relative">
                    <Phone className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                    <Input
                      id="phone"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      placeholder="09xxxxxxxx"
                      className="pr-9"
                      dir="ltr"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email">البريد الإلكتروني</Label>
                  <div className="relative">
                    <Mail className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                    <Input
                      id="email"
                      type="email"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      placeholder="email@example.com"
                      className="pr-9"
                      dir="ltr"
                    />
                  </div>
                </div>
              </div>

              {/* City */}
              <div className="space-y-2">
                <Label htmlFor="city">المدينة</Label>
                <Input
                  id="city"
                  value={formData.city}
                  onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                  placeholder="مدينة النشاط التجاري"
                />
              </div>

              {/* Commercial Registration */}
              {formData.businessType === 'company' && (
                <div className="space-y-2">
                  <Label htmlFor="commercialReg">رقم السجل التجاري</Label>
                  <div className="relative">
                    <FileText className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                    <Input
                      id="commercialReg"
                      value={formData.commercialReg}
                      onChange={(e) => setFormData({ ...formData, commercialReg: e.target.value })}
                      placeholder="رقم السجل التجاري"
                      className="pr-9"
                    />
                  </div>
                </div>
              )}

              {/* Description */}
              <div className="space-y-2">
                <Label htmlFor="description">نبذة عن النشاط</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="اكتب نبذة مختصرة عن نشاطك التجاري..."
                  rows={3}
                />
              </div>

              {/* Terms */}
              <div className="p-4 bg-amber-50 rounded-lg border border-amber-200">
                <div className="flex items-start gap-3">
                  <Shield className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
                  <div className="text-sm text-gray-700">
                    <p className="font-medium mb-1">بالضغط على "تسجيل" أنت توافق على:</p>
                    <ul className="list-disc list-inside text-gray-600 space-y-1">
                      <li>شروط وأحكام منصة ضيف</li>
                      <li>سياسة الخصوصية</li>
                      <li>نظام العمولات (0% للأشهر 3 الأولى)</li>
                    </ul>
                  </div>
                </div>
              </div>

              {/* Submit Button */}
              <Button 
                type="submit" 
                className="w-full h-12 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white rounded-lg shadow-lg"
                disabled={loading}
              >
                {loading ? (
                  <Loader2 className="w-5 h-5 animate-spin" />
                ) : (
                  <>
                    <User className="w-4 h-4 ml-2" />
                    تسجيل كمضيف
                  </>
                )}
              </Button>
            </form>
          </CardContent>
        </Card>

        {/* Benefits */}
        <div className="mt-8 grid grid-cols-2 gap-4">
          <Card className="border-0 shadow-md text-center p-4">
            <div className="text-2xl font-bold text-amber-500">0%</div>
            <div className="text-sm text-gray-600">عمولة للأشهر 3 الأولى</div>
          </Card>
          <Card className="border-0 shadow-md text-center p-4">
            <div className="text-2xl font-bold text-emerald-500">24/7</div>
            <div className="text-sm text-gray-600">دعم فني مستمر</div>
          </Card>
        </div>
      </div>
    </div>
  )
}

// ==================== Host Dashboard View ====================

export function HostDashboardView() {
  const { navigate } = useNavigation()
  const { user, isHost, isAuthenticated } = useAuth()
  const [activeTab, setActiveTab] = useState('overview')
  const [loading, setLoading] = useState(true)
  const [stats, setStats] = useState({
    totalAccommodations: 0,
    activeBookings: 0,
    totalEarnings: 0,
    pendingPayouts: 0,
    totalReviews: 0,
    averageRating: 0,
    occupancyRate: 0
  })
  const [accommodations, setAccommodations] = useState<any[]>([])
  const [bookings, setBookings] = useState<any[]>([])
  const [reviews, setReviews] = useState<any[]>([])

  // Load data
  useEffect(() => {
    const loadData = async () => {
      try {
        const [statsRes, accRes, bookingsRes, reviewsRes] = await Promise.all([
          fetch('/api/host/stats'),
          fetch('/api/host/accommodations'),
          fetch('/api/host/bookings'),
          fetch('/api/host/reviews')
        ])

        if (statsRes.ok) {
          const data = await statsRes.json()
          setStats(data.stats || stats)
        }
        if (accRes.ok) {
          const data = await accRes.json()
          setAccommodations(data.accommodations || [])
        }
        if (bookingsRes.ok) {
          const data = await bookingsRes.json()
          setBookings(data.bookings || [])
        }
        if (reviewsRes.ok) {
          const data = await reviewsRes.json()
          setReviews(data.reviews || [])
        }
      } catch (error) {
        console.error('Error loading host data:', error)
      } finally {
        setLoading(false)
      }
    }

    if (isHost) {
      loadData()
    }
  }, [isHost])

  // Show registration form for non-hosts
  if (!isAuthenticated || !isHost) {
    return <HostRegistrationForm />
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-amber-500" />
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-amber-500 to-orange-500 text-white py-8">
        <div className="container mx-auto px-4">
          <Button variant="ghost" className="text-white mb-4" onClick={() => navigate('home')}>
            <ArrowLeft className="w-4 h-4 ml-2" />
            العودة للرئيسية
          </Button>
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl md:text-3xl font-bold">لوحة المضيف</h1>
              <p className="text-white/80">مرحباً {user?.nameAr || user?.name || 'مضيف'}</p>
            </div>
            <Button 
              className="bg-white text-amber-600 hover:bg-gray-100"
              onClick={() => navigate('host-register')}
            >
              <Plus className="w-4 h-4 ml-2" />
              إضافة إقامة
            </Button>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="mb-6 flex flex-wrap gap-2 bg-white p-2 rounded-lg shadow-sm">
            <TabsTrigger value="overview" className="gap-2">
              <LayoutDashboard className="w-4 h-4" />
              نظرة عامة
            </TabsTrigger>
            <TabsTrigger value="accommodations" className="gap-2">
              <Home className="w-4 h-4" />
              الإقامات
            </TabsTrigger>
            <TabsTrigger value="bookings" className="gap-2">
              <Calendar className="w-4 h-4" />
              الحجوزات
            </TabsTrigger>
            <TabsTrigger value="reviews" className="gap-2">
              <Star className="w-4 h-4" />
              التقييمات
            </TabsTrigger>
            <TabsTrigger value="earnings" className="gap-2">
              <CreditCard className="w-4 h-4" />
              المدفوعات
            </TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview">
            {/* Stats Grid */}
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
              <Card className="border-0 shadow-md">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-500">الإقامات</p>
                      <p className="text-2xl font-bold">{stats.totalAccommodations}</p>
                    </div>
                    <div className="w-12 h-12 bg-amber-100 rounded-full flex items-center justify-center">
                      <Home className="w-6 h-6 text-amber-600" />
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card className="border-0 shadow-md">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-500">الحجوزات النشطة</p>
                      <p className="text-2xl font-bold">{stats.activeBookings}</p>
                    </div>
                    <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                      <Calendar className="w-6 h-6 text-blue-600" />
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card className="border-0 shadow-md">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-500">الأرباح</p>
                      <p className="text-2xl font-bold">{stats.totalEarnings.toLocaleString()}</p>
                      <p className="text-xs text-gray-400">ل.س</p>
                    </div>
                    <div className="w-12 h-12 bg-emerald-100 rounded-full flex items-center justify-center">
                      <DollarSign className="w-6 h-6 text-emerald-600" />
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card className="border-0 shadow-md">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-500">التقييم</p>
                      <p className="text-2xl font-bold">{stats.averageRating.toFixed(1)}</p>
                      <p className="text-xs text-gray-400">من 5</p>
                    </div>
                    <div className="w-12 h-12 bg-yellow-100 rounded-full flex items-center justify-center">
                      <Star className="w-6 h-6 text-yellow-600" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Recent Bookings */}
            <Card className="border-0 shadow-md mb-6">
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle>الحجوزات الأخيرة</CardTitle>
                <Button variant="ghost" onClick={() => setActiveTab('bookings')}>عرض الكل</Button>
              </CardHeader>
              <CardContent>
                {bookings.length === 0 ? (
                  <p className="text-gray-500 text-center py-8">لا توجد حجوزات</p>
                ) : (
                  <div className="space-y-3">
                    {bookings.slice(0, 3).map((booking) => {
                      const statusInfo = BOOKING_STATUS_LABELS[booking.status as BookingStatus]
                      return (
                        <div key={booking.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                          <div className="flex items-center gap-3">
                            <Avatar className="w-10 h-10">
                              <AvatarFallback className="bg-amber-100 text-amber-700">
                                {booking.guest?.name?.charAt(0) || 'ض'}
                              </AvatarFallback>
                            </Avatar>
                            <div>
                              <p className="font-medium">{booking.guest?.name || 'ضيف'}</p>
                              <p className="text-sm text-gray-500">
                                {new Date(booking.checkIn).toLocaleDateString('ar-SY')}
                              </p>
                            </div>
                          </div>
                          <Badge className={statusInfo?.color}>{statusInfo?.label}</Badge>
                        </div>
                      )
                    })}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Accommodations Tab */}
          <TabsContent value="accommodations">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-bold">إقاماتي ({accommodations.length})</h2>
              <Button className="bg-amber-500 hover:bg-amber-600" onClick={() => navigate('host-register')}>
                <Plus className="w-4 h-4 ml-2" />
                إضافة إقامة
              </Button>
            </div>

            {accommodations.length === 0 ? (
              <Card className="border-0 shadow-md">
                <CardContent className="p-8 text-center">
                  <Home className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                  <h3 className="text-lg font-bold mb-2">لا توجد إقامات</h3>
                  <p className="text-gray-500 mb-4">أضف إقامتك الأولى وابدأ باستقبال الضيوف</p>
                  <Button className="bg-amber-500 hover:bg-amber-600" onClick={() => navigate('host-register')}>
                    إضافة إقامة
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                {accommodations.map((acc) => (
                  <Card key={acc.id} className="border-0 shadow-md overflow-hidden">
                    <div className="relative h-40 bg-gray-200">
                      <img 
                        src={acc.coverImage || '/images/default-accommodation.png'} 
                        alt={acc.titleAr}
                        className="w-full h-full object-cover"
                      />
                      <Badge 
                        className={`absolute top-2 right-2 ${acc.status === 'ACTIVE' ? 'bg-emerald-500' : 'bg-yellow-500'}`}
                      >
                        {acc.status === 'ACTIVE' ? 'نشط' : 'قيد المراجعة'}
                      </Badge>
                    </div>
                    <CardContent className="p-4">
                      <h3 className="font-bold mb-1">{acc.titleAr}</h3>
                      <p className="text-sm text-gray-500 mb-2">{acc.city?.nameAr}</p>
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-amber-600">{acc.basePrice?.toLocaleString()} ل.س/ليلة</span>
                        <div className="flex items-center gap-1">
                          <Star className="w-4 h-4 text-amber-400 fill-amber-400" />
                          <span className="text-sm">{acc.rating?.toFixed(1) || 'جديد'}</span>
                        </div>
                      </div>
                      <div className="flex gap-2 mt-3">
                        <Button variant="outline" size="sm" className="flex-1">
                          <Edit className="w-4 h-4 ml-1" />
                          تعديل
                        </Button>
                        <Button variant="outline" size="sm">
                          <Eye className="w-4 h-4" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>

          {/* Bookings Tab */}
          <TabsContent value="bookings">
            <h2 className="text-xl font-bold mb-4">الحجوزات ({bookings.length})</h2>
            {bookings.length === 0 ? (
              <Card className="border-0 shadow-md">
                <CardContent className="p-8 text-center">
                  <Calendar className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                  <h3 className="text-lg font-bold mb-2">لا توجد حجوزات</h3>
                  <p className="text-gray-500">ستظهر الحجوزات هنا عندما يحجز الضيوف إقاماتك</p>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-3">
                {bookings.map((booking) => {
                  const statusInfo = BOOKING_STATUS_LABELS[booking.status as BookingStatus]
                  return (
                    <Card key={booking.id} className="border-0 shadow-md">
                      <CardContent className="p-4">
                        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                          <div className="flex items-center gap-3">
                            <Avatar className="w-12 h-12">
                              <AvatarFallback className="bg-amber-100 text-amber-700">
                                {booking.guest?.name?.charAt(0) || 'ض'}
                              </AvatarFallback>
                            </Avatar>
                            <div>
                              <p className="font-medium">{booking.guest?.name || 'ضيف'}</p>
                              <p className="text-sm text-gray-500">{booking.accommodation?.titleAr}</p>
                            </div>
                          </div>
                          <div className="flex flex-wrap items-center gap-4 text-sm">
                            <div className="flex items-center gap-1">
                              <Clock className="w-4 h-4 text-gray-400" />
                              <span>{new Date(booking.checkIn).toLocaleDateString('ar-SY')}</span>
                              <span>→</span>
                              <span>{new Date(booking.checkOut).toLocaleDateString('ar-SY')}</span>
                            </div>
                            <span className="font-bold">{booking.totalAmount?.toLocaleString()} ل.س</span>
                            <Badge className={statusInfo?.color}>{statusInfo?.label}</Badge>
                          </div>
                          <div className="flex gap-2">
                            <Button variant="outline" size="sm">
                              <MessageCircle className="w-4 h-4 ml-1" />
                              تواصل
                            </Button>
                            {booking.status === 'PENDING' && (
                              <>
                                <Button size="sm" className="bg-emerald-500 hover:bg-emerald-600">
                                  <Check className="w-4 h-4" />
                                </Button>
                                <Button size="sm" variant="destructive">
                                  <X className="w-4 h-4" />
                                </Button>
                              </>
                            )}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  )
                })}
              </div>
            )}
          </TabsContent>

          {/* Reviews Tab */}
          <TabsContent value="reviews">
            <h2 className="text-xl font-bold mb-4">التقييمات ({reviews.length})</h2>
            {reviews.length === 0 ? (
              <Card className="border-0 shadow-md">
                <CardContent className="p-8 text-center">
                  <Star className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                  <h3 className="text-lg font-bold mb-2">لا توجد تقييمات</h3>
                  <p className="text-gray-500">سيظهر تقييمات الضيوف هنا</p>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-3">
                {reviews.map((review) => (
                  <Card key={review.id} className="border-0 shadow-md">
                    <CardContent className="p-4">
                      <div className="flex items-start gap-3">
                        <Avatar className="w-10 h-10">
                          <AvatarFallback className="bg-amber-100 text-amber-700">
                            {review.reviewer?.name?.charAt(0) || 'ض'}
                          </AvatarFallback>
                        </Avatar>
                        <div className="flex-1">
                          <div className="flex items-center justify-between">
                            <p className="font-medium">{review.reviewer?.name || 'ضيف'}</p>
                            <div className="flex items-center gap-1">
                              {[1, 2, 3, 4, 5].map((i) => (
                                <Star key={i} className={`w-4 h-4 ${i <= review.overallRating ? 'text-amber-400 fill-amber-400' : 'text-gray-300'}`} />
                              ))}
                            </div>
                          </div>
                          <p className="text-sm text-gray-500">{review.accommodation?.titleAr}</p>
                          <p className="mt-2 text-gray-700">{review.commentAr}</p>
                          {!review.hostResponse && (
                            <Button variant="outline" size="sm" className="mt-2">
                              الرد على التقييم
                            </Button>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>

          {/* Earnings Tab */}
          <TabsContent value="earnings">
            <div className="grid md:grid-cols-3 gap-4 mb-6">
              <Card className="border-0 shadow-md">
                <CardContent className="p-4 text-center">
                  <p className="text-sm text-gray-500">الأرباح الكلية</p>
                  <p className="text-3xl font-bold text-emerald-600">{stats.totalEarnings.toLocaleString()} ل.س</p>
                </CardContent>
              </Card>
              <Card className="border-0 shadow-md">
                <CardContent className="p-4 text-center">
                  <p className="text-sm text-gray-500">قيد الانتظار</p>
                  <p className="text-3xl font-bold text-amber-600">{stats.pendingPayouts.toLocaleString()} ل.س</p>
                </CardContent>
              </Card>
              <Card className="border-0 shadow-md">
                <CardContent className="p-4 text-center">
                  <p className="text-sm text-gray-500">معدل الإشغال</p>
                  <p className="text-3xl font-bold text-blue-600">{stats.occupancyRate}%</p>
                </CardContent>
              </Card>
            </div>
            <Card className="border-0 shadow-md">
              <CardHeader>
                <CardTitle>سجل المدفوعات</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-500 text-center py-8">لا توجد مدفوعات بعد</p>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
