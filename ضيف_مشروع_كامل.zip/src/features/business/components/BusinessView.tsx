'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { 
  Building2, Search, MapPin, Star, Heart, ArrowLeft, 
  TrendingUp, DollarSign, Loader2
} from 'lucide-react'
import { useNavigation } from '@/shared/contexts/NavigationContext'
import { BUSINESS_TYPE_LABELS, BusinessListing } from '@/shared/types'

// ==================== Business View ====================

export function BusinessView() {
  const [listings, setListings] = useState<BusinessListing[]>([])
  const [loading, setLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState('')
  const [selectedType, setSelectedType] = useState<string | null>(null)
  const { navigate } = useNavigation()

  useEffect(() => {
    const fetchListings = async () => {
      try {
        const response = await fetch('/api/business?limit=20')
        if (response.ok) {
          const data = await response.json()
          setListings(data.listings || [])
        }
      } catch (error) {
        console.error('Error fetching business listings:', error)
      } finally {
        setLoading(false)
      }
    }
    fetchListings()
  }, [])

  const filteredListings = listings.filter(l => {
    const matchesSearch = !searchQuery || 
      l.titleAr.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesType = !selectedType || l.type === selectedType
    return matchesSearch && matchesType
  })

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-violet-600 to-purple-600 text-white py-12">
        <div className="container mx-auto px-4">
          <Button variant="ghost" className="text-white mb-4 cursor-pointer" onClick={() => navigate('home')}>
            <ArrowLeft className="w-4 h-4 ml-2" />
            العودة للرئيسية
          </Button>
          <h1 className="text-3xl md:text-4xl font-bold mb-2">فرص الأعمال والاستثمار</h1>
          <p className="text-white/80 text-lg">اكتشف فرص استثمارية وعقارات تجارية في سوريا</p>
        </div>
      </div>

      {/* Content */}
      <div className="container mx-auto px-4 py-8">
        {/* Search & Filter */}
        <div className="flex flex-col md:flex-row gap-4 mb-8">
          <div className="flex-1 relative">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
            <Input
              placeholder="ابحث عن فرصة استثمارية..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pr-10"
            />
          </div>
          <div className="flex gap-2 flex-wrap">
            <Button
              variant={selectedType === null ? "default" : "outline"}
              onClick={() => setSelectedType(null)}
              className={selectedType === null ? "bg-violet-500 hover:bg-violet-600" : ""}
            >
              الكل
            </Button>
            {Object.entries(BUSINESS_TYPE_LABELS).slice(0, 4).map(([type, label]) => (
              <Button
                key={type}
                variant={selectedType === type ? "default" : "outline"}
                onClick={() => setSelectedType(type)}
                className={selectedType === type ? "bg-violet-500 hover:bg-violet-600" : ""}
              >
                {label}
              </Button>
            ))}
          </div>
        </div>

        <p className="text-gray-600 mb-4">عرض {filteredListings.length} فرصة</p>

        {loading ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <Card key={i} className="border-0 shadow-md">
                <div className="h-48 bg-gray-200 animate-pulse" />
                <CardContent className="p-4">
                  <div className="h-4 bg-gray-200 rounded w-3/4 mb-2 animate-pulse" />
                  <div className="h-4 bg-gray-200 rounded w-1/2 animate-pulse" />
                </CardContent>
              </Card>
            ))}
          </div>
        ) : filteredListings.length > 0 ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredListings.map((listing) => (
              <Card 
                key={listing.id} 
                className="group border-0 shadow-md hover:shadow-xl transition-all cursor-pointer overflow-hidden"
                onClick={() => navigate('business-details', { id: listing.id })}
              >
                <div className="relative h-48 overflow-hidden bg-gray-200">
                  <img 
                    src={listing.coverImage || '/images/default-business.png'} 
                    alt={listing.titleAr}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                  />
                  <Badge className="absolute top-3 right-3 bg-violet-500 text-white">
                    {BUSINESS_TYPE_LABELS[listing.type] || listing.type}
                  </Badge>
                </div>
                <CardContent className="p-4">
                  <div className="flex items-center text-sm text-gray-500 mb-2">
                    <MapPin className="w-3 h-3 ml-1" />
                    {listing.city?.nameAr || 'سوريا'}
                  </div>
                  <h3 className="font-semibold text-gray-900 mb-2 line-clamp-2">{listing.titleAr}</h3>
                  
                  {/* Investment Details */}
                  {listing.type === 'INVESTMENT_OPPORTUNITY' && (
                    <div className="flex items-center gap-4 text-sm text-gray-500 mb-3">
                      {listing.expectedReturn && (
                        <span className="flex items-center gap-1">
                          <TrendingUp className="w-3 h-3 text-emerald-500" />
                          عائد متوقع: {listing.expectedReturn}%
                        </span>
                      )}
                    </div>
                  )}
                  
                  {/* Price Range */}
                  <div className="flex items-center justify-between">
                    {listing.price ? (
                      <div>
                        <span className="font-bold text-lg text-gray-900">{listing.price.toLocaleString()}</span>
                        <span className="text-gray-500 text-sm mr-1">ل.س</span>
                      </div>
                    ) : listing.investmentMin && listing.investmentMax ? (
                      <div className="text-sm">
                        <span className="text-gray-500">الاستثمار: </span>
                        <span className="font-medium">{listing.investmentMin.toLocaleString()} - {listing.investmentMax.toLocaleString()} ل.س</span>
                      </div>
                    ) : (
                      <span className="text-gray-400 text-sm">السعر عند الطلب</span>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <Building2 className="w-12 h-12 text-gray-300 mx-auto mb-4" />
            <p className="text-gray-500">لا توجد فرص استثمارية تطابق بحثك</p>
          </div>
        )}
      </div>
    </div>
  )
}
