'use client'

import { useState, useEffect, useRef } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { 
  MessageCircle, Send, ArrowLeft, Search, MoreVertical,
  Loader2, Paperclip, Image, Phone, Calendar
} from 'lucide-react'
import { useNavigation } from '@/shared/contexts/NavigationContext'
import { useAuth } from '@/shared/contexts/AuthContext'
import { useMessages, Conversation, Message } from '@/shared/contexts/MessagesContext'
import { toast } from 'sonner'

// ==================== Messages View ====================

export function MessagesView() {
  const { navigate } = useNavigation()
  const { user } = useAuth()
  const { 
    conversations, currentConversation, messages, 
    loading, messagesLoading, loadConversation, sendMessage 
  } = useMessages()
  
  const [selectedConversation, setSelectedConversation] = useState<Conversation | null>(null)
  const [messageInput, setMessageInput] = useState('')
  const [searchQuery, setSearchQuery] = useState('')
  const messagesEndRef = useRef<HTMLDivElement>(null)

  // Filter conversations
  const filteredConversations = conversations.filter(c => {
    const otherName = c.host?.nameAr || c.host?.name || c.guest?.nameAr || c.guest?.name || ''
    return otherName.toLowerCase().includes(searchQuery.toLowerCase())
  })

  // Load conversation messages
  const handleSelectConversation = async (conv: Conversation) => {
    setSelectedConversation(conv)
    await loadConversation(conv.id)
  }

  // Send message
  const handleSendMessage = async () => {
    if (!selectedConversation || !messageInput.trim()) return

    const result = await sendMessage(selectedConversation.id, messageInput.trim())
    if (result.success) {
      setMessageInput('')
    } else {
      toast.error(result.error || 'حدث خطأ')
    }
  }

  // Scroll to bottom when new messages arrive
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  // Format time
  const formatTime = (dateString: string) => {
    const date = new Date(dateString)
    const now = new Date()
    const diff = now.getTime() - date.getTime()
    const days = Math.floor(diff / 86400000)
    
    if (days === 0) {
      return date.toLocaleTimeString('ar-SY', { hour: '2-digit', minute: '2-digit' })
    } else if (days === 1) {
      return 'أمس'
    } else if (days < 7) {
      return `منذ ${days} أيام`
    } else {
      return date.toLocaleDateString('ar-SY')
    }
  }

  // Get other user in conversation
  const getOtherUser = (conv: Conversation) => {
    return user?.id === conv.guest?.id ? conv.host : conv.guest
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Card className="max-w-md mx-4">
          <CardContent className="p-8 text-center">
            <MessageCircle className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <h2 className="text-xl font-bold mb-2">يرجى تسجيل الدخول</h2>
            <p className="text-gray-500 mb-4">تحتاج لتسجيل الدخول للوصول للرسائل</p>
            <Button onClick={() => navigate('home')} className="bg-amber-500 hover:bg-amber-600">
              العودة للرئيسية
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b sticky top-16 z-40">
        <div className="container mx-auto px-4 py-3 flex items-center gap-4">
          <Button variant="ghost" onClick={() => navigate('home')}>
            <ArrowLeft className="w-4 h-4 ml-2" />
            العودة
          </Button>
          <h1 className="text-xl font-bold">الرسائل</h1>
        </div>
      </div>

      <div className="container mx-auto px-4 py-4">
        <div className="grid md:grid-cols-3 gap-4 h-[calc(100vh-140px)]">
          {/* Conversations List */}
          <div className="md:col-span-1 bg-white rounded-lg border overflow-hidden flex flex-col">
            {/* Search */}
            <div className="p-3 border-b">
              <div className="relative">
                <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <Input
                  placeholder="بحث..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pr-9"
                />
              </div>
            </div>

            {/* Conversations */}
            <div className="flex-1 overflow-y-auto">
              {loading ? (
                <div className="flex justify-center py-8">
                  <Loader2 className="w-6 h-6 animate-spin text-amber-500" />
                </div>
              ) : filteredConversations.length === 0 ? (
                <div className="p-8 text-center text-gray-500">
                  <MessageCircle className="w-12 h-12 mx-auto mb-2 text-gray-300" />
                  <p>لا توجد محادثات</p>
                </div>
              ) : (
                filteredConversations.map((conv) => {
                  const otherUser = getOtherUser(conv)
                  const isSelected = selectedConversation?.id === conv.id
                  
                  return (
                    <div
                      key={conv.id}
                      onClick={() => handleSelectConversation(conv)}
                      className={`p-3 border-b cursor-pointer transition-colors ${
                        isSelected ? 'bg-amber-50' : 'hover:bg-gray-50'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <Avatar className="w-12 h-12">
                          <AvatarImage src={otherUser?.avatar || undefined} />
                          <AvatarFallback className="bg-amber-100 text-amber-700">
                            {otherUser?.nameAr?.charAt(0) || otherUser?.name?.charAt(0) || 'ض'}
                          </AvatarFallback>
                        </Avatar>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between">
                            <p className="font-medium truncate">
                              {otherUser?.nameAr || otherUser?.name || 'ضيف'}
                            </p>
                            <span className="text-xs text-gray-400">
                              {conv.lastMessageAt ? formatTime(conv.lastMessageAt) : ''}
                            </span>
                          </div>
                          <p className="text-sm text-gray-500 truncate">
                            {conv.lastMessage || 'بدون رسائل'}
                          </p>
                          {conv.booking && (
                            <div className="flex items-center gap-1 mt-1">
                              <Calendar className="w-3 h-3 text-gray-400" />
                              <span className="text-xs text-gray-400">
                                {conv.booking.accommodation?.titleAr}
                              </span>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  )
                })
              )}
            </div>
          </div>

          {/* Chat Area */}
          <div className="md:col-span-2 bg-white rounded-lg border overflow-hidden flex flex-col">
            {selectedConversation ? (
              <>
                {/* Chat Header */}
                <div className="p-3 border-b flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Avatar className="w-10 h-10">
                      <AvatarImage src={getOtherUser(selectedConversation)?.avatar || undefined} />
                      <AvatarFallback className="bg-amber-100 text-amber-700">
                        {getOtherUser(selectedConversation)?.nameAr?.charAt(0) || 
                         getOtherUser(selectedConversation)?.name?.charAt(0) || 'ض'}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-medium">
                        {getOtherUser(selectedConversation)?.nameAr || 
                         getOtherUser(selectedConversation)?.name || 'ضيف'}
                      </p>
                      {selectedConversation.booking && (
                        <p className="text-xs text-gray-500">
                          {selectedConversation.booking.accommodation?.titleAr}
                        </p>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button variant="ghost" size="icon">
                      <Phone className="w-4 h-4" />
                    </Button>
                    <Button variant="ghost" size="icon">
                      <MoreVertical className="w-4 h-4" />
                    </Button>
                  </div>
                </div>

                {/* Messages */}
                <div className="flex-1 overflow-y-auto p-4 space-y-4">
                  {messagesLoading ? (
                    <div className="flex justify-center py-8">
                      <Loader2 className="w-6 h-6 animate-spin text-amber-500" />
                    </div>
                  ) : (
                    messages.map((msg) => {
                      const isOwn = msg.senderId === user.id
                      
                      return (
                        <div
                          key={msg.id}
                          className={`flex ${isOwn ? 'justify-start' : 'justify-end'}`}
                        >
                          <div className={`max-w-[70%] ${isOwn ? 'order-2' : 'order-1'}`}>
                            <div className={`rounded-2xl px-4 py-2 ${
                              isOwn 
                                ? 'bg-amber-500 text-white rounded-tl-none' 
                                : 'bg-gray-100 text-gray-900 rounded-tr-none'
                            }`}>
                              <p className="whitespace-pre-wrap">{msg.content}</p>
                            </div>
                            <p className={`text-xs text-gray-400 mt-1 ${isOwn ? 'text-right' : 'text-left'}`}>
                              {formatTime(msg.createdAt)}
                            </p>
                          </div>
                          {!isOwn && (
                            <Avatar className="w-8 h-8 mx-2 order-2">
                              <AvatarImage src={msg.sender?.avatar || undefined} />
                              <AvatarFallback className="bg-gray-100 text-gray-600 text-xs">
                                {msg.sender?.nameAr?.charAt(0) || msg.sender?.name?.charAt(0) || 'ض'}
                              </AvatarFallback>
                            </Avatar>
                          )}
                        </div>
                      )
                    })
                  )}
                  <div ref={messagesEndRef} />
                </div>

                {/* Message Input */}
                <div className="p-3 border-t">
                  <div className="flex items-center gap-2">
                    <Button variant="ghost" size="icon">
                      <Paperclip className="w-4 h-4" />
                    </Button>
                    <Button variant="ghost" size="icon">
                      <Image className="w-4 h-4" />
                    </Button>
                    <Input
                      placeholder="اكتب رسالتك..."
                      value={messageInput}
                      onChange={(e) => setMessageInput(e.target.value)}
                      onKeyDown={(e) => e.key === 'Enter' && !e.shiftKey && handleSendMessage()}
                      className="flex-1"
                    />
                    <Button 
                      onClick={handleSendMessage} 
                      disabled={!messageInput.trim()}
                      className="bg-amber-500 hover:bg-amber-600"
                    >
                      <Send className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </>
            ) : (
              <div className="flex-1 flex items-center justify-center">
                <div className="text-center">
                  <MessageCircle className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                  <h3 className="text-lg font-bold mb-2">اختر محادثة</h3>
                  <p className="text-gray-500">اختر محادثة من القائمة للبدء</p>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
