'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { 
  Car, Search, MapPin, Star, Heart, ArrowLeft, Users, Clock,
  Fuel, Gauge, Loader2
} from 'lucide-react'
import { useNavigation } from '@/shared/contexts/NavigationContext'
import { useFavorites } from '@/shared/contexts/FavoritesContext'
import { TRANSPORT_TYPE_LABELS, Transport } from '@/shared/types'

// ==================== Transports View ====================

export function TransportsView() {
  const [transports, setTransports] = useState<Transport[]>([])
  const [loading, setLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState('')
  const [selectedType, setSelectedType] = useState<string | null>(null)
  const { navigate } = useNavigation()
  const { toggleFavorite, isFavorite } = useFavorites()

  useEffect(() => {
    const fetchTransports = async () => {
      try {
        const response = await fetch('/api/transports?limit=20')
        if (response.ok) {
          const data = await response.json()
          setTransports(data.transports || [])
        }
      } catch (error) {
        console.error('Error fetching transports:', error)
      } finally {
        setLoading(false)
      }
    }
    fetchTransports()
  }, [])

  const filteredTransports = transports.filter(t => {
    const matchesSearch = !searchQuery || 
      t.titleAr.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesType = !selectedType || t.type === selectedType
    return matchesSearch && matchesType
  })

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-emerald-600 to-teal-600 text-white py-12">
        <div className="container mx-auto px-4">
          <Button variant="ghost" className="text-white mb-4 cursor-pointer" onClick={() => navigate('home')}>
            <ArrowLeft className="w-4 h-4 ml-2" />
            العودة للرئيسية
          </Button>
          <h1 className="text-3xl md:text-4xl font-bold mb-2">خدمات النقل</h1>
          <p className="text-white/80 text-lg">سيارات، باصات، وخدمات نقل آمنة في جميع أنحاء سوريا</p>
        </div>
      </div>

      {/* Content */}
      <div className="container mx-auto px-4 py-8">
        {/* Search & Filter */}
        <div className="flex flex-col md:flex-row gap-4 mb-8">
          <div className="flex-1 relative">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
            <Input
              placeholder="ابحث عن خدمة نقل..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pr-10"
            />
          </div>
          <div className="flex gap-2 flex-wrap">
            <Button
              variant={selectedType === null ? "default" : "outline"}
              onClick={() => setSelectedType(null)}
              className={selectedType === null ? "bg-emerald-500 hover:bg-emerald-600" : ""}
            >
              الكل
            </Button>
            {Object.entries(TRANSPORT_TYPE_LABELS).slice(0, 4).map(([type, label]) => (
              <Button
                key={type}
                variant={selectedType === type ? "default" : "outline"}
                onClick={() => setSelectedType(type)}
                className={selectedType === type ? "bg-emerald-500 hover:bg-emerald-600" : ""}
              >
                {label}
              </Button>
            ))}
          </div>
        </div>

        {/* Results */}
        <p className="text-gray-600 mb-4">عرض {filteredTransports.length} خدمة نقل</p>

        {loading ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <Card key={i} className="border-0 shadow-md">
                <div className="h-48 bg-gray-200 animate-pulse" />
                <CardContent className="p-4">
                  <div className="h-4 bg-gray-200 rounded w-3/4 mb-2 animate-pulse" />
                  <div className="h-4 bg-gray-200 rounded w-1/2 animate-pulse" />
                </CardContent>
              </Card>
            ))}
          </div>
        ) : filteredTransports.length > 0 ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredTransports.map((transport) => (
              <Card 
                key={transport.id} 
                className="group border-0 shadow-md hover:shadow-xl transition-all cursor-pointer overflow-hidden"
                onClick={() => navigate('transport-details', { id: transport.id })}
              >
                <div className="relative h-48 overflow-hidden bg-gray-200">
                  <img 
                    src={transport.coverImage || '/images/default-transport.png'} 
                    alt={transport.titleAr}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                  />
                  <Badge className="absolute top-3 right-3 bg-emerald-500 text-white">
                    {TRANSPORT_TYPE_LABELS[transport.type] || transport.type}
                  </Badge>
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="absolute top-3 left-3 bg-white/80 hover:bg-white rounded-full h-8 w-8"
                    onClick={(e) => { e.stopPropagation(); toggleFavorite(transport.id) }}
                  >
                    <Heart className={`w-4 h-4 ${isFavorite(transport.id) ? 'fill-red-500 text-red-500' : 'text-gray-600'}`} />
                  </Button>
                </div>
                <CardContent className="p-4">
                  <div className="flex items-center text-sm text-gray-500 mb-2">
                    <MapPin className="w-3 h-3 ml-1" />
                    {transport.city?.nameAr || 'سوريا'}
                  </div>
                  <h3 className="font-semibold text-gray-900 mb-2 line-clamp-1">{transport.titleAr}</h3>
                  
                  {/* Transport Details */}
                  <div className="flex items-center gap-4 text-sm text-gray-500 mb-3">
                    {transport.brand && <span>{transport.brand} {transport.model}</span>}
                    {transport.year && <span>{transport.year}</span>}
                  </div>
                  
                  <div className="flex items-center gap-4 text-sm text-gray-500 mb-3">
                    <span className="flex items-center gap-1"><Users className="w-3 h-3" />{transport.seats} مقعد</span>
                    {transport.hasAC && <span className="flex items-center gap-1"><Fuel className="w-3 h-3" />تكييف</span>}
                    {transport.hasDriver && <span className="flex items-center gap-1"><Car className="w-3 h-3" />مع سائق</span>}
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <Star className="w-4 h-4 text-amber-400 fill-amber-400 ml-1" />
                      <span className="font-medium text-sm">{transport.rating.toFixed(1)}</span>
                    </div>
                    <div>
                      <span className="font-bold text-lg text-gray-900">{transport.basePrice.toLocaleString()}</span>
                      <span className="text-gray-500 text-sm mr-1">ل.س</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <Car className="w-12 h-12 text-gray-300 mx-auto mb-4" />
            <p className="text-gray-500">لا توجد خدمات نقل تطابق بحثك</p>
          </div>
        )}
      </div>
    </div>
  )
}
