'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Input } from '@/components/ui/input'
import { 
  LayoutDashboard, Users, Home, Flag, Settings, Shield, 
  Check, X, Search, Eye, Ban, Trash2, ArrowLeft,
  TrendingUp, DollarSign, Calendar, Loader2
} from 'lucide-react'
import { useNavigation } from '@/shared/contexts/NavigationContext'
import { useAuth } from '@/shared/contexts/AuthContext'
import { toast } from 'sonner'

// ==================== Admin Dashboard View ====================

export function AdminDashboardView() {
  const { navigate } = useNavigation()
  const { user, isAdmin } = useAuth()
  const [activeTab, setActiveTab] = useState('overview')
  const [loading, setLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState('')
  
  // Stats
  const [stats, setStats] = useState({
    totalUsers: 0,
    totalHosts: 0,
    totalAccommodations: 0,
    totalBookings: 0,
    totalRevenue: 0,
    pendingApprovals: 0
  })

  // Data
  const [users, setUsers] = useState<any[]>([])
  const [accommodations, setAccommodations] = useState<any[]>([])
  const [reports, setReports] = useState<any[]>([])

  // Load data
  useEffect(() => {
    const loadData = async () => {
      try {
        const [statsRes, usersRes, accRes] = await Promise.all([
          fetch('/api/admin/stats'),
          fetch('/api/admin/users?limit=20'),
          fetch('/api/admin/accommodations?limit=20')
        ])

        if (statsRes.ok) {
          const data = await statsRes.json()
          setStats(data.stats || stats)
        }
        if (usersRes.ok) {
          const data = await usersRes.json()
          setUsers(data.users || [])
        }
        if (accRes.ok) {
          const data = await accRes.json()
          setAccommodations(data.accommodations || [])
        }
      } catch (error) {
        console.error('Error loading admin data:', error)
      } finally {
        setLoading(false)
      }
    }

    if (isAdmin) {
      loadData()
    }
  }, [isAdmin])

  // Actions
  const handleApproveAccommodation = async (id: string) => {
    try {
      const res = await fetch(`/api/admin/accommodations/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: 'ACTIVE' })
      })
      if (res.ok) {
        toast.success('تمت الموافقة على الإقامة')
        setAccommodations(prev => 
          prev.map(a => a.id === id ? { ...a, status: 'ACTIVE' } : a)
        )
      }
    } catch (error) {
      toast.error('حدث خطأ')
    }
  }

  const handleSuspendUser = async (id: string) => {
    try {
      const res = await fetch(`/api/admin/users/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: 'SUSPENDED' })
      })
      if (res.ok) {
        toast.success('تم تعليق المستخدم')
        setUsers(prev => 
          prev.map(u => u.id === id ? { ...u, status: 'SUSPENDED' } : u)
        )
      }
    } catch (error) {
      toast.error('حدث خطأ')
    }
  }

  // Check admin access
  if (!isAdmin) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Card className="max-w-md mx-4">
          <CardContent className="p-8 text-center">
            <Shield className="w-16 h-16 text-red-300 mx-auto mb-4" />
            <h2 className="text-xl font-bold mb-2">غير مصرح لك</h2>
            <p className="text-gray-500 mb-4">ليس لديك صلاحية الوصول لهذه الصفحة</p>
            <Button onClick={() => navigate('home')} className="bg-amber-500 hover:bg-amber-600">
              العودة للرئيسية
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-amber-500" />
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-gray-900 text-white py-8">
        <div className="container mx-auto px-4">
          <Button variant="ghost" className="text-white mb-4" onClick={() => navigate('home')}>
            <ArrowLeft className="w-4 h-4 ml-2" />
            العودة للرئيسية
          </Button>
          <div className="flex items-center gap-3">
            <Shield className="w-8 h-8 text-amber-500" />
            <div>
              <h1 className="text-2xl font-bold">لوحة الإدارة</h1>
              <p className="text-gray-400">مرحباً {user?.nameAr || user?.name || 'مدير'}</p>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="mb-6 flex flex-wrap gap-2 bg-white p-2 rounded-lg shadow-sm">
            <TabsTrigger value="overview" className="gap-2">
              <LayoutDashboard className="w-4 h-4" />
              نظرة عامة
            </TabsTrigger>
            <TabsTrigger value="users" className="gap-2">
              <Users className="w-4 h-4" />
              المستخدمين
            </TabsTrigger>
            <TabsTrigger value="accommodations" className="gap-2">
              <Home className="w-4 h-4" />
              الإقامات
            </TabsTrigger>
            <TabsTrigger value="reports" className="gap-2">
              <Flag className="w-4 h-4" />
              البلاغات
            </TabsTrigger>
            <TabsTrigger value="settings" className="gap-2">
              <Settings className="w-4 h-4" />
              الإعدادات
            </TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
              <Card className="border-0 shadow-md">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-500">المستخدمين</p>
                      <p className="text-2xl font-bold">{stats.totalUsers}</p>
                    </div>
                    <Users className="w-8 h-8 text-blue-500" />
                  </div>
                </CardContent>
              </Card>
              <Card className="border-0 shadow-md">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-500">المضيفين</p>
                      <p className="text-2xl font-bold">{stats.totalHosts}</p>
                    </div>
                    <Home className="w-8 h-8 text-amber-500" />
                  </div>
                </CardContent>
              </Card>
              <Card className="border-0 shadow-md">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-500">الإقامات</p>
                      <p className="text-2xl font-bold">{stats.totalAccommodations}</p>
                    </div>
                    <Home className="w-8 h-8 text-emerald-500" />
                  </div>
                </CardContent>
              </Card>
              <Card className="border-0 shadow-md">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-500">الحجوزات</p>
                      <p className="text-2xl font-bold">{stats.totalBookings}</p>
                    </div>
                    <Calendar className="w-8 h-8 text-violet-500" />
                  </div>
                </CardContent>
              </Card>
              <Card className="border-0 shadow-md">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-500">الإيرادات</p>
                      <p className="text-2xl font-bold">{stats.totalRevenue.toLocaleString()}</p>
                      <p className="text-xs text-gray-400">ل.س</p>
                    </div>
                    <DollarSign className="w-8 h-8 text-green-500" />
                  </div>
                </CardContent>
              </Card>
              <Card className="border-0 shadow-md">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-500">بانتظار الموافقة</p>
                      <p className="text-2xl font-bold text-amber-600">{stats.pendingApprovals}</p>
                    </div>
                    <TrendingUp className="w-8 h-8 text-amber-500" />
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Users Tab */}
          <TabsContent value="users">
            <Card className="border-0 shadow-md">
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle>المستخدمين ({users.length})</CardTitle>
                <div className="relative w-64">
                  <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <Input
                    placeholder="بحث..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pr-9"
                  />
                </div>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b">
                        <th className="text-right p-3">المستخدم</th>
                        <th className="text-right p-3">الهاتف</th>
                        <th className="text-right p-3">الدور</th>
                        <th className="text-right p-3">الحالة</th>
                        <th className="text-right p-3">تاريخ التسجيل</th>
                        <th className="text-right p-3">إجراءات</th>
                      </tr>
                    </thead>
                    <tbody>
                      {users.map((u) => (
                        <tr key={u.id} className="border-b hover:bg-gray-50">
                          <td className="p-3">
                            <div className="flex items-center gap-2">
                              <Avatar className="w-8 h-8">
                                <AvatarImage src={u.avatar} />
                                <AvatarFallback className="bg-gray-100">
                                  {u.nameAr?.charAt(0) || u.name?.charAt(0) || 'ض'}
                                </AvatarFallback>
                              </Avatar>
                              <span>{u.nameAr || u.name || 'ضيف'}</span>
                            </div>
                          </td>
                          <td className="p-3 text-gray-500" dir="ltr">{u.phone}</td>
                          <td className="p-3">
                            <Badge variant={u.role === 'HOST' ? 'default' : 'secondary'}>
                              {u.role === 'HOST' ? 'مضيف' : u.role === 'ADMIN' ? 'مدير' : 'ضيف'}
                            </Badge>
                          </td>
                          <td className="p-3">
                            <Badge className={
                              u.status === 'ACTIVE' ? 'bg-emerald-100 text-emerald-700' :
                              u.status === 'SUSPENDED' ? 'bg-red-100 text-red-700' :
                              'bg-yellow-100 text-yellow-700'
                            }>
                              {u.status === 'ACTIVE' ? 'نشط' : 
                               u.status === 'SUSPENDED' ? 'معلق' : 'قيد التحقق'}
                            </Badge>
                          </td>
                          <td className="p-3 text-gray-500">
                            {new Date(u.createdAt).toLocaleDateString('ar-SY')}
                          </td>
                          <td className="p-3">
                            <div className="flex gap-1">
                              <Button variant="ghost" size="icon">
                                <Eye className="w-4 h-4" />
                              </Button>
                              {u.status !== 'SUSPENDED' && (
                                <Button 
                                  variant="ghost" 
                                  size="icon"
                                  onClick={() => handleSuspendUser(u.id)}
                                >
                                  <Ban className="w-4 h-4 text-red-500" />
                                </Button>
                              )}
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Accommodations Tab */}
          <TabsContent value="accommodations">
            <Card className="border-0 shadow-md">
              <CardHeader>
                <CardTitle>الإقامات ({accommodations.length})</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {accommodations.map((acc) => (
                    <div key={acc.id} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex items-center gap-3">
                        <div className="w-16 h-16 rounded-lg overflow-hidden bg-gray-200">
                          <img 
                            src={acc.coverImage || '/images/default-accommodation.png'} 
                            alt={acc.titleAr}
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <div>
                          <p className="font-medium">{acc.titleAr}</p>
                          <p className="text-sm text-gray-500">{acc.host?.name || acc.host?.nameAr}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <Badge className={
                          acc.status === 'ACTIVE' ? 'bg-emerald-100 text-emerald-700' :
                          acc.status === 'PENDING_APPROVAL' ? 'bg-yellow-100 text-yellow-700' :
                          'bg-gray-100 text-gray-700'
                        }>
                          {acc.status === 'ACTIVE' ? 'نشط' : 
                           acc.status === 'PENDING_APPROVAL' ? 'بانتظار الموافقة' : acc.status}
                        </Badge>
                        {acc.status === 'PENDING_APPROVAL' && (
                          <>
                            <Button 
                              size="sm" 
                              className="bg-emerald-500 hover:bg-emerald-600"
                              onClick={() => handleApproveAccommodation(acc.id)}
                            >
                              <Check className="w-4 h-4" />
                            </Button>
                            <Button size="sm" variant="destructive">
                              <X className="w-4 h-4" />
                            </Button>
                          </>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Reports Tab */}
          <TabsContent value="reports">
            <Card className="border-0 shadow-md">
              <CardContent className="p-8 text-center">
                <Flag className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-lg font-bold mb-2">لا توجد بلاغات</h3>
                <p className="text-gray-500">ستظهر البلاغات هنا</p>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Settings Tab */}
          <TabsContent value="settings">
            <Card className="border-0 shadow-md">
              <CardHeader>
                <CardTitle>إعدادات النظام</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="p-4 border rounded-lg flex items-center justify-between">
                  <div>
                    <h4 className="font-medium">نسبة العمولة</h4>
                    <p className="text-sm text-gray-500">نسبة عمولة المنصة من كل حجز</p>
                  </div>
                  <Badge>8%</Badge>
                </div>
                <div className="p-4 border rounded-lg flex items-center justify-between">
                  <div>
                    <h4 className="font-medium">رسوم الضمان</h4>
                    <p className="text-sm text-gray-500">نسبة رسوم الضمان</p>
                  </div>
                  <Badge>5%</Badge>
                </div>
                <div className="p-4 border rounded-lg flex items-center justify-between">
                  <div>
                    <h4 className="font-medium">فترة الإصدار التجريبي</h4>
                    <p className="text-sm text-gray-500">فترة بدون عمولة للمضيفين الجدد</p>
                  </div>
                  <Badge>3 أشهر</Badge>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
