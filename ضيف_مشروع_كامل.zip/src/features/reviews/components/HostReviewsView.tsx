'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Star, ArrowLeft, User, MessageCircle } from 'lucide-react'
import { useNavigation } from '@/shared/contexts/NavigationContext'
import { HostReview } from '@/shared/types'

export function HostReviewsView() {
  const [reviews, setReviews] = useState<HostReview[]>([])
  const [loading, setLoading] = useState(true)
  const { navigate } = useNavigation()

  useEffect(() => {
    const fetchReviews = async () => {
      try {
        const response = await fetch('/api/host-reviews?limit=10')
        if (response.ok) {
          const data = await response.json()
          setReviews(data.reviews || [])
        }
      } catch (error) {
        console.error('Error fetching reviews:', error)
      } finally {
        setLoading(false)
      }
    }

    fetchReviews()
  }, [])

  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, i) => (
      <Star key={i} className={`w-4 h-4 ${i < Math.round(rating) ? 'text-amber-400 fill-amber-400' : 'text-gray-300'}`} />
    ))
  }

  const averageRating = reviews.length > 0 
    ? (reviews.reduce((sum, r) => sum + r.overallRating, 0) / reviews.length).toFixed(1)
    : '0.0'

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-gradient-to-r from-teal-600 to-cyan-600 text-white py-12">
        <div className="container mx-auto px-4">
          <Button variant="ghost" className="text-white mb-4 cursor-pointer" onClick={() => navigate('home')}>
            <ArrowLeft className="w-4 h-4 ml-2" />
            العودة للرئيسية
          </Button>
          <h1 className="text-3xl md:text-4xl font-bold mb-2">تقييمات المضيفين</h1>
          <p className="text-white/80 text-lg">تجارب حقيقية من ضيوف حقيقيين</p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-wrap gap-6 mb-8">
          <Card className="flex-1 min-w-[200px] border-0 shadow-md">
            <CardContent className="p-6 text-center">
              <div className="text-4xl font-bold text-teal-600 mb-2">{averageRating}</div>
              <div className="flex justify-center mb-2">{renderStars(parseFloat(averageRating))}</div>
              <p className="text-gray-500 text-sm">متوسط التقييم</p>
            </CardContent>
          </Card>
          <Card className="flex-1 min-w-[200px] border-0 shadow-md">
            <CardContent className="p-6 text-center">
              <div className="text-4xl font-bold text-emerald-600 mb-2">{reviews.length}</div>
              <p className="text-gray-500 text-sm">تقييم مثبت</p>
            </CardContent>
          </Card>
          <Card className="flex-1 min-w-[200px] border-0 shadow-md">
            <CardContent className="p-6 text-center">
              <div className="text-4xl font-bold text-amber-600 mb-2">98%</div>
              <p className="text-gray-500 text-sm">نسبة الرضا</p>
            </CardContent>
          </Card>
        </div>

        {loading ? (
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <Card key={i} className="border-0 shadow-md">
                <CardContent className="p-6">
                  <div className="h-4 bg-gray-200 rounded w-1/2 mb-4 animate-pulse" />
                  <div className="h-3 bg-gray-100 rounded w-full mb-2 animate-pulse" />
                  <div className="h-3 bg-gray-100 rounded w-3/4 animate-pulse" />
                </CardContent>
              </Card>
            ))}
          </div>
        ) : reviews.length > 0 ? (
          <div className="space-y-6">
            {reviews.map((review) => (
              <Card key={review.id} className="border-0 shadow-md overflow-hidden">
                <CardContent className="p-6">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 rounded-full bg-gradient-to-br from-teal-400 to-cyan-500 flex items-center justify-center text-white font-bold shrink-0">
                      {review.reviewer.name?.charAt(0) || review.reviewer.nameAr?.charAt(0) || 'ض'}
                    </div>
                    
                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-3">
                        <div>
                          <h4 className="font-bold text-gray-900">{review.reviewer.nameAr || review.reviewer.name || 'ضيف'}</h4>
                          <div className="flex items-center gap-2 mt-1">
                            <div className="flex">{renderStars(review.overallRating)}</div>
                            <span className="text-sm text-gray-500">{review.overallRating.toFixed(1)}</span>
                            {review.isVerified && <Badge className="bg-emerald-100 text-emerald-700 text-xs">موثق</Badge>}
                          </div>
                        </div>
                        <p className="text-sm text-gray-500">{new Date(review.createdAt).toLocaleDateString('ar-SY')}</p>
                      </div>

                      <p className="text-gray-600 mb-4">{review.commentAr || 'تقييم إيجابي'}</p>

                      <div className="grid grid-cols-3 md:grid-cols-6 gap-4 p-4 bg-gray-50 rounded-lg">
                        {[
                          { label: 'التواصل', value: review.communication },
                          { label: 'النظافة', value: review.cleanliness },
                          { label: 'الدقة', value: review.accuracy },
                          { label: 'القيمة', value: review.value },
                          { label: 'الموقع', value: review.location },
                          { label: 'تسجيل الوصول', value: review.checkIn }
                        ].map((item) => (
                          <div key={item.label} className="text-center">
                            <p className="text-xs text-gray-500 mb-1">{item.label}</p>
                            <p className="font-bold text-teal-600">{item.value.toFixed(1)}</p>
                          </div>
                        ))}
                      </div>

                      {review.hostResponse && (
                        <div className="mt-4 p-4 bg-amber-50 rounded-lg border-r-4 border-amber-400">
                          <p className="text-sm text-gray-500 mb-2">رد المضيف ({review.host.nameAr || review.host.name || 'المضيف'}):</p>
                          <p className="text-gray-700">{review.hostResponse}</p>
                        </div>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <MessageCircle className="w-12 h-12 text-gray-300 mx-auto mb-4" />
            <p className="text-gray-500">لا توجد تقييمات بعد</p>
          </div>
        )}
      </div>
    </div>
  )
}
