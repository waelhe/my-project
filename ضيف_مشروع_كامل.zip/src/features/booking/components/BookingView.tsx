'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import { 
  Calendar, Users, CreditCard, Check, ArrowRight, ArrowLeft,
  Loader2, Shield, MapPin, Star, Clock, AlertCircle
} from 'lucide-react'
import { useNavigation } from '@/shared/contexts/NavigationContext'
import { useAuth } from '@/shared/contexts/AuthContext'
import { useBooking } from '@/shared/contexts/BookingContext'
import { toast } from 'sonner'
import { PAYMENT_METHOD_LABELS, PaymentMethod } from '@/shared/types'

const paymentMethods: { id: PaymentMethod; label: string; icon: string; description: string }[] = [
  { id: 'CASH', label: 'نقدي عند الوصول', icon: '💵', description: 'ادفع نقداً عند وصولك للمكان' },
  { id: 'SYRIATEL', label: 'سيرياتيل كاش', icon: '📱', description: 'ادفع عبر محفظة سيرياتيل كاش' },
  { id: 'MTN', label: 'MTN كاش', icon: '📱', description: 'ادفع عبر محفظة MTN كاش' },
  { id: 'BANK_TRANSFER', label: 'تحويل بنكي', icon: '🏦', description: 'حول المبلغ إلى الحساب البنكي' },
]

// ==================== Booking View ====================

export function BookingView() {
  const { pageParams, navigate } = useNavigation()
  const { isAuthenticated, user } = useAuth()
  const { 
    accommodation, dates, guests, pricing, specialRequests, guestInfo,
    setGuests, setSpecialRequests, setGuestInfo, createBooking, 
    calculatePricing, loading, bookingId 
  } = useBooking()

  const [currentStep, setCurrentStep] = useState<'guests' | 'details' | 'payment' | 'confirmation'>('guests')
  const [selectedPayment, setSelectedPayment] = useState<PaymentMethod>('CASH')
  const [termsAccepted, setTermsAccepted] = useState(false)

  // Load accommodation if not loaded
  useEffect(() => {
    if (!accommodation && pageParams.id) {
      // Redirect to accommodation details
      navigate('accommodation-details', { id: pageParams.id })
    }
  }, [accommodation, pageParams.id, navigate])

  // Calculate pricing when dates change
  useEffect(() => {
    calculatePricing()
  }, [calculatePricing])

  // Redirect if not authenticated
  useEffect(() => {
    if (!isAuthenticated) {
      toast.error('يرجى تسجيل الدخول للحجز')
      navigate('home')
    }
  }, [isAuthenticated, navigate])

  // Pre-fill guest info from user
  useEffect(() => {
    if (user && !guestInfo.name) {
      setGuestInfo({
        name: user.nameAr || user.name || '',
        phone: user.phone,
        email: user.email || ''
      })
    }
  }, [user, guestInfo.name, setGuestInfo])

  // Handle next step
  const handleNext = async () => {
    if (currentStep === 'guests') {
      if (!dates.checkIn || !dates.checkOut) {
        toast.error('يرجى اختيار تواريخ الحجز')
        return
      }
      setCurrentStep('details')
    } else if (currentStep === 'details') {
      if (!guestInfo.name.trim()) {
        toast.error('يرجى إدخال اسمك')
        return
      }
      if (!guestInfo.phone.trim()) {
        toast.error('يرجى إدخال رقم هاتفك')
        return
      }
      setCurrentStep('payment')
    } else if (currentStep === 'payment') {
      if (!termsAccepted) {
        toast.error('يرجى الموافقة على الشروط')
        return
      }
      
      const result = await createBooking()
      if (result.success) {
        setCurrentStep('confirmation')
      } else {
        toast.error(result.error || 'حدث خطأ')
      }
    }
  }

  // Handle back
  const handleBack = () => {
    if (currentStep === 'details') setCurrentStep('guests')
    else if (currentStep === 'payment') setCurrentStep('details')
    else if (currentStep === 'confirmation') navigate('my-bookings')
  }

  // Loading state
  if (!accommodation || !pricing) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-amber-500" />
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="container mx-auto px-4">
        {/* Progress Steps */}
        <div className="max-w-2xl mx-auto mb-8">
          <div className="flex items-center justify-between">
            {['guests', 'details', 'payment', 'confirmation'].map((step, index) => (
              <div key={step} className="flex items-center">
                <div className={`
                  w-10 h-10 rounded-full flex items-center justify-center text-sm font-medium
                  ${currentStep === step ? 'bg-amber-500 text-white' : 
                    index < ['guests', 'details', 'payment', 'confirmation'].indexOf(currentStep) 
                      ? 'bg-emerald-500 text-white' : 'bg-gray-200 text-gray-500'}
                `}>
                  {index < ['guests', 'details', 'payment', 'confirmation'].indexOf(currentStep) ? (
                    <Check className="w-5 h-5" />
                  ) : (
                    index + 1
                  )}
                </div>
                {index < 3 && (
                  <div className={`w-12 sm:w-24 h-1 ${
                    index < ['guests', 'details', 'payment', 'confirmation'].indexOf(currentStep) 
                      ? 'bg-emerald-500' : 'bg-gray-200'
                  }`} />
                )}
              </div>
            ))}
          </div>
          <div className="flex justify-between mt-2 text-xs text-gray-500 px-2">
            <span>الضيوف</span>
            <span>التفاصيل</span>
            <span>الدفع</span>
            <span>التأكيد</span>
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {/* Main Content */}
          <div className="lg:col-span-2">
            {/* Step: Guests */}
            {currentStep === 'guests' && (
              <Card className="border-0 shadow-md">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Users className="w-5 h-5" />
                    معلومات الضيوف
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="p-4 border rounded-lg">
                      <Label className="text-sm text-gray-500">تسجيل الوصول</Label>
                      <p className="font-medium flex items-center gap-2 mt-1">
                        <Calendar className="w-4 h-4 text-amber-500" />
                        {dates.checkIn?.toLocaleDateString('ar-SY', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
                      </p>
                    </div>
                    <div className="p-4 border rounded-lg">
                      <Label className="text-sm text-gray-500">تسجيل المغادرة</Label>
                      <p className="font-medium flex items-center gap-2 mt-1">
                        <Calendar className="w-4 h-4 text-amber-500" />
                        {dates.checkOut?.toLocaleDateString('ar-SY', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
                      </p>
                    </div>
                  </div>

                  <div className="p-4 border rounded-lg">
                    <Label className="text-sm text-gray-500">عدد الضيوف</Label>
                    <div className="flex items-center justify-between mt-2">
                      <div>
                        <p className="font-medium">بالغين</p>
                        <p className="text-sm text-gray-500">أعمارهم 13 سنة فأكثر</p>
                      </div>
                      <div className="flex items-center gap-3">
                        <Button 
                          variant="outline" 
                          size="icon"
                          onClick={() => setGuests({ ...guests, adults: Math.max(1, guests.adults - 1) })}
                        >
                          -
                        </Button>
                        <span className="w-8 text-center font-medium">{guests.adults}</span>
                        <Button 
                          variant="outline" 
                          size="icon"
                          onClick={() => setGuests({ ...guests, adults: Math.min(accommodation.maxGuests, guests.adults + 1) })}
                        >
                          +
                        </Button>
                      </div>
                    </div>
                    <Separator className="my-4" />
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium">أطفال</p>
                        <p className="text-sm text-gray-500">أعمارهم 2-12 سنة</p>
                      </div>
                      <div className="flex items-center gap-3">
                        <Button 
                          variant="outline" 
                          size="icon"
                          onClick={() => setGuests({ ...guests, children: Math.max(0, guests.children - 1) })}
                        >
                          -
                        </Button>
                        <span className="w-8 text-center font-medium">{guests.children}</span>
                        <Button 
                          variant="outline" 
                          size="icon"
                          onClick={() => setGuests({ ...guests, children: Math.min(accommodation.maxGuests - guests.adults, guests.children + 1) })}
                        >
                          +
                        </Button>
                      </div>
                    </div>
                  </div>

                  <div>
                    <Label>طلبات خاصة (اختياري)</Label>
                    <textarea
                      className="w-full mt-1 p-3 border rounded-lg resize-none focus:ring-2 focus:ring-amber-500 focus:border-transparent"
                      rows={3}
                      placeholder="أي طلبات خاصة للمضيف..."
                      value={specialRequests}
                      onChange={(e) => setSpecialRequests(e.target.value)}
                    />
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Step: Details */}
            {currentStep === 'details' && (
              <Card className="border-0 shadow-md">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Users className="w-5 h-5" />
                    بيانات الضيف
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label htmlFor="name">الاسم الكامل *</Label>
                    <Input
                      id="name"
                      value={guestInfo.name}
                      onChange={(e) => setGuestInfo({ ...guestInfo, name: e.target.value })}
                      placeholder="أدخل اسمك الكامل"
                      className="mt-1"
                    />
                  </div>
                  <div>
                    <Label htmlFor="phone">رقم الهاتف *</Label>
                    <Input
                      id="phone"
                      type="tel"
                      value={guestInfo.phone}
                      onChange={(e) => setGuestInfo({ ...guestInfo, phone: e.target.value })}
                      placeholder="09XXXXXXXX"
                      dir="ltr"
                      className="mt-1"
                    />
                  </div>
                  <div>
                    <Label htmlFor="email">البريد الإلكتروني (اختياري)</Label>
                    <Input
                      id="email"
                      type="email"
                      value={guestInfo.email}
                      onChange={(e) => setGuestInfo({ ...guestInfo, email: e.target.value })}
                      placeholder="email@example.com"
                      dir="ltr"
                      className="mt-1"
                    />
                  </div>

                  <div className="p-4 bg-amber-50 rounded-lg flex items-start gap-3">
                    <AlertCircle className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />
                    <div className="text-sm text-amber-700">
                      <p className="font-medium">معلومات مهمة</p>
                      <p>سيتم إرسال تفاصيل الحجز ورمز التأكيد إلى رقم هاتفك</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Step: Payment */}
            {currentStep === 'payment' && (
              <Card className="border-0 shadow-md">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <CreditCard className="w-5 h-5" />
                    طريقة الدفع
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    {paymentMethods.map((method) => (
                      <label 
                        key={method.id}
                        className={`
                          flex items-center gap-4 p-4 border rounded-lg cursor-pointer transition-all
                          ${selectedPayment === method.id ? 'border-amber-500 bg-amber-50' : 'hover:border-gray-300'}
                        `}
                      >
                        <input
                          type="radio"
                          name="payment"
                          value={method.id}
                          checked={selectedPayment === method.id}
                          onChange={() => setSelectedPayment(method.id)}
                          className="hidden"
                        />
                        <span className="text-2xl">{method.icon}</span>
                        <div className="flex-1">
                          <p className="font-medium">{method.label}</p>
                          <p className="text-sm text-gray-500">{method.description}</p>
                        </div>
                        <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center
                          ${selectedPayment === method.id ? 'border-amber-500' : 'border-gray-300'}
                        `}>
                          {selectedPayment === method.id && (
                            <div className="w-2.5 h-2.5 rounded-full bg-amber-500" />
                          )}
                        </div>
                      </label>
                    ))}
                  </div>

                  <Separator />

                  <label className="flex items-start gap-3 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={termsAccepted}
                      onChange={(e) => setTermsAccepted(e.target.checked)}
                      className="mt-1"
                    />
                    <span className="text-sm text-gray-600">
                      أوافق على <a href="#" className="text-amber-600 hover:underline">شروط الاستخدام</a> و{' '}
                      <a href="#" className="text-amber-600 hover:underline">سياسة الإلغاء</a>
                    </span>
                  </label>
                </CardContent>
              </Card>
            )}

            {/* Step: Confirmation */}
            {currentStep === 'confirmation' && (
              <Card className="border-0 shadow-md">
                <CardContent className="p-8 text-center">
                  <div className="w-20 h-20 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Check className="w-10 h-10 text-emerald-500" />
                  </div>
                  <h2 className="text-2xl font-bold mb-2">تم الحجز بنجاح!</h2>
                  <p className="text-gray-500 mb-4">
                    تم إرسال تفاصيل الحجز إلى هاتفك
                  </p>
                  <Badge className="bg-amber-100 text-amber-700 text-lg px-4 py-2">
                    رمز التأكيد: {bookingId?.slice(-6).toUpperCase()}
                  </Badge>
                  
                  <div className="mt-8 flex flex-col sm:flex-row gap-3 justify-center">
                    <Button onClick={() => navigate('my-bookings')} className="bg-amber-500 hover:bg-amber-600">
                      عرض حجوزاتي
                    </Button>
                    <Button variant="outline" onClick={() => navigate('home')}>
                      العودة للرئيسية
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Navigation Buttons */}
            {currentStep !== 'confirmation' && (
              <div className="flex gap-3 mt-6">
                <Button 
                  variant="outline" 
                  onClick={currentStep === 'guests' ? () => navigate('accommodation-details', { id: accommodation.id }) : handleBack}
                  className="flex-1"
                >
                  <ArrowRight className="w-4 h-4 ml-2" />
                  رجوع
                </Button>
                <Button 
                  onClick={handleNext}
                  disabled={loading}
                  className="flex-1 bg-amber-500 hover:bg-amber-600"
                >
                  {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : (
                    <>
                      التالي
                      <ArrowLeft className="w-4 h-4 mr-2" />
                    </>
                  )}
                </Button>
              </div>
            )}
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1">
            <Card className="border-0 shadow-md sticky top-24">
              <CardContent className="p-4">
                {/* Accommodation Info */}
                <div className="flex gap-3 mb-4">
                  <div className="w-20 h-20 rounded-lg overflow-hidden bg-gray-200 shrink-0">
                    <img 
                      src={accommodation.coverImage || '/images/default-accommodation.png'} 
                      alt={accommodation.titleAr}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div>
                    <h3 className="font-medium line-clamp-2">{accommodation.titleAr}</h3>
                    <p className="text-sm text-gray-500 flex items-center gap-1 mt-1">
                      <MapPin className="w-3 h-3" />
                      {accommodation.city?.nameAr}
                    </p>
                    <div className="flex items-center gap-1 mt-1">
                      <Star className="w-3 h-3 text-amber-400 fill-amber-400" />
                      <span className="text-sm">4.8</span>
                    </div>
                  </div>
                </div>

                <Separator />

                {/* Pricing */}
                <div className="py-4 space-y-2">
                  <div className="flex justify-between text-gray-600">
                    <span>{accommodation.basePrice.toLocaleString()} ل.س × {pricing.nightsCount} ليالي</span>
                    <span>{pricing.baseAmount.toLocaleString()} ل.س</span>
                  </div>
                  {pricing.cleaningFee > 0 && (
                    <div className="flex justify-between text-gray-600">
                      <span>رسوم التنظيف</span>
                      <span>{pricing.cleaningFee.toLocaleString()} ل.س</span>
                    </div>
                  )}
                  <div className="flex justify-between text-gray-600">
                    <span>رسوم الخدمة</span>
                    <span>{pricing.serviceFee.toLocaleString()} ل.س</span>
                  </div>
                  {pricing.guaranteeFee > 0 && (
                    <div className="flex justify-between text-gray-600">
                      <span>رسوم الضمان</span>
                      <span>{pricing.guaranteeFee.toLocaleString()} ل.س</span>
                    </div>
                  )}
                </div>

                <Separator />

                <div className="flex justify-between font-bold text-lg pt-4">
                  <span>المجموع</span>
                  <span>{pricing.totalAmount.toLocaleString()} ل.س</span>
                </div>

                {/* Guarantee */}
                <div className="mt-4 p-3 bg-emerald-50 rounded-lg flex items-center gap-2">
                  <Shield className="w-5 h-5 text-emerald-500" />
                  <span className="text-sm text-emerald-700">حجز محمي بضمان ضيف</span>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
