'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { 
  Compass, Search, MapPin, Star, Heart, ArrowLeft, Users, Clock,
  Mountain, Sun, Loader2
} from 'lucide-react'
import { useNavigation } from '@/shared/contexts/NavigationContext'
import { useFavorites } from '@/shared/contexts/FavoritesContext'
import { TOUR_TYPE_LABELS, Tour } from '@/shared/types'

// ==================== Tours View ====================

export function ToursView() {
  const [tours, setTours] = useState<Tour[]>([])
  const [loading, setLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState('')
  const [selectedType, setSelectedType] = useState<string | null>(null)
  const { navigate } = useNavigation()
  const { toggleFavorite, isFavorite } = useFavorites()

  useEffect(() => {
    const fetchTours = async () => {
      try {
        const response = await fetch('/api/tours?limit=20')
        if (response.ok) {
          const data = await response.json()
          setTours(data.tours || [])
        }
      } catch (error) {
        console.error('Error fetching tours:', error)
      } finally {
        setLoading(false)
      }
    }
    fetchTours()
  }, [])

  const filteredTours = tours.filter(t => {
    const matchesSearch = !searchQuery || 
      t.titleAr.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesType = !selectedType || t.type === selectedType
    return matchesSearch && matchesType
  })

  // Get unique tour types from data
  const tourTypes = [...new Set(tours.map(t => t.type))].slice(0, 5)

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-sky-600 to-blue-600 text-white py-12">
        <div className="container mx-auto px-4">
          <Button variant="ghost" className="text-white mb-4 cursor-pointer" onClick={() => navigate('home')}>
            <ArrowLeft className="w-4 h-4 ml-2" />
            العودة للرئيسية
          </Button>
          <h1 className="text-3xl md:text-4xl font-bold mb-2">الجولات السياحية</h1>
          <p className="text-white/80 text-lg">اكتشف جمال سوريا مع أفضل الجولات السياحية</p>
        </div>
      </div>

      {/* Content */}
      <div className="container mx-auto px-4 py-8">
        {/* Search & Filter */}
        <div className="flex flex-col md:flex-row gap-4 mb-8">
          <div className="flex-1 relative">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
            <Input
              placeholder="ابحث عن جولة..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pr-10"
            />
          </div>
          <div className="flex gap-2 flex-wrap">
            <Button
              variant={selectedType === null ? "default" : "outline"}
              onClick={() => setSelectedType(null)}
              className={selectedType === null ? "bg-sky-500 hover:bg-sky-600" : ""}
            >
              الكل
            </Button>
            {tourTypes.map((type) => (
              <Button
                key={type}
                variant={selectedType === type ? "default" : "outline"}
                onClick={() => setSelectedType(type)}
                className={selectedType === type ? "bg-sky-500 hover:bg-sky-600" : ""}
              >
                {TOUR_TYPE_LABELS[type] || type}
              </Button>
            ))}
          </div>
        </div>

        <p className="text-gray-600 mb-4">عرض {filteredTours.length} جولة</p>

        {loading ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <Card key={i} className="border-0 shadow-md">
                <div className="h-48 bg-gray-200 animate-pulse" />
                <CardContent className="p-4">
                  <div className="h-4 bg-gray-200 rounded w-3/4 mb-2 animate-pulse" />
                  <div className="h-4 bg-gray-200 rounded w-1/2 animate-pulse" />
                </CardContent>
              </Card>
            ))}
          </div>
        ) : filteredTours.length > 0 ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredTours.map((tour) => (
              <Card 
                key={tour.id} 
                className="group border-0 shadow-md hover:shadow-xl transition-all cursor-pointer overflow-hidden"
                onClick={() => navigate('tour-details', { id: tour.id })}
              >
                <div className="relative h-48 overflow-hidden bg-gray-200">
                  <img 
                    src={tour.coverImage || '/images/default-tour.png'} 
                    alt={tour.titleAr}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                  />
                  <Badge className="absolute top-3 right-3 bg-sky-500 text-white">
                    {TOUR_TYPE_LABELS[tour.type] || tour.type}
                  </Badge>
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="absolute top-3 left-3 bg-white/80 hover:bg-white rounded-full h-8 w-8"
                    onClick={(e) => { e.stopPropagation(); toggleFavorite(tour.id) }}
                  >
                    <Heart className={`w-4 h-4 ${isFavorite(tour.id) ? 'fill-red-500 text-red-500' : 'text-gray-600'}`} />
                  </Button>
                  <div className="absolute bottom-3 right-3 bg-black/50 text-white text-xs px-2 py-1 rounded flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    {tour.duration} ساعات
                  </div>
                </div>
                <CardContent className="p-4">
                  <div className="flex items-center text-sm text-gray-500 mb-2">
                    <MapPin className="w-3 h-3 ml-1" />
                    {tour.city?.nameAr || 'سوريا'}
                  </div>
                  <h3 className="font-semibold text-gray-900 mb-2 line-clamp-2">{tour.titleAr}</h3>
                  
                  {/* Tour Details */}
                  <div className="flex items-center gap-4 text-sm text-gray-500 mb-3">
                    <span className="flex items-center gap-1"><Users className="w-3 h-3" />{tour.maxGroupSize} شخص</span>
                    <span className="flex items-center gap-1">
                      {tour.difficulty === 'easy' && <Sun className="w-3 h-3 text-amber-400" />}
                      {tour.difficulty === 'moderate' && <Mountain className="w-3 h-3 text-blue-400" />}
                      {tour.difficulty === 'hard' && <Mountain className="w-3 h-3 text-red-400" />}
                      {tour.difficulty === 'easy' ? 'سهل' : tour.difficulty === 'moderate' ? 'متوسط' : 'صعب'}
                    </span>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <Star className="w-4 h-4 text-amber-400 fill-amber-400 ml-1" />
                      <span className="font-medium text-sm">{tour.rating.toFixed(1)}</span>
                    </div>
                    <div>
                      <span className="font-bold text-lg text-gray-900">{tour.basePrice.toLocaleString()}</span>
                      <span className="text-gray-500 text-sm mr-1">ل.س / شخص</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <Compass className="w-12 h-12 text-gray-300 mx-auto mb-4" />
            <p className="text-gray-500">لا توجد جولات تطابق بحثك</p>
          </div>
        )}
      </div>
    </div>
  )
}
