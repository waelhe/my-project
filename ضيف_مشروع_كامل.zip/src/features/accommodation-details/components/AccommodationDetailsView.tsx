'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import { Input } from '@/components/ui/input'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { 
  Star, Heart, Share2, MapPin, User, Bed, Bath, Maximize, 
  Calendar, ChevronLeft, ChevronRight, MessageCircle, Shield,
  Wifi, Wind, Car, Waves, ChefHat, Shirt, Tv, Flame, Dumbbell,
  Trees, Sun, Coffee, Umbrella, Mountain, Clock, Check, X,
  Loader2, ArrowRight
} from 'lucide-react'
import { useNavigation } from '@/shared/contexts/NavigationContext'
import { useAuth } from '@/shared/contexts/AuthContext'
import { useFavorites } from '@/shared/contexts/FavoritesContext'
import { useBooking } from '@/shared/contexts/BookingContext'
import { toast } from 'sonner'
import { 
  Accommodation, AccommodationReview, AMENITY_LABELS, ACCOMMODATION_TYPE_LABELS 
} from '@/shared/types'

// Amenity icons map - supports both lowercase and capitalized keys
const AmenityIcons: Record<string, React.ComponentType<{ className?: string }>> = {
  // lowercase keys
  wifi: Wifi, ac: Wind, parking: Car, pool: Waves, kitchen: ChefHat,
  washer: Shirt, tv: Tv, heater: Flame, gym: Dumbbell, garden: Trees,
  balcony: Sun, fireplace: Flame, breakfast: Coffee, beach: Umbrella, view: Mountain,
  // capitalized keys (matching AMENITY_LABELS.icon values)
  Wifi: Wifi, Wind: Wind, Car: Car, Waves: Waves, ChefHat: ChefHat,
  Shirt: Shirt, Tv: Tv, Flame: Flame, Dumbbell: Dumbbell, Trees: Trees,
  Sun: Sun, Coffee: Coffee, Umbrella: Umbrella, Mountain: Mountain
}

// Fallback icon for unknown amenities
const FallbackIcon = Check

// ==================== Accommodation Details View ====================

export function AccommodationDetailsView() {
  const { pageParams, navigate } = useNavigation()
  const { isAuthenticated, user } = useAuth()
  const { isFavorite, toggleFavorite } = useFavorites()
  const { setAccommodation: setBookingAccommodation, setDates, setCurrentStep } = useBooking()
  
  const [accommodation, setAccommodation] = useState<Accommodation | null>(null)
  const [reviews, setReviews] = useState<AccommodationReview[]>([])
  const [loading, setLoading] = useState(true)
  const [currentImage, setCurrentImage] = useState(0)
  const [saving, setSaving] = useState(false)

  // Check-in/out dates
  const [checkIn, setCheckIn] = useState('')
  const [checkOut, setCheckOut] = useState('')
  const [guests, setGuests] = useState(1)

  // Load accommodation data
  useEffect(() => {
    const accommodationId = pageParams.id
    if (!accommodationId) {
      navigate('accommodations')
      return
    }

    const loadData = async () => {
      try {
        const [accRes, reviewsRes] = await Promise.all([
          fetch(`/api/accommodations/${accommodationId}`),
          fetch(`/api/accommodations/${accommodationId}/reviews?limit=5`)
        ])

        if (accRes.ok) {
          const data = await accRes.json()
          setAccommodation(data.accommodation)
        }

        if (reviewsRes.ok) {
          const data = await reviewsRes.json()
          setReviews(data.reviews || [])
        }
      } catch (error) {
        console.error('Error loading accommodation:', error)
      } finally {
        setLoading(false)
      }
    }

    loadData()
  }, [pageParams.id, navigate])

  // Calculate pricing
  const calculatePricing = () => {
    if (!accommodation || !checkIn || !checkOut) return null
    
    const nights = Math.ceil(
      (new Date(checkOut).getTime() - new Date(checkIn).getTime()) / (1000 * 60 * 60 * 24)
    )
    
    if (nights <= 0) return null

    const baseAmount = accommodation.basePrice * nights
    const cleaningFee = accommodation.cleaningFee || 0
    const serviceFee = Math.round(baseAmount * 0.08)
    const totalAmount = baseAmount + cleaningFee + serviceFee

    return { nights, baseAmount, cleaningFee, serviceFee, totalAmount }
  }

  const pricing = calculatePricing()

  // Handle favorite toggle
  const handleFavorite = async () => {
    if (!accommodation) return
    
    if (!isAuthenticated) {
      toast.error('يرجى تسجيل الدخول لإضافة للمفضلة')
      return
    }

    setSaving(true)
    await toggleFavorite(accommodation.id)
    setSaving(false)
  }

  // Handle booking
  const handleBooking = () => {
    if (!isAuthenticated) {
      toast.error('يرجى تسجيل الدخول للحجز')
      return
    }

    if (!accommodation || !checkIn || !checkOut) {
      toast.error('يرجى اختيار تواريخ الحجز')
      return
    }

    setBookingAccommodation({
      id: accommodation.id,
      titleAr: accommodation.titleAr,
      coverImage: accommodation.coverImage,
      city: accommodation.city,
      basePrice: accommodation.basePrice,
      cleaningFee: accommodation.cleaningFee,
      minNights: accommodation.minNights,
      maxNights: accommodation.maxNights,
      maxGuests: accommodation.maxGuests
    })

    setDates({
      checkIn: new Date(checkIn),
      checkOut: new Date(checkOut)
    })

    setCurrentStep('guests')
    navigate('booking', { id: accommodation.id })
  }

  // Handle contact host
  const handleContactHost = () => {
    if (!isAuthenticated) {
      toast.error('يرجى تسجيل الدخول للتواصل مع المضيف')
      return
    }
    navigate('messages')
  }

  // Image navigation
  const nextImage = () => {
    if (!accommodation) return
    const images = accommodation.images?.length > 0 ? accommodation.images : [accommodation.coverImage || '/images/default-accommodation.png']
    setCurrentImage((prev) => (prev + 1) % images.length)
  }

  const prevImage = () => {
    if (!accommodation) return
    const images = accommodation.images?.length > 0 ? accommodation.images : [accommodation.coverImage || '/images/default-accommodation.png']
    setCurrentImage((prev) => (prev - 1 + images.length) % images.length)
  }

  // Render stars
  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, i) => (
      <Star key={i} className={`w-4 h-4 ${i < Math.round(rating) ? 'text-amber-400 fill-amber-400' : 'text-gray-300'}`} />
    ))
  }

  // Loading state
  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-amber-500" />
      </div>
    )
  }

  // Not found
  if (!accommodation) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Card className="max-w-md mx-4">
          <CardContent className="p-8 text-center">
            <h2 className="text-xl font-bold mb-2">الإقامة غير موجودة</h2>
            <p className="text-gray-500 mb-4">لم نتمكن من العثور على هذه الإقامة</p>
            <Button onClick={() => navigate('accommodations')}>العودة للإقامات</Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  const images = accommodation.images?.length > 0 ? accommodation.images : [accommodation.coverImage || '/images/default-accommodation.png']
  const isFav = isFavorite(accommodation.id)

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b sticky top-16 z-40">
        <div className="container mx-auto px-4 py-3 flex items-center justify-between">
          <Button variant="ghost" onClick={() => navigate('accommodations')}>
            <ArrowRight className="w-4 h-4 ml-2" />
            العودة
          </Button>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={handleFavorite} disabled={saving}>
              <Heart className={`w-4 h-4 ml-1 ${isFav ? 'fill-red-500 text-red-500' : ''}`} />
              {isFav ? 'محفوظ' : 'حفظ'}
            </Button>
            <Button variant="outline" size="sm">
              <Share2 className="w-4 h-4 ml-1" />
              مشاركة
            </Button>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-6">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Image Gallery */}
            <div className="relative rounded-xl overflow-hidden bg-gray-200">
              <div className="aspect-[16/9] md:aspect-[21/9]">
                <img 
                  src={images[currentImage]} 
                  alt={accommodation.titleAr}
                  className="w-full h-full object-cover"
                />
              </div>
              {images.length > 1 && (
                <>
                  <button 
                    onClick={prevImage}
                    className="absolute right-4 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-white/80 hover:bg-white flex items-center justify-center shadow-lg"
                  >
                    <ChevronRight className="w-5 h-5" />
                  </button>
                  <button 
                    onClick={nextImage}
                    className="absolute left-4 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-white/80 hover:bg-white flex items-center justify-center shadow-lg"
                  >
                    <ChevronLeft className="w-5 h-5" />
                  </button>
                  <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-1">
                    {images.map((_, i) => (
                      <button
                        key={i}
                        onClick={() => setCurrentImage(i)}
                        className={`w-2 h-2 rounded-full ${i === currentImage ? 'bg-white' : 'bg-white/50'}`}
                      />
                    ))}
                  </div>
                </>
              )}
            </div>

            {/* Title & Basic Info */}
            <div>
              <div className="flex items-start justify-between gap-4 mb-2">
                <h1 className="text-2xl md:text-3xl font-bold text-gray-900">{accommodation.titleAr}</h1>
                <Badge className="shrink-0">{ACCOMMODATION_TYPE_LABELS[accommodation.type] || accommodation.type}</Badge>
              </div>
              <div className="flex flex-wrap items-center gap-4 text-gray-600">
                <span className="flex items-center gap-1">
                  <MapPin className="w-4 h-4" />
                  {accommodation.city?.nameAr}{accommodation.addressAr && `، ${accommodation.addressAr}`}
                </span>
                <span className="flex items-center gap-1">
                  <Star className="w-4 h-4 text-amber-400 fill-amber-400" />
                  {accommodation.rating.toFixed(1)} ({accommodation.reviewCount} تقييم)
                </span>
              </div>
            </div>

            <Separator />

            {/* Host Info */}
            {accommodation.host && (
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Avatar className="w-12 h-12">
                    <AvatarImage src={accommodation.host.avatar || undefined} />
                    <AvatarFallback className="bg-amber-100 text-amber-700">
                      {accommodation.host.nameAr?.charAt(0) || accommodation.host.name?.charAt(0) || 'م'}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="font-medium">يستضيفها {accommodation.host.nameAr || accommodation.host.name || 'مضيف'}</p>
                    <p className="text-sm text-gray-500">
                      {accommodation.host.role === 'HOST' ? 'مضيف موثوق' : 'ضيف'}
                    </p>
                  </div>
                </div>
                <Button variant="outline" onClick={handleContactHost}>
                  <MessageCircle className="w-4 h-4 ml-2" />
                  تواصل
                </Button>
              </div>
            )}

            <Separator />

            {/* Quick Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="flex items-center gap-2 p-3 bg-gray-50 rounded-lg">
                <User className="w-5 h-5 text-gray-400" />
                <div>
                  <p className="text-sm text-gray-500">الضيوف</p>
                  <p className="font-medium">{accommodation.maxGuests} ضيف</p>
                </div>
              </div>
              <div className="flex items-center gap-2 p-3 bg-gray-50 rounded-lg">
                <Bed className="w-5 h-5 text-gray-400" />
                <div>
                  <p className="text-sm text-gray-500">غرف النوم</p>
                  <p className="font-medium">{accommodation.bedrooms} غرفة</p>
                </div>
              </div>
              <div className="flex items-center gap-2 p-3 bg-gray-50 rounded-lg">
                <Bath className="w-5 h-5 text-gray-400" />
                <div>
                  <p className="text-sm text-gray-500">الحمامات</p>
                  <p className="font-medium">{accommodation.bathrooms} حمام</p>
                </div>
              </div>
              <div className="flex items-center gap-2 p-3 bg-gray-50 rounded-lg">
                <Maximize className="w-5 h-5 text-gray-400" />
                <div>
                  <p className="text-sm text-gray-500">الأسرة</p>
                  <p className="font-medium">{accommodation.beds} سرير</p>
                </div>
              </div>
            </div>

            <Separator />

            {/* Description */}
            <div>
              <h2 className="text-xl font-bold mb-4">عن هذا المكان</h2>
              <p className="text-gray-600 leading-relaxed whitespace-pre-line">
                {accommodation.descriptionAr || 'لا يوجد وصف متاح لهذه الإقامة.'}
              </p>
            </div>

            <Separator />

            {/* Amenities */}
            <div>
              <h2 className="text-xl font-bold mb-4">ما يقدمه هذا المكان</h2>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                {accommodation.amenities?.map((amenity) => {
                  const info = AMENITY_LABELS[amenity]
                  // Safe icon lookup with multiple fallbacks
                  const IconComponent = info?.icon 
                    ? (AmenityIcons[info.icon] || AmenityIcons[amenity] || FallbackIcon)
                    : (AmenityIcons[amenity] || FallbackIcon)
                  return (
                    <div key={amenity} className="flex items-center gap-2 p-2">
                      <IconComponent className="w-5 h-5 text-gray-600" />
                      <span>{info?.label || amenity}</span>
                    </div>
                  )
                })}
                {(!accommodation.amenities || accommodation.amenities.length === 0) && (
                  <p className="text-gray-500 col-span-full">لا توجد مرافق محددة</p>
                )}
              </div>
            </div>

            <Separator />

            {/* House Rules */}
            <div>
              <h2 className="text-xl font-bold mb-4">قواعد المنزل</h2>
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  {accommodation.smokingAllowed ? <Check className="w-5 h-5 text-green-500" /> : <X className="w-5 h-5 text-red-500" />}
                  <span>{accommodation.smokingAllowed ? 'مسموح التدخين' : 'ممنوع التدخين'}</span>
                </div>
                <div className="flex items-center gap-2">
                  {accommodation.petsAllowed ? <Check className="w-5 h-5 text-green-500" /> : <X className="w-5 h-5 text-red-500" />}
                  <span>{accommodation.petsAllowed ? 'مسموح بالحيوانات الأليفة' : 'غير مسموح بالحيوانات الأليفة'}</span>
                </div>
                <div className="flex items-center gap-2">
                  {accommodation.partiesAllowed ? <Check className="w-5 h-5 text-green-500" /> : <X className="w-5 h-5 text-red-500" />}
                  <span>{accommodation.partiesAllowed ? 'مسموح بالحفلات' : 'غير مسموح بالحفلات'}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Clock className="w-5 h-5 text-gray-400" />
                  <span>تسجيل الوصول: {accommodation.checkInTime}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Clock className="w-5 h-5 text-gray-400" />
                  <span>تسجيل المغادرة: {accommodation.checkOutTime}</span>
                </div>
                {accommodation.minNights > 1 && (
                  <div className="flex items-center gap-2">
                    <Calendar className="w-5 h-5 text-gray-400" />
                    <span>الحد الأدنى: {accommodation.minNights} ليالي</span>
                  </div>
                )}
              </div>
            </div>

            <Separator />

            {/* Reviews */}
            <div>
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-bold flex items-center gap-2">
                  <Star className="w-5 h-5 text-amber-400 fill-amber-400" />
                  {accommodation.rating.toFixed(1)} · {accommodation.reviewCount} تقييم
                </h2>
              </div>

              {reviews.length > 0 ? (
                <div className="space-y-4">
                  {reviews.map((review) => (
                    <Card key={review.id} className="border-0 shadow-sm">
                      <CardContent className="p-4">
                        <div className="flex items-start gap-3">
                          <Avatar className="w-10 h-10">
                            <AvatarImage src={review.user.avatar || undefined} />
                            <AvatarFallback className="bg-gray-100">
                              {review.user.nameAr?.charAt(0) || review.user.name?.charAt(0) || 'ض'}
                            </AvatarFallback>
                          </Avatar>
                          <div className="flex-1">
                            <div className="flex items-center justify-between">
                              <p className="font-medium">{review.user.nameAr || review.user.name || 'ضيف'}</p>
                              <span className="text-sm text-gray-500">
                                {new Date(review.createdAt).toLocaleDateString('ar-SY')}
                              </span>
                            </div>
                            <div className="flex items-center gap-1 mt-1 mb-2">
                              {renderStars(review.rating)}
                            </div>
                            <p className="text-gray-600">{review.commentAr || review.commentEn}</p>
                            {review.hostResponse && (
                              <div className="mt-3 p-3 bg-gray-50 rounded-lg border-r-4 border-amber-400">
                                <p className="text-sm text-gray-500 mb-1">رد المضيف:</p>
                                <p className="text-gray-700">{review.hostResponse}</p>
                              </div>
                            )}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                  {accommodation.reviewCount > 5 && (
                    <Button variant="outline" className="w-full">
                      عرض كل التقييمات ({accommodation.reviewCount})
                    </Button>
                  )}
                </div>
              ) : (
                <p className="text-gray-500 text-center py-8">لا توجد تقييمات بعد</p>
              )}
            </div>
          </div>

          {/* Booking Sidebar */}
          <div className="lg:col-span-1">
            <div className="sticky top-24">
              <Card className="border-0 shadow-xl">
                <CardContent className="p-6">
                  {/* Price */}
                  <div className="mb-4">
                    <span className="text-2xl font-bold">{accommodation.basePrice.toLocaleString()}</span>
                    <span className="text-gray-500 mr-1">ل.س / ليلة</span>
                  </div>

                  {/* Date Pickers */}
                  <div className="space-y-3 mb-4">
                    <div className="grid grid-cols-2 gap-2">
                      <div className="border rounded-lg p-3">
                        <Label className="text-xs text-gray-500">تسجيل الوصول</Label>
                        <Input
                          type="date"
                          value={checkIn}
                          onChange={(e) => setCheckIn(e.target.value)}
                          min={new Date().toISOString().split('T')[0]}
                          className="border-0 p-0 h-auto text-base focus:ring-0"
                        />
                      </div>
                      <div className="border rounded-lg p-3">
                        <Label className="text-xs text-gray-500">تسجيل المغادرة</Label>
                        <Input
                          type="date"
                          value={checkOut}
                          onChange={(e) => setCheckOut(e.target.value)}
                          min={checkIn || new Date().toISOString().split('T')[0]}
                          className="border-0 p-0 h-auto text-base focus:ring-0"
                        />
                      </div>
                    </div>
                    <div className="border rounded-lg p-3">
                      <Label className="text-xs text-gray-500">عدد الضيوف</Label>
                      <div className="flex items-center justify-between">
                        <Button 
                          variant="outline" 
                          size="icon" 
                          className="w-8 h-8"
                          onClick={() => setGuests(Math.max(1, guests - 1))}
                        >
                          -
                        </Button>
                        <span className="font-medium">{guests} ضيف</span>
                        <Button 
                          variant="outline" 
                          size="icon" 
                          className="w-8 h-8"
                          onClick={() => setGuests(Math.min(accommodation.maxGuests, guests + 1))}
                        >
                          +
                        </Button>
                      </div>
                    </div>
                  </div>

                  {/* Pricing Breakdown */}
                  {pricing && (
                    <div className="space-y-2 mb-4 py-4 border-t border-b">
                      <div className="flex justify-between text-gray-600">
                        <span>{accommodation.basePrice.toLocaleString()} ل.س × {pricing.nights} ليالي</span>
                        <span>{pricing.baseAmount.toLocaleString()} ل.س</span>
                      </div>
                      {pricing.cleaningFee > 0 && (
                        <div className="flex justify-between text-gray-600">
                          <span>رسوم التنظيف</span>
                          <span>{pricing.cleaningFee.toLocaleString()} ل.س</span>
                        </div>
                      )}
                      <div className="flex justify-between text-gray-600">
                        <span>رسوم الخدمة</span>
                        <span>{pricing.serviceFee.toLocaleString()} ل.س</span>
                      </div>
                      <div className="flex justify-between font-bold text-lg pt-2">
                        <span>المجموع</span>
                        <span>{pricing.totalAmount.toLocaleString()} ل.س</span>
                      </div>
                    </div>
                  )}

                  {/* Book Button */}
                  <Button 
                    className="w-full h-12 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white rounded-lg shadow-lg"
                    onClick={handleBooking}
                    disabled={!checkIn || !checkOut}
                  >
                    احجز الآن
                  </Button>

                  {!checkIn && !checkOut && (
                    <p className="text-center text-sm text-gray-500 mt-2">اختر تواريخ للحجز</p>
                  )}

                  {/* Guarantee */}
                  <div className="mt-4 flex items-center justify-center gap-2 text-sm text-gray-500">
                    <Shield className="w-4 h-4 text-emerald-500" />
                    <span>حجز آمن مع ضمان ضيف</span>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

// Label component
function Label({ className, children }: { className?: string; children: React.ReactNode }) {
  return <span className={className}>{children}</span>
}
