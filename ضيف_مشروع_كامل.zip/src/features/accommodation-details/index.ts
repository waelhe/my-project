export { AccommodationDetailsView } from './components/AccommodationDetailsView'
