'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { useNavigation } from '@/shared/contexts/NavigationContext'
import { useFavorites } from '@/shared/contexts/FavoritesContext'
import { useAuth } from '@/shared/contexts/AuthContext'
import { ACCOMMODATION_TYPE_LABELS } from '@/shared/types'
import { Search, MapPin, Star, Heart, ArrowLeft, Home as HomeIcon, Loader2 } from 'lucide-react'
import { toast } from 'sonner'

interface Accommodation {
  id: string
  titleAr: string
  type: string
  addressAr: string | null
  basePrice: number
  rating: number
  reviewCount: number
  coverImage: string | null
  images: string[]
  city: { nameAr: string } | null
}

export function AccommodationsView() {
  const [accommodations, setAccommodations] = useState<Accommodation[]>([])
  const [loading, setLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedType, setSelectedType] = useState<string | null>(null)
  const { navigate } = useNavigation()
  const { isFavorite, toggleFavorite } = useFavorites()
  const { isAuthenticated } = useAuth()
  const [favoriteLoading, setFavoriteLoading] = useState<string | null>(null)

  const defaultImage = "/images/default-accommodation.png"

  useEffect(() => {
    const fetchAccommodations = async () => {
      try {
        const response = await fetch('/api/accommodations?limit=20')
        if (response.ok) {
          const data = await response.json()
          setAccommodations(data.accommodations || [])
        }
      } catch (error) {
        console.error('Error fetching accommodations:', error)
      } finally {
        setLoading(false)
      }
    }

    fetchAccommodations()
  }, [])

  const filteredAccommodations = accommodations.filter(acc => {
    const matchesSearch = !searchQuery || 
      acc.titleAr.toLowerCase().includes(searchQuery.toLowerCase()) ||
      acc.city?.nameAr.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesType = !selectedType || acc.type === selectedType
    return matchesSearch && matchesType
  })

  const handleFavoriteClick = async (e: React.MouseEvent, accommodationId: string) => {
    e.stopPropagation()
    
    if (!isAuthenticated) {
      toast.error('يرجى تسجيل الدخول لإضافة للمفضلة')
      return
    }

    setFavoriteLoading(accommodationId)
    const result = await toggleFavorite(accommodationId)
    setFavoriteLoading(null)

    if (result.success) {
      toast.success(result.added ? 'تمت الإضافة للمفضلة' : 'تمت الإزالة من المفضلة')
    } else {
      toast.error(result.error || 'حدث خطأ')
    }
  }

  const handleCardClick = (accommodationId: string) => {
    navigate('accommodation-details', { id: accommodationId })
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-gradient-to-r from-amber-500 to-orange-500 text-white py-12">
        <div className="container mx-auto px-4">
          <Button variant="ghost" className="text-white mb-4 cursor-pointer" onClick={() => navigate('home')}>
            <ArrowLeft className="w-4 h-4 ml-2" />
            العودة للرئيسية
          </Button>
          <h1 className="text-3xl md:text-4xl font-bold mb-2">أماكن الإقامة</h1>
          <p className="text-white/80 text-lg">اكتشف أفضل أماكن الإقامة في سوريا</p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col md:flex-row gap-4 mb-8">
          <div className="flex-1 relative">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
            <Input
              placeholder="ابحث عن مكان إقامة..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pr-10"
            />
          </div>
          <div className="flex gap-2 flex-wrap">
            <Button
              variant={selectedType === null ? "default" : "outline"}
              onClick={() => setSelectedType(null)}
              className={selectedType === null ? "bg-amber-500 hover:bg-amber-600 cursor-pointer" : "cursor-pointer"}
            >
              الكل
            </Button>
            {Object.entries(ACCOMMODATION_TYPE_LABELS).slice(0, 4).map(([type, label]) => (
              <Button
                key={type}
                variant={selectedType === type ? "default" : "outline"}
                onClick={() => setSelectedType(type)}
                className={selectedType === type ? "bg-amber-500 hover:bg-amber-600 cursor-pointer" : "cursor-pointer"}
              >
                {label}
              </Button>
            ))}
          </div>
        </div>

        <p className="text-gray-600 mb-4">عرض {filteredAccommodations.length} مكان إقامة</p>

        {loading ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {[1, 2, 3, 4, 5, 6, 7, 8].map((i) => (
              <div key={i} className="bg-gray-100 rounded-xl animate-pulse">
                <div className="h-48 bg-gray-200 rounded-t-xl" />
                <div className="p-4 space-y-2">
                  <div className="h-4 bg-gray-200 rounded w-3/4" />
                  <div className="h-4 bg-gray-200 rounded w-1/2" />
                </div>
              </div>
            ))}
          </div>
        ) : filteredAccommodations.length > 0 ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredAccommodations.map((acc) => {
              const displayImage = acc.coverImage || (acc.images && acc.images[0]) || defaultImage
              const location = acc.city ? `${acc.city.nameAr}` : 'سوريا'
              const isFav = isFavorite(acc.id)
              
              return (
                <Card 
                  key={acc.id} 
                  className="group overflow-hidden border-0 shadow-md hover:shadow-xl transition-all duration-300 cursor-pointer bg-white"
                  onClick={() => handleCardClick(acc.id)}
                >
                  <div className="relative h-48 overflow-hidden">
                    <img src={displayImage} alt={acc.titleAr} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" loading="lazy" />
                    {acc.rating >= 4.8 && <Badge className="absolute top-3 right-3 bg-amber-500 text-white">مميز</Badge>}
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className={`absolute top-3 left-3 bg-white/80 hover:bg-white rounded-full h-8 w-8 cursor-pointer ${isFav ? 'text-red-500' : 'text-gray-600'}`}
                      onClick={(e) => handleFavoriteClick(e, acc.id)}
                      disabled={favoriteLoading === acc.id}
                    >
                      {favoriteLoading === acc.id ? (
                        <Loader2 className="w-4 h-4 animate-spin" />
                      ) : (
                        <Heart className={`w-4 h-4 ${isFav ? 'fill-red-500' : ''}`} />
                      )}
                    </Button>
                  </div>
                  <CardContent className="p-4">
                    <div className="flex items-center text-sm text-gray-500 mb-2">
                      <MapPin className="w-3 h-3 ml-1" />
                      {location}
                    </div>
                    <h3 className="font-semibold text-gray-900 mb-2 line-clamp-1">{acc.titleAr}</h3>
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center">
                        <Star className="w-4 h-4 text-amber-400 fill-amber-400 ml-1" />
                        <span className="font-medium text-sm">{acc.rating.toFixed(1)}</span>
                        <span className="text-gray-400 text-sm mr-1">({acc.reviewCount})</span>
                      </div>
                      <Badge variant="secondary" className="text-xs">{ACCOMMODATION_TYPE_LABELS[acc.type] || acc.type}</Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <div>
                        <span className="font-bold text-lg text-gray-900">{acc.basePrice.toLocaleString()}</span>
                        <span className="text-gray-500 text-sm mr-1">ل.س / ليلة</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        ) : (
          <div className="text-center py-12">
            <HomeIcon className="w-12 h-12 text-gray-300 mx-auto mb-4" />
            <p className="text-gray-500">لا توجد أماكن إقامة تطابق بحثك</p>
          </div>
        )}
      </div>
    </div>
  )
}
