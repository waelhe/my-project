export { AccommodationsView } from './components/AccommodationsView'
