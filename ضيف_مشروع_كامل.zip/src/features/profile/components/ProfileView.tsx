'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { 
  User as UserIcon, Settings, Calendar, Heart, MessageSquare, 
  Star, LogOut, Camera, Save, Loader2, MapPin, Phone, Mail,
  Building2, Shield, ChevronLeft
} from 'lucide-react'
import { useAuth } from '@/shared/contexts/AuthContext'
import { useNavigation } from '@/shared/contexts/NavigationContext'
import { useFavorites } from '@/shared/contexts/FavoritesContext'
import { toast } from 'sonner'
import { BOOKING_STATUS_LABELS, BookingStatus } from '@/shared/types'

// ==================== Profile View ====================

export function ProfileView() {
  const { user, logout, updateProfile, loading: authLoading } = useAuth()
  const { navigate } = useNavigation()
  const { favorites } = useFavorites()
  const [activeTab, setActiveTab] = useState('info')
  const [editing, setEditing] = useState(false)
  const [saving, setSaving] = useState(false)
  const [formData, setFormData] = useState({
    name: user?.name || '',
    nameAr: user?.nameAr || '',
    email: user?.email || '',
    city: user?.city || ''
  })
  const [bookings, setBookings] = useState<any[]>([])
  const [bookingsLoading, setBookingsLoading] = useState(true)

  // Load bookings
  useState(() => {
    const loadBookings = async () => {
      try {
        const res = await fetch('/api/bookings')
        if (res.ok) {
          const data = await res.json()
          setBookings(data.bookings || [])
        }
      } catch (error) {
        console.error('Error loading bookings:', error)
      } finally {
        setBookingsLoading(false)
      }
    }
    loadBookings()
  })

  const handleSave = async () => {
    setSaving(true)
    const result = await updateProfile(formData)
    setSaving(false)
    
    if (result.success) {
      toast.success('تم حفظ التغييرات')
      setEditing(false)
    } else {
      toast.error(result.error || 'حدث خطأ')
    }
  }

  const handleLogout = async () => {
    await logout()
    navigate('home')
    toast.success('تم تسجيل الخروج')
  }

  const getInitials = () => {
    if (user?.nameAr) return user.nameAr.charAt(0)
    if (user?.name) return user.name.charAt(0)
    return 'ض'
  }

  const getRoleBadge = () => {
    switch (user?.role) {
      case 'HOST':
        return <Badge className="bg-amber-500">مضيف</Badge>
      case 'ADMIN':
        return <Badge className="bg-red-500">مدير</Badge>
      case 'SUPER_ADMIN':
        return <Badge className="bg-purple-500">مدير عام</Badge>
      default:
        return <Badge className="bg-emerald-500">ضيف</Badge>
    }
  }

  if (authLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-amber-500" />
      </div>
    )
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Card className="w-full max-w-md mx-4">
          <CardContent className="p-6 text-center">
            <UserIcon className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <h2 className="text-xl font-bold mb-2">يرجى تسجيل الدخول</h2>
            <p className="text-gray-500 mb-4">تحتاج لتسجيل الدخول للوصول لملفك الشخصي</p>
            <Button onClick={() => navigate('home')} className="bg-amber-500 hover:bg-amber-600">
              العودة للرئيسية
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-amber-500 to-orange-500 text-white py-8">
        <div className="container mx-auto px-4">
          <Button variant="ghost" className="text-white mb-4" onClick={() => navigate('home')}>
            <ChevronLeft className="w-4 h-4 ml-2" />
            العودة للرئيسية
          </Button>
          <div className="flex items-center gap-4">
            <div className="relative">
              <Avatar className="w-20 h-20 border-4 border-white">
                <AvatarImage src={user.avatar || undefined} />
                <AvatarFallback className="bg-amber-600 text-2xl">{getInitials()}</AvatarFallback>
              </Avatar>
              <Button size="icon" className="absolute -bottom-1 -left-1 w-8 h-8 rounded-full bg-white text-amber-500 hover:bg-gray-100">
                <Camera className="w-4 h-4" />
              </Button>
            </div>
            <div>
              <h1 className="text-2xl font-bold">{user.nameAr || user.name || 'ضيف'}</h1>
              <div className="flex items-center gap-2 mt-1">
                {getRoleBadge()}
                {user.isVerified && (
                  <Badge className="bg-white/20">
                    <Shield className="w-3 h-3 ml-1" />
                    موثق
                  </Badge>
                )}
              </div>
              {user.city && (
                <p className="text-white/80 text-sm mt-1 flex items-center gap-1">
                  <MapPin className="w-3 h-3" />
                  {user.city}
                </p>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="container mx-auto px-4 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="mb-6 flex flex-wrap gap-2 bg-white p-2 rounded-lg shadow-sm">
            <TabsTrigger value="info" className="gap-2">
              <UserIcon className="w-4 h-4" />
              معلوماتي
            </TabsTrigger>
            <TabsTrigger value="bookings" className="gap-2">
              <Calendar className="w-4 h-4" />
              حجوزاتي
            </TabsTrigger>
            <TabsTrigger value="favorites" className="gap-2">
              <Heart className="w-4 h-4" />
              المفضلة
            </TabsTrigger>
            <TabsTrigger value="settings" className="gap-2">
              <Settings className="w-4 h-4" />
              الإعدادات
            </TabsTrigger>
          </TabsList>

          {/* Info Tab */}
          <TabsContent value="info">
            <Card className="border-0 shadow-md">
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle>المعلومات الشخصية</CardTitle>
                <Button 
                  variant="outline" 
                  onClick={() => editing ? setEditing(false) : setEditing(true)}
                >
                  {editing ? 'إلغاء' : 'تعديل'}
                </Button>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="nameAr">الاسم بالعربية</Label>
                    <Input
                      id="nameAr"
                      value={formData.nameAr}
                      onChange={(e) => setFormData({ ...formData, nameAr: e.target.value })}
                      disabled={!editing}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="name">الاسم بالإنجليزية</Label>
                    <Input
                      id="name"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      disabled={!editing}
                      dir="ltr"
                    />
                  </div>
                </div>
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="phone">رقم الهاتف</Label>
                    <div className="relative">
                      <Phone className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                      <Input
                        id="phone"
                        value={user.phone}
                        disabled
                        className="pr-10 bg-gray-50"
                        dir="ltr"
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">البريد الإلكتروني</Label>
                    <div className="relative">
                      <Mail className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                      <Input
                        id="email"
                        type="email"
                        value={formData.email || ''}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        disabled={!editing}
                        className="pr-10"
                        dir="ltr"
                      />
                    </div>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="city">المدينة</Label>
                  <div className="relative">
                    <MapPin className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                    <Input
                      id="city"
                      value={formData.city || ''}
                      onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                      disabled={!editing}
                      className="pr-10"
                    />
                  </div>
                </div>

                {editing && (
                  <Button onClick={handleSave} disabled={saving} className="w-full bg-amber-500 hover:bg-amber-600">
                    {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4 ml-2" />}
                    حفظ التغييرات
                  </Button>
                )}
              </CardContent>
            </Card>

            {user.role === 'HOST' && (
              <Card className="border-0 shadow-md mt-4">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Building2 className="w-5 h-5" />
                    معلومات المضيف
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <Label className="text-gray-500">اسم النشاط</Label>
                      <p className="font-medium">{user.businessNameAr || user.businessName || 'غير محدد'}</p>
                    </div>
                    <div>
                      <Label className="text-gray-500">نوع النشاط</Label>
                      <p className="font-medium">{user.businessType === 'individual' ? 'فرد' : 'شركة'}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          {/* Bookings Tab */}
          <TabsContent value="bookings">
            <div className="space-y-4">
              {bookingsLoading ? (
                <div className="flex justify-center py-8">
                  <Loader2 className="w-8 h-8 animate-spin text-amber-500" />
                </div>
              ) : bookings.length === 0 ? (
                <Card className="border-0 shadow-md">
                  <CardContent className="p-8 text-center">
                    <Calendar className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                    <h3 className="text-lg font-bold mb-2">لا توجد حجوزات</h3>
                    <p className="text-gray-500 mb-4">لم تقم بأي حجز بعد</p>
                    <Button onClick={() => navigate('accommodations')} className="bg-amber-500 hover:bg-amber-600">
                      استكشف الإقامات
                    </Button>
                  </CardContent>
                </Card>
              ) : (
                bookings.map((booking) => {
                  const status = booking.status as BookingStatus
                  const statusInfo = BOOKING_STATUS_LABELS[status] || { label: status, color: 'bg-gray-100 text-gray-700' }
                  
                  return (
                    <Card key={booking.id} className="border-0 shadow-md hover:shadow-lg transition-shadow cursor-pointer"
                      onClick={() => navigate('booking-confirmation', { id: booking.id })}
                    >
                      <CardContent className="p-4">
                        <div className="flex gap-4">
                          <div className="w-24 h-24 rounded-lg overflow-hidden bg-gray-200 shrink-0">
                            <img 
                              src={booking.accommodation?.coverImage || '/images/default-accommodation.png'} 
                              alt={booking.accommodation?.titleAr}
                              className="w-full h-full object-cover"
                            />
                          </div>
                          <div className="flex-1">
                            <div className="flex items-start justify-between">
                              <div>
                                <h3 className="font-bold text-gray-900">{booking.accommodation?.titleAr}</h3>
                                <p className="text-sm text-gray-500">{booking.confirmationCode}</p>
                              </div>
                              <Badge className={statusInfo.color}>{statusInfo.label}</Badge>
                            </div>
                            <div className="flex items-center gap-4 mt-2 text-sm text-gray-600">
                              <span className="flex items-center gap-1">
                                <Calendar className="w-3 h-3" />
                                {new Date(booking.checkIn).toLocaleDateString('ar-SY')}
                              </span>
                              <span>→</span>
                              <span>{new Date(booking.checkOut).toLocaleDateString('ar-SY')}</span>
                            </div>
                            <div className="flex items-center justify-between mt-2">
                              <span className="text-sm text-gray-500">{booking.nightsCount} ليالي • {booking.guestsCount} ضيوف</span>
                              <span className="font-bold text-amber-600">{booking.totalAmount.toLocaleString()} ل.س</span>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  )
                })
              )}
            </div>
          </TabsContent>

          {/* Favorites Tab */}
          <TabsContent value="favorites">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              {favorites.length === 0 ? (
                <Card className="col-span-full border-0 shadow-md">
                  <CardContent className="p-8 text-center">
                    <Heart className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                    <h3 className="text-lg font-bold mb-2">قائمة المفضلة فارغة</h3>
                    <p className="text-gray-500 mb-4">أضف الإقامات التي تعجبك للمفضلة</p>
                    <Button onClick={() => navigate('accommodations')} className="bg-amber-500 hover:bg-amber-600">
                      استكشف الإقامات
                    </Button>
                  </CardContent>
                </Card>
              ) : (
                favorites.map((fav) => (
                  <Card key={fav.id} className="border-0 shadow-md hover:shadow-lg transition-shadow cursor-pointer overflow-hidden"
                    onClick={() => navigate('accommodation-details', { id: fav.accommodationId })}
                  >
                    <div className="h-40 bg-gray-200">
                      <img 
                        src={fav.accommodation.coverImage || '/images/default-accommodation.png'} 
                        alt={fav.accommodation.titleAr}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <CardContent className="p-4">
                      <h3 className="font-bold text-gray-900 mb-1">{fav.accommodation.titleAr}</h3>
                      <p className="text-sm text-gray-500 mb-2">{fav.accommodation.city?.nameAr}</p>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-1">
                          <Star className="w-4 h-4 text-amber-400 fill-amber-400" />
                          <span className="text-sm">{fav.accommodation.rating.toFixed(1)}</span>
                        </div>
                        <span className="font-bold text-amber-600">{fav.accommodation.basePrice.toLocaleString()} ل.س</span>
                      </div>
                    </CardContent>
                  </Card>
                ))
              )}
            </div>
          </TabsContent>

          {/* Settings Tab */}
          <TabsContent value="settings">
            <Card className="border-0 shadow-md">
              <CardHeader>
                <CardTitle>إعدادات الحساب</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="p-4 border rounded-lg flex items-center justify-between">
                  <div>
                    <h4 className="font-medium">تغيير كلمة المرور</h4>
                    <p className="text-sm text-gray-500">تحديث كلمة مرور حسابك</p>
                  </div>
                  <Button variant="outline">تغيير</Button>
                </div>
                <div className="p-4 border rounded-lg flex items-center justify-between">
                  <div>
                    <h4 className="font-medium">إشعارات البريد الإلكتروني</h4>
                    <p className="text-sm text-gray-500">إدارة إشعارات البريد</p>
                  </div>
                  <Button variant="outline">إدارة</Button>
                </div>
                <div className="p-4 border rounded-lg flex items-center justify-between bg-red-50 border-red-200">
                  <div>
                    <h4 className="font-medium text-red-700">تسجيل الخروج</h4>
                    <p className="text-sm text-red-500">تسجيل الخروج من حسابك</p>
                  </div>
                  <Button variant="destructive" onClick={handleLogout}>
                    <LogOut className="w-4 h-4 ml-2" />
                    خروج
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
