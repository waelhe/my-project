export { HomeView } from './components/HomeView'
export {
  HeroSection,
  ServicesSection,
  PopularDestinations,
  FeaturedAccommodations,
  HowItWorks,
  TrustSection,
  CTASection,
  HostCTA
} from './components/HomeSections'
