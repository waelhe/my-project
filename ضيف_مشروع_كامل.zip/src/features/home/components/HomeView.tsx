'use client'

import { useState, useEffect } from 'react'
import { useNavigation } from '@/shared/contexts/NavigationContext'
import {
  HeroSection,
  ServicesSection,
  PopularDestinations,
  FeaturedAccommodations,
  HowItWorks,
  TrustSection,
  CTASection,
  HostCTA
} from './HomeSections'

interface City {
  id: string
  nameAr: string
  governorate: string
  image: string | null
  _count: { accommodations: number }
}

interface Accommodation {
  id: string
  titleAr: string
  type: string
  addressAr: string | null
  basePrice: number
  rating: number
  reviewCount: number
  coverImage: string | null
  images: string[]
  city: { nameAr: string } | null
}

export function HomeView() {
  const [cities, setCities] = useState<City[]>([])
  const [citiesLoading, setCitiesLoading] = useState(true)
  const [accommodations, setAccommodations] = useState<Accommodation[]>([])
  const [accommodationsLoading, setAccommodationsLoading] = useState(true)
  const { navigate } = useNavigation()

  const [stats, setStats] = useState({
    totalAccommodations: 500,
    totalCities: 50
  })

  useEffect(() => {
    fetch('/api/cities')
      .then(async (response) => {
        if (!response.ok) throw new Error('فشل في جلب البيانات')
        const data = await response.json()
        setCities(data.cities || [])
        setStats(prev => ({ ...prev, totalCities: data.cities?.length || 0 }))
      })
      .catch((err) => console.error('Error fetching cities:', err))
      .finally(() => setCitiesLoading(false))

    fetch('/api/accommodations?limit=4')
      .then(async (response) => {
        if (!response.ok) throw new Error('فشل في جلب البيانات')
        const data = await response.json()
        setAccommodations(data.accommodations || [])
        setStats(prev => ({ ...prev, totalAccommodations: data.pagination?.total || data.accommodations?.length || 0 }))
      })
      .catch((err) => console.error('Error fetching accommodations:', err))
      .finally(() => setAccommodationsLoading(false))
  }, [])

  return (
    <main>
      <HeroSection 
        totalAccommodations={stats.totalAccommodations}
        totalCities={stats.totalCities}
        onSearch={() => navigate('accommodations')}
      />
      <ServicesSection onNavigate={navigate} />
      <PopularDestinations cities={cities} loading={citiesLoading} onNavigate={navigate} />
      <FeaturedAccommodations accommodations={accommodations} loading={accommodationsLoading} onNavigate={navigate} />
      <HowItWorks />
      <TrustSection />
      <CTASection onNavigate={navigate} />
      <HostCTA onNavigate={navigate} />
    </main>
  )
}
