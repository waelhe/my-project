'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Card, CardContent } from '@/components/ui/card'
import { 
  Search, MapPin, Star, Heart, Shield, Users, CheckCircle2, 
  ArrowLeft, Home as HomeIcon, Car, Compass, Building2, 
  ChevronLeft, ChevronRight, Sparkles 
} from 'lucide-react'
import { PageType } from '@/shared/types'
import { useAuth } from '@/shared/contexts/AuthContext'
import { useAuthModal } from '@/shared/contexts/AuthModalContext'
import { useNavigation } from '@/shared/contexts/NavigationContext'

// ==================== Types ====================

interface City {
  id: string
  nameAr: string
  governorate: string
  image: string | null
  _count: { accommodations: number }
}

interface Accommodation {
  id: string
  titleAr: string
  type: string
  addressAr: string | null
  basePrice: number
  rating: number
  reviewCount: number
  coverImage: string | null
  images: string[]
  city: { nameAr: string } | null
}

const ACCOMMODATION_TYPE_LABELS: Record<string, string> = {
  HOTEL: "فندق", APARTMENT: "شقة", VILLA: "فيلا", CHALET: "شاليه",
  CAMP: "مخيم", GUESTHOUSE: "نزل", HOSTEL: "سكن شباب", RESORT: "منتجع"
}

// ==================== Hero Section ====================

export function HeroSection({ 
  totalAccommodations, 
  totalCities, 
  onSearch 
}: { 
  totalAccommodations: number
  totalCities: number
  onSearch: () => void 
}) {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedType, setSelectedType] = useState("all")
  const [currentSlide, setCurrentSlide] = useState(0)
  const [isTransitioning, setIsTransitioning] = useState(false)

  const destinations = [
    { name: "دمشق", description: "أقدم عاصمة مأهولة في العالم - الجامع الأموي والأسواق التاريخية", image: "/images/cities/damascus.png" },
    { name: "حلب", description: "قلعة حلب - من أعظم القلاع في العالم", image: "/images/cities/aleppo.png" },
    { name: "اللاذقية", description: "سحر البحر المتوسط - شواطئ خلابة ومنتجعات سياحية", image: "/images/cities/latakia.png" },
    { name: "تدمر", description: "عروس الصحراء - آثار رومانية تراث عالمي", image: "/images/cities/palmyra.png" },
    { name: "معلولا", description: "دير مار تقلا - مدينة الكهوف والتاريخ", image: "/images/cities/maaloula.png" },
    { name: "حمص", description: "قلعة الحصن - كراك دي شوفالييه العظيمة", image: "/images/cities/homs.png" },
  ]

  const searchTypes = [
    { id: "all", label: "الكل" },
    { id: "hotel", label: "فنادق" },
    { id: "apartment", label: "شقق" },
    { id: "chalet", label: "شاليهات" },
    { id: "tour", label: "جولات" },
  ]

  useEffect(() => {
    const interval = setInterval(() => {
      setIsTransitioning(true)
      setTimeout(() => {
        setCurrentSlide((prev) => (prev + 1) % destinations.length)
        setIsTransitioning(false)
      }, 500)
    }, 5000)
    return () => clearInterval(interval)
  }, [destinations.length])

  const goToSlide = (index: number) => {
    setIsTransitioning(true)
    setTimeout(() => {
      setCurrentSlide(index)
      setIsTransitioning(false)
    }, 500)
  }

  return (
    <section className="relative min-h-[60vh] md:min-h-[75vh] flex items-center justify-center overflow-hidden">
      {destinations.map((dest, index) => (
        <div
          key={index}
          className={`absolute inset-0 bg-cover bg-center transition-all duration-1000 ease-in-out ${
            index === currentSlide ? 'opacity-100 scale-100' : 'opacity-0 scale-105'
          }`}
          style={{ backgroundImage: `url('${dest.image}')` }}
        />
      ))}
      
      <div className="absolute inset-0 bg-gradient-to-b from-black/50 via-black/30 to-black/80" />
      
      <div className="relative z-10 w-full max-w-7xl mx-auto px-4 sm:px-6 text-center pt-8 sm:pt-12">
        <div className="mb-4 sm:mb-6 flex justify-center">
          <div className="bg-white/20 backdrop-blur-md rounded-full px-4 sm:px-6 py-2 sm:py-3 flex items-center gap-2">
            <Sparkles className="w-4 h-4 sm:w-5 sm:h-5 text-amber-400" />
            <span className="text-white text-sm sm:text-base font-medium">منصة ضيف السياحية</span>
          </div>
        </div>
        
        <h2 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-4 sm:mb-6 leading-tight px-2">
          اكتشف جمال <span className="bg-gradient-to-r from-amber-300 to-orange-300 bg-clip-text text-transparent">سوريا</span>
        </h2>
        
        <div className={`mb-4 sm:mb-6 transition-all duration-1000 ${isTransitioning ? 'opacity-0 translate-y-2' : 'opacity-100 translate-y-0'}`}>
          <div className="flex items-center justify-center gap-2 mb-2">
            <MapPin className="w-5 h-5 sm:w-6 sm:h-6 text-amber-300" />
            <span className="text-xl sm:text-2xl md:text-3xl font-bold text-white">{destinations[currentSlide].name}</span>
          </div>
          <p className="text-white/90 text-sm sm:text-base md:text-lg max-w-2xl mx-auto px-4 font-medium leading-relaxed drop-shadow-md">
            {destinations[currentSlide].description}
          </p>
        </div>
        
        <div className="w-full max-w-4xl mx-auto bg-white/95 backdrop-blur-sm rounded-2xl shadow-2xl p-4 sm:p-6 md:p-8 mb-6 sm:mb-8 border border-amber-100">
          <div className="text-center mb-4 sm:mb-6">
            <p className="text-base sm:text-lg md:text-xl text-gray-800 font-semibold leading-relaxed">
              احجز إقامتك وجولاتك بكل أمان مع أفضل المضيفين المحليين
            </p>
            <div className="flex items-center justify-center gap-4 mt-3">
              <div className="flex items-center gap-1.5">
                <Shield className="w-4 h-4 text-emerald-500" />
                <span className="text-sm text-gray-700">حجز آمن</span>
              </div>
              <div className="w-1 h-1 rounded-full bg-emerald-300" />
              <div className="flex items-center gap-1.5">
                <Users className="w-4 h-4 text-emerald-500" />
                <span className="text-sm text-gray-700">مضيفون موثوقون</span>
              </div>
            </div>
          </div>
          
          <div className="flex flex-wrap gap-2 mb-4 sm:mb-6 justify-center">
            {searchTypes.map((type) => (
              <Button
                key={type.id}
                variant={selectedType === type.id ? "default" : "outline"}
                onClick={() => setSelectedType(type.id)}
                className={`rounded-full px-4 sm:px-6 text-sm sm:text-base ${selectedType === type.id ? "bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white border-0" : "border-emerald-200 text-gray-700 hover:bg-emerald-50"}`}
              >
                {type.label}
              </Button>
            ))}
          </div>
          
          <div className="flex flex-col sm:flex-row gap-3 sm:gap-4">
            <div className="flex-1 relative">
              <Search className="absolute right-3 sm:right-4 top-1/2 -translate-y-1/2 text-emerald-500 w-4 h-4 sm:w-5 sm:h-5" />
              <Input
                type="text"
                placeholder="ابحث عن وجهتك..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="h-12 sm:h-14 pr-10 sm:pr-12 text-base sm:text-lg border-emerald-200 rounded-xl focus:border-emerald-500 focus:ring-emerald-500"
              />
            </div>
            <Button size="lg" onClick={onSearch} className="h-12 sm:h-14 px-6 sm:px-8 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white rounded-xl shadow-lg shadow-amber-500/25">
              <Search className="w-4 h-4 sm:w-5 sm:h-5 ml-2" />
              بحث
            </Button>
          </div>
          
          <div className="flex flex-wrap justify-center gap-4 sm:gap-8 mt-4 sm:mt-6 pt-4 sm:pt-6 border-t border-emerald-100">
            <div className="text-center">
              <div className="text-xl sm:text-2xl font-bold text-emerald-600">+{totalAccommodations}</div>
              <div className="text-xs sm:text-sm text-gray-600">مكان إقامة</div>
            </div>
            <div className="text-center">
              <div className="text-xl sm:text-2xl font-bold text-teal-600">+{totalCities}</div>
              <div className="text-xs sm:text-sm text-gray-600">وجهة سياحية</div>
            </div>
            <div className="text-center">
              <div className="text-xl sm:text-2xl font-bold text-amber-500">+10,000</div>
              <div className="text-xs sm:text-sm text-gray-600">ضيف سعيد</div>
            </div>
          </div>
        </div>
      </div>
      
      <button onClick={() => goToSlide((currentSlide - 1 + destinations.length) % destinations.length)} className="absolute right-4 sm:right-8 top-1/2 -translate-y-1/2 z-20 w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-white/10 backdrop-blur-md hover:bg-white/20 flex items-center justify-center transition-all duration-300 group">
        <ChevronRight className="w-5 h-5 sm:w-6 sm:h-6 text-white group-hover:scale-110 transition-transform" />
      </button>
      <button onClick={() => goToSlide((currentSlide + 1) % destinations.length)} className="absolute left-4 sm:left-8 top-1/2 -translate-y-1/2 z-20 w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-white/10 backdrop-blur-md hover:bg-white/20 flex items-center justify-center transition-all duration-300 group">
        <ChevronLeft className="w-5 h-5 sm:w-6 sm:h-6 text-white group-hover:scale-110 transition-transform" />
      </button>
      
      <div className="absolute bottom-6 sm:bottom-8 left-1/2 -translate-x-1/2 z-20 flex items-center gap-2">
        {destinations.map((_, index) => (
          <button key={index} onClick={() => goToSlide(index)} className={`h-2 rounded-full transition-all duration-300 ${index === currentSlide ? 'w-6 bg-white' : 'w-2 bg-white/50 hover:bg-white/70'}`} />
        ))}
      </div>
    </section>
  )
}

// ==================== Services Section ====================

export function ServicesSection({ onNavigate }: { onNavigate: (page: PageType) => void }) {
  const services = [
    { icon: HomeIcon, title: "السكن", description: "فنادق، شقق مفروشة، شاليهات، ومخيمات في جميع أنحاء سوريا", color: "bg-amber-500", page: 'accommodations' as PageType },
    { icon: Car, title: "النقل", description: "سيارات مع أو بدون سائق، باصات، وخدمات نقل آمنة", color: "bg-emerald-500", page: 'home' as PageType },
    { icon: Compass, title: "السياحة", description: "جولات سياحية، معالم تاريخية، سياحة علاجية وسياحة حرب", color: "bg-sky-500", page: 'home' as PageType },
    { icon: Building2, title: "الأعمال", description: "فرص استثمارية، خدمات للأعمال، وشراكات تجارية", color: "bg-violet-500", page: 'home' as PageType }
  ]

  return (
    <section className="py-20 bg-gradient-to-b from-gray-50 to-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <Badge className="mb-4 bg-amber-100 text-amber-700 hover:bg-amber-100">خدماتنا</Badge>
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">كل ما تحتاجه لرحلتك في مكان واحد</h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">نقدم لك مجموعة متكاملة من الخدمات لتجعل رحلتك إلى سوريا تجربة لا تُنسى</p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {services.map((service, index) => (
            <Card key={index} className="group hover:shadow-xl transition-all duration-300 border-0 bg-white cursor-pointer overflow-hidden" onClick={() => onNavigate(service.page)}>
              <CardContent className="p-6">
                <div className={`w-14 h-14 ${service.color} rounded-2xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                  <service.icon className="w-7 h-7 text-white" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">{service.title}</h3>
                <p className="text-gray-500 text-sm mb-4">{service.description}</p>
                <Button variant="ghost" className="text-amber-600 hover:text-amber-700 p-0 group/btn">
                  اكتشف المزيد
                  <ArrowLeft className="w-4 h-4 mr-2 group-hover/btn:-translate-x-1 transition-transform" />
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}

// ==================== Popular Destinations ====================

export function PopularDestinations({ cities, loading, onNavigate }: { cities: City[]; loading: boolean; onNavigate: (page: PageType) => void }) {
  const defaultCityImages: Record<string, string> = {
    "دمشق": "/images/cities/damascus.png",
    "حلب": "/images/cities/aleppo.png",
    "اللاذقية": "/images/cities/latakia.png",
    "طرطوس": "/images/cities/tartus.png",
    "تدمر": "/images/cities/palmyra.png",
    "معلولا": "/images/cities/maaloula.png",
  }
  const defaultImage = "/images/cities/damascus.png"

  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <Badge className="mb-4 bg-sky-100 text-sky-700 hover:bg-sky-100">وجهات مميزة</Badge>
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">اكتشف أجمل الأماكن في سوريا</h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">من المدن التاريخية إلى السواحل الخلابة، سوريا تنتظرك</p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {loading ? (
            [1, 2, 3, 4, 5, 6].map((i) => (
              <div key={i} className="h-64 bg-gray-100 rounded-xl animate-pulse overflow-hidden">
                <div className="h-full bg-gradient-to-b from-gray-200 to-gray-100" />
              </div>
            ))
          ) : (
            cities.slice(0, 6).map((city) => (
              <Card key={city.id} className="group overflow-hidden border-0 shadow-lg hover:shadow-2xl transition-all duration-300 cursor-pointer" onClick={() => onNavigate('accommodations')}>
                <div className="relative h-64 overflow-hidden bg-gray-200">
                  <img 
                    src={city.image || defaultCityImages[city.nameAr] || defaultImage} 
                    alt={`صورة لمدينة ${city.nameAr}`} 
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" 
                    loading="lazy" 
                    onError={(e) => { e.currentTarget.src = defaultImage }} 
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent" />
                  <div className="absolute bottom-0 right-0 left-0 p-6">
                    <h3 className="text-2xl font-bold text-white mb-1">{city.nameAr}</h3>
                    <p className="text-white/80 text-sm mb-2">{city.governorate}</p>
                    <div className="flex items-center text-white/70 text-sm">
                      <HomeIcon className="w-4 h-4 ml-1" />
                      <span>{city._count.accommodations} مكان إقامة</span>
                    </div>
                  </div>
                </div>
              </Card>
            ))
          )}
        </div>
      </div>
    </section>
  )
}

// ==================== Featured Accommodations ====================

export function FeaturedAccommodations({ accommodations, loading, onNavigate }: { accommodations: Accommodation[]; loading: boolean; onNavigate: (page: PageType, params?: Record<string, string>) => void }) {
  const defaultImage = "/images/default-accommodation.png"

  if (loading) {
    return (
      <section className="py-20 bg-gradient-to-b from-white to-gray-50">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="bg-gray-100 rounded-xl animate-pulse">
                <div className="h-48 bg-gray-200 rounded-t-xl" />
                <div className="p-4 space-y-2">
                  <div className="h-4 bg-gray-200 rounded w-3/4" />
                  <div className="h-4 bg-gray-200 rounded w-1/2" />
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    )
  }

  return (
    <section className="py-20 bg-gradient-to-b from-white to-gray-50">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-end mb-12">
          <div>
            <Badge className="mb-4 bg-amber-100 text-amber-700 hover:bg-amber-100">أماكن مميزة</Badge>
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900">أماكن الإقامة الأكثر طلباً</h2>
          </div>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {accommodations.slice(0, 4).map((acc) => {
            const displayImage = acc.coverImage || (acc.images && acc.images[0]) || defaultImage
            const location = acc.city ? `${acc.city.nameAr}${acc.addressAr ? '، ' + acc.addressAr : ''}` : acc.addressAr || 'سوريا'
            
            return (
              <Card key={acc.id} className="group overflow-hidden border-0 shadow-md hover:shadow-xl transition-all duration-300 cursor-pointer bg-white" onClick={() => onNavigate('accommodation-details', { id: acc.id })}>
                <div className="relative h-48 overflow-hidden">
                  <img src={displayImage} alt={`صورة ${acc.titleAr}`} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" loading="lazy" />
                  {acc.rating >= 4.8 && <Badge className="absolute top-3 right-3 bg-amber-500 text-white">مميز</Badge>}
                </div>
                <CardContent className="p-4">
                  <div className="flex items-center text-sm text-gray-500 mb-2">
                    <MapPin className="w-3 h-3 ml-1" />{location}
                  </div>
                  <h3 className="font-semibold text-gray-900 mb-2 line-clamp-1">{acc.titleAr}</h3>
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center">
                      <Star className="w-4 h-4 text-amber-400 fill-amber-400 ml-1" />
                      <span className="font-medium text-sm">{acc.rating.toFixed(1)}</span>
                      <span className="text-gray-400 text-sm mr-1">({acc.reviewCount})</span>
                    </div>
                    <Badge variant="secondary" className="text-xs">{ACCOMMODATION_TYPE_LABELS[acc.type] || acc.type}</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="font-bold text-lg text-gray-900">{acc.basePrice.toLocaleString()}</span>
                      <span className="text-gray-500 text-sm mr-1">ل.س / ليلة</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </div>
      </div>
    </section>
  )
}

// ==================== How It Works ====================

export function HowItWorks() {
  const steps = [
    { number: "01", title: "ابحث واختر", description: "تصفح مئات الخيارات وابحث عن المكان المناسب لرحلتك", icon: Search },
    { number: "02", title: "احجز بسهولة", description: "أكمل الحجز بخطوات بسيطة مع خيارات دفع متعددة", icon: CheckCircle2 },
    { number: "03", title: "استمتع برحلتك", description: "تواصل مع المضيف واستمتع بإقامتك مع ضمان ضيف", icon: Heart }
  ]

  return (
    <section className="py-20 bg-gradient-to-br from-amber-50 to-orange-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <Badge className="mb-4 bg-amber-100 text-amber-700 hover:bg-amber-100">كيف يعمل</Badge>
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">احجز رحلتك في 3 خطوات بسيطة</h2>
        </div>
        
        <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
          {steps.map((step, index) => (
            <div key={index} className="text-center relative">
              <div className="w-20 h-20 bg-white rounded-2xl shadow-lg flex items-center justify-center mx-auto mb-6 relative">
                <step.icon className="w-8 h-8 text-amber-500" />
                <div className="absolute -top-2 -right-2 w-8 h-8 bg-amber-500 text-white rounded-full flex items-center justify-center text-sm font-bold">{step.number}</div>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">{step.title}</h3>
              <p className="text-gray-600">{step.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

// ==================== Trust Section ====================

export function TrustSection() {
  const features = [
    { icon: Shield, title: "ضمان الحجز", description: "نظام ضمان يحمي حقوق الضيف والمضيف على حد سواء" },
    { icon: Users, title: "مضيفون موثوقون", description: "جميع المضيفين مُتحقق منهم لضمان تجربة آمنة" },
    { icon: Heart, title: "دعم على مدار الساعة", description: "فريق دعم متخصص جاهز لمساعدتك في أي وقت" },
    { icon: MapPin, title: "تواصل آمن", description: "تواصل مع المضيفين دون الحاجة لكشف معلوماتك الشخصية" }
  ]

  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <Badge className="mb-4 bg-emerald-100 text-emerald-700 hover:bg-emerald-100">لماذا ضيف؟</Badge>
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">رحلتك بأمان مع ضيف</h2>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <div key={index} className="text-center p-6 rounded-2xl bg-gray-50 hover:bg-gray-100 transition-colors">
              <div className="w-16 h-16 bg-emerald-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <feature.icon className="w-8 h-8 text-emerald-600" />
              </div>
              <h3 className="text-lg font-bold text-gray-900 mb-2">{feature.title}</h3>
              <p className="text-gray-600 text-sm">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

// ==================== CTA Section ====================

export function CTASection({ onNavigate }: { onNavigate: (page: PageType) => void }) {
  return (
    <section className="py-20 bg-gradient-to-r from-amber-500 to-orange-500">
      <div className="container mx-auto px-4 text-center">
        <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">هل أنت مستعد لاستكشاف سوريا؟</h2>
        <p className="text-white/90 text-lg mb-8 max-w-2xl mx-auto">انضم إلى آلاف الضيوف الذين اكتشفوا جمال سوريا معنا</p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button size="lg" onClick={() => onNavigate('accommodations')} className="bg-white text-amber-600 hover:bg-gray-100 rounded-full px-8 cursor-pointer">ابدأ البحث الآن</Button>
          <Button size="lg" variant="outline" className="border-white text-white hover:bg-white/10 rounded-full px-8 cursor-pointer">كيف تعمل المنصة؟</Button>
        </div>
      </div>
    </section>
  )
}

// ==================== Host CTA ====================

export function HostCTA({ onNavigate }: { onNavigate: (page: PageType) => void }) {
  const { isAuthenticated, isHost } = useAuth()
  const { openAuthModal } = useAuthModal()
  const { navigate } = useNavigation()

  const handleBecomeHost = () => {
    if (!isAuthenticated) {
      // Open AuthModal with HOST role for registration
      openAuthModal('HOST')
    } else if (!isHost) {
      // User is logged in but not a host - go to registration form
      navigate('host-dashboard')
    } else {
      // User is already a host - go to dashboard
      navigate('host-dashboard')
    }
  }

  return (
    <section className="py-20 bg-gray-900">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div>
            <Badge className="mb-4 bg-amber-500/20 text-amber-400 hover:bg-amber-500/20">كن مضيفاً</Badge>
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">شارك مكانك مع ضيوف من جميع أنحاء العالم</h2>
            <p className="text-gray-400 text-lg mb-8">سواء كان لديك فندق، شقة، شاليه، أو حتى مخيم، انضم إلى منصة ضيف وابدأ بتقديم خدمتك للضيوف</p>
            <ul className="space-y-4 mb-8">
              {["إدارة سهلة للحجوزات عبر واتساب", "نظام ضمان يحمي حقوقك", "دعم فني متواصل", "تحصيل آمن للمدفوعات"].map((item, i) => (
                <li key={i} className="flex items-center text-gray-300">
                  <CheckCircle2 className="w-5 h-5 text-amber-500 ml-3" />
                  {item}
                </li>
              ))}
            </ul>
            <Button size="lg" onClick={handleBecomeHost} className="bg-amber-500 hover:bg-amber-600 text-white rounded-full px-8 cursor-pointer">سجل كمضيف الآن</Button>
          </div>
          <div className="relative">
            <div className="bg-gradient-to-br from-amber-500/20 to-orange-500/20 rounded-3xl p-8 backdrop-blur-sm border border-amber-500/20">
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-gray-800 rounded-2xl p-6 text-center"><div className="text-3xl font-bold text-amber-400 mb-2">0%</div><div className="text-gray-400 text-sm">عمولة للأشهر الـ 3 الأولى</div></div>
                <div className="bg-gray-800 rounded-2xl p-6 text-center"><div className="text-3xl font-bold text-emerald-400 mb-2">24/7</div><div className="text-gray-400 text-sm">دعم فني مستمر</div></div>
                <div className="bg-gray-800 rounded-2xl p-6 text-center"><div className="text-3xl font-bold text-sky-400 mb-2">+500</div><div className="text-gray-400 text-sm">مضيف نشط</div></div>
                <div className="bg-gray-800 rounded-2xl p-6 text-center"><div className="text-3xl font-bold text-violet-400 mb-2">8%</div><div className="text-gray-400 text-sm">عمولة بعد الترويج</div></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
