'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { useNavigation } from '@/shared/contexts/NavigationContext'
import { 
  Clock, TrendingUp, Star, Plus, Bookmark, Eye, ThumbsUp, 
  MessageSquare, ArrowLeft, Heart, MessageCircle, Megaphone, BookOpen 
} from 'lucide-react'
import { CommunityPost, CommunityCategory, POST_TYPE_LABELS } from '@/shared/types'

// ==================== Community View ====================

export function CommunityView() {
  const [posts, setPosts] = useState<CommunityPost[]>([])
  const [categories, setCategories] = useState<CommunityCategory[]>([])
  const [loading, setLoading] = useState(true)
  const [activeCategory, setActiveCategory] = useState<string | null>(null)
  const [activeTab, setActiveTab] = useState("latest")
  const { navigate } = useNavigation()

  useEffect(() => {
    const fetchCommunityData = async () => {
      try {
        const [postsRes, categoriesRes] = await Promise.all([
          fetch('/api/community/posts?limit=12&sort=latest'),
          fetch('/api/community/categories?includeStats=true')
        ])

        if (postsRes.ok) {
          const data = await postsRes.json()
          setPosts(data.posts || [])
        }

        if (categoriesRes.ok) {
          const data = await categoriesRes.json()
          setCategories(data.categories || [])
        }
      } catch (error) {
        console.error('Error fetching community data:', error)
      } finally {
        setLoading(false)
      }
    }

    fetchCommunityData()
  }, [])

  const formatTimeAgo = (dateString: string) => {
    const date = new Date(dateString)
    const now = new Date()
    const diff = now.getTime() - date.getTime()
    const minutes = Math.floor(diff / 60000)
    const hours = Math.floor(diff / 3600000)
    const days = Math.floor(diff / 86400000)
    
    if (minutes < 60) return `منذ ${minutes} دقيقة`
    if (hours < 24) return `منذ ${hours} ساعة`
    if (days < 7) return `منذ ${days} يوم`
    return date.toLocaleDateString('ar-SY')
  }

  const filteredPosts = activeCategory ? posts.filter(p => p.category?.id === activeCategory) : posts

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-gradient-to-r from-violet-600 to-purple-600 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div>
              <h1 className="text-3xl md:text-4xl font-bold mb-2">مجتمع ضيف</h1>
              <p className="text-white/80 text-lg">شارك تجاربك واستفد من خبرات الآخرين</p>
            </div>
            <Button size="lg" className="bg-white text-violet-600 hover:bg-gray-100 rounded-full">
              <Plus className="w-4 h-4 ml-2" />
              مشاركة جديدة
            </Button>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          <aside className="lg:w-64 shrink-0">
            <Card className="sticky top-24 border-0 shadow-md">
              <CardContent className="p-4">
                <h3 className="font-bold text-gray-900 mb-4 flex items-center gap-2">
                  <Bookmark className="w-4 h-4" />
                  الأقسام
                </h3>
                <div className="space-y-1">
                  <button
                    onClick={() => setActiveCategory(null)}
                    className={`w-full text-right px-3 py-2 rounded-lg transition-colors ${
                      activeCategory === null ? 'bg-violet-100 text-violet-700' : 'hover:bg-gray-100 text-gray-700'
                    }`}
                  >
                    جميع المواضيع
                  </button>
                  {categories.map((cat) => (
                    <button
                      key={cat.id}
                      onClick={() => setActiveCategory(cat.id)}
                      className={`w-full text-right px-3 py-2 rounded-lg transition-colors flex items-center justify-between ${
                        activeCategory === cat.id ? 'bg-violet-100 text-violet-700' : 'hover:bg-gray-100 text-gray-700'
                      }`}
                    >
                      <span>{cat.nameAr}</span>
                      {cat.postsCount !== undefined && (
                        <span className="text-xs bg-gray-200 px-2 py-0.5 rounded-full">{cat.postsCount}</span>
                      )}
                    </button>
                  ))}
                </div>
              </CardContent>
            </Card>
          </aside>

          <main className="flex-1">
            <Tabs value={activeTab} onValueChange={setActiveTab} className="mb-6">
              <TabsList className="bg-white border shadow-sm">
                <TabsTrigger value="latest" className="gap-2">
                  <Clock className="w-4 h-4" />
                  الأحدث
                </TabsTrigger>
                <TabsTrigger value="popular" className="gap-2">
                  <TrendingUp className="w-4 h-4" />
                  الأكثر تفاعلاً
                </TabsTrigger>
                <TabsTrigger value="featured" className="gap-2">
                  <Star className="w-4 h-4" />
                  المميزة
                </TabsTrigger>
              </TabsList>
            </Tabs>

            {loading ? (
              <div className="space-y-4">
                {[1, 2, 3, 4].map((i) => (
                  <Card key={i} className="border-0 shadow-md">
                    <CardContent className="p-5">
                      <div className="h-4 bg-gray-200 rounded w-3/4 mb-3 animate-pulse" />
                      <div className="h-3 bg-gray-100 rounded w-full mb-2 animate-pulse" />
                      <div className="h-3 bg-gray-100 rounded w-2/3 animate-pulse" />
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : filteredPosts.length > 0 ? (
              <div className="space-y-4">
                {filteredPosts.map((post) => {
                  const typeInfo = POST_TYPE_LABELS[post.type] || POST_TYPE_LABELS.DISCUSSION
                  return (
                    <Card 
                      key={post.id} 
                      className={`group border-0 shadow-md hover:shadow-xl transition-all duration-300 cursor-pointer ${
                        post.isPinned ? 'ring-2 ring-amber-400 bg-amber-50/30' : ''
                      }`}
                      onClick={() => navigate('community-post', { id: post.id })}
                    >
                      <CardContent className="p-5">
                        <div className="flex items-start gap-4">
                          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-amber-400 to-orange-500 flex items-center justify-center text-white font-bold shrink-0">
                            {post.author.name?.charAt(0) || post.author.nameAr?.charAt(0) || 'ض'}
                          </div>
                          
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center justify-between mb-2">
                              <div className="flex items-center gap-2">
                                <p className="font-medium text-gray-900">{post.author.nameAr || post.author.name || 'ضيف'}</p>
                                <span className="text-gray-400">•</span>
                                <p className="text-sm text-gray-500">{formatTimeAgo(post.createdAt)}</p>
                                {post.isPinned && (
                                  <Badge className="bg-amber-100 text-amber-700 text-xs">
                                    <Bookmark className="w-3 h-3 ml-1" />
                                    مثبت
                                  </Badge>
                                )}
                              </div>
                              <Badge className={typeInfo.color}>
                                {typeInfo.label}
                              </Badge>
                            </div>

                            <h3 className="font-bold text-lg text-gray-900 mb-2 group-hover:text-violet-600 transition-colors">
                              {post.titleAr}
                            </h3>
                            <p className="text-gray-600 line-clamp-2 mb-3">{post.contentAr}</p>

                            <div className="flex items-center gap-2 mb-3">
                              {post.category && (
                                <span 
                                  className="text-xs px-2 py-1 rounded-full"
                                  style={{ backgroundColor: post.category.color || '#f3f4f6', color: '#374151' }}
                                >
                                  {post.category.nameAr}
                                </span>
                              )}
                              {post.tags.slice(0, 3).map((tag, i) => (
                                <span key={i} className="text-xs text-gray-500 bg-gray-100 px-2 py-1 rounded-full">
                                  #{tag}
                                </span>
                              ))}
                            </div>

                            <div className="flex items-center justify-between pt-3 border-t border-gray-100">
                              <div className="flex items-center gap-4 text-sm text-gray-500">
                                <span className="flex items-center gap-1"><Eye className="w-4 h-4" />{post.viewCount}</span>
                                <span className="flex items-center gap-1"><ThumbsUp className="w-4 h-4" />{post.likeCount}</span>
                                <span className="flex items-center gap-1"><MessageSquare className="w-4 h-4" />{post._count.comments}</span>
                              </div>
                              <Button variant="ghost" size="sm" className="text-violet-600 hover:text-violet-700">
                                اقرأ المزيد
                                <ArrowLeft className="w-4 h-4 mr-1" />
                              </Button>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  )
                })}
              </div>
            ) : (
              <div className="text-center py-12">
                <MessageSquare className="w-12 h-12 text-gray-300 mx-auto mb-4" />
                <p className="text-gray-500">لا توجد مشاركات في هذا القسم</p>
              </div>
            )}
          </main>
        </div>
      </div>
    </div>
  )
}
