'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { Menu, X, Bell, MessageCircle, User, Settings, LogOut, Home, Calendar, Shield, Heart } from 'lucide-react'
import { useNavigation } from '@/shared/contexts/NavigationContext'
import { useAuth } from '@/shared/contexts/AuthContext'
import { useNotifications } from '@/shared/contexts/NotificationsContext'
import { useAuthModal } from '@/shared/contexts/AuthModalContext'
import { PageType } from '@/shared/types'

const navItems: { id: PageType; label: string }[] = [
  { id: 'home', label: 'الرئيسية' },
  { id: 'accommodations', label: 'الإقامات' },
  { id: 'community', label: 'المجتمع' },
  { id: 'host-reviews', label: 'التقييمات' },
]

export function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  
  const { currentPage, navigate } = useNavigation()
  const { user, isAuthenticated, isHost, isAdmin, logout } = useAuth()
  const { unreadCount } = useNotifications()
  const { openAuthModal } = useAuthModal()

  const handleLogin = () => {
    openAuthModal('GUEST')
  }

  const handleBecomeHost = () => {
    if (!isAuthenticated) {
      openAuthModal('HOST')
    } else {
      navigate('host-dashboard')
    }
  }

  const handleLogout = async () => {
    await logout()
    navigate('home')
  }

  const handleNavigate = (page: PageType) => {
    navigate(page)
    setMobileMenuOpen(false)
  }

  return (
    <>
      <header className="fixed top-0 right-0 left-0 z-50 bg-white/95 backdrop-blur-md border-b">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <div 
              className="flex items-center gap-2 cursor-pointer" 
              onClick={() => navigate('home')}
            >
              <h1 className="text-2xl font-bold text-amber-600">ضيف</h1>
            </div>
            
            {/* Desktop Navigation */}
            <nav className="hidden md:flex items-center gap-6">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => navigate(item.id)}
                  className={`transition-colors bg-transparent cursor-pointer ${
                    currentPage === item.id 
                      ? 'text-amber-600 font-medium' 
                      : 'text-gray-600 hover:text-amber-600'
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </nav>
            
            {/* Right Side */}
            <div className="flex items-center gap-2">
              {isAuthenticated ? (
                <>
                  {/* Notifications */}
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="relative"
                    onClick={() => navigate('messages')}
                  >
                    <Bell className="w-5 h-5" />
                    {unreadCount > 0 && (
                      <Badge className="absolute -top-1 -left-1 h-5 w-5 flex items-center justify-center p-0 bg-red-500 text-white text-xs">
                        {unreadCount > 9 ? '9+' : unreadCount}
                      </Badge>
                    )}
                  </Button>

                  {/* Messages */}
                  <Button 
                    variant="ghost" 
                    size="icon"
                    onClick={() => navigate('messages')}
                  >
                    <MessageCircle className="w-5 h-5" />
                  </Button>

                  {/* User Menu */}
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" className="gap-2 px-2">
                        <Avatar className="w-8 h-8">
                          <AvatarImage src={user?.avatar || undefined} />
                          <AvatarFallback className="bg-amber-100 text-amber-700">
                            {user?.nameAr?.charAt(0) || user?.name?.charAt(0) || 'ض'}
                          </AvatarFallback>
                        </Avatar>
                        <span className="hidden sm:inline font-medium">
                          {user?.nameAr || user?.name || 'ضيف'}
                        </span>
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="w-56">
                      <div className="px-2 py-1.5">
                        <p className="font-medium">{user?.nameAr || user?.name}</p>
                        <p className="text-sm text-gray-500">{user?.phone}</p>
                      </div>
                      <DropdownMenuSeparator />
                      
                      <DropdownMenuItem onClick={() => navigate('profile')}>
                        <User className="w-4 h-4 ml-2" />
                        ملفي الشخصي
                      </DropdownMenuItem>
                      
                      <DropdownMenuItem onClick={() => navigate('accommodations')}>
                        <Home className="w-4 h-4 ml-2" />
                        استكشف الإقامات
                      </DropdownMenuItem>
                      
                      <DropdownMenuItem onClick={() => navigate('profile')}>
                        <Heart className="w-4 h-4 ml-2" />
                        المفضلة
                      </DropdownMenuItem>
                      
                      <DropdownMenuItem onClick={() => navigate('profile')}>
                        <Calendar className="w-4 h-4 ml-2" />
                        حجوزاتي
                      </DropdownMenuItem>
                      
                      {isHost && (
                        <>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem onClick={() => navigate('host-dashboard')}>
                            <Home className="w-4 h-4 ml-2" />
                            لوحة المضيف
                          </DropdownMenuItem>
                        </>
                      )}
                      
                      {isAdmin && (
                        <DropdownMenuItem onClick={() => navigate('admin-dashboard')}>
                          <Shield className="w-4 h-4 ml-2" />
                          لوحة الإدارة
                        </DropdownMenuItem>
                      )}
                      
                      <DropdownMenuSeparator />
                      
                      <DropdownMenuItem onClick={() => navigate('profile')}>
                        <Settings className="w-4 h-4 ml-2" />
                        الإعدادات
                      </DropdownMenuItem>
                      
                      <DropdownMenuItem onClick={handleLogout} className="text-red-600">
                        <LogOut className="w-4 h-4 ml-2" />
                        تسجيل الخروج
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>

                  {/* Become Host Button (if not host) */}
                  {!isHost && (
                    <Button 
                      className="bg-amber-500 hover:bg-amber-600 text-white rounded-full hidden md:flex"
                      onClick={handleBecomeHost}
                    >
                      انضم كمضيف
                    </Button>
                  )}
                </>
              ) : (
                <>
                  {/* Login Button */}
                  <Button 
                    variant="ghost" 
                    className="text-gray-600 cursor-pointer hidden md:flex"
                    onClick={handleLogin}
                  >
                    تسجيل الدخول
                  </Button>
                  
                  {/* Become Host Button */}
                  <Button 
                    className="bg-amber-500 hover:bg-amber-600 text-white rounded-full cursor-pointer"
                    onClick={handleBecomeHost}
                  >
                    <span className="hidden md:inline">انضم كمضيف</span>
                    <span className="md:hidden">مضيف</span>
                  </Button>
                </>
              )}

              {/* Mobile Menu Button */}
              <Button
                variant="ghost"
                size="icon"
                className="md:hidden cursor-pointer"
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              >
                {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
              </Button>
            </div>
          </div>
          
          {/* Mobile Menu */}
          {mobileMenuOpen && (
            <div className="md:hidden py-4 border-t">
              <nav className="flex flex-col gap-2">
                {navItems.map((item) => (
                  <button
                    key={item.id}
                    onClick={() => handleNavigate(item.id)}
                    className={`text-right py-2 px-3 rounded-lg bg-transparent cursor-pointer ${
                      currentPage === item.id 
                        ? 'text-amber-600 font-medium bg-amber-50' 
                        : 'text-gray-600 hover:bg-gray-50'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
                
                <div className="border-t mt-2 pt-2">
                  {isAuthenticated ? (
                    <>
                      <button 
                        onClick={() => handleNavigate('profile')}
                        className="w-full text-right py-2 px-3 rounded-lg hover:bg-gray-50 flex items-center gap-2"
                      >
                        <User className="w-4 h-4" />
                        ملفي الشخصي
                      </button>
                      <button 
                        onClick={() => handleNavigate('messages')}
                        className="w-full text-right py-2 px-3 rounded-lg hover:bg-gray-50 flex items-center gap-2"
                      >
                        <MessageCircle className="w-4 h-4" />
                        الرسائل
                        {unreadCount > 0 && (
                          <Badge className="bg-red-500 text-white text-xs">{unreadCount}</Badge>
                        )}
                      </button>
                      {isHost && (
                        <button 
                          onClick={() => handleNavigate('host-dashboard')}
                          className="w-full text-right py-2 px-3 rounded-lg hover:bg-gray-50 flex items-center gap-2"
                        >
                          <Home className="w-4 h-4" />
                          لوحة المضيف
                        </button>
                      )}
                      <button 
                        onClick={handleLogout}
                        className="w-full text-right py-2 px-3 rounded-lg hover:bg-gray-50 flex items-center gap-2 text-red-600"
                      >
                        <LogOut className="w-4 h-4" />
                        تسجيل الخروج
                      </button>
                    </>
                  ) : (
                    <>
                      <Button 
                        variant="outline" 
                        className="w-full justify-center cursor-pointer"
                        onClick={handleLogin}
                      >
                        تسجيل الدخول
                      </Button>
                    </>
                  )}
                </div>
              </nav>
            </div>
          )}
        </div>
      </header>
    </>
  )
}
