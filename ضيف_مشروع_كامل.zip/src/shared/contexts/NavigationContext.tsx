'use client'

import { createContext, useContext, useState, useCallback, ReactNode } from 'react'
import { PageType, NavigationContextType } from '@/shared/types'

const NavigationContext = createContext<NavigationContextType | null>(null)

export function NavigationProvider({ children }: { children: ReactNode }) {
  const [currentPage, setCurrentPage] = useState<PageType>('home')
  const [pageParams, setPageParams] = useState<Record<string, string>>({})

  const navigate = useCallback((page: PageType, params?: Record<string, string>) => {
    setCurrentPage(page)
    setPageParams(params || {})
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }, [])

  const value: NavigationContextType = {
    currentPage,
    setCurrentPage,
    pageParams,
    setPageParams,
    navigate
  }

  return (
    <NavigationContext.Provider value={value}>
      {children}
    </NavigationContext.Provider>
  )
}

export function useNavigation() {
  const context = useContext(NavigationContext)
  if (!context) {
    throw new Error('useNavigation must be used within NavigationProvider')
  }
  return context
}

export { NavigationContext }
