'use client'

import { createContext, useContext, useState, useEffect, useCallback, ReactNode } from 'react'

// ==================== Types ====================

export interface FavoriteItem {
  id: string
  accommodationId: string
  accommodation: {
    id: string
    titleAr: string
    coverImage: string | null
    basePrice: number
    rating: number
    city: { nameAr: string } | null
  }
  createdAt: string
}

export interface FavoritesContextType {
  favorites: FavoriteItem[]
  favoriteIds: string[]
  loading: boolean
  isFavorite: (accommodationId: string) => boolean
  addFavorite: (accommodationId: string) => Promise<{ success: boolean; error?: string }>
  removeFavorite: (accommodationId: string) => Promise<{ success: boolean; error?: string }>
  toggleFavorite: (accommodationId: string) => Promise<{ success: boolean; added: boolean; error?: string }>
  refreshFavorites: () => Promise<void>
}

// ==================== Context ====================

const FavoritesContext = createContext<FavoritesContextType | null>(null)

export function FavoritesProvider({ children }: { children: ReactNode }) {
  const [favorites, setFavorites] = useState<FavoriteItem[]>([])
  const [loading, setLoading] = useState(true)

  // Get favorite IDs for quick lookup
  const favoriteIds = favorites.map(f => f.accommodationId)

  // Check if accommodation is favorite
  const isFavorite = useCallback((accommodationId: string) => {
    return favoriteIds.includes(accommodationId)
  }, [favoriteIds])

  // Load favorites from server
  const refreshFavorites = useCallback(async () => {
    try {
      const res = await fetch('/api/favorites')
      if (res.ok) {
        const data = await res.json()
        setFavorites(data.favorites || [])
      }
    } catch (error) {
      console.error('Error loading favorites:', error)
    } finally {
      setLoading(false)
    }
  }, [])

  // Load favorites on mount
  useEffect(() => {
    refreshFavorites()
  }, [refreshFavorites])

  // Add to favorites
  const addFavorite = useCallback(async (accommodationId: string) => {
    try {
      const res = await fetch('/api/favorites', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ accommodationId })
      })

      const data = await res.json()

      if (!res.ok) {
        return { success: false, error: data.error || 'حدث خطأ' }
      }

      if (data.favorite) {
        setFavorites(prev => {
          // Avoid duplicates
          if (prev.some(f => f.accommodationId === accommodationId)) {
            return prev
          }
          return [...prev, data.favorite]
        })
      }
      return { success: true }
    } catch (error) {
      return { success: false, error: 'حدث خطأ، يرجى المحاولة لاحقاً' }
    }
  }, [])

  // Remove from favorites
  const removeFavorite = useCallback(async (accommodationId: string) => {
    try {
      const res = await fetch(`/api/favorites?accommodationId=${accommodationId}`, {
        method: 'DELETE'
      })

      if (!res.ok) {
        const data = await res.json()
        return { success: false, error: data.error || 'حدث خطأ' }
      }

      setFavorites(prev => prev.filter(f => f.accommodationId !== accommodationId))
      return { success: true }
    } catch (error) {
      return { success: false, error: 'حدث خطأ، يرجى المحاولة لاحقاً' }
    }
  }, [])

  // Toggle favorite
  const toggleFavorite = useCallback(async (accommodationId: string) => {
    if (isFavorite(accommodationId)) {
      const result = await removeFavorite(accommodationId)
      return { ...result, added: false }
    } else {
      const result = await addFavorite(accommodationId)
      return { ...result, added: true }
    }
  }, [isFavorite, addFavorite, removeFavorite])

  const value: FavoritesContextType = {
    favorites,
    favoriteIds,
    loading,
    isFavorite,
    addFavorite,
    removeFavorite,
    toggleFavorite,
    refreshFavorites
  }

  return (
    <FavoritesContext.Provider value={value}>
      {children}
    </FavoritesContext.Provider>
  )
}

export function useFavorites() {
  const context = useContext(FavoritesContext)
  if (!context) {
    throw new Error('useFavorites must be used within FavoritesProvider')
  }
  return context
}

export { FavoritesContext }
