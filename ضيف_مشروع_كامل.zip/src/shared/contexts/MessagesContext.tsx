'use client'

import { createContext, useContext, useState, useEffect, useCallback, ReactNode } from 'react'

// ==================== Types ====================

export interface Message {
  id: string
  content: string
  type: 'text' | 'image' | 'system'
  isFromGuest: boolean
  isRead: boolean
  readAt: string | null
  createdAt: string
  senderId: string
  sender: {
    id: string
    name: string | null
    nameAr: string | null
    avatar: string | null
  }
}

export interface Conversation {
  id: string
  type: 'booking' | 'inquiry' | 'support'
  status: 'active' | 'archived' | 'blocked'
  lastMessage: string | null
  lastMessageAt: string | null
  createdAt: string
  guest: {
    id: string
    name: string | null
    nameAr: string | null
    avatar: string | null
  }
  host: {
    id: string
    name: string | null
    nameAr: string | null
    avatar: string | null
  } | null
  booking: {
    id: string
    confirmationCode: string
    accommodation: {
      id: string
      titleAr: string
      coverImage: string | null
    }
  } | null
  _count: {
    messages: number
  }
}

export interface MessagesContextType {
  conversations: Conversation[]
  currentConversation: Conversation | null
  messages: Message[]
  loading: boolean
  messagesLoading: boolean
  unreadCount: number
  loadConversations: () => Promise<void>
  loadConversation: (conversationId: string) => Promise<void>
  sendMessage: (conversationId: string, content: string, type?: 'text' | 'image') => Promise<{ success: boolean; error?: string }>
  markAsRead: (conversationId: string) => Promise<void>
  createConversation: (hostId: string, bookingId?: string, type?: 'booking' | 'inquiry' | 'support') => Promise<{ success: boolean; conversationId?: string; error?: string }>
}

// ==================== Context ====================

const MessagesContext = createContext<MessagesContextType | null>(null)

export function MessagesProvider({ children }: { children: ReactNode }) {
  const [conversations, setConversations] = useState<Conversation[]>([])
  const [currentConversation, setCurrentConversation] = useState<Conversation | null>(null)
  const [messages, setMessages] = useState<Message[]>([])
  const [loading, setLoading] = useState(true)
  const [messagesLoading, setMessagesLoading] = useState(false)

  // Calculate unread count
  const unreadCount = conversations.filter(c => c.lastMessage && !c.lastMessage.includes('read')).length

  // Load conversations
  const loadConversations = useCallback(async () => {
    setLoading(true)
    try {
      const res = await fetch('/api/conversations')
      if (res.ok) {
        const data = await res.json()
        setConversations(data.conversations || [])
      }
    } catch (error) {
      console.error('Error loading conversations:', error)
    } finally {
      setLoading(false)
    }
  }, [])

  // Load single conversation with messages
  const loadConversation = useCallback(async (conversationId: string) => {
    setMessagesLoading(true)
    try {
      const res = await fetch(`/api/conversations/${conversationId}`)
      if (res.ok) {
        const data = await res.json()
        setCurrentConversation(data.conversation)
        setMessages(data.messages || [])
      }
    } catch (error) {
      console.error('Error loading conversation:', error)
    } finally {
      setMessagesLoading(false)
    }
  }, [])

  // Send message
  const sendMessage = useCallback(async (conversationId: string, content: string, type: 'text' | 'image' = 'text') => {
    try {
      const res = await fetch(`/api/conversations/${conversationId}/messages`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ content, type })
      })

      const data = await res.json()

      if (!res.ok) {
        return { success: false, error: data.error || 'حدث خطأ' }
      }

      setMessages(prev => [...prev, data.message])
      return { success: true }
    } catch (error) {
      return { success: false, error: 'حدث خطأ، يرجى المحاولة لاحقاً' }
    }
  }, [])

  // Mark as read
  const markAsRead = useCallback(async (conversationId: string) => {
    try {
      await fetch(`/api/conversations/${conversationId}/read`, { method: 'POST' })
    } catch (error) {
      console.error('Error marking as read:', error)
    }
  }, [])

  // Create new conversation
  const createConversation = useCallback(async (
    hostId: string, 
    bookingId?: string, 
    type: 'booking' | 'inquiry' | 'support' = 'inquiry'
  ) => {
    try {
      const res = await fetch('/api/conversations', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ hostId, bookingId, type })
      })

      const data = await res.json()

      if (!res.ok) {
        return { success: false, error: data.error || 'حدث خطأ' }
      }

      setConversations(prev => [data.conversation, ...prev])
      return { success: true, conversationId: data.conversation.id }
    } catch (error) {
      return { success: false, error: 'حدث خطأ، يرجى المحاولة لاحقاً' }
    }
  }, [])

  // Load conversations on mount
  useEffect(() => {
    loadConversations()
  }, [loadConversations])

  const value: MessagesContextType = {
    conversations,
    currentConversation,
    messages,
    loading,
    messagesLoading,
    unreadCount,
    loadConversations,
    loadConversation,
    sendMessage,
    markAsRead,
    createConversation
  }

  return (
    <MessagesContext.Provider value={value}>
      {children}
    </MessagesContext.Provider>
  )
}

export function useMessages() {
  const context = useContext(MessagesContext)
  if (!context) {
    throw new Error('useMessages must be used within MessagesProvider')
  }
  return context
}

export { MessagesContext }
