'use client'

import { createContext, useContext, useState, useEffect, useCallback, ReactNode } from 'react'

// ==================== Types ====================

export type UserRole = 'GUEST' | 'HOST' | 'ADMIN' | 'SUPER_ADMIN'
export type UserStatus = 'ACTIVE' | 'INACTIVE' | 'SUSPENDED' | 'PENDING_VERIFICATION'

export interface User {
  id: string
  phone: string
  email: string | null
  name: string | null
  nameAr: string | null
  avatar: string | null
  role: UserRole
  status: UserStatus
  isVerified: boolean
  language: string
  businessName: string | null
  businessNameAr: string | null
  businessType: string | null
  city: string | null
  country: string | null
  createdAt: string
  lastLoginAt: string | null
}

export interface AuthContextType {
  user: User | null
  loading: boolean
  isAuthenticated: boolean
  isHost: boolean
  isAdmin: boolean
  login: (phone: string, code: string, name?: string, role?: UserRole) => Promise<{ success: boolean; error?: string; isNewUser?: boolean }>
  sendOTP: (phone: string, purpose: 'login' | 'verify' | 'reset') => Promise<{ success: boolean; error?: string }>
  logout: () => Promise<void>
  refreshUser: () => Promise<void>
  updateProfile: (data: Partial<User>) => Promise<{ success: boolean; error?: string }>
}

// ==================== Context ====================

const AuthContext = createContext<AuthContextType | null>(null)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)

  // Check if user is logged in on mount
  const checkAuth = useCallback(async () => {
    try {
      const res = await fetch('/api/auth/me')
      if (res.ok) {
        const data = await res.json()
        setUser(data.user)
      } else {
        setUser(null)
      }
    } catch (error) {
      console.error('Auth check error:', error)
      setUser(null)
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    checkAuth()
  }, [checkAuth])

  // Send OTP
  const sendOTP = useCallback(async (phone: string, purpose: 'login' | 'verify' | 'reset' = 'login') => {
    try {
      const res = await fetch('/api/auth/send-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phone, purpose })
      })

      const data = await res.json()

      if (!res.ok) {
        return { success: false, error: data.error || 'حدث خطأ' }
      }

      return { success: true }
    } catch (error) {
      return { success: false, error: 'حدث خطأ، يرجى المحاولة لاحقاً' }
    }
  }, [])

  // Login with OTP
  const login = useCallback(async (phone: string, code: string, name?: string, role: UserRole = 'GUEST') => {
    try {
      const res = await fetch('/api/auth/verify-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phone, code, name, role })
      })

      const data = await res.json()

      if (!res.ok) {
        return { success: false, error: data.error || 'رمز التحقق غير صحيح' }
      }

      setUser(data.user)
      return { success: true, isNewUser: data.isNewUser }
    } catch (error) {
      return { success: false, error: 'حدث خطأ، يرجى المحاولة لاحقاً' }
    }
  }, [])

  // Logout
  const logout = useCallback(async () => {
    try {
      await fetch('/api/auth/logout', { method: 'POST' })
      setUser(null)
    } catch (error) {
      console.error('Logout error:', error)
    }
  }, [])

  // Refresh user data
  const refreshUser = useCallback(async () => {
    await checkAuth()
  }, [checkAuth])

  // Update profile
  const updateProfile = useCallback(async (data: Partial<User>) => {
    try {
      const res = await fetch('/api/auth/me', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      })

      const responseData = await res.json()

      if (!res.ok) {
        return { success: false, error: responseData.error || 'حدث خطأ' }
      }

      setUser(responseData.user)
      return { success: true }
    } catch (error) {
      return { success: false, error: 'حدث خطأ، يرجى المحاولة لاحقاً' }
    }
  }, [])

  const value: AuthContextType = {
    user,
    loading,
    isAuthenticated: !!user,
    isHost: user?.role === 'HOST' || user?.role === 'ADMIN' || user?.role === 'SUPER_ADMIN',
    isAdmin: user?.role === 'ADMIN' || user?.role === 'SUPER_ADMIN',
    login,
    sendOTP,
    logout,
    refreshUser,
    updateProfile
  }

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (!context) {
    throw new Error('useAuth must be used within AuthProvider')
  }
  return context
}

export { AuthContext }
