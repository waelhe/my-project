'use client'

import { createContext, useContext, useState, useEffect, ReactNode } from 'react'

// ==================== Types ====================

export type Theme = 'light' | 'dark' | 'system'

export interface ThemeContextType {
  theme: Theme
  setTheme: (theme: Theme) => void
  resolvedTheme: 'light' | 'dark'
}

// ==================== Context ====================

const ThemeContext = createContext<ThemeContextType | null>(null)

export function ThemeProvider({ children }: { children: ReactNode }) {
  // Use lazy initialization to avoid SSR issues
  const [theme, setThemeState] = useState<Theme>('light')
  const [resolvedTheme, setResolvedTheme] = useState<'light' | 'dark'>('light')
  const [mounted, setMounted] = useState(false)

  // Custom setTheme that also updates localStorage
  const setTheme = (newTheme: Theme) => {
    setThemeState(newTheme)
    if (typeof window !== 'undefined') {
      localStorage.setItem('dayf_theme', newTheme)
    }
  }

  // Initialize and apply theme on mount
  useEffect(() => {
    // Read initial theme from localStorage
    const stored = localStorage.getItem('dayf_theme') as Theme | null
    const initialTheme = stored || 'light'
    
    // Apply theme
    const root = document.documentElement
    const isDark = initialTheme === 'dark' || 
      (initialTheme === 'system' && window.matchMedia('(prefers-color-scheme: dark)').matches)
    
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setThemeState(initialTheme)
    if (isDark) {
      root.classList.add('dark')
      // eslint-disable-next-line react-hooks/set-state-in-effect
      setResolvedTheme('dark')
    } else {
      root.classList.remove('dark')
      // eslint-disable-next-line react-hooks/set-state-in-effect
      setResolvedTheme('light')
    }
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setMounted(true)
  }, []) // Empty deps - only runs once on mount

  // Apply theme when it changes
  useEffect(() => {
    if (!mounted) return
    
    const root = document.documentElement
    const isDark = theme === 'dark' || 
      (theme === 'system' && window.matchMedia('(prefers-color-scheme: dark)').matches)
    
    if (isDark) {
      root.classList.add('dark')
      // eslint-disable-next-line react-hooks/set-state-in-effect
      setResolvedTheme('dark')
    } else {
      root.classList.remove('dark')
      // eslint-disable-next-line react-hooks/set-state-in-effect
      setResolvedTheme('light')
    }
  }, [theme, mounted])

  // Listen for system theme changes
  useEffect(() => {
    if (theme !== 'system') return

    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)')
    const handler = (e: MediaQueryListEvent) => {
      const root = document.documentElement
      if (e.matches) {
        root.classList.add('dark')
        setResolvedTheme('dark')
      } else {
        root.classList.remove('dark')
        setResolvedTheme('light')
      }
    }

    mediaQuery.addEventListener('change', handler)
    return () => mediaQuery.removeEventListener('change', handler)
  }, [theme])

  const value: ThemeContextType = {
    theme,
    setTheme,
    resolvedTheme
  }

  return (
    <ThemeContext.Provider value={value}>
      {children}
    </ThemeContext.Provider>
  )
}

export function useTheme() {
  const context = useContext(ThemeContext)
  if (!context) {
    throw new Error('useTheme must be used within ThemeProvider')
  }
  return context
}

export { ThemeContext }
