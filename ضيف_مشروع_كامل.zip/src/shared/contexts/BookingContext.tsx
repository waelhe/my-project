'use client'

import { createContext, useContext, useState, useCallback, ReactNode } from 'react'

// ==================== Types ====================

export interface BookingGuests {
  adults: number
  children: number
  infants: number
}

export interface BookingDates {
  checkIn: Date | null
  checkOut: Date | null
}

export interface BookingPricing {
  baseAmount: number
  nightsCount: number
  cleaningFee: number
  serviceFee: number
  guaranteeFee: number
  discount: number
  totalAmount: number
  currency: string
}

export interface BookingAccommodation {
  id: string
  titleAr: string
  coverImage: string | null
  city: { nameAr: string } | null
  basePrice: number
  cleaningFee: number | null
  minNights: number
  maxNights: number | null
  maxGuests: number
}

export interface BookingStep {
  step: 'dates' | 'guests' | 'details' | 'payment' | 'confirmation'
  completed: boolean
}

export interface BookingContextType {
  // State
  accommodation: BookingAccommodation | null
  dates: BookingDates
  guests: BookingGuests
  pricing: BookingPricing | null
  specialRequests: string
  guestInfo: {
    name: string
    phone: string
    email: string
  }
  currentStep: BookingStep['step']
  loading: boolean
  bookingId: string | null

  // Actions
  setAccommodation: (acc: BookingAccommodation | null) => void
  setDates: (dates: BookingDates) => void
  setGuests: (guests: BookingGuests) => void
  setSpecialRequests: (requests: string) => void
  setGuestInfo: (info: { name: string; phone: string; email: string }) => void
  setCurrentStep: (step: BookingStep['step']) => void
  calculatePricing: () => void
  createBooking: () => Promise<{ success: boolean; error?: string; bookingId?: string }>
  resetBooking: () => void
  loadBooking: (bookingId: string) => Promise<{ success: boolean; error?: string }>
}

// ==================== Context ====================

const BookingContext = createContext<BookingContextType | null>(null)

export function BookingProvider({ children }: { children: ReactNode }) {
  const [accommodation, setAccommodation] = useState<BookingAccommodation | null>(null)
  const [dates, setDates] = useState<BookingDates>({ checkIn: null, checkOut: null })
  const [guests, setGuests] = useState<BookingGuests>({ adults: 1, children: 0, infants: 0 })
  const [pricing, setPricing] = useState<BookingPricing | null>(null)
  const [specialRequests, setSpecialRequests] = useState('')
  const [guestInfo, setGuestInfo] = useState({ name: '', phone: '', email: '' })
  const [currentStep, setCurrentStep] = useState<BookingStep['step']>('dates')
  const [loading, setLoading] = useState(false)
  const [bookingId, setBookingId] = useState<string | null>(null)

  // Calculate pricing
  const calculatePricing = useCallback(() => {
    if (!accommodation || !dates.checkIn || !dates.checkOut) {
      setPricing(null)
      return
    }

    const nightsCount = Math.ceil((dates.checkOut.getTime() - dates.checkIn.getTime()) / (1000 * 60 * 60 * 24))
    const baseAmount = accommodation.basePrice * nightsCount
    const cleaningFee = accommodation.cleaningFee || 0
    const serviceFee = Math.round(baseAmount * 0.08) // 8% service fee
    const guaranteeFee = Math.round(baseAmount * 0.05) // 5% guarantee fee
    const totalAmount = baseAmount + cleaningFee + serviceFee + guaranteeFee

    setPricing({
      baseAmount,
      nightsCount,
      cleaningFee,
      serviceFee,
      guaranteeFee,
      discount: 0,
      totalAmount,
      currency: 'SYP'
    })
  }, [accommodation, dates])

  // Create booking
  const createBooking = useCallback(async () => {
    if (!accommodation || !dates.checkIn || !dates.checkOut || !pricing) {
      return { success: false, error: 'بيانات الحجز غير كاملة' }
    }

    setLoading(true)
    try {
      const res = await fetch('/api/bookings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          accommodationId: accommodation.id,
          checkIn: dates.checkIn.toISOString(),
          checkOut: dates.checkOut.toISOString(),
          guestsCount: guests.adults + guests.children,
          guestName: guestInfo.name,
          guestPhone: guestInfo.phone,
          guestEmail: guestInfo.email,
          specialRequests
        })
      })

      const data = await res.json()

      if (!res.ok) {
        return { success: false, error: data.error || 'حدث خطأ' }
      }

      setBookingId(data.booking.id)
      return { success: true, bookingId: data.booking.id }
    } catch (error) {
      return { success: false, error: 'حدث خطأ، يرجى المحاولة لاحقاً' }
    } finally {
      setLoading(false)
    }
  }, [accommodation, dates, guests, guestInfo, pricing, specialRequests])

  // Load existing booking
  const loadBooking = useCallback(async (id: string) => {
    setLoading(true)
    try {
      const res = await fetch(`/api/bookings/${id}`)
      const data = await res.json()

      if (!res.ok) {
        return { success: false, error: data.error || 'حدث خطأ' }
      }

      const booking = data.booking
      setBookingId(booking.id)
      setDates({
        checkIn: new Date(booking.checkIn),
        checkOut: new Date(booking.checkOut)
      })
      setGuests({
        adults: booking.guestsCount,
        children: 0,
        infants: 0
      })
      setSpecialRequests(booking.specialRequests || '')
      setGuestInfo({
        name: booking.guestName || '',
        phone: booking.guestPhone || '',
        email: booking.guestEmail || ''
      })

      return { success: true }
    } catch (error) {
      return { success: false, error: 'حدث خطأ، يرجى المحاولة لاحقاً' }
    } finally {
      setLoading(false)
    }
  }, [])

  // Reset booking
  const resetBooking = useCallback(() => {
    setAccommodation(null)
    setDates({ checkIn: null, checkOut: null })
    setGuests({ adults: 1, children: 0, infants: 0 })
    setPricing(null)
    setSpecialRequests('')
    setGuestInfo({ name: '', phone: '', email: '' })
    setCurrentStep('dates')
    setBookingId(null)
  }, [])

  const value: BookingContextType = {
    accommodation,
    dates,
    guests,
    pricing,
    specialRequests,
    guestInfo,
    currentStep,
    loading,
    bookingId,
    setAccommodation,
    setDates,
    setGuests,
    setSpecialRequests,
    setGuestInfo,
    setCurrentStep,
    calculatePricing,
    createBooking,
    resetBooking,
    loadBooking
  }

  return (
    <BookingContext.Provider value={value}>
      {children}
    </BookingContext.Provider>
  )
}

export function useBooking() {
  const context = useContext(BookingContext)
  if (!context) {
    throw new Error('useBooking must be used within BookingProvider')
  }
  return context
}

export { BookingContext }
