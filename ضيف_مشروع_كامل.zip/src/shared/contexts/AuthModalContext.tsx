'use client'

import { createContext, useContext, useState, useCallback, ReactNode } from 'react'

export type AuthModalRole = 'GUEST' | 'HOST'

interface AuthModalContextType {
  isOpen: boolean
  defaultRole: AuthModalRole
  openAuthModal: (role?: AuthModalRole) => void
  closeAuthModal: () => void
}

const AuthModalContext = createContext<AuthModalContextType | null>(null)

export function AuthModalProvider({ children }: { children: ReactNode }) {
  const [isOpen, setIsOpen] = useState(false)
  const [defaultRole, setDefaultRole] = useState<AuthModalRole>('GUEST')

  const openAuthModal = useCallback((role: AuthModalRole = 'GUEST') => {
    setDefaultRole(role)
    setIsOpen(true)
  }, [])

  const closeAuthModal = useCallback(() => {
    setIsOpen(false)
  }, [])

  return (
    <AuthModalContext.Provider value={{
      isOpen,
      defaultRole,
      openAuthModal,
      closeAuthModal
    }}>
      {children}
    </AuthModalContext.Provider>
  )
}

export function useAuthModal() {
  const context = useContext(AuthModalContext)
  if (!context) {
    throw new Error('useAuthModal must be used within AuthModalProvider')
  }
  return context
}

export { AuthModalContext }
