// ==================== Navigation Types ====================

export type PageType = 
  // Main Pages
  | 'home' 
  | 'search'
  // Auth Pages
  | 'login'
  | 'register'
  | 'profile'
  | 'settings'
  // Accommodation Pages
  | 'accommodations' 
  | 'accommodation-details'
  // Booking Pages
  | 'booking'
  | 'booking-confirmation'
  | 'my-bookings'
  // Community Pages
  | 'community' 
  | 'community-post'
  | 'community-create'
  // Review Pages
  | 'host-reviews'
  | 'write-review'
  // Host Dashboard
  | 'host-dashboard'
  | 'host-accommodations'
  | 'host-bookings'
  | 'host-calendar'
  | 'host-reviews-manage'
  | 'host-payments'
  | 'host-register'
  // Messages
  | 'messages'
  | 'conversation'
  // Admin Pages
  | 'admin-dashboard'
  | 'admin-users'
  | 'admin-accommodations'
  | 'admin-bookings'
  | 'admin-reports'
  // Services
  | 'transports'
  | 'transport-details'
  | 'tours'
  | 'tour-details'
  | 'business'
  | 'business-details'
  // Static Pages
  | 'terms'
  | 'privacy'
  | 'help'
  | 'about'

export interface NavigationContextType {
  currentPage: PageType
  setCurrentPage: (page: PageType) => void
  pageParams: Record<string, string>
  setPageParams: (params: Record<string, string>) => void
  navigate: (page: PageType, params?: Record<string, string>) => void
}

// ==================== User Types ====================

export type UserRole = 'GUEST' | 'HOST' | 'ADMIN' | 'SUPER_ADMIN'
export type UserStatus = 'ACTIVE' | 'INACTIVE' | 'SUSPENDED' | 'PENDING_VERIFICATION'

export interface User {
  id: string
  phone: string
  email: string | null
  name: string | null
  nameAr: string | null
  avatar: string | null
  role: UserRole
  status: UserStatus
  isVerified: boolean
  language: string
  businessName: string | null
  businessNameAr: string | null
  businessType: string | null
  city: string | null
  country: string | null
  createdAt: string
  lastLoginAt: string | null
}

// ==================== City Types ====================

export interface City {
  id: string
  nameAr: string
  nameEn: string
  governorate: string
  isPopular: boolean
  image: string | null
  _count: {
    accommodations: number
  }
}

// ==================== Accommodation Types ====================

export interface Accommodation {
  id: string
  titleAr: string
  titleEn: string | null
  descriptionAr: string | null
  descriptionEn: string | null
  type: string
  status: string
  addressAr: string | null
  basePrice: number
  weekendPrice: number | null
  cleaningFee: number | null
  rating: number
  reviewCount: number
  coverImage: string | null
  images: string[]
  amenities: string[]
  bedrooms: number
  bathrooms: number
  maxGuests: number
  beds: number
  checkInTime: string
  checkOutTime: string
  minNights: number
  maxNights: number | null
  houseRules: string[]
  smokingAllowed: boolean
  petsAllowed: boolean
  partiesAllowed: boolean
  latitude: number | null
  longitude: number | null
  city: {
    id: string
    nameAr: string
    nameEn: string
  } | null
  host: {
    id: string
    name: string | null
    nameAr: string | null
    avatar: string | null
    role: string
  } | null
}

export const ACCOMMODATION_TYPE_LABELS: Record<string, string> = {
  HOTEL: "فندق",
  APARTMENT: "شقة",
  VILLA: "فيلا",
  CHALET: "شاليه",
  CAMP: "مخيم",
  GUESTHOUSE: "نزل",
  HOSTEL: "سكن شباب",
  RESORT: "منتجع"
}

export const AMENITY_LABELS: Record<string, { label: string; icon: string }> = {
  wifi: { label: 'واي فاي', icon: 'Wifi' },
  ac: { label: 'تكييف', icon: 'Wind' },
  parking: { label: 'موقف سيارات', icon: 'Car' },
  pool: { label: 'مسبح', icon: 'Waves' },
  kitchen: { label: 'مطبخ', icon: 'ChefHat' },
  washer: { label: 'غسالة', icon: 'Shirt' },
  tv: { label: 'تلفزيون', icon: 'Tv' },
  heater: { label: 'تدفئة', icon: 'Flame' },
  gym: { label: 'صالة رياضية', icon: 'Dumbbell' },
  garden: { label: 'حديقة', icon: 'Trees' },
  balcony: { label: 'شرفة', icon: 'Sun' },
  fireplace: { label: 'مدفأة', icon: 'Flame' },
  breakfast: { label: 'إفطار', icon: 'Coffee' },
  beach: { label: 'شاطئ', icon: 'Umbrella' },
  view: { label: 'إطلالة', icon: 'Mountain' }
}

// ==================== Booking Types ====================

export type BookingStatus = 'PENDING' | 'CONFIRMED' | 'PAYMENT_PENDING' | 'PAID' | 'CHECKED_IN' | 'CHECKED_OUT' | 'CANCELLED' | 'REFUNDED' | 'DISPUTED'

export interface Booking {
  id: string
  confirmationCode: string
  status: BookingStatus
  checkIn: string
  checkOut: string
  nightsCount: number
  guestsCount: number
  baseAmount: number
  cleaningFee: number | null
  serviceFee: number
  guaranteeFee: number
  discount: number
  totalAmount: number
  currency: string
  guestName: string | null
  guestPhone: string | null
  guestEmail: string | null
  specialRequests: string | null
  createdAt: string
  confirmedAt: string | null
  cancelledAt: string | null
  cancellationReason: string | null
  accommodation: {
    id: string
    titleAr: string
    coverImage: string | null
    addressAr: string | null
    city: { nameAr: string } | null
    host: {
      id: string
      name: string | null
      nameAr: string | null
      phone: string
    }
  }
}

export const BOOKING_STATUS_LABELS: Record<BookingStatus, { label: string; color: string }> = {
  PENDING: { label: 'قيد الانتظار', color: 'bg-yellow-100 text-yellow-700' },
  CONFIRMED: { label: 'مؤكد', color: 'bg-blue-100 text-blue-700' },
  PAYMENT_PENDING: { label: 'بانتظار الدفع', color: 'bg-orange-100 text-orange-700' },
  PAID: { label: 'مدفوع', color: 'bg-green-100 text-green-700' },
  CHECKED_IN: { label: 'وصل', color: 'bg-teal-100 text-teal-700' },
  CHECKED_OUT: { label: 'غادر', color: 'bg-gray-100 text-gray-700' },
  CANCELLED: { label: 'ملغي', color: 'bg-red-100 text-red-700' },
  REFUNDED: { label: 'مسترد', color: 'bg-purple-100 text-purple-700' },
  DISPUTED: { label: 'نزاع', color: 'bg-pink-100 text-pink-700' }
}

// ==================== Community Types ====================

export interface CommunityPost {
  id: string
  titleAr: string
  titleEn: string | null
  contentAr: string
  contentEn: string | null
  type: string
  status: string
  viewCount: number
  likeCount: number
  commentCount: number
  isPinned: boolean
  isFeatured: boolean
  tags: string[]
  images: string[]
  createdAt: string
  author: {
    id: string
    name: string | null
    nameAr: string | null
    avatar: string | null
    role: string
  }
  category: {
    id: string
    nameAr: string
    nameEn: string | null
    icon: string | null
    color: string | null
  } | null
  _count: {
    comments: number
    likes: number
  }
}

export interface CommunityCategory {
  id: string
  nameAr: string
  nameEn: string | null
  descriptionAr: string | null
  icon: string | null
  color: string | null
  isPopular: boolean
  postsCount?: number
}

export const POST_TYPE_LABELS: Record<string, { label: string; color: string }> = {
  DISCUSSION: { label: 'نقاش', color: 'bg-sky-100 text-sky-700' },
  QUESTION: { label: 'سؤال', color: 'bg-amber-100 text-amber-700' },
  STORY: { label: 'تجربة', color: 'bg-rose-100 text-rose-700' },
  ANNOUNCEMENT: { label: 'إعلان', color: 'bg-violet-100 text-violet-700' },
  GUIDE: { label: 'دليل', color: 'bg-emerald-100 text-emerald-700' }
}

// ==================== Review Types ====================

export interface HostReview {
  id: string
  communication: number
  cleanliness: number
  accuracy: number
  value: number
  location: number
  checkIn: number
  overallRating: number
  commentAr: string | null
  commentEn: string | null
  isVerified: boolean
  hostResponse: string | null
  hostResponseAt: string | null
  createdAt: string
  reviewer: {
    id: string
    name: string | null
    nameAr: string | null
    avatar: string | null
  }
  host: {
    id: string
    name: string | null
    nameAr: string | null
    avatar: string | null
  }
}

export interface AccommodationReview {
  id: string
  rating: number
  commentAr: string | null
  commentEn: string | null
  cleanliness: number | null
  location: number | null
  value: number | null
  communication: number | null
  checkIn: number | null
  isVerified: boolean
  hostResponse: string | null
  hostResponseAt: string | null
  createdAt: string
  user: {
    id: string
    name: string | null
    nameAr: string | null
    avatar: string | null
  }
}

// ==================== Message Types ====================

export interface Message {
  id: string
  content: string
  type: 'text' | 'image' | 'system'
  isFromGuest: boolean
  isRead: boolean
  readAt: string | null
  createdAt: string
  senderId: string
  sender: {
    id: string
    name: string | null
    nameAr: string | null
    avatar: string | null
  }
}

export interface Conversation {
  id: string
  type: 'booking' | 'inquiry' | 'support'
  status: 'active' | 'archived' | 'blocked'
  lastMessage: string | null
  lastMessageAt: string | null
  createdAt: string
  guest: {
    id: string
    name: string | null
    nameAr: string | null
    avatar: string | null
  }
  host: {
    id: string
    name: string | null
    nameAr: string |    null
    avatar: string | null
  } | null
  booking: {
    id: string
    confirmationCode: string
    accommodation: {
      id: string
      titleAr: string
      coverImage: string | null
    }
  } | null
  _count: {
    messages: number
  }
}

// ==================== Notification Types ====================

export interface Notification {
  id: string
  type: 'booking' | 'message' | 'review' | 'payment' | 'system' | 'host'
  titleAr: string
  titleEn: string | null
  bodyAr: string | null
  bodyEn: string | null
  data: Record<string, string> | null
  isRead: boolean
  readAt: string | null
  createdAt: string
}

// ==================== Transport Types ====================

export interface Transport {
  id: string
  titleAr: string
  titleEn: string | null
  descriptionAr: string | null
  type: string
  status: string
  brand: string | null
  model: string | null
  year: number | null
  color: string | null
  seats: number
  hasDriver: boolean
  hasWifi: boolean
  hasAC: boolean
  hasGPS: boolean
  basePrice: number
  pricePerKm: number | null
  pricePerDay: number | null
  currency: string
  coverImage: string | null
  images: string[]
  rating: number
  reviewCount: number
  city: {
    id: string
    nameAr: string
  } | null
  host: {
    id: string
    name: string | null
    nameAr: string | null
    avatar: string | null
  }
}

export const TRANSPORT_TYPE_LABELS: Record<string, string> = {
  CAR: 'سيارة',
  CAR_WITH_DRIVER: 'سيارة مع سائق',
  BUS: 'باص',
  MINIVAN: 'حافلة صغيرة',
  BOAT: 'قارب',
  HELICOPTER: 'هليكوبتر'
}

// ==================== Tour Types ====================

export interface Tour {
  id: string
  titleAr: string
  titleEn: string | null
  descriptionAr: string | null
  type: string
  status: string
  duration: number
  maxGroupSize: number
  minGroupSize: number
  difficulty: string
  meetingPoint: string | null
  basePrice: number
  currency: string
  coverImage: string | null
  images: string[]
  rating: number
  reviewCount: number
  city: {
    id: string
    nameAr: string
  } | null
  guide: {
    id: string
    name: string | null
    nameAr: string | null
    avatar: string | null
  } | null
}

export const TOUR_TYPE_LABELS: Record<string, string> = {
  CITY_TOUR: 'جولة مدينة',
  HISTORICAL: 'سياحة تاريخية',
  RELIGIOUS: 'سياحة دينية',
  ADVENTURE: 'سياحة مغامرة',
  MEDICAL: 'سياحة علاجية',
  WAR_TOURISM: 'سياحة الحرب',
  NATURE: 'سياحة طبيعية',
  FOOD: 'سياحة الطعام',
  SHOPPING: 'سياحة تسوق',
  CUSTOM: 'جولة مخصصة'
}

// ==================== Business Types ====================

export interface BusinessListing {
  id: string
  titleAr: string
  titleEn: string | null
  descriptionAr: string | null
  type: string
  status: string
  sector: string | null
  investmentMin: number | null
  investmentMax: number | null
  expectedReturn: number | null
  price: number | null
  currency: string
  coverImage: string | null
  images: string[]
  city: {
    id: string
    nameAr: string
  } | null
  owner: {
    id: string
    name: string | null
    nameAr: string | null
  }
}

export const BUSINESS_TYPE_LABELS: Record<string, string> = {
  INVESTMENT_OPPORTUNITY: 'فرصة استثمارية',
  COMMERCIAL_PROPERTY: 'عقار تجاري',
  BUSINESS_SERVICE: 'خدمة أعمال',
  PARTNERSHIP: 'شراكة تجارية',
  FRANCHISE: 'امتياز تجاري'
}

// ==================== Payment Types ====================

export type PaymentStatus = 'PENDING' | 'PROCESSING' | 'COMPLETED' | 'FAILED' | 'REFUNDED' | 'DISPUTED'
export type PaymentMethod = 'CASH' | 'SYRIATEL' | 'MTN' | 'BANK_TRANSFER' | 'CREDIT_CARD'

export interface Payment {
  id: string
  amount: number
  currency: string
  status: PaymentStatus
  method: PaymentMethod
  transactionId: string | null
  isGuarantee: boolean
  releaseDate: string | null
  createdAt: string
  booking: {
    id: string
    confirmationCode: string
  }
}

export const PAYMENT_METHOD_LABELS: Record<PaymentMethod, string> = {
  CASH: 'نقدي عند الوصول',
  SYRIATEL: 'سيرياتيل كاش',
  MTN: 'MTN كاش',
  BANK_TRANSFER: 'تحويل بنكي',
  CREDIT_CARD: 'بطاقة ائتمان'
}

// ==================== Favorite Types ====================

export interface Favorite {
  id: string
  accommodationId: string
  accommodation: {
    id: string
    titleAr: string
    coverImage: string | null
    basePrice: number
    rating: number
    city: { nameAr: string } | null
  }
  createdAt: string
}

// ==================== Host Dashboard Types ====================

export interface HostStats {
  totalAccommodations: number
  activeBookings: number
  totalEarnings: number
  pendingPayouts: number
  totalReviews: number
  averageRating: number
  occupancyRate: number
  monthlyEarnings: Array<{
    month: string
    amount: number
  }>
}

// ==================== Admin Dashboard Types ====================

export interface AdminStats {
  totalUsers: number
  totalHosts: number
  totalAccommodations: number
  totalBookings: number
  totalRevenue: number
  pendingApprovals: number
  recentSignups: number
  monthlyBookings: Array<{
    month: string
    count: number
  }>
}
