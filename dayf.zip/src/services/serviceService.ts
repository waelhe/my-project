import { db } from '../firebase';
import { 
  collection, 
  getDocs, 
  getDoc, 
  doc, 
  query, 
  where, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  serverTimestamp,
  Timestamp,
  setDoc,
  getDocsFromCache
} from 'firebase/firestore';
import { MOCK_SERVICES } from '../data/categories';

export interface Service {
  id: string;
  mainCategoryId: string;
  subCategoryId: string;
  subSubCategoryId?: string;
  title: string;
  location: string;
  price: number;
  originalPrice?: number;
  rating: number;
  reviews: number;
  images: string[];
  type: string;
  amenities: string[];
  features: string[];
  isPopular: boolean;
  host?: {
    name: string;
    isSuperhost: boolean;
    avatar: string;
  };
  authorUid: string;
  createdAt: any;
}

const SERVICES_COLLECTION = 'services';

export const seedServices = async (userUid: string) => {
  try {
    const querySnapshot = await getDocs(collection(db, SERVICES_COLLECTION));
    if (querySnapshot.empty) {
      console.log('Seeding services...');
      for (const service of MOCK_SERVICES) {
        const { id, ...serviceData } = service;
        try {
          await setDoc(doc(db, SERVICES_COLLECTION, id), {
            ...serviceData,
            authorUid: userUid,
            createdAt: serverTimestamp()
          });
        } catch (err) {
          // If we can't seed (e.g. not an admin), just skip it
          console.warn(`Could not seed service ${id}:`, err);
        }
      }
      console.log('Seeding complete or skipped.');
    }
  } catch (error) {
    console.error('Error during seeding check:', error);
    // Don't throw, just let the app continue
  }
};

export const getAllServices = async (): Promise<Service[]> => {
  try {
    const querySnapshot = await getDocs(collection(db, SERVICES_COLLECTION));
    return querySnapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data()
    })) as Service[];
  } catch (error) {
    console.warn('Error fetching from server, trying cache...', error);
    try {
      const cacheSnapshot = await getDocsFromCache(collection(db, SERVICES_COLLECTION));
      return cacheSnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Service[];
    } catch (cacheError) {
      console.error('Error fetching from cache:', cacheError);
      return [];
    }
  }
};

export const getServicesByCategory = async (categoryId: string): Promise<Service[]> => {
  const q = query(collection(db, SERVICES_COLLECTION), where('mainCategoryId', '==', categoryId));
  try {
    const querySnapshot = await getDocs(q);
    return querySnapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data()
    })) as Service[];
  } catch (error) {
    console.warn('Error fetching category from server, trying cache...', error);
    try {
      const cacheSnapshot = await getDocsFromCache(q);
      return cacheSnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Service[];
    } catch (cacheError) {
      console.error('Error fetching category from cache:', cacheError);
      return [];
    }
  }
};

export const getServiceById = async (id: string): Promise<Service | null> => {
  const docRef = doc(db, SERVICES_COLLECTION, id);
  try {
    const docSnap = await getDoc(docRef);
    if (docSnap.exists()) {
      return { id: docSnap.id, ...docSnap.data() } as Service;
    }
  } catch (error) {
    console.warn('Error fetching service from server, trying cache...', error);
    try {
      // Note: getDocFromCache is imported but we can just use getDoc with source if needed, 
      // but standard getDoc also tries cache if offline. 
      // However, explicit cache fetch is safer for "Could not reach backend" errors.
      const cacheSnap = await getDoc(docRef); // getDoc automatically handles cache if offline
      if (cacheSnap.exists()) {
        return { id: cacheSnap.id, ...cacheSnap.data() } as Service;
      }
    } catch (cacheError) {
      console.error('Error fetching service from cache:', cacheError);
    }
  }
  return null;
};

export const createService = async (serviceData: Omit<Service, 'id' | 'createdAt'>) => {
  return await addDoc(collection(db, SERVICES_COLLECTION), {
    ...serviceData,
    createdAt: serverTimestamp()
  });
};

export const updateService = async (id: string, serviceData: Partial<Service>) => {
  const docRef = doc(db, SERVICES_COLLECTION, id);
  await updateDoc(docRef, serviceData);
};

export const deleteService = async (id: string) => {
  const docRef = doc(db, SERVICES_COLLECTION, id);
  await deleteDoc(docRef);
};
