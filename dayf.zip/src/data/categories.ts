import { Plane, HeartPulse, GraduationCap, Briefcase } from 'lucide-react';

export const MAIN_CATEGORIES = [
  {
    id: 'tourism',
    name: 'السياحة',
    description: 'اكتشف جمال سوريا، تاريخها العريق، وطبيعتها الساحرة',
    icon: Plane,
    color: 'emerald',
    image: 'https://picsum.photos/seed/syria_tourism/1200/400',
    subCategories: [
      { 
        id: 'recreational', 
        name: 'ترفيهية واستجمام', 
        icon: '🏖️',
        subCategories: [
          { id: 'destinations', name: 'الوجهات' },
          { id: 'stays', name: 'الإقامات' },
          { id: 'activities', name: 'الأنشطة' },
          { id: 'services', name: 'الخدمات' }
        ]
      },
      { 
        id: 'cultural', 
        name: 'ثقافية وتاريخية', 
        icon: '🏛️',
        subCategories: [
          { id: 'landmarks', name: 'المعالم' },
          { id: 'services', name: 'الخدمات' },
          { id: 'workshops', name: 'الورش' }
        ]
      },
      { 
        id: 'religious', 
        name: 'دينية وروحانية', 
        icon: '🕌',
        subCategories: [
          { id: 'landmarks', name: 'المعالم' },
          { id: 'services', name: 'الخدمات' },
          { id: 'programs', name: 'البرامج' }
        ]
      },
      { 
        id: 'nature', 
        name: 'طبيعية ومغامرة', 
        icon: '🏔️',
        subCategories: [
          { id: 'landmarks', name: 'المعالم' },
          { id: 'activities', name: 'الأنشطة' },
          { id: 'adventures', name: 'المغامرات' }
        ]
      }
    ]
  },
  {
    id: 'medical',
    name: 'العلاج',
    description: 'رعاية صحية متميزة، أطباء خبراء، ومراكز طبية متقدمة',
    icon: HeartPulse,
    color: 'blue',
    image: 'https://picsum.photos/seed/syria_medical/1200/400',
    subCategories: [
      { 
        id: 'medical', 
        name: 'رعاية طبية', 
        icon: '🏥',
        subCategories: [
          { id: 'hospitals', name: 'مستشفيات' },
          { id: 'surgeries', name: 'عمليات جراحية' },
          { id: 'specialized', name: 'علاجات متخصصة' },
          { id: 'diagnosis', name: 'تشخيص ومتابعة' }
        ]
      },
      { 
        id: 'dental', 
        name: 'طب الأسنان', 
        icon: '🦷',
        subCategories: [
          { id: 'clinics', name: 'عيادات متخصصة' },
          { id: 'cosmetic', name: 'تجميل الأسنان' },
          { id: 'implants', name: 'زراعة وتقويم' },
          { id: 'whitening', name: 'تبييض وحشوات' }
        ]
      },
      { 
        id: 'eye', 
        name: 'طب العيون', 
        icon: '👁️',
        subCategories: [
          { id: 'centers', name: 'مراكز دولية' },
          { id: 'lasik', name: 'عمليات الليزر' },
          { id: 'lenses', name: 'عدسات وعلاجات' },
          { id: 'exams', name: 'فحوصات شاملة' }
        ]
      },
      { 
        id: 'alternative', 
        name: 'طب بديل واستشفاء', 
        icon: '🌿',
        subCategories: [
          { id: 'herbal', name: 'مراكز أعشاب' },
          { id: 'natural', name: 'حجامة وعلاجات طبيعية' },
          { id: 'spa', name: 'استشفاء وسبا صحي' },
          { id: 'yoga', name: 'يوغا وتأمل' }
        ]
      },
      {
        id: 'foreign_patients',
        name: 'خدمات المرضى الأجانب',
        icon: '🛠️',
        subCategories: [
          { id: 'arrangements', name: 'ترتيبات العلاج' },
          { id: 'transport', name: 'نقل ومواصلات' },
          { id: 'translation', name: 'ترجمة طبية' },
          { id: 'visas', name: 'تأشيرات علاجية' },
          { id: 'recovery', name: 'إقامة وتعافي' }
        ]
      }
    ]
  },
  {
    id: 'education',
    name: 'الدراسة',
    description: 'جامعات عريقة، معاهد متخصصة، وبرامج تعليمية شاملة',
    icon: GraduationCap,
    color: 'amber',
    image: 'https://picsum.photos/seed/syria_education/1200/400',
    subCategories: [
      { 
        id: 'university', 
        name: 'تعليم جامعي', 
        icon: '🎓',
        subCategories: [
          { id: 'public', name: 'جامعات حكومية' },
          { id: 'degrees', name: 'بكالوريوس وماجستير' },
          { id: 'specialties', name: 'تخصصات متنوعة' },
          { id: 'registration', name: 'قبول وتسجيل' }
        ]
      },
      { 
        id: 'vocational', 
        name: 'تأهيل مهني', 
        icon: '📜',
        subCategories: [
          { id: 'technical', name: 'معاهد تقنية' },
          { id: 'training', name: 'دورات تأهيل' },
          { id: 'certificates', name: 'شهادات مهنية' },
          { id: 'workshops', name: 'ورش تدريبية' }
        ]
      },
      { 
        id: 'languages', 
        name: 'تعلم اللغات', 
        icon: '🗣️',
        subCategories: [
          { id: 'arabic', name: 'العربية للأجانب' },
          { id: 'english', name: 'الإنجليزية' },
          { id: 'other', name: 'لغات أخرى' },
          { id: 'immersion', name: 'محادثة وانغماس' }
        ]
      },
      { 
        id: 'arts', 
        name: 'حرف وفنون', 
        icon: '🎨',
        subCategories: [
          { id: 'crafts', name: 'ورش حرفية' },
          { id: 'traditional', name: 'فنون تقليدية' },
          { id: 'design', name: 'تصميم وإبداع' },
          { id: 'heritage', name: 'تراث وحرف يدوية' }
        ]
      },
      {
        id: 'foreign_students',
        name: 'خدمات الطلاب الأجانب',
        icon: '🛠️',
        subCategories: [
          { id: 'visas', name: 'تأشيرات طالب' },
          { id: 'housing', name: 'سكن طلابي' },
          { id: 'insurance', name: 'تأمين صحي' },
          { id: 'transport', name: 'تنقلات' },
          { id: 'support', name: 'دعم أكاديمي' }
        ]
      }
    ]
  },
  {
    id: 'business',
    name: 'الأعمال',
    description: 'فرص استثمارية، شراكات استراتيجية، وخدمات أعمال متكاملة',
    icon: Briefcase,
    color: 'purple',
    image: 'https://picsum.photos/seed/syria_business/1200/400',
    subCategories: [
      { 
        id: 'investment', 
        name: 'فرص استثمارية', 
        icon: '💰',
        subCategories: [
          { id: 'realestate', name: 'عقارات' },
          { id: 'tourism', name: 'سياحي' },
          { id: 'industrial', name: 'صناعي' },
          { id: 'commercial', name: 'تجاري' }
        ]
      },
      { 
        id: 'partnerships', 
        name: 'شراكات تجارية', 
        icon: '🤝',
        subCategories: [
          { id: 'commercial', name: 'شراكات تجارية' },
          { id: 'industrial', name: 'شراكات صناعية' },
          { id: 'services', name: 'شراكات خدمات' },
          { id: 'opportunities', name: 'فرص مشتركة' }
        ]
      },
      { 
        id: 'conferences', 
        name: 'مؤتمرات ومعارض', 
        icon: '📅',
        subCategories: [
          { id: 'trade', name: 'معارض تجارية' },
          { id: 'economic', name: 'مؤتمرات اقتصادية' },
          { id: 'workshops', name: 'ورش عمل' },
          { id: 'networking', name: 'فعاليات التواصل' }
        ]
      },
      { 
        id: 'services', 
        name: 'خدمات أعمال', 
        icon: '🏢',
        subCategories: [
          { id: 'offices', name: 'مكاتب مؤقتة' },
          { id: 'meetings', name: 'قاعات اجتماعات' },
          { id: 'legal', name: 'استشارات قانونية' },
          { id: 'feasibility', name: 'دراسات جدوى' },
          { id: 'translation', name: 'ترجمة معتمدة' },
          { id: 'government', name: 'تسهيلات حكومية' }
        ]
      }
    ]
  }
];

export const MOCK_SERVICES = [
  // ================= TOURISM - RECREATIONAL =================
  {
    id: 't1',
    mainCategoryId: 'tourism',
    subCategoryId: 'recreational',
    subSubCategoryId: 'stays',
    title: 'منتجع الرمال الذهبية الفاخر',
    location: 'طرطوس، الشاطئ الأزرق',
    price: 150,
    originalPrice: 200,
    rating: 4.9,
    reviews: 320,
    images: [
      'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1566073771259-6a8506099945?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'
    ],
    type: 'منتجع',
    amenities: ['مسبح خاص', 'واي فاي سريع', 'إطلالة بحرية', 'سبا ومساج', 'موقف سيارات مجاني', 'مطعم فاخر'],
    features: ['إلغاء مجاني', 'حجز فوري'],
    isPopular: true,
    host: { name: 'إدارة المنتجع', isSuperhost: true, avatar: 'https://i.pravatar.cc/150?u=t1' }
  },
  {
    id: 't2',
    mainCategoryId: 'tourism',
    subCategoryId: 'recreational',
    subSubCategoryId: 'destinations',
    title: 'جولة القوارب في جزيرة أرواد',
    location: 'طرطوس، جزيرة أرواد',
    price: 25,
    rating: 4.7,
    reviews: 85,
    images: ['https://images.unsplash.com/photo-1544551763-46a013bb70d5?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'],
    type: 'جولة بحرية',
    amenities: ['مرشد سياحي', 'سترات نجاة', 'وجبة خفيفة'],
    features: ['مناسب للأطفال'],
    isPopular: false,
    host: { name: 'الكابتن علي', isSuperhost: false, avatar: 'https://i.pravatar.cc/150?u=t2' }
  },
  {
    id: 't3',
    mainCategoryId: 'tourism',
    subCategoryId: 'recreational',
    subSubCategoryId: 'stays',
    title: 'شاليهات النورس الملكية',
    location: 'اللاذقية، وادي قنديل',
    price: 120,
    rating: 4.8,
    reviews: 210,
    images: ['https://images.unsplash.com/photo-1499793983690-e29da59ef1c2?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'],
    type: 'شاليه',
    amenities: ['شاطئ خاص', 'مطبخ كامل', 'تكييف'],
    features: ['إلغاء مجاني'],
    isPopular: true,
    host: { name: 'شركة النورس', isSuperhost: true, avatar: 'https://i.pravatar.cc/150?u=t3' }
  },

  // ================= TOURISM - CULTURAL =================
  {
    id: 't4',
    mainCategoryId: 'tourism',
    subCategoryId: 'cultural',
    subSubCategoryId: 'landmarks',
    title: 'فندق بيت المملوكة التراثي',
    location: 'دمشق، باب توما',
    price: 95,
    rating: 4.9,
    reviews: 180,
    images: ['https://images.unsplash.com/photo-1518780664697-55e3ad937233?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'],
    type: 'فندق تراثي',
    amenities: ['فطور دمشقي', 'فناء داخلي', 'واي فاي'],
    features: ['مبنى تاريخي'],
    isPopular: true,
    host: { name: 'عائلة المملوكة', isSuperhost: true, avatar: 'https://i.pravatar.cc/150?u=t4' }
  },
  {
    id: 't5',
    mainCategoryId: 'tourism',
    subCategoryId: 'cultural',
    subSubCategoryId: 'workshops',
    title: 'ورشة تعليم صناعة الموزاييك',
    location: 'دمشق، التكية السليمانية',
    price: 40,
    rating: 4.6,
    reviews: 55,
    images: ['https://images.unsplash.com/photo-1513519245088-0e12902e5a38?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'],
    type: 'ورشة عمل',
    amenities: ['المواد الأولية', 'شهادة حضور'],
    features: ['صناعة يدوية'],
    isPopular: false,
    host: { name: 'الحرفي أبو محمد', isSuperhost: false, avatar: 'https://i.pravatar.cc/150?u=t5' }
  },

  // ================= TOURISM - NATURE =================
  {
    id: 't6',
    mainCategoryId: 'tourism',
    subCategoryId: 'nature',
    subSubCategoryId: 'adventures',
    title: 'رحلة تخييم في غابات كسب',
    location: 'اللاذقية، كسب',
    price: 50,
    rating: 4.8,
    reviews: 42,
    images: ['https://images.unsplash.com/photo-1478131143081-80f7f84ca84d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'],
    type: 'مغامرة',
    amenities: ['خيمة مجهزة', 'وجبات طعام', 'مرشد جبلي'],
    features: ['إطلالة جبلية'],
    isPopular: true,
    host: { name: 'فريق مغامرة', isSuperhost: true, avatar: 'https://i.pravatar.cc/150?u=t6' }
  },
  {
    id: 't7',
    mainCategoryId: 'tourism',
    subCategoryId: 'nature',
    subSubCategoryId: 'landmarks',
    title: 'زيارة مغارة الضوايات',
    location: 'طرطوس، مشتى الحلو',
    price: 15,
    rating: 4.5,
    reviews: 120,
    images: ['https://images.unsplash.com/photo-1502726299822-6f583f972e02?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'],
    type: 'معلم طبيعي',
    amenities: ['تذاكر دخول', 'مرشد'],
    features: ['مناسب للعائلات'],
    isPopular: false,
    host: { name: 'بلدية مشتى الحلو', isSuperhost: false, avatar: 'https://i.pravatar.cc/150?u=t7' }
  },

  // ================= MEDICAL - DENTAL =================
  {
    id: 'm1',
    mainCategoryId: 'medical',
    subCategoryId: 'dental',
    subSubCategoryId: 'cosmetic',
    title: 'مركز ابتسامة الشام لطب وتجميل الأسنان',
    location: 'دمشق، المزة',
    price: 1200,
    originalPrice: 1500,
    rating: 4.9,
    reviews: 412,
    images: ['https://images.unsplash.com/photo-1629909613654-28e377c37b09?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'],
    type: 'عيادة تخصصية',
    amenities: ['أشعة بانورامية', 'تخدير بدون ألم', 'تعقيم دولي'],
    features: ['حجز موعد فوري'],
    isPopular: true,
    host: { name: 'د. سامر', isSuperhost: true, avatar: 'https://i.pravatar.cc/150?u=m1' }
  },
  {
    id: 'm2',
    mainCategoryId: 'medical',
    subCategoryId: 'dental',
    subSubCategoryId: 'implants',
    title: 'مركز النخبة لزراعة الأسنان',
    location: 'حلب، الفرقان',
    price: 800,
    rating: 4.8,
    reviews: 156,
    images: ['https://images.unsplash.com/photo-1588776814546-1ffcf47267a5?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'],
    type: 'مركز زراعة',
    amenities: ['زراعة فورية', 'ضمان مدى الحياة'],
    features: ['أحدث التقنيات'],
    isPopular: false,
    host: { name: 'د. يحيى', isSuperhost: true, avatar: 'https://i.pravatar.cc/150?u=m2' }
  },

  // ================= MEDICAL - EYE =================
  {
    id: 'm3',
    mainCategoryId: 'medical',
    subCategoryId: 'eye',
    subSubCategoryId: 'lasik',
    title: 'المركز الدولي لليزك وجراحة العيون',
    location: 'دمشق، كفرسوسة',
    price: 500,
    rating: 5.0,
    reviews: 850,
    images: ['https://images.unsplash.com/photo-1576091160550-2173dba999ef?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'],
    type: 'مركز جراحي',
    amenities: ['فيمتو ليزك', 'فحوصات شاملة'],
    features: ['نتائج مضمونة'],
    isPopular: true,
    host: { name: 'د. ريم', isSuperhost: true, avatar: 'https://i.pravatar.cc/150?u=m3' }
  },

  // ================= MEDICAL - ALTERNATIVE =================
  {
    id: 'm4',
    mainCategoryId: 'medical',
    subCategoryId: 'alternative',
    subSubCategoryId: 'spa',
    title: 'مركز استشفاء حمام الملك الظاهر',
    location: 'دمشق، دمشق القديمة',
    price: 30,
    rating: 4.7,
    reviews: 210,
    images: ['https://images.unsplash.com/photo-1544161515-4ab6ce6db874?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'],
    type: 'حمام تراثي',
    amenities: ['تدليك', 'بخار', 'ليفة وصابون غار'],
    features: ['تجربة تاريخية'],
    isPopular: true,
    host: { name: 'إدارة الحمام', isSuperhost: false, avatar: 'https://i.pravatar.cc/150?u=m4' }
  },

  // ================= EDUCATION - LANGUAGES =================
  {
    id: 'e1',
    mainCategoryId: 'education',
    subCategoryId: 'languages',
    subSubCategoryId: 'arabic',
    title: 'معهد الضاد لتعليم العربية للأجانب',
    location: 'دمشق، الميدان',
    price: 450,
    rating: 4.9,
    reviews: 320,
    images: ['https://images.unsplash.com/photo-1546410531-bb4caa6b424d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'],
    type: 'معهد لغات',
    amenities: ['كتب مجانية', 'جولات ثقافية', 'سكن طلابي'],
    features: ['شهادة معتمدة'],
    isPopular: true,
    host: { name: 'معهد الضاد', isSuperhost: true, avatar: 'https://i.pravatar.cc/150?u=e1' }
  },
  {
    id: 'e2',
    mainCategoryId: 'education',
    subCategoryId: 'languages',
    subSubCategoryId: 'english',
    title: 'مركز أكسفورد للغات',
    location: 'حلب، العزيزية',
    price: 200,
    rating: 4.6,
    reviews: 145,
    images: ['https://images.unsplash.com/photo-1523050335456-c38730b0ebf4?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'],
    type: 'معهد لغات',
    amenities: ['مختبر صوتيات', 'مدرسين أجانب'],
    features: ['تحضير آيلتس'],
    isPopular: false,
    host: { name: 'إدارة المركز', isSuperhost: false, avatar: 'https://i.pravatar.cc/150?u=e2' }
  },

  // ================= EDUCATION - UNIVERSITY =================
  {
    id: 'e3',
    mainCategoryId: 'education',
    subCategoryId: 'university',
    subSubCategoryId: 'registration',
    title: 'خدمات القبول في الجامعات السورية الخاصة',
    location: 'دمشق، المزة',
    price: 100,
    rating: 4.8,
    reviews: 89,
    images: ['https://images.unsplash.com/photo-1523240795612-9a054b0db644?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'],
    type: 'خدمات طلابية',
    amenities: ['استشارات أكاديمية', 'تأمين سكن'],
    features: ['قبول مضمون'],
    isPopular: true,
    host: { name: 'مكتب الطالب', isSuperhost: true, avatar: 'https://i.pravatar.cc/150?u=e3' }
  },

  // ================= BUSINESS - INVESTMENT =================
  {
    id: 'b1',
    mainCategoryId: 'business',
    subCategoryId: 'investment',
    subSubCategoryId: 'realestate',
    title: 'فرص استثمار عقاري في ماروتا سيتي',
    location: 'دمشق، ماروتا سيتي',
    price: 50000,
    rating: 4.7,
    reviews: 34,
    images: ['https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'],
    type: 'استثمار',
    amenities: ['دراسة جدوى', 'استشارات قانونية'],
    features: ['عائد مرتفع'],
    isPopular: true,
    host: { name: 'شركة إعمار الشام', isSuperhost: true, avatar: 'https://i.pravatar.cc/150?u=b1' }
  },

  // ================= BUSINESS - SERVICES =================
  {
    id: 'b2',
    mainCategoryId: 'business',
    subCategoryId: 'services',
    subSubCategoryId: 'offices',
    title: 'مساحة عمل مشتركة (Damascus Hub)',
    location: 'دمشق، كفرسوسة',
    price: 25,
    rating: 4.9,
    reviews: 120,
    images: ['https://images.unsplash.com/photo-1497366216548-37526070297c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'],
    type: 'مساحة عمل',
    amenities: ['إنترنت سريع', 'قهوة مجانية', 'قاعات اجتماعات'],
    features: ['دخول 24/7'],
    isPopular: true,
    host: { name: 'Damascus Hub', isSuperhost: true, avatar: 'https://i.pravatar.cc/150?u=b2' }
  }
];
