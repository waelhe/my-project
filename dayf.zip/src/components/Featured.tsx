import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Loader2, Sparkles } from 'lucide-react';
import { motion } from 'motion/react';
import ServiceCard from './ServiceCard';
import { getAllServices, Service } from '../services/serviceService';

import { useLanguage } from '../contexts/LanguageContext';

export default function Featured() {
  const { t } = useLanguage();
  const [services, setServices] = useState<Service[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchFeatured = async () => {
      try {
        const data = await getAllServices();
        // Show popular services first, or just the first 6
        const featured = data
          .sort((a, b) => (b.isPopular ? 1 : 0) - (a.isPopular ? 1 : 0) || b.rating - a.rating)
          .slice(0, 6);
        setServices(featured);
      } catch (error) {
        console.error('Error fetching featured services:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchFeatured();
  }, []);

  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:justify-between md:items-end gap-4 mb-12">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-4">
              <Sparkles className="w-6 h-6 text-emerald-600" />
              <span className="text-emerald-600 font-bold uppercase tracking-wider text-sm">{t('featured.title')}</span>
            </div>
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4 leading-tight truncate">{t('featured.title')}</h2>
            <p className="text-lg text-gray-600 max-w-2xl leading-relaxed">
              {t('featured.subtitle')}
            </p>
          </div>
          <Link to="/category/tourism" className="hidden md:inline-flex shrink-0 items-center text-emerald-600 font-semibold hover:text-emerald-700 transition-colors">
            {t('featured.view_all')}
          </Link>
        </div>

        {loading ? (
          <div className="flex flex-col items-center justify-center py-20 text-gray-500">
            <Loader2 className="w-10 h-10 animate-spin mb-4 text-emerald-600" />
            <p className="text-lg font-medium">جاري تحميل المميزات...</p>
          </div>
        ) : services.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <ServiceCard 
                key={service.id} 
                service={service} 
                activeColorClass="bg-emerald-600 text-white"
                activeTextClass="text-emerald-600"
                activeBgLightClass="bg-emerald-50"
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-20 bg-gray-50 rounded-3xl border border-dashed border-gray-300">
            <p className="text-gray-500">لا توجد خدمات مميزة حالياً. يرجى العودة لاحقاً.</p>
          </div>
        )}
        
        <div className="mt-12 text-center md:hidden">
          <Link to="/category/tourism" className="inline-flex items-center bg-emerald-600 text-white px-8 py-3 rounded-2xl font-bold hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-200">
            {t('featured.view_all')}
          </Link>
        </div>
      </div>
    </section>
  );
}
