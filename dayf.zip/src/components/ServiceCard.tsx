import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Star, MapPin, Heart, ChevronRight, ChevronLeft, ShieldCheck, Zap, Loader2 } from 'lucide-react';
import { motion } from 'motion/react';
import { useAuth } from '../contexts/AuthContext';
import { db } from '../firebase';
import { collection, query, where, getDocs, addDoc, deleteDoc, doc, serverTimestamp, onSnapshot } from 'firebase/firestore';
import toast from 'react-hot-toast';

interface ServiceCardProps {
  service: {
    id: string;
    title: string;
    location: string;
    price: number;
    originalPrice?: number;
    rating: number;
    reviews: number;
    images: string[];
    type: string;
    isPopular?: boolean;
    features?: string[];
    amenities?: string[];
    mainCategoryId?: string;
    subCategoryId?: string;
    host?: {
      name: string;
      isSuperhost: boolean;
      avatar: string;
    };
  };
  activeColorClass: string;
  activeTextClass: string;
  activeBgLightClass: string;
}

const ServiceCard: React.FC<ServiceCardProps> = ({ service, activeColorClass, activeTextClass, activeBgLightClass }) => {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [isHovered, setIsHovered] = useState(false);
  const { user, signInWithGoogle } = useAuth();
  const [isFavorite, setIsFavorite] = useState(false);
  const [favoriteId, setFavoriteId] = useState<string | null>(null);
  const [isFavoriteLoading, setIsFavoriteLoading] = useState(false);

  useEffect(() => {
    if (!user) {
      setIsFavorite(false);
      setFavoriteId(null);
      return;
    }

    const q = query(
      collection(db, 'favorites'),
      where('userId', '==', user.uid),
      where('serviceId', '==', service.id)
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      if (!snapshot.empty) {
        setIsFavorite(true);
        setFavoriteId(snapshot.docs[0].id);
      } else {
        setIsFavorite(false);
        setFavoriteId(null);
      }
    });

    return () => unsubscribe();
  }, [user, service.id]);

  const toggleFavorite = async (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();

    if (!user) {
      signInWithGoogle();
      return;
    }

    setIsFavoriteLoading(true);
    try {
      if (isFavorite && favoriteId) {
        await deleteDoc(doc(db, 'favorites', favoriteId));
        toast.success('تمت الإزالة من المفضلة');
      } else {
        await addDoc(collection(db, 'favorites'), {
          userId: user.uid,
          serviceId: service.id,
          createdAt: serverTimestamp()
        });
        toast.success('تمت الإضافة إلى المفضلة');
      }
    } catch (error) {
      console.error("Error toggling favorite:", error);
      toast.error('حدث خطأ. يرجى المحاولة مرة أخرى.');
    } finally {
      setIsFavoriteLoading(false);
    }
  };

  const nextImage = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setCurrentImageIndex((prev) => (prev + 1) % service.images.length);
  };

  const prevImage = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setCurrentImageIndex((prev) => (prev - 1 + service.images.length) % service.images.length);
  };

  const hasDiscount = service.originalPrice && service.originalPrice > service.price;

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className="group bg-white rounded-3xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 border border-gray-100 flex flex-col min-w-0"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div className="relative h-64 overflow-hidden block shrink-0">
        {/* Image Carousel */}
        <Link to={`/listing/${service.id}`}>
          <img 
            src={service.images[currentImageIndex]} 
            alt={service.title} 
            className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
            referrerPolicy="no-referrer"
          />
        </Link>

        {/* Carousel Controls */}
        {isHovered && service.images.length > 1 && (
          <>
            <button 
              onClick={prevImage}
              className="absolute top-1/2 right-2 -translate-y-1/2 p-1.5 bg-white/90 backdrop-blur-sm rounded-full text-gray-700 hover:bg-white hover:scale-110 transition-all z-10 shadow-sm"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
            <button 
              onClick={nextImage}
              className="absolute top-1/2 left-2 -translate-y-1/2 p-1.5 bg-white/90 backdrop-blur-sm rounded-full text-gray-700 hover:bg-white hover:scale-110 transition-all z-10 shadow-sm"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
          </>
        )}

        {/* Carousel Dots */}
        {service.images.length > 1 && (
          <div className="absolute bottom-3 left-0 right-0 flex justify-center gap-1.5 z-10">
            {service.images.map((_, idx) => (
              <div 
                key={idx} 
                className={`h-1.5 rounded-full transition-all ${idx === currentImageIndex ? 'w-4 bg-white' : 'w-1.5 bg-white/60'}`}
              />
            ))}
          </div>
        )}

        {/* Top Badges */}
        <div className="absolute top-4 right-4 flex flex-col gap-2 items-end z-10">
          <div className="px-3 py-1 bg-white/90 backdrop-blur-sm rounded-full text-sm font-semibold text-gray-900 shadow-sm">
            {service.type}
          </div>
          {service.isPopular && (
            <div className={`px-3 py-1 ${activeColorClass} rounded-full text-xs font-bold shadow-sm`}>
              الأكثر طلباً
            </div>
          )}
        </div>

        {/* Favorite Button */}
        <button 
          onClick={toggleFavorite}
          disabled={isFavoriteLoading}
          className={`absolute top-4 left-4 p-2 backdrop-blur-sm rounded-full transition-all z-10 shadow-sm ${
            isFavorite 
              ? 'bg-red-500 text-white scale-110' 
              : 'bg-white/80 text-gray-600 hover:text-red-500 hover:bg-white'
          }`}
        >
          {isFavoriteLoading ? (
            <Loader2 className="w-5 h-5 animate-spin" />
          ) : (
            <Heart className={`w-5 h-5 ${isFavorite ? 'fill-current' : ''}`} />
          )}
        </button>
      </div>
      
      <div className="p-5 flex-1 flex flex-col min-w-0">
        {/* Host Info (if available) */}
        {service.host && (
          <div className="flex items-center justify-between mb-3 gap-2">
            <div className="flex items-center gap-2 min-w-0">
              <img src={service.host.avatar} alt={service.host.name} className="w-6 h-6 rounded-full shrink-0" />
              <span className="text-xs text-gray-500 truncate">بواسطة {service.host.name}</span>
            </div>
            {service.host.isSuperhost && (
              <div className="flex items-center gap-1 text-xs font-medium text-amber-600 bg-amber-50 px-2 py-0.5 rounded-md shrink-0">
                <ShieldCheck className="w-3 h-3" />
                <span>موثوق</span>
              </div>
            )}
          </div>
        )}

        <div className="flex justify-between items-start mb-3 gap-2">
          <div className="flex-1 ml-2 min-w-0">
            <Link to={`/listing/${service.id}`}>
              <h3 className={`text-lg font-bold text-gray-900 mb-1.5 truncate hover:${activeTextClass} transition-colors`}>
                {service.title}
              </h3>
            </Link>
            <div className="flex items-center text-gray-500 text-sm">
              <MapPin className="w-3.5 h-3.5 mr-1 ml-1 shrink-0" />
              <span className="truncate">{service.location}</span>
            </div>
          </div>
          <div className={`flex items-center gap-1 ${activeBgLightClass} px-2 py-1 rounded-lg shrink-0`}>
            <Star className={`w-3.5 h-3.5 ${activeTextClass} fill-current`} />
            <span className={`font-bold text-sm ${activeTextClass}`}>{service.rating}</span>
            <span className="text-gray-500 text-xs">({service.reviews})</span>
          </div>
        </div>

        {/* Features */}
        {service.features && service.features.length > 0 && (
          <div className="flex flex-wrap gap-2 mb-4">
            {service.features.map((feature, idx) => (
              <span key={idx} className="inline-flex items-center gap-1 text-xs font-medium text-gray-600 bg-gray-100 px-2 py-1 rounded-md">
                {feature === 'حجز فوري' && <Zap className="w-3 h-3 text-amber-500 fill-current" />}
                {feature}
              </span>
            ))}
          </div>
        )}

        <div className="pt-4 border-t border-gray-100 flex justify-between items-end mt-auto gap-4">
          <div className="text-gray-900 flex flex-col shrink-0">
            {hasDiscount && (
              <span className="text-sm text-gray-400 line-through mb-0.5">${service.originalPrice}</span>
            )}
            <div>
              <span className="text-xl font-bold">${service.price}</span>
              <span className="text-gray-500 text-sm font-normal"> / ليلة</span>
            </div>
          </div>
          <Link 
            to={`/listing/${service.id}`} 
            className={`px-5 py-2.5 rounded-xl font-medium text-sm transition-colors ${activeColorClass} hover:opacity-90 shadow-sm shrink-0`}
          >
            التفاصيل
          </Link>
        </div>
      </div>
    </motion.div>
  );
};

export default ServiceCard;
