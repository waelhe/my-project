import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Menu, Search, User, Globe, MessageSquare, LogOut } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useLanguage } from '../contexts/LanguageContext';
import toast from 'react-hot-toast';

export default function Navbar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isLangOpen, setIsLangOpen] = useState(false);
  const { user, userProfile, signInWithGoogle, logout } = useAuth();
  const { language, setLanguage, t } = useLanguage();
  const isProvider = userProfile?.role === 'provider' || userProfile?.role === 'admin';

  const handleComingSoon = () => {
    toast(t('coming_soon'), { icon: '⏳' });
  };

  const toggleLanguage = (lang: 'ar' | 'en') => {
    setLanguage(lang);
    setIsLangOpen(false);
    toast.success(lang === 'ar' ? 'تم تغيير اللغة إلى العربية' : 'Language changed to English');
  };

  return (
    <nav className="fixed top-0 left-0 right-0 bg-white/90 backdrop-blur-md z-50 border-b border-gray-100 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <Link to="/" className="flex-shrink-0 flex items-center gap-2 hover:opacity-90 transition-opacity">
            <div className="w-10 h-10 bg-emerald-600 rounded-xl flex items-center justify-center text-white font-bold text-xl">
              {language === 'ar' ? 'ض' : 'D'}
            </div>
            <span className="font-bold text-2xl text-gray-900 tracking-tight">{language === 'ar' ? 'ضيف' : 'Dayf'}</span>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8 space-x-reverse">
            <Link to="/category/tourism" className="text-gray-700 hover:text-emerald-600 font-medium transition-colors">{t('nav.tourism')}</Link>
            <Link to="/category/medical" className="text-gray-700 hover:text-emerald-600 font-medium transition-colors">{t('nav.medical')}</Link>
            <Link to="/category/education" className="text-gray-700 hover:text-emerald-600 font-medium transition-colors">{t('nav.education')}</Link>
            <Link to="/category/business" className="text-gray-700 hover:text-emerald-600 font-medium transition-colors">{t('nav.business')}</Link>
            <Link to="/community" className="text-gray-700 hover:text-emerald-600 font-medium transition-colors">{t('nav.community')}</Link>
            <Link to="/marketplace" className="text-gray-700 hover:text-emerald-600 font-medium transition-colors">{language === 'ar' ? 'السوق' : 'Market'}</Link>
          </div>

          {/* Right Actions */}
          <div className="hidden md:flex items-center space-x-4 space-x-reverse">
            <div className="relative">
              <button 
                onClick={() => setIsLangOpen(!isLangOpen)} 
                className="p-2 text-gray-500 hover:text-emerald-600 transition-colors flex items-center gap-1"
              >
                <Globe className="w-5 h-5" />
                <span className="text-xs font-bold uppercase">{language}</span>
              </button>
              
              {isLangOpen && (
                <div className="absolute top-full mt-2 bg-white border border-gray-100 rounded-xl shadow-xl overflow-hidden min-w-[120px] left-0 md:left-auto md:right-0">
                  <button 
                    onClick={() => toggleLanguage('ar')}
                    className={`w-full text-right px-4 py-2 text-sm hover:bg-gray-50 transition-colors ${language === 'ar' ? 'text-emerald-600 font-bold bg-emerald-50' : 'text-gray-700'}`}
                  >
                    العربية
                  </button>
                  <button 
                    onClick={() => toggleLanguage('en')}
                    className={`w-full text-right px-4 py-2 text-sm hover:bg-gray-50 transition-colors ${language === 'en' ? 'text-emerald-600 font-bold bg-emerald-50' : 'text-gray-700'}`}
                  >
                    English
                  </button>
                </div>
              )}
            </div>
            
            <button onClick={handleComingSoon} className="p-2 text-gray-500 hover:text-emerald-600 transition-colors">
              <MessageSquare className="w-5 h-5" />
            </button>
            
            {user ? (
              <div className="flex items-center gap-4">
                {isProvider && (
                  <Link to="/provider" className="text-emerald-600 hover:text-emerald-700 font-bold transition-colors">{t('nav.dashboard')}</Link>
                )}
                <Link to="/my-bookings" className="text-gray-700 hover:text-emerald-600 font-medium transition-colors">{t('nav.my_bookings')}</Link>
                <Link to="/profile" className="flex items-center gap-2 hover:opacity-80 transition-all">
                  {user.photoURL ? (
                    <img src={user.photoURL} alt={user.displayName || 'User'} className="w-8 h-8 rounded-full border border-gray-200" />
                  ) : (
                    <div className="w-8 h-8 rounded-full bg-emerald-100 flex items-center justify-center text-emerald-700 font-bold">
                      {user.displayName?.charAt(0) || user.email?.charAt(0) || 'U'}
                    </div>
                  )}
                  <span className="text-sm font-medium text-gray-700 hidden lg:block">{user.displayName || 'مستخدم'}</span>
                </Link>
                <button 
                  onClick={logout}
                  className="p-2 text-gray-500 hover:text-red-600 transition-colors"
                  title="تسجيل الخروج"
                >
                  <LogOut className="w-5 h-5" />
                </button>
              </div>
            ) : (
              <button 
                onClick={signInWithGoogle}
                className="flex items-center gap-2 bg-emerald-600 text-white px-4 py-2 rounded-full hover:bg-emerald-700 transition-colors font-medium"
              >
                <User className="w-4 h-4" />
                <span>تسجيل الدخول</span>
              </button>
            )}
          </div>

          {/* Mobile Search/Filter Bar (Airbnb Style) */}
          <div className="md:hidden flex-1 flex justify-center px-4">
            <button 
              onClick={handleComingSoon}
              className="w-full max-w-sm flex items-center gap-3 px-4 py-2 bg-white border border-gray-200 rounded-full shadow-sm hover:shadow-md transition-shadow text-right"
            >
              <div className="w-8 h-8 bg-emerald-600 rounded-full flex items-center justify-center text-white">
                <Search className="w-4 h-4" />
              </div>
              <div className="flex flex-col items-start overflow-hidden">
                <span className="text-xs font-bold text-gray-900 truncate">أين تود الذهاب؟</span>
                <span className="text-[10px] text-gray-500 truncate">أي مكان • أي أسبوع • إضافة ضيوف</span>
              </div>
            </button>
          </div>

          {/* Mobile Language Toggle */}
          <div className="md:hidden flex items-center">
            <button 
              onClick={() => toggleLanguage(language === 'ar' ? 'en' : 'ar')}
              className="p-2 text-gray-500 hover:text-emerald-600 transition-colors"
            >
              <Globe className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
}
