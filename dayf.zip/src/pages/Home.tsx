import React from 'react';
import Hero from '../components/Hero';
import Categories from '../components/Categories';
import Featured from '../components/Featured';
import CommunityHighlights from '../components/CommunityHighlights';
import MarketHighlights from '../components/MarketHighlights';

export default function Home() {
  return (
    <main>
      <Hero />
      <Categories />
      <Featured />
      <MarketHighlights />
      <CommunityHighlights />
    </main>
  );
}
