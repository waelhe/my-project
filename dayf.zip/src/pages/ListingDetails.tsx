import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Star, MapPin, Share, Heart, Users, BedDouble, Bath, Wifi, Car, Coffee, Wind, Tv, ShieldCheck, Sparkles, Loader2, CheckCircle2, AlertCircle, Home, Utensils, Waves, Dumbbell, ParkingCircle, ShoppingBag, Calendar, DollarSign, ListChecks, Info, ChevronRight } from 'lucide-react';
import { GoogleGenAI } from '@google/genai';
import { useAuth } from '../contexts/AuthContext';
import { db } from '../firebase';
import { collection, addDoc, serverTimestamp } from 'firebase/firestore';
import ReviewSection from '../components/ReviewSection';
import { getServiceById, Service } from '../services/serviceService';
import toast from 'react-hot-toast';

const ai = new GoogleGenAI({ apiKey: import.meta.env.VITE_GEMINI_API_KEY || process.env.GEMINI_API_KEY || '' });

// Icon mapping for amenities
const getAmenityIcon = (name: string) => {
  const n = name.toLowerCase();
  if (n.includes('واي فاي') || n.includes('wifi')) return Wifi;
  if (n.includes('تكييف') || n.includes('ac') || n.includes('air')) return Wind;
  if (n.includes('تلفاز') || n.includes('tv') || n.includes('شاشة')) return Tv;
  if (n.includes('قهوة') || n.includes('coffee')) return Coffee;
  if (n.includes('موقف') || n.includes('parking') || n.includes('سيارات')) return Car;
  if (n.includes('أمان') || n.includes('security') || n.includes('حراسة')) return ShieldCheck;
  if (n.includes('مطبخ') || n.includes('kitchen')) return Utensils;
  if (n.includes('مسبح') || n.includes('pool') || n.includes('سباحة')) return Waves;
  if (n.includes('نادي') || n.includes('gym') || n.includes('رياضة')) return Dumbbell;
  return CheckCircle2;
};

export default function ListingDetails() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user, signInWithGoogle } = useAuth();
  const [listing, setListing] = useState<Service | null>(null);
  const [loading, setLoading] = useState(true);
  const [guests, setGuests] = useState(1);
  const [nights, setNights] = useState(3);
  const [aiSummary, setAiSummary] = useState<string | null>(null);
  const [isAiLoading, setIsAiLoading] = useState(false);
  const [isBooking, setIsBooking] = useState(false);
  const [bookingStatus, setBookingStatus] = useState<'idle' | 'success' | 'error'>('idle');

  useEffect(() => {
    const fetchListing = async () => {
      if (!id) return;
      setLoading(true);
      try {
        const data = await getServiceById(id);
        if (data) {
          setListing(data);
        } else {
          navigate('/');
        }
      } catch (error) {
        console.error('Error fetching listing:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchListing();
  }, [id, navigate]);

  useEffect(() => {
    const generateAISummary = async () => {
      if (!listing) return;
      setIsAiLoading(true);
      try {
        const prompt = `
أنت خبير سياحي في منصة "ضيف". قم بكتابة ملخص جذاب وقصير (حوالي 3-4 أسطر) يبرز أهم مميزات هذا المكان بناءً على المعلومات التالية:
الاسم: ${listing.title}
الموقع: ${listing.location}
الوصف: ${listing.type}
المميزات: ${listing.amenities?.join('، ')}
التقييم: ${listing.rating} من ${listing.reviews} تقييم.

اجعل الملخص مشوقاً وموجهاً للزائر باللغة العربية.
`;
        const response = await ai.models.generateContent({
          model: 'gemini-3-flash-preview',
          contents: prompt,
        });
        setAiSummary(response.text || 'مكان رائع يستحق الزيارة.');
      } catch (error) {
        console.error('Error generating AI summary:', error);
      } finally {
        setIsAiLoading(false);
      }
    };

    if (listing) {
      generateAISummary();
    }
  }, [listing]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-10 h-10 animate-spin text-emerald-600" />
      </div>
    );
  }

  if (!listing) return null;

  const totalBase = listing.price * nights;
  const serviceFee = Math.round(totalBase * 0.1);
  const total = totalBase + serviceFee;

  const handleBooking = async () => {
    if (!user) {
      signInWithGoogle();
      return;
    }

    setIsBooking(true);
    setBookingStatus('idle');

    try {
      await addDoc(collection(db, 'bookings'), {
        serviceId: listing.id,
        serviceTitle: listing.title,
        userId: user.uid,
        userEmail: user.email,
        providerId: listing.authorUid,
        checkIn: '2026-10-15',
        checkOut: '2026-10-18',
        guests: guests,
        totalPrice: total,
        status: 'pending',
        createdAt: serverTimestamp()
      });
      setBookingStatus('success');
      toast.success('تم الحجز بنجاح!');
    } catch (error) {
      console.error("Booking error:", error);
      setBookingStatus('error');
      toast.error('حدث خطأ أثناء محاولة الحجز.');
    } finally {
      setIsBooking(false);
    }
  };

  const handleShare = () => {
    toast.success('تم نسخ الرابط بنجاح');
  };

  const handleSave = () => {
    toast.success('تم الحفظ في المفضلة');
  };


  return (
    <div className="pt-24 pb-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      {/* Header */}
      <div className="mb-6">
        <h1 className="text-3xl font-bold text-gray-900 mb-4">{listing.title}</h1>
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-4 text-sm font-medium text-gray-700">
            <div className="flex items-center gap-1">
              <Star className="w-4 h-4 text-emerald-500 fill-emerald-500" />
              <span>{listing.rating}</span>
              <span className="text-gray-500 underline cursor-pointer">({listing.reviews} تقييم)</span>
            </div>
            <span>·</span>
            <div className="flex items-center gap-1 text-gray-600">
              <MapPin className="w-4 h-4" />
              <span className="underline cursor-pointer">{listing.location}</span>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <button onClick={handleShare} className="flex items-center gap-2 text-gray-600 hover:text-gray-900 font-medium transition-colors">
              <Share className="w-4 h-4" />
              <span>مشاركة</span>
            </button>
            <button onClick={handleSave} className="flex items-center gap-2 text-gray-600 hover:text-red-500 font-medium transition-colors">
              <Heart className="w-4 h-4" />
              <span>حفظ</span>
            </button>
          </div>
        </div>
      </div>

      {/* Image Gallery */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-2 h-[400px] md:h-[500px] mb-12 rounded-2xl overflow-hidden">
        <div className="md:col-span-2 h-full">
          <img 
            src={listing.images[0]} 
            alt="Main" 
            className="w-full h-full object-cover hover:opacity-90 transition-opacity cursor-pointer"
            referrerPolicy="no-referrer"
          />
        </div>
        <div className="hidden md:grid grid-cols-1 gap-2 h-full">
          <img src={listing.images[1] || listing.images[0]} alt="Gallery 1" className="w-full h-full object-cover hover:opacity-90 transition-opacity cursor-pointer" referrerPolicy="no-referrer" />
          <img src={listing.images[2] || listing.images[0]} alt="Gallery 2" className="w-full h-full object-cover hover:opacity-90 transition-opacity cursor-pointer" referrerPolicy="no-referrer" />
        </div>
        <div className="hidden md:grid grid-cols-1 gap-2 h-full">
          <img src={listing.images[3] || listing.images[0]} alt="Gallery 3" className="w-full h-full object-cover hover:opacity-90 transition-opacity cursor-pointer" referrerPolicy="no-referrer" />
          <img src={listing.images[4] || listing.images[0]} alt="Gallery 4" className="w-full h-full object-cover hover:opacity-90 transition-opacity cursor-pointer" referrerPolicy="no-referrer" />
        </div>
      </div>

      {/* Content Split */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
        {/* Main Details (Right in RTL) */}
        <div className="lg:col-span-2">
          {/* Host Info */}
          <div className="flex justify-between items-start sm:items-center pb-6 border-b border-gray-200 gap-4">
            <div className="flex-1 min-w-0">
              <h2 className="text-2xl font-bold text-gray-900 mb-2 truncate">
                استضافة بواسطة {listing.host?.name || 'مضيف ضيف'}
              </h2>
              <div className="flex flex-wrap items-center gap-x-4 gap-y-2 text-gray-600 text-sm sm:text-base">
                <span className="flex items-center gap-1 shrink-0"><Home className="w-4 h-4"/> {listing.type}</span>
                {listing.features?.map((feature, idx) => (
                  <React.Fragment key={idx}>
                    <span className="hidden sm:inline">·</span>
                    <span className="flex items-center gap-1 shrink-0"><Sparkles className="w-4 h-4"/> {feature}</span>
                  </React.Fragment>
                ))}
              </div>
            </div>
            <img 
              src={listing.host?.avatar || 'https://i.pravatar.cc/150?u=default'} 
              alt={listing.host?.name} 
              className="w-14 h-14 rounded-full object-cover shrink-0"
              referrerPolicy="no-referrer"
            />
          </div>

          {/* AI Insights Section */}
          <div className="py-8 border-b border-gray-200">
            <div className="bg-gradient-to-r from-emerald-50 to-teal-50 rounded-2xl p-6 border border-emerald-100 relative overflow-hidden">
              <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/10 rounded-full blur-3xl -mr-10 -mt-10 pointer-events-none"></div>
              <div className="flex items-start gap-4 relative z-10">
                <div className="w-12 h-12 bg-emerald-100 rounded-full flex items-center justify-center shrink-0">
                  <Sparkles className="w-6 h-6 text-emerald-600" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-gray-900 mb-2 flex items-center gap-2">
                    نظرة سريعة بالذكاء الاصطناعي
                    <span className="text-xs bg-emerald-100 text-emerald-700 px-2 py-1 rounded-full font-medium">Gemini AI</span>
                  </h3>
                  {isAiLoading ? (
                    <div className="flex items-center gap-2 text-emerald-600 mt-2">
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span className="text-sm">جاري تحليل المعلومات...</span>
                    </div>
                  ) : (
                    <p className="text-gray-700 leading-relaxed text-sm md:text-base whitespace-pre-wrap">
                      {aiSummary}
                    </p>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Description */}
          <div className="py-8 border-b border-gray-200">
            <h3 className="text-xl font-bold text-gray-900 mb-4">عن هذا المكان</h3>
            <p className="text-gray-600 leading-relaxed text-lg">
              {listing.title} - {listing.type} في {listing.location}. يوفر هذا المكان تجربة مميزة مع مجموعة من المرافق والخدمات.
            </p>
          </div>

          {/* Amenities */}
          <div className="py-8 border-b border-gray-200">
            <h3 className="text-xl font-bold text-gray-900 mb-6">ما يوفره هذا المكان</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {listing.amenities?.map((amenity, index) => {
                const Icon = getAmenityIcon(amenity);
                return (
                  <div key={index} className="flex items-center gap-4 text-gray-700">
                    <Icon className="w-6 h-6 text-emerald-600" />
                    <span className="text-lg">{amenity}</span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Review Section */}
          <ReviewSection serviceId={listing.id} />

          {/* Community Integration */}
          <div className="py-8 border-t border-gray-200 mt-8">
            <div className="bg-emerald-50 rounded-3xl p-8 border border-emerald-100 flex flex-col md:flex-row items-center justify-between gap-6">
              <div className="flex-1">
                <h3 className="text-2xl font-bold text-gray-900 mb-2 flex items-center gap-2">
                  <Users className="w-6 h-6 text-emerald-600" />
                  اسأل مجتمع ضيف
                </h3>
                <p className="text-gray-600 leading-relaxed">
                  هل لديك استفسارات حول هذا المكان أو المنطقة المحيطة به؟ تواصل مع ضيوف سابقين أو خبراء محليين في مجتمع ضيف للحصول على إجابات وتوصيات.
                </p>
              </div>
              <button 
                onClick={() => navigate('/community')}
                className="shrink-0 bg-emerald-600 text-white px-8 py-3 rounded-xl font-bold hover:bg-emerald-700 transition-colors shadow-lg shadow-emerald-200 w-full md:w-auto text-center"
              >
                اذهب إلى المجتمع
              </button>
            </div>
          </div>

          {/* Local Market Integration */}
          <div className="py-8 border-t border-gray-200">
            <div className="bg-amber-50 rounded-3xl p-8 border border-amber-100 flex flex-col md:flex-row items-center justify-between gap-6">
              <div className="flex-1">
                <h3 className="text-2xl font-bold text-gray-900 mb-2 flex items-center gap-2">
                  <ShoppingBag className="w-6 h-6 text-amber-600" />
                  تسوق منتجات محلية
                </h3>
                <p className="text-gray-600 leading-relaxed">
                  اكتشف أفضل المنتجات المحلية في {listing.location} واطلب توصيلها مباشرة إلى مكان إقامتك أثناء رحلتك.
                </p>
              </div>
              <button 
                onClick={() => navigate('/marketplace')}
                className="shrink-0 bg-amber-600 text-white px-8 py-3 rounded-xl font-bold hover:bg-amber-700 transition-colors shadow-lg shadow-amber-200 w-full md:w-auto text-center"
              >
                تصفح سوق ضيف
              </button>
            </div>
          </div>
        </div>

        {/* Booking Widget (Left in RTL) */}
        <div className="lg:col-span-1">
          <div className="sticky top-28 bg-white border border-gray-200 rounded-2xl p-6 shadow-xl">
            <div className="flex justify-between items-end mb-6">
              <div>
                <span className="text-2xl font-bold text-gray-900">${listing.price}</span>
                <span className="text-gray-500"> / ليلة</span>
              </div>
              <div className="flex items-center gap-1 text-sm font-medium">
                <Star className="w-4 h-4 text-emerald-500 fill-emerald-500" />
                <span>{listing.rating}</span>
                <span className="text-gray-500">({listing.reviews})</span>
              </div>
            </div>

            <div className="border border-gray-300 rounded-xl mb-4 overflow-hidden">
              <div className="flex border-b border-gray-300">
                <div className="flex-1 p-3 border-l border-gray-300">
                  <div className="text-xs font-bold text-gray-900">تسجيل الوصول</div>
                  <div className="text-gray-500 text-sm mt-1">15 أكتوبر 2026</div>
                </div>
                <div className="flex-1 p-3">
                  <div className="text-xs font-bold text-gray-900">المغادرة</div>
                  <div className="text-gray-500 text-sm mt-1">18 أكتوبر 2026</div>
                </div>
              </div>
              <div className="p-3">
                <div className="text-xs font-bold text-gray-900">الضيوف</div>
                <select 
                  className="w-full mt-1 bg-transparent outline-none text-gray-700 text-sm cursor-pointer"
                  value={guests}
                  onChange={(e) => setGuests(Number(e.target.value))}
                >
                  <option value={1}>ضيف واحد</option>
                  <option value={2}>ضيفان</option>
                  <option value={3}>3 ضيوف</option>
                  <option value={4}>4 ضيوف</option>
                </select>
              </div>
            </div>

            {/* Escrow Badge */}
            <div className="bg-blue-50 border border-blue-100 rounded-xl p-3 mb-4 flex items-start gap-2">
              <ShieldCheck className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
              <div>
                <div className="text-xs font-bold text-blue-800">حماية ضيف المالية</div>
                <div className="text-[10px] text-blue-600 leading-tight">يتم الاحتفاظ بأموالك في حساب وسيط (Escrow) ولا يتم تحويلها للمزود إلا بعد إتمام الخدمة.</div>
              </div>
            </div>

            <button 
              onClick={handleBooking}
              disabled={isBooking || bookingStatus === 'success'}
              className={`w-full py-4 rounded-xl font-bold text-lg transition-all mb-4 flex items-center justify-center gap-2 ${
                bookingStatus === 'success' 
                  ? 'bg-emerald-100 text-emerald-700 cursor-default' 
                  : 'bg-emerald-600 text-white hover:bg-emerald-700 active:scale-[0.98]'
              }`}
            >
              {isBooking ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  <span>جاري المعالجة...</span>
                </>
              ) : bookingStatus === 'success' ? (
                <>
                  <CheckCircle2 className="w-5 h-5" />
                  <span>تم الحجز بنجاح!</span>
                </>
              ) : (
                'احجز الآن'
              )}
            </button>
            
            {bookingStatus === 'success' && (
              <div className="bg-emerald-50 text-emerald-700 p-4 rounded-xl text-sm mb-6 flex items-start gap-3 border border-emerald-100">
                <CheckCircle2 className="w-5 h-5 shrink-0 mt-0.5" />
                <p>لقد تم إرسال طلب الحجز الخاص بك بنجاح. يمكنك متابعة حالة الحجز من لوحة التحكم الخاصة بك.</p>
              </div>
            )}

            {bookingStatus === 'error' && (
              <div className="bg-red-50 text-red-700 p-4 rounded-xl text-sm mb-6 flex items-start gap-3 border border-red-100">
                <AlertCircle className="w-5 h-5 shrink-0 mt-0.5" />
                <p>عذراً، حدث خطأ أثناء محاولة الحجز. يرجى المحاولة مرة أخرى لاحقاً.</p>
              </div>
            )}
            
            <p className="text-center text-gray-500 text-sm mb-6">لن يتم خصم أي مبلغ منك الآن</p>

            <div className="space-y-4 text-gray-600">
              <div className="flex justify-between">
                <span className="underline">${listing.price} × {nights} ليالي</span>
                <span>${totalBase}</span>
              </div>
              <div className="flex justify-between">
                <span className="underline">رسوم خدمة ضيف</span>
                <span>${serviceFee}</span>
              </div>
            </div>

            <div className="border-t border-gray-200 mt-6 pt-6 flex justify-between font-bold text-lg text-gray-900">
              <span>الإجمالي</span>
              <span>${total}</span>
            </div>
          </div>

          {/* Planning Tools Widget */}
          <div className="mt-8 bg-white border border-gray-200 rounded-2xl p-6 shadow-sm">
            <h3 className="text-lg font-bold text-gray-900 mb-4 flex items-center gap-2">
              <ListChecks className="w-5 h-5 text-emerald-600" />
              أدوات التخطيط
            </h3>
            <div className="space-y-4">
              <button className="w-full flex items-center justify-between p-3 bg-gray-50 rounded-xl hover:bg-gray-100 transition-colors group">
                <div className="flex items-center gap-3">
                  <Calendar className="w-5 h-5 text-gray-400 group-hover:text-emerald-600" />
                  <span className="text-sm font-medium text-gray-700">بناء برنامج الرحلة</span>
                </div>
                <ChevronRight className="w-4 h-4 text-gray-300 rotate-180" />
              </button>
              <button className="w-full flex items-center justify-between p-3 bg-gray-50 rounded-xl hover:bg-gray-100 transition-colors group">
                <div className="flex items-center gap-3">
                  <DollarSign className="w-5 h-5 text-gray-400 group-hover:text-emerald-600" />
                  <span className="text-sm font-medium text-gray-700">تقدير الميزانية الكلية</span>
                </div>
                <ChevronRight className="w-4 h-4 text-gray-300 rotate-180" />
              </button>
              <div className="p-3 bg-amber-50 rounded-xl border border-amber-100">
                <div className="flex items-center gap-2 text-amber-800 font-bold text-xs mb-1">
                  <Info className="w-3 h-3" />
                  نصيحة ضيف
                </div>
                <p className="text-[11px] text-amber-700 leading-relaxed">
                  هذا المكان قريب من 3 معالم سياحية مشهورة. ننصح بحجز جولة سياحية معه لتوفير الوقت.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
