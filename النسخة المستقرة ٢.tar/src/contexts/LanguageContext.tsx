"use client";

import React, { createContext, useContext, useState, useEffect, ReactNode } from "react";

type Language = "ar" | "en";

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
  isRTL: boolean;
}

const translations: Record<Language, Record<string, string>> = {
  ar: {
    // Navigation
    "nav.tourism": "السياحة",
    "nav.medical": "العلاج",
    "nav.education": "الدراسة",
    "nav.business": "الأعمال",
    "nav.community": "المجتمع",
    "nav.marketplace": "السوق",
    "nav.dashboard": "لوحة التحكم",
    "nav.my_bookings": "حجوزاتي",
    "nav.login": "تسجيل الدخول",
    "nav.logout": "تسجيل الخروج",
    "nav.profile": "حسابي",
    "nav.home": "الرئيسية",
    "nav.provider": "لوحة المزود",

    // Hero
    "hero.title": "اكتشف سحر سوريا مع ضيف",
    "hero.subtitle": "منصة متكاملة للسياحة، العلاج، الدراسة، وفرص الأعمال. خطط لرحلتك القادمة بكل سهولة وأمان.",
    "hero.search": "بحث",
    "hero.ai_search": "بحث ذكي",
    "hero.destination": "الوجهة",
    "hero.date": "التاريخ",
    "hero.guests": "الضيوف",
    "hero.placeholder": "إلى أين تريد الذهاب؟",
    "hero.anywhere": "أين تود الذهاب؟",
    "hero.any_week": "أي أسبوع",
    "hero.add_guests": "إضافة ضيوف",
    "hero.ai_placeholder": "مثال: أريد فندق رخيص في دمشق القديمة مع مسبح وواي فاي...",

    // Common
    "coming_soon": "سيتم تفعيل هذه الميزة قريباً",
    "loading": "جاري التحميل...",
    "error": "حدث خطأ. يرجى المحاولة مرة أخرى.",
    "success": "تمت العملية بنجاح",
    "save": "حفظ",
    "cancel": "إلغاء",
    "delete": "حذف",
    "edit": "تعديل",
    "add": "إضافة",
    "search": "بحث",
    "filter": "تصفية",
    "sort": "ترتيب",
    "all": "الكل",
    "popular": "الأكثر شعبية",
    "featured": "مميز",
    "price": "السعر",
    "rating": "التقييم",
    "reviews": "تقييم",
    "location": "الموقع",
    "book_now": "احجز الآن",
    "view_all": "عرض الكل",
    "view_details": "عرض التفاصيل",
    "per_night": "/ ليلة",
    "guest": "ضيف",
    "guests": "ضيوف",
    "person": "شخص",
    "people": "أشخاص",

    // Featured
    "featured.title": "إقامات وخدمات مميزة",
    "featured.subtitle": "اكتشف أفضل العروض والخدمات الموصى بها في جميع أنحاء سوريا",
    "featured.loading": "جاري تحميل المميزات...",
    "featured.no_services": "لا توجد خدمات مميزة حالياً. يرجى العودة لاحقاً.",

    // Categories
    "categories.title": "استكشف حسب الفئة",
    "categories.subtitle": "اختر الفئة التي تناسب احتياجاتك لتبدأ رحلتك",
    "categories.browse_all": "تصفح جميع الخدمات",

    // Community
    "community.title": "أحدث المشاركات",
    "community.subtitle": "تعرف على تجارب المسافرين واحصل على نصائح مفيدة",
    "community.read_more": "اقرأ المزيد",
    "community.ask_community": "اسأل مجتمع ضيف",
    "community.ask_description": "هل لديك استفسارات؟ تواصل مع ضيوف سابقين أو خبراء محليين.",

    // Market
    "market.title": "أحدث المنتجات",
    "market.subtitle": "تسوق منتجات محلية مميزة من جميع أنحاء سوريا",
    "market.shop_local": "تسوق منتجات محلية",

    // Footer
    "footer.about": "عن ضيف",
    "footer.how_it_works": "كيف يعمل الموقع",
    "footer.faq": "الأسئلة الشائعة",
    "footer.privacy": "سياسة الخصوصية",
    "footer.terms": "الشروط والأحكام",
    "footer.contact": "تواصل معنا",
    "footer.description": "منصة السياحة السورية الشاملة. نجمع لك أفضل خيارات الإقامة، العلاج، الدراسة، والأعمال في مكان واحد.",
    "footer.rights": "جميع الحقوق محفوظة",
    "footer.language": "اللغة",

    // AI Agent
    "ai.title": "المساعد الذكي",
    "ai.online": "متصل الآن",
    "ai.placeholder": "اسألني عن أي شيء...",
    "ai.powered_by": "مدعوم بالذكاء الاصطناعي",
    "ai.thinking": "يفكر...",
    "ai.welcome": "مرحباً! أنا المساعد الذكي لمنصة ضيف. كيف يمكنني مساعدتك في التخطيط لرحلتك إلى سوريا اليوم؟",
    "ai.summary_title": "نظرة سريعة بالذكاء الاصطناعي",
    "ai.recommendations": "توصيات الذكاء الاصطناعي",
    "ai.searching": "الذكاء الاصطناعي يبحث لك...",
    "ai.analyzing": "جاري تحليل المعلومات...",

    // Service
    "service.per_night": "/ ليلة",
    "service.popular": "الأكثر طلباً",
    "service.favorite_added": "تمت الإضافة إلى المفضلة",
    "service.favorite_removed": "تمت الإزالة من المفضلة",
    "service.error": "حدث خطأ. يرجى المحاولة مرة أخرى.",
    "service.share": "مشاركة",
    "service.save": "حفظ",
    "service.hosted_by": "استضافة بواسطة",
    "service.about": "عن هذا المكان",
    "service.amenities": "ما يوفره هذا المكان",
    "service.reviews_title": "التقييمات",
    "service.booking_title": "حجز",
    "service.check_in": "تسجيل الوصول",
    "service.check_out": "المغادرة",
    "service.total": "الإجمالي",
    "service.service_fee": "رسوم خدمة ضيف",
    "service.protected": "حماية ضيف المالية",
    "service.protected_desc": "يتم الاحتفاظ بأموالك في حساب وسيط (Escrow) ولا يتم تحويلها للمزود إلا بعد إتمام الخدمة.",
    "service.not_charged": "لن يتم خصم أي مبلغ منك الآن",
    "service.planning_tools": "أدوات التخطيط",
    "service.build_itinerary": "بناء برنامج الرحلة",
    "service.estimate_budget": "تقدير الميزانية الكلية",

    // Login
    "login.title": "تسجيل الدخول",
    "login.google": "المتابعة مع جوجل",
    "login.or": "أو",
    "login.email": "البريد الإلكتروني",
    "login.password": "كلمة المرور",
    "login.submit": "دخول",
    "login.no_account": "ليس لديك حساب؟",
    "login.register": "سجل الآن",
    "login.success": "تم تسجيل الدخول بنجاح",
    "login.error": "حدث خطأ أثناء تسجيل الدخول",

    // Booking
    "booking.title": "حجوزاتي",
    "booking.pending": "قيد الانتظار",
    "booking.confirmed": "مؤكد",
    "booking.cancelled": "ملغي",
    "booking.completed": "مكتمل",
    "booking.no_bookings": "لا توجد حجوزات حالياً",
    "booking.success": "تم الحجز بنجاح!",
    "booking.error": "حدث خطأ أثناء محاولة الحجز.",
    "booking.processing": "جاري المعالجة...",

    // Provider Dashboard
    "provider.title": "لوحة تحكم المزود",
    "provider.services": "خدماتي",
    "provider.bookings": "الحجوزات",
    "provider.earnings": "الأرباح",
    "provider.settings": "الإعدادات",
    "provider.add_service": "إضافة خدمة جديدة",
    "provider.manage_services": "إدارة الخدمات",
    "provider.manage_bookings": "إدارة الحجوزات",
    "provider.profile_settings": "إعدادات الملف الشخصي",

    // Category Page
    "category.results": "تم العثور على",
    "category.results_suffix": "نتيجة",
    "category.sort_by": "ترتيب حسب:",
    "category.recommended": "الأوصى به",
    "category.price_asc": "السعر: من الأقل للأعلى",
    "category.price_desc": "السعر: من الأعلى للأقل",
    "category.rating_desc": "الأعلى تقييماً",
    "category.no_results": "لا توجد نتائج مطابقة",
    "category.try_filters": "حاول تغيير خيارات البحث، أو تقليل الفلاتر المحددة لرؤية المزيد من النتائج المتاحة.",
    "category.clear_filters": "مسح جميع الفلاتر",
    "category.filters": "تصفية متقدمة",
    "category.price_range": "نطاق السعر (لليلة)",
    "category.guest_rating": "تقييم الضيوف",
    "category.stars_plus": "نجوم",
    "category.property_type": "نوع المكان",
    "category.amenities": "المرافق والمميزات",
    "category.map_view": "خريطة",
    "category.list_view": "قائمة",
    "category.services_map": "خريطة الخدمات",
    "category.services_available": "خدمة متوفرة في هذه المنطقة",

    // Profile
    "profile.title": "الملف الشخصي",
    "profile.edit": "تعديل الملف",
    "profile.name": "الاسم",
    "profile.email": "البريد الإلكتروني",
    "profile.phone": "رقم الهاتف",
    "profile.avatar": "الصورة الشخصية",
    "profile.saved": "تم حفظ التغييرات",
  },
  en: {
    // Navigation
    "nav.tourism": "Tourism",
    "nav.medical": "Medical",
    "nav.education": "Education",
    "nav.business": "Business",
    "nav.community": "Community",
    "nav.marketplace": "Market",
    "nav.dashboard": "Dashboard",
    "nav.my_bookings": "My Bookings",
    "nav.login": "Login",
    "nav.logout": "Logout",
    "nav.profile": "Profile",
    "nav.home": "Home",
    "nav.provider": "Provider Dashboard",

    // Hero
    "hero.title": "Discover the Magic of Syria with Dayf",
    "hero.subtitle": "A comprehensive platform for tourism, medical, education, and business services. Plan your next trip with ease and safety.",
    "hero.search": "Search",
    "hero.ai_search": "AI Search",
    "hero.destination": "Destination",
    "hero.date": "Date",
    "hero.guests": "Guests",
    "hero.placeholder": "Where do you want to go?",
    "hero.anywhere": "Anywhere",
    "hero.any_week": "Any week",
    "hero.add_guests": "Add guests",
    "hero.ai_placeholder": "Example: I want a budget hotel in Old Damascus with pool and WiFi...",

    // Common
    "coming_soon": "This feature will be available soon",
    "loading": "Loading...",
    "error": "An error occurred. Please try again.",
    "success": "Operation completed successfully",
    "save": "Save",
    "cancel": "Cancel",
    "delete": "Delete",
    "edit": "Edit",
    "add": "Add",
    "search": "Search",
    "filter": "Filter",
    "sort": "Sort",
    "all": "All",
    "popular": "Most Popular",
    "featured": "Featured",
    "price": "Price",
    "rating": "Rating",
    "reviews": "reviews",
    "location": "Location",
    "book_now": "Book Now",
    "view_all": "View All",
    "view_details": "View Details",
    "per_night": "/ night",
    "guest": "guest",
    "guests": "guests",
    "person": "person",
    "people": "people",

    // Featured
    "featured.title": "Featured Stays & Services",
    "featured.subtitle": "Discover the best recommended offers and services across Syria",
    "featured.loading": "Loading featured services...",
    "featured.no_services": "No featured services available. Please check back later.",

    // Categories
    "categories.title": "Explore by Category",
    "categories.subtitle": "Choose the category that fits your needs to start your journey",
    "categories.browse_all": "Browse all services",

    // Community
    "community.title": "Latest Posts",
    "community.subtitle": "Learn from traveler experiences and get helpful tips",
    "community.read_more": "Read more",
    "community.ask_community": "Ask the Dayf Community",
    "community.ask_description": "Have questions? Connect with previous guests or local experts.",

    // Market
    "market.title": "Latest Products",
    "market.subtitle": "Shop unique local products from all across Syria",
    "market.shop_local": "Shop Local Products",

    // Footer
    "footer.about": "About Dayf",
    "footer.how_it_works": "How it Works",
    "footer.faq": "FAQ",
    "footer.privacy": "Privacy Policy",
    "footer.terms": "Terms & Conditions",
    "footer.contact": "Contact Us",
    "footer.description": "The comprehensive Syrian tourism platform. We bring you the best options for accommodation, medical, education, and business in one place.",
    "footer.rights": "All rights reserved",
    "footer.language": "Language",

    // AI Agent
    "ai.title": "AI Assistant",
    "ai.online": "Online now",
    "ai.placeholder": "Ask me anything...",
    "ai.powered_by": "Powered by AI",
    "ai.thinking": "Thinking...",
    "ai.welcome": "Hello! I'm the AI assistant for Dayf platform. How can I help you plan your trip to Syria today?",
    "ai.summary_title": "AI Quick Overview",
    "ai.recommendations": "AI Recommendations",
    "ai.searching": "AI is searching for you...",
    "ai.analyzing": "Analyzing information...",

    // Service
    "service.per_night": "/ night",
    "service.popular": "Most Popular",
    "service.favorite_added": "Added to favorites",
    "service.favorite_removed": "Removed from favorites",
    "service.error": "An error occurred. Please try again.",
    "service.share": "Share",
    "service.save": "Save",
    "service.hosted_by": "Hosted by",
    "service.about": "About this place",
    "service.amenities": "What this place offers",
    "service.reviews_title": "Reviews",
    "service.booking_title": "Booking",
    "service.check_in": "Check-in",
    "service.check_out": "Check-out",
    "service.total": "Total",
    "service.service_fee": "Dayf service fee",
    "service.protected": "Dayf Financial Protection",
    "service.protected_desc": "Your money is held in an Escrow account and is only released to the provider after service completion.",
    "service.not_charged": "You won't be charged yet",
    "service.planning_tools": "Planning Tools",
    "service.build_itinerary": "Build Itinerary",
    "service.estimate_budget": "Estimate Total Budget",

    // Login
    "login.title": "Login",
    "login.google": "Continue with Google",
    "login.or": "or",
    "login.email": "Email",
    "login.password": "Password",
    "login.submit": "Sign In",
    "login.no_account": "Don't have an account?",
    "login.register": "Register now",
    "login.success": "Successfully logged in",
    "login.error": "An error occurred during login",

    // Booking
    "booking.title": "My Bookings",
    "booking.pending": "Pending",
    "booking.confirmed": "Confirmed",
    "booking.cancelled": "Cancelled",
    "booking.completed": "Completed",
    "booking.no_bookings": "No bookings yet",
    "booking.success": "Booking successful!",
    "booking.error": "An error occurred during booking.",
    "booking.processing": "Processing...",

    // Provider Dashboard
    "provider.title": "Provider Dashboard",
    "provider.services": "My Services",
    "provider.bookings": "Bookings",
    "provider.earnings": "Earnings",
    "provider.settings": "Settings",
    "provider.add_service": "Add New Service",
    "provider.manage_services": "Manage Services",
    "provider.manage_bookings": "Manage Bookings",
    "provider.profile_settings": "Profile Settings",

    // Category Page
    "category.results": "Found",
    "category.results_suffix": "results",
    "category.sort_by": "Sort by:",
    "category.recommended": "Recommended",
    "category.price_asc": "Price: Low to High",
    "category.price_desc": "Price: High to Low",
    "category.rating_desc": "Highest Rated",
    "category.no_results": "No matching results",
    "category.try_filters": "Try changing your search options or reducing filters to see more available results.",
    "category.clear_filters": "Clear all filters",
    "category.filters": "Advanced Filters",
    "category.price_range": "Price range (per night)",
    "category.guest_rating": "Guest Rating",
    "category.stars_plus": "stars+",
    "category.property_type": "Property Type",
    "category.amenities": "Amenities & Features",
    "category.map_view": "Map",
    "category.list_view": "List",
    "category.services_map": "Services Map",
    "category.services_available": "services available in this area",

    // Profile
    "profile.title": "Profile",
    "profile.edit": "Edit Profile",
    "profile.name": "Name",
    "profile.email": "Email",
    "profile.phone": "Phone",
    "profile.avatar": "Avatar",
    "profile.saved": "Changes saved",
  },
};

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export function LanguageProvider({ children }: { children: ReactNode }) {
  // Initialize state with a function to read from localStorage
  const [language, setLanguage] = useState<Language>(() => {
    if (typeof window === "undefined") return "ar";
    const saved = localStorage.getItem("language");
    return (saved === "en" || saved === "ar") ? saved : "ar";
  });
  
  const isRTL = language === "ar";

  // Save language to localStorage and update document direction
  useEffect(() => {
    localStorage.setItem("language", language);
    document.documentElement.dir = isRTL ? "rtl" : "ltr";
    document.documentElement.lang = language;
  }, [language, isRTL]);

  const t = (key: string): string => {
    return translations[language][key] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t, isRTL }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error("useLanguage must be used within a LanguageProvider");
  }
  return context;
}
