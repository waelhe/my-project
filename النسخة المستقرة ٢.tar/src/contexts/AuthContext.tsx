"use client";

import { createContext, useContext, useState, useEffect, useCallback, ReactNode } from "react";
import { useRouter } from "next/navigation";

// User profile interface
export interface UserProfile {
  id: string;
  email: string;
  displayName: string | null;
  avatar: string | null;
  role: "user" | "host" | "admin";
  phone?: string;
  city?: string;
  bio?: string;
}

// Auth context type
interface AuthContextType {
  user: UserProfile | null;
  loading: boolean;
  signIn: (email: string, password: string) => Promise<void>;
  signInWithGoogle: () => Promise<void>;
  signUp: (email: string, password: string, displayName: string) => Promise<void>;
  logout: () => Promise<void>;
  updateProfile: (data: Partial<UserProfile>) => Promise<void>;
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  loading: true,
  signIn: async () => {},
  signInWithGoogle: async () => {},
  signUp: async () => {},
  logout: async () => {},
  updateProfile: async () => {},
});

export const useAuth = () => useContext(AuthContext);

// Mock users for demo
const MOCK_USERS: Record<string, UserProfile> = {
  "guest@dayf.sy": {
    id: "guest-user",
    email: "guest@dayf.sy",
    displayName: "ضيف جديد",
    avatar: "https://i.pravatar.cc/150?u=guest",
    role: "user",
    city: "دمشق",
  },
  "host@dayf.sy": {
    id: "dayf-host",
    email: "host@dayf.sy",
    displayName: "مضيف ضيف",
    avatar: "https://i.pravatar.cc/150?u=host",
    role: "host",
    city: "دمشق",
    bio: "مضيف معتمد في منصة ضيف",
  },
  "admin@dayf.sy": {
    id: "admin-user",
    email: "admin@dayf.sy",
    displayName: "مدير النظام",
    avatar: "https://i.pravatar.cc/150?u=admin",
    role: "admin",
    city: "دمشق",
  },
};

const STORAGE_KEY = "dayf_user";

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const router = useRouter();

  // Load user from localStorage on mount
  useEffect(() => {
    const storedUser = localStorage.getItem(STORAGE_KEY);
    if (storedUser) {
      try {
        const parsedUser = JSON.parse(storedUser);
        setUser(parsedUser);
      } catch {
        localStorage.removeItem(STORAGE_KEY);
      }
    }
    setLoading(false);
  }, []);

  // Sign in with email and password
  const signIn = useCallback(async (email: string, password: string) => {
    setLoading(true);
    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1000));

      // Check mock users
      const mockUser = MOCK_USERS[email.toLowerCase()];
      if (mockUser && password === "password123") {
        setUser(mockUser);
        localStorage.setItem(STORAGE_KEY, JSON.stringify(mockUser));
        router.push("/");
      } else {
        // Create a new guest user
        const newUser: UserProfile = {
          id: `user-${Date.now()}`,
          email,
          displayName: email.split("@")[0],
          avatar: `https://i.pravatar.cc/150?u=${email}`,
          role: "user",
        };
        setUser(newUser);
        localStorage.setItem(STORAGE_KEY, JSON.stringify(newUser));
        router.push("/");
      }
    } finally {
      setLoading(false);
    }
  }, [router]);

  // Sign in with Google (simulated)
  const signInWithGoogle = useCallback(async () => {
    setLoading(true);
    try {
      // Simulate OAuth flow
      await new Promise((resolve) => setTimeout(resolve, 1500));

      // Create a Google user
      const googleUser: UserProfile = {
        id: `google-${Date.now()}`,
        email: `user${Math.floor(Math.random() * 1000)}@gmail.com`,
        displayName: "مستخدم جوجل",
        avatar: "https://i.pravatar.cc/150?u=google",
        role: "user",
      };
      setUser(googleUser);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(googleUser));
      router.push("/");
    } finally {
      setLoading(false);
    }
  }, [router]);

  // Sign up
  const signUp = useCallback(async (email: string, password: string, displayName: string) => {
    setLoading(true);
    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1000));

      const newUser: UserProfile = {
        id: `user-${Date.now()}`,
        email,
        displayName,
        avatar: `https://i.pravatar.cc/150?u=${email}`,
        role: "user",
      };
      setUser(newUser);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(newUser));
      router.push("/");
    } finally {
      setLoading(false);
    }
  }, [router]);

  // Logout
  const logout = useCallback(async () => {
    setLoading(true);
    try {
      await new Promise((resolve) => setTimeout(resolve, 500));
      setUser(null);
      localStorage.removeItem(STORAGE_KEY);
      router.push("/");
    } finally {
      setLoading(false);
    }
  }, [router]);

  // Update profile
  const updateProfile = useCallback(async (data: Partial<UserProfile>) => {
    if (!user) return;

    setLoading(true);
    try {
      await new Promise((resolve) => setTimeout(resolve, 500));
      const updatedUser = { ...user, ...data };
      setUser(updatedUser);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(updatedUser));
    } finally {
      setLoading(false);
    }
  }, [user]);

  return (
    <AuthContext.Provider
      value={{
        user,
        loading,
        signIn,
        signInWithGoogle,
        signUp,
        logout,
        updateProfile,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}
