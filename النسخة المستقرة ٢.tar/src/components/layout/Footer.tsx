"use client";

import Link from "next/link";
import { Facebook, Twitter, Instagram, Linkedin, Mail, Phone, MapPin } from "lucide-react";
import { useLanguage } from "@/contexts/LanguageContext";
import { toast } from "sonner";

export function Footer() {
  const { t, language } = useLanguage();

  const handleComingSoon = (e: React.MouseEvent) => {
    e.preventDefault();
    toast.message(t("coming_soon"), { icon: "⏳" });
  };

  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-gray-900 text-gray-300 mt-auto">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-2 mb-6">
              <div className="w-10 h-10 bg-emerald-600 rounded-xl flex items-center justify-center text-white font-bold text-xl">
                {language === "ar" ? "ض" : "D"}
              </div>
              <span className="font-bold text-2xl text-white tracking-tight">
                {language === "ar" ? "ضيف" : "Dayf"}
              </span>
            </div>
            <p className="text-gray-400 mb-6 leading-relaxed">
              {t("footer.description")}
            </p>
            <div className="flex items-center gap-4">
              <a
                href="#"
                onClick={handleComingSoon}
                className="w-10 h-10 rounded-full bg-gray-800 flex items-center justify-center hover:bg-emerald-600 hover:text-white transition-colors"
              >
                <Facebook className="w-5 h-5" />
              </a>
              <a
                href="#"
                onClick={handleComingSoon}
                className="w-10 h-10 rounded-full bg-gray-800 flex items-center justify-center hover:bg-emerald-600 hover:text-white transition-colors"
              >
                <Twitter className="w-5 h-5" />
              </a>
              <a
                href="#"
                onClick={handleComingSoon}
                className="w-10 h-10 rounded-full bg-gray-800 flex items-center justify-center hover:bg-emerald-600 hover:text-white transition-colors"
              >
                <Instagram className="w-5 h-5" />
              </a>
              <a
                href="#"
                onClick={handleComingSoon}
                className="w-10 h-10 rounded-full bg-gray-800 flex items-center justify-center hover:bg-emerald-600 hover:text-white transition-colors"
              >
                <Linkedin className="w-5 h-5" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-white font-bold text-lg mb-6">
              {language === "ar" ? "روابط سريعة" : "Quick Links"}
            </h3>
            <ul className="space-y-4">
              <li>
                <a href="#" onClick={handleComingSoon} className="hover:text-emerald-500 transition-colors">
                  {t("footer.about")}
                </a>
              </li>
              <li>
                <a href="#" onClick={handleComingSoon} className="hover:text-emerald-500 transition-colors">
                  {language === "ar" ? "كيف يعمل الموقع" : "How it Works"}
                </a>
              </li>
              <li>
                <a href="#" onClick={handleComingSoon} className="hover:text-emerald-500 transition-colors">
                  {t("footer.faq")}
                </a>
              </li>
              <li>
                <a href="#" onClick={handleComingSoon} className="hover:text-emerald-500 transition-colors">
                  {t("footer.privacy")}
                </a>
              </li>
              <li>
                <a href="#" onClick={handleComingSoon} className="hover:text-emerald-500 transition-colors">
                  {t("footer.terms")}
                </a>
              </li>
            </ul>
          </div>

          {/* Services */}
          <div>
            <h3 className="text-white font-bold text-lg mb-6">
              {language === "ar" ? "خدماتنا" : "Our Services"}
            </h3>
            <ul className="space-y-4">
              <li>
                <Link href="/category/tourism" className="hover:text-emerald-500 transition-colors">
                  {language === "ar" ? "حجز الفنادق والإقامات" : "Hotel & Stay Bookings"}
                </Link>
              </li>
              <li>
                <Link href="/category/medical" className="hover:text-emerald-500 transition-colors">
                  {language === "ar" ? "السياحة العلاجية" : "Medical Tourism"}
                </Link>
              </li>
              <li>
                <Link href="/category/education" className="hover:text-emerald-500 transition-colors">
                  {language === "ar" ? "القبولات الجامعية" : "University Admissions"}
                </Link>
              </li>
              <li>
                <Link href="/category/business" className="hover:text-emerald-500 transition-colors">
                  {language === "ar" ? "فرص الاستثمار" : "Investment Opportunities"}
                </Link>
              </li>
              <li>
                <a href="#" onClick={handleComingSoon} className="hover:text-emerald-500 transition-colors">
                  {language === "ar" ? "تنظيم المؤتمرات" : "Conference Organization"}
                </a>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="text-white font-bold text-lg mb-6">
              {t("footer.contact")}
            </h3>
            <ul className="space-y-4">
              <li className="flex items-start gap-3">
                <MapPin className="w-5 h-5 text-emerald-500 mt-1 flex-shrink-0" />
                <span>
                  {language === "ar" ? (
                    <>
                      دمشق، سوريا
                      <br />
                      شارع الثورة، بناء 12
                    </>
                  ) : (
                    <>
                      Damascus, Syria
                      <br />
                      Al-Thawra Street, Building 12
                    </>
                  )}
                </span>
              </li>
              <li className="flex items-center gap-3">
                <Phone className="w-5 h-5 text-emerald-500 flex-shrink-0" />
                <span dir="ltr">+963 11 123 4567</span>
              </li>
              <li className="flex items-center gap-3">
                <Mail className="w-5 h-5 text-emerald-500 flex-shrink-0" />
                <span>info@dayf.sy</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-12 pt-8 text-center text-gray-500 text-sm">
          <p>
            © {currentYear} {language === "ar" ? "منصة ضيف (Dayf)" : "Dayf Platform"}.{" "}
            {t("footer.rights")}
          </p>
        </div>
      </div>
    </footer>
  );
}
