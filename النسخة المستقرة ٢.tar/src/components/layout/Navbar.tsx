"use client";

import { useState, useRef, useEffect } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { Menu, Search, User, Globe, MessageSquare, LogOut, ChevronDown, Calendar, Heart, Settings } from "lucide-react";
import { useLanguage } from "@/contexts/LanguageContext";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { motion, AnimatePresence } from "framer-motion";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

const NAV_ITEMS = [
  { href: "/", labelKey: "nav.home" },
  { href: "/category/tourism", labelKey: "nav.tourism" },
  { href: "/category/medical", labelKey: "nav.medical" },
  { href: "/category/education", labelKey: "nav.education" },
  { href: "/category/business", labelKey: "nav.business" },
  { href: "/community", labelKey: "nav.community" },
  { href: "/marketplace", labelKey: "nav.marketplace" },
];

export function Navbar() {
  const [isLangOpen, setIsLangOpen] = useState(false);
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const { language, setLanguage, t, isRTL } = useLanguage();
  const { user, loading, logout, signInWithGoogle } = useAuth();
  const pathname = usePathname();
  const userMenuRef = useRef<HTMLDivElement>(null);
  const langMenuRef = useRef<HTMLDivElement>(null);

  // Close menus when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (userMenuRef.current && !userMenuRef.current.contains(event.target as Node)) {
        setIsUserMenuOpen(false);
      }
      if (langMenuRef.current && !langMenuRef.current.contains(event.target as Node)) {
        setIsLangOpen(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleComingSoon = () => {
    toast.message(t("coming_soon"), {
      icon: "⏳",
    });
  };

  const toggleLanguage = (lang: "ar" | "en") => {
    setLanguage(lang);
    setIsLangOpen(false);
    toast.success(lang === "ar" ? "تم تغيير اللغة إلى العربية" : "Language changed to English");
  };

  const handleLogout = async () => {
    await logout();
    setIsUserMenuOpen(false);
    toast.success(language === "ar" ? "تم تسجيل الخروج" : "Signed out successfully");
  };

  const handleLogin = async () => {
    await signInWithGoogle();
  };

  const userMenuItems = [
    { href: "/profile", icon: User, label: language === "ar" ? "الملف الشخصي" : "Profile" },
    { href: "/my-bookings", icon: Calendar, label: language === "ar" ? "حجوزاتي" : "My Bookings" },
    { href: "/favorites", icon: Heart, label: language === "ar" ? "المفضلة" : "Favorites" },
    { href: "/settings", icon: Settings, label: language === "ar" ? "الإعدادات" : "Settings" },
  ];

  return (
    <nav className="fixed top-0 left-0 right-0 bg-white/95 backdrop-blur-md z-50 border-b border-gray-100 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <Link href="/" className="flex-shrink-0 flex items-center gap-2 hover:opacity-90 transition-opacity">
            <div className="w-10 h-10 bg-emerald-600 rounded-xl flex items-center justify-center text-white font-bold text-xl">
              {language === "ar" ? "ض" : "D"}
            </div>
            <span className="font-bold text-2xl text-gray-900 tracking-tight">
              {language === "ar" ? "ضيف" : "Dayf"}
            </span>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden lg:flex items-center gap-x-6">
            {NAV_ITEMS.map((item) => {
              const isActive = pathname === item.href ||
                (item.href !== "/" && pathname.startsWith(item.href));
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={cn(
                    "text-sm font-medium transition-colors",
                    isActive
                      ? "text-emerald-600"
                      : "text-gray-700 hover:text-emerald-600"
                  )}
                >
                  {t(item.labelKey)}
                </Link>
              );
            })}
          </div>

          {/* Right Actions */}
          <div className="hidden lg:flex items-center gap-4">
            {/* Language Selector */}
            <div className="relative" ref={langMenuRef}>
              <button
                onClick={() => setIsLangOpen(!isLangOpen)}
                className="p-2 text-gray-500 hover:text-emerald-600 transition-colors flex items-center gap-1"
              >
                <Globe className="w-5 h-5" />
                <span className="text-xs font-bold uppercase">{language}</span>
                <ChevronDown className="w-3 h-3" />
              </button>

              <AnimatePresence>
                {isLangOpen && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 10 }}
                    className="absolute top-full mt-2 bg-white border border-gray-100 rounded-xl shadow-xl overflow-hidden min-w-[120px] left-0"
                  >
                    <button
                      onClick={() => toggleLanguage("ar")}
                      className={cn(
                        "w-full text-right px-4 py-2 text-sm hover:bg-gray-50 transition-colors",
                        language === "ar" ? "text-emerald-600 font-bold bg-emerald-50" : "text-gray-700"
                      )}
                    >
                      العربية
                    </button>
                    <button
                      onClick={() => toggleLanguage("en")}
                      className={cn(
                        "w-full text-right px-4 py-2 text-sm hover:bg-gray-50 transition-colors",
                        language === "en" ? "text-emerald-600 font-bold bg-emerald-50" : "text-gray-700"
                      )}
                    >
                      English
                    </button>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* Messages */}
            <button
              onClick={handleComingSoon}
              className="p-2 text-gray-500 hover:text-emerald-600 transition-colors"
            >
              <MessageSquare className="w-5 h-5" />
            </button>

            {/* User Menu or Login Button */}
            {user ? (
              <div className="relative" ref={userMenuRef}>
                <button
                  onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}
                  className="flex items-center gap-2 p-1.5 rounded-full hover:bg-gray-100 transition-colors"
                >
                  <img
                    src={user.avatar || "https://i.pravatar.cc/150?u=default"}
                    alt={user.displayName || ""}
                    className="w-8 h-8 rounded-full object-cover"
                  />
                  <ChevronDown className="w-4 h-4 text-gray-500" />
                </button>

                <AnimatePresence>
                  {isUserMenuOpen && (
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: 10 }}
                      className="absolute top-full mt-2 bg-white border border-gray-100 rounded-xl shadow-xl overflow-hidden min-w-[200px] left-0"
                    >
                      <div className="p-4 border-b border-gray-100">
                        <p className="font-bold text-gray-900 truncate">{user.displayName}</p>
                        <p className="text-sm text-gray-500 truncate">{user.email}</p>
                      </div>
                      <div className="py-2">
                        {userMenuItems.map((item) => (
                          <Link
                            key={item.href}
                            href={item.href}
                            onClick={() => setIsUserMenuOpen(false)}
                            className="flex items-center gap-3 px-4 py-2 text-sm text-gray-700 hover:bg-gray-50 transition-colors"
                          >
                            <item.icon className="w-4 h-4" />
                            {item.label}
                          </Link>
                        ))}
                      </div>
                      <div className="border-t border-gray-100 py-2">
                        <button
                          onClick={handleLogout}
                          className="w-full flex items-center gap-3 px-4 py-2 text-sm text-red-600 hover:bg-red-50 transition-colors"
                        >
                          <LogOut className="w-4 h-4" />
                          {language === "ar" ? "تسجيل الخروج" : "Sign Out"}
                        </button>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            ) : (
              <Button
                onClick={handleLogin}
                disabled={loading}
                className="flex items-center gap-2 bg-emerald-600 text-white hover:bg-emerald-700"
              >
                <User className="w-4 h-4" />
                <span>{t("nav.login")}</span>
              </Button>
            )}
          </div>

          {/* Mobile Search/Filter Bar */}
          <div className="lg:hidden flex-1 flex justify-center px-4">
            <button
              onClick={handleComingSoon}
              className="w-full max-w-sm flex items-center gap-3 px-4 py-2 bg-white border border-gray-200 rounded-full shadow-sm hover:shadow-md transition-shadow"
            >
              <div className="w-8 h-8 bg-emerald-600 rounded-full flex items-center justify-center text-white">
                <Search className="w-4 h-4" />
              </div>
              <div className="flex flex-col items-start overflow-hidden">
                <span className="text-xs font-bold text-gray-900 truncate">
                  {t("hero.anywhere")}
                </span>
                <span className="text-[10px] text-gray-500 truncate">
                  {t("hero.any_week")} • {t("hero.add_guests")}
                </span>
              </div>
            </button>
          </div>

          {/* Mobile Language Toggle */}
          <div className="lg:hidden flex items-center">
            <button
              onClick={() => toggleLanguage(language === "ar" ? "en" : "ar")}
              className="p-2 text-gray-500 hover:text-emerald-600 transition-colors"
            >
              <Globe className="w-5 h-5" />
            </button>
          </div>

          {/* Mobile Menu */}
          <div className="lg:hidden">
            <Sheet open={isMobileMenuOpen} onOpenChange={setIsMobileMenuOpen}>
              <SheetTrigger asChild>
                <button className="p-2 text-gray-500 hover:text-emerald-600 transition-colors">
                  <Menu className="w-6 h-6" />
                </button>
              </SheetTrigger>
              <SheetContent side={isRTL ? "left" : "right"} className="w-80 p-0">
                <div className="flex flex-col h-full">
                  <div className="p-4 border-b border-gray-100">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="w-10 h-10 bg-emerald-600 rounded-xl flex items-center justify-center text-white font-bold text-xl">
                          {language === "ar" ? "ض" : "D"}
                        </div>
                        <span className="font-bold text-xl text-gray-900">
                          {language === "ar" ? "ضيف" : "Dayf"}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* User Info in Mobile Menu */}
                  {user ? (
                    <div className="p-4 border-b border-gray-100 bg-emerald-50">
                      <div className="flex items-center gap-3">
                        <img
                          src={user.avatar || "https://i.pravatar.cc/150?u=default"}
                          alt={user.displayName || ""}
                          className="w-12 h-12 rounded-full object-cover"
                        />
                        <div className="flex-1 min-w-0">
                          <p className="font-bold text-gray-900 truncate">{user.displayName}</p>
                          <p className="text-sm text-gray-500 truncate">{user.email}</p>
                        </div>
                      </div>
                    </div>
                  ) : null}

                  <nav className="flex-1 p-4 overflow-y-auto">
                    <div className="space-y-2">
                      {NAV_ITEMS.map((item) => {
                        const isActive = pathname === item.href ||
                          (item.href !== "/" && pathname.startsWith(item.href));
                        return (
                          <Link
                            key={item.href}
                            href={item.href}
                            onClick={() => setIsMobileMenuOpen(false)}
                            className={cn(
                              "block px-4 py-3 rounded-xl text-base font-medium transition-colors",
                              isActive
                                ? "bg-emerald-50 text-emerald-600"
                                : "text-gray-700 hover:bg-gray-50"
                            )}
                          >
                            {t(item.labelKey)}
                          </Link>
                        );
                      })}
                    </div>

                    {/* User Menu Items in Mobile */}
                    {user && (
                      <div className="mt-4 pt-4 border-t border-gray-100">
                        {userMenuItems.map((item) => (
                          <Link
                            key={item.href}
                            href={item.href}
                            onClick={() => setIsMobileMenuOpen(false)}
                            className="flex items-center gap-3 px-4 py-3 rounded-xl text-base font-medium text-gray-700 hover:bg-gray-50 transition-colors"
                          >
                            <item.icon className="w-5 h-5" />
                            {item.label}
                          </Link>
                        ))}
                      </div>
                    )}
                  </nav>

                  <div className="p-4 border-t border-gray-100">
                    {user ? (
                      <Button
                        onClick={() => {
                          handleLogout();
                          setIsMobileMenuOpen(false);
                        }}
                        variant="outline"
                        className="w-full flex items-center justify-center gap-2 text-red-600 hover:bg-red-50 hover:text-red-600"
                      >
                        <LogOut className="w-4 h-4" />
                        <span>{language === "ar" ? "تسجيل الخروج" : "Sign Out"}</span>
                      </Button>
                    ) : (
                      <Button
                        onClick={() => {
                          handleLogin();
                          setIsMobileMenuOpen(false);
                        }}
                        disabled={loading}
                        className="w-full flex items-center justify-center gap-2 bg-emerald-600 text-white hover:bg-emerald-700"
                      >
                        <User className="w-4 h-4" />
                        <span>{t("nav.login")}</span>
                      </Button>
                    )}
                  </div>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </nav>
  );
}
