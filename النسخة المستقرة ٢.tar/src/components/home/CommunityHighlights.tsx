"use client";

import { motion } from "framer-motion";
import { MessageSquare, Heart, User, Bookmark, Share2 } from "lucide-react";
import Link from "next/link";
import { useLanguage } from "@/contexts/LanguageContext";
import { INITIAL_POSTS } from "@/data/initialServices";
import { cn } from "@/lib/utils";

export function CommunityHighlights() {
  const { language, t } = useLanguage();
  const posts = INITIAL_POSTS.slice(0, 3);

  const formatDate = (date: Date) => {
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    
    if (days === 0) {
      return language === "ar" ? "اليوم" : "Today";
    } else if (days === 1) {
      return language === "ar" ? "أمس" : "Yesterday";
    } else if (days < 7) {
      return language === "ar" ? `منذ ${days} أيام` : `${days} days ago`;
    } else {
      return date.toLocaleDateString(language === "ar" ? "ar-SY" : "en-US");
    }
  };

  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:justify-between md:items-end gap-4 mb-12">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-4">
              <MessageSquare className="w-6 h-6 text-emerald-600" />
              <span className="text-emerald-600 font-bold uppercase tracking-wider text-sm">
                {language === "ar" ? "المجتمع" : "Community"}
              </span>
            </div>
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4 leading-tight">
              {t("community.title")}
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl leading-relaxed">
              {t("community.subtitle")}
            </p>
          </div>
          <Link
            href="/community"
            className="hidden md:inline-flex shrink-0 items-center text-emerald-600 font-semibold hover:text-emerald-700 transition-colors"
          >
            {t("featured.view_all")}
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {posts.map((post, index) => (
            <motion.article
              key={post.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="group bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-md transition-all duration-300 border border-gray-100 flex flex-col"
            >
              {/* Post Image */}
              {post.images && post.images[0] && (
                <Link href={`/community/${post.id}`} className="block shrink-0">
                  <div className="aspect-video overflow-hidden">
                    <img
                      src={post.images[0]}
                      alt={post.title || ""}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                  </div>
                </Link>
              )}

              <div className="p-5 flex-1 flex flex-col min-w-0">
                {/* Author Info */}
                <div className="flex items-center gap-3 mb-3">
                  {post.authorAvatar ? (
                    <img
                      src={post.authorAvatar}
                      alt={post.authorName}
                      className="w-10 h-10 rounded-full object-cover"
                    />
                  ) : (
                    <div className="w-10 h-10 rounded-full bg-emerald-100 flex items-center justify-center text-emerald-600">
                      <User className="w-5 h-5" />
                    </div>
                  )}
                  <div className="flex-1 min-w-0">
                    <h4 className="font-bold text-gray-900 truncate">{post.authorName}</h4>
                    <span className="text-xs text-gray-500">
                      {formatDate(new Date(post.createdAt))}
                    </span>
                  </div>
                  <button className="p-2 text-gray-400 hover:text-emerald-600 transition-colors">
                    <Bookmark className="w-4 h-4" />
                  </button>
                </div>

                {/* Category Badge */}
                {post.category && (
                  <div className="mb-3">
                    <span className="text-[10px] px-2 py-1 bg-emerald-50 text-emerald-700 rounded-md font-bold uppercase tracking-wider">
                      {post.category}
                    </span>
                  </div>
                )}

                {/* Title */}
                {post.title && (
                  <Link href={`/community/${post.id}`}>
                    <h3 className="font-bold text-gray-900 mb-2 line-clamp-2 group-hover:text-emerald-600 transition-colors">
                      {post.title}
                    </h3>
                  </Link>
                )}

                {/* Content Preview */}
                <p className="text-gray-600 text-sm line-clamp-3 mb-4 flex-1">{post.content}</p>

                {/* Engagement Stats */}
                <div className="flex items-center justify-between pt-3 border-t border-gray-100">
                  <div className="flex items-center gap-4">
                    <button className="flex items-center gap-1.5 text-gray-500 hover:text-red-500 transition-colors">
                      <Heart className="w-4 h-4" />
                      <span className="text-sm font-medium">{post.likesCount}</span>
                    </button>
                    <button className="flex items-center gap-1.5 text-gray-500 hover:text-emerald-600 transition-colors">
                      <MessageSquare className="w-4 h-4" />
                      <span className="text-sm font-medium">{post.commentsCount}</span>
                    </button>
                  </div>
                  <button className="flex items-center gap-1.5 text-gray-500 hover:text-emerald-600 transition-colors">
                    <Share2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </motion.article>
          ))}
        </div>

        <div className="mt-12 text-center md:hidden">
          <Link
            href="/community"
            className="inline-flex items-center bg-emerald-600 text-white px-8 py-3 rounded-2xl font-bold hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-200"
          >
            {t("community.read_more")}
          </Link>
        </div>
      </div>
    </section>
  );
}
