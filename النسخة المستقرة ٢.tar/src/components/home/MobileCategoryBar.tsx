"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { useLanguage } from "@/contexts/LanguageContext";
import { MAIN_CATEGORIES } from "@/data/categories";
import { cn } from "@/lib/utils";

const colorMap: Record<string, string> = {
  emerald: "bg-emerald-50 text-emerald-600 border-emerald-200",
  blue: "bg-blue-50 text-blue-600 border-blue-200",
  amber: "bg-amber-50 text-amber-600 border-amber-200",
  purple: "bg-purple-50 text-purple-600 border-purple-200",
};

export function MobileCategoryBar() {
  const { language } = useLanguage();

  return (
    <div className="md:hidden py-4 overflow-x-auto hide-scrollbar -mx-4 px-4">
      <div className="flex gap-3">
        {MAIN_CATEGORIES.map((category) => {
          const colorClass = colorMap[category.color || "emerald"];

          return (
            <Link
              key={category.id}
              href={`/category/${category.id}`}
              className="shrink-0"
            >
              <motion.div
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className={cn(
                  "flex items-center gap-2 px-4 py-2.5 rounded-2xl border font-medium transition-colors",
                  colorClass
                )}
              >
                <span className="text-sm font-semibold">
                  {language === "ar" ? category.name : category.nameEn || category.name}
                </span>
              </motion.div>
            </Link>
          );
        })}
      </div>
    </div>
  );
}
