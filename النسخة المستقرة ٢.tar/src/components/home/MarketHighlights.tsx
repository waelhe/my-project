"use client";

import { motion } from "framer-motion";
import { ShoppingBag, Star, MapPin } from "lucide-react";
import Link from "next/link";
import { useLanguage } from "@/contexts/LanguageContext";
import { INITIAL_PRODUCTS } from "@/data/initialServices";

export function MarketHighlights() {
  const { language, t } = useLanguage();
  const products = INITIAL_PRODUCTS.slice(0, 4);

  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:justify-between md:items-end gap-4 mb-12">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-4">
              <ShoppingBag className="w-6 h-6 text-emerald-600" />
              <span className="text-emerald-600 font-bold uppercase tracking-wider text-sm">
                {t("market.title")}
              </span>
            </div>
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4 leading-tight truncate">
              {t("market.title")}
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl leading-relaxed">
              {t("market.subtitle")}
            </p>
          </div>
          <Link
            href="/marketplace"
            className="hidden md:inline-flex shrink-0 items-center text-emerald-600 font-semibold hover:text-emerald-700 transition-colors"
          >
            {t("featured.view_all")}
          </Link>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {products.map((product, index) => (
            <motion.div
              key={product.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="group bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-md transition-all duration-300 border border-gray-100"
            >
              <Link href={`/marketplace/${product.id}`}>
                <div className="aspect-square overflow-hidden">
                  <img
                    src={product.images[0]}
                    alt={product.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                </div>
                <div className="p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="px-2 py-0.5 bg-emerald-50 text-emerald-700 text-[10px] font-bold rounded-md uppercase tracking-wider">
                      {product.category}
                    </span>
                  </div>
                  <h3 className="font-bold text-gray-900 line-clamp-1 mb-1 group-hover:text-emerald-600 transition-colors">
                    {product.title}
                  </h3>
                  <div className="flex items-center text-gray-500 text-sm mb-2">
                    <MapPin className="w-3.5 h-3.5 ml-1" />
                    <span className="truncate">{product.location}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="font-bold text-emerald-600">
                      ${product.price}
                    </span>
                    <div className="flex items-center gap-1">
                      <Star className="w-3.5 h-3.5 text-emerald-600 fill-current" />
                      <span className="text-sm font-medium text-gray-700">{product.rating}</span>
                    </div>
                  </div>
                </div>
              </Link>
            </motion.div>
          ))}
        </div>

        <div className="mt-12 text-center md:hidden">
          <Link
            href="/marketplace"
            className="inline-flex items-center bg-emerald-600 text-white px-8 py-3 rounded-2xl font-bold hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-200"
          >
            {t("featured.view_all")}
          </Link>
        </div>
      </div>
    </section>
  );
}
