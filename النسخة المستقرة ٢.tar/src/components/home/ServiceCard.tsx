"use client";

import { useState } from "react";
import Link from "next/link";
import { Star, MapPin, Heart, ChevronRight, ChevronLeft, Loader2 } from "lucide-react";
import { motion } from "framer-motion";
import { Service } from "@/types";
import { useLanguage } from "@/contexts/LanguageContext";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

interface ServiceCardProps {
  service: Service;
  index?: number;
  className?: string;
}

export function ServiceCard({ service, index = 0, className }: ServiceCardProps) {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [isHovered, setIsHovered] = useState(false);
  const [isFavorite, setIsFavorite] = useState(false);
  const [isFavoriteLoading, setIsFavoriteLoading] = useState(false);
  const { language, isRTL } = useLanguage();

  const toggleFavorite = async (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();

    setIsFavoriteLoading(true);
    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 500));
      setIsFavorite(!isFavorite);
      toast.success(
        isFavorite
          ? language === "ar"
            ? "تمت الإزالة من المفضلة"
            : "Removed from favorites"
          : language === "ar"
          ? "تمت الإضافة إلى المفضلة"
          : "Added to favorites"
      );
    } catch (error) {
      toast.error(language === "ar" ? "حدث خطأ" : "An error occurred");
    } finally {
      setIsFavoriteLoading(false);
    }
  };

  const nextImage = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setCurrentImageIndex((prev) => (prev + 1) % service.images.length);
  };

  const prevImage = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setCurrentImageIndex((prev) => (prev - 1 + service.images.length) % service.images.length);
  };

  const formattedPrice = new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: service.currency || "USD",
    maximumFractionDigits: 0,
  }).format(service.price);

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.3, delay: index * 0.05 }}
      className={cn(
        "group bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-md transition-all duration-300 flex flex-col min-w-0",
        className
      )}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div className="relative aspect-[4/3] overflow-hidden block shrink-0">
        {/* Image Carousel */}
        <Link href={`/listing/${service.id}`}>
          <img
            src={service.images[currentImageIndex]}
            alt={service.title}
            className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
          />
        </Link>

        {/* Carousel Controls */}
        {isHovered && service.images.length > 1 && (
          <>
            <button
              onClick={prevImage}
              className="absolute top-1/2 right-2 -translate-y-1/2 p-1.5 bg-white/90 backdrop-blur-sm rounded-full text-gray-700 hover:bg-white hover:scale-110 transition-all z-10 shadow-sm"
            >
              {isRTL ? (
                <ChevronLeft className="w-4 h-4" />
              ) : (
                <ChevronRight className="w-4 h-4" />
              )}
            </button>
            <button
              onClick={nextImage}
              className="absolute top-1/2 left-2 -translate-y-1/2 p-1.5 bg-white/90 backdrop-blur-sm rounded-full text-gray-700 hover:bg-white hover:scale-110 transition-all z-10 shadow-sm"
            >
              {isRTL ? (
                <ChevronRight className="w-4 h-4" />
              ) : (
                <ChevronLeft className="w-4 h-4" />
              )}
            </button>
          </>
        )}

        {/* Carousel Dots */}
        {service.images.length > 1 && (
          <div className="absolute bottom-3 left-0 right-0 flex justify-center gap-1.5 z-10">
            {service.images.map((_, idx) => (
              <div
                key={idx}
                className={cn(
                  "h-1.5 rounded-full transition-all",
                  idx === currentImageIndex ? "w-4 bg-white" : "w-1.5 bg-white/60"
                )}
              />
            ))}
          </div>
        )}

        {/* Popular Badge */}
        {service.isPopular && (
          <div className="absolute top-4 right-4 flex flex-col gap-2 items-end z-10">
            <div className="px-3 py-1 bg-emerald-600 text-white rounded-full text-xs font-bold shadow-sm">
              {language === "ar" ? "الأكثر طلباً" : "Popular"}
            </div>
          </div>
        )}

        {/* Favorite Button */}
        <button
          onClick={toggleFavorite}
          disabled={isFavoriteLoading}
          className={cn(
            "absolute top-3 left-3 p-2 backdrop-blur-sm rounded-full transition-all z-10 shadow-sm",
            isFavorite
              ? "bg-red-500 text-white scale-110"
              : "bg-white/80 text-gray-600 hover:text-red-500 hover:bg-white"
          )}
        >
          {isFavoriteLoading ? (
            <Loader2 className="w-5 h-5 animate-spin" />
          ) : (
            <Heart className={cn("w-5 h-5", isFavorite && "fill-current")} />
          )}
        </button>
      </div>

      <div className="p-4 flex-1 flex flex-col min-w-0">
        <div className="flex justify-between items-start mb-1 gap-2">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1">
              <span className="px-2 py-0.5 bg-emerald-50 text-emerald-700 text-[10px] font-bold rounded-md uppercase tracking-wider">
                {service.type}
              </span>
            </div>
            <Link href={`/listing/${service.id}`}>
              <h3 className="text-base font-bold text-gray-900 truncate hover:text-emerald-600 transition-colors">
                {service.title}
              </h3>
            </Link>
            <div className="flex items-center text-gray-500 text-sm mt-0.5">
              <MapPin className="w-3.5 h-3.5 ml-1" />
              <span className="truncate">{service.location}</span>
            </div>
          </div>
          <div className="flex items-center gap-1 shrink-0">
            <Star className="w-3.5 h-3.5 text-emerald-600 fill-current" />
            <span className="font-bold text-sm text-gray-900">{service.rating}</span>
          </div>
        </div>

        <div className="mt-3 flex items-baseline gap-1">
          <span className="text-lg font-bold text-gray-900">{formattedPrice}</span>
          <span className="text-gray-500 text-sm font-normal">
            {language === "ar" ? "/ ليلة" : "/ night"}
          </span>
        </div>

        {/* Amenities */}
        {service.amenities && service.amenities.length > 0 && (
          <div className="mt-2 flex flex-wrap gap-1">
            {service.amenities.slice(0, 3).map((amenity, idx) => (
              <span
                key={idx}
                className="text-[10px] px-2 py-0.5 bg-gray-100 text-gray-600 rounded-full"
              >
                {amenity}
              </span>
            ))}
            {service.amenities.length > 3 && (
              <span className="text-[10px] px-2 py-0.5 bg-gray-100 text-gray-600 rounded-full">
                +{service.amenities.length - 3}
              </span>
            )}
          </div>
        )}
      </div>
    </motion.div>
  );
}
