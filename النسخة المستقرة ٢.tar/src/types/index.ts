import { z } from "zod";

// Service Schema
export const ServiceSchema = z.object({
  id: z.string(),
  mainCategoryId: z.string(),
  subCategoryId: z.string().optional(),
  subSubCategoryId: z.string().optional(),
  title: z.string(),
  description: z.string().optional(),
  location: z.string(),
  city: z.string().optional(),
  price: z.number(),
  originalPrice: z.number().optional(),
  currency: z.string().default("USD"),
  rating: z.number().min(0).max(5).default(4.5),
  reviews: z.number().int().nonnegative().default(0),
  images: z.array(z.string()).min(1),
  type: z.string(),
  amenities: z.array(z.string()).default([]),
  features: z.array(z.string()).default([]),
  isPopular: z.boolean().default(false),
  isFeatured: z.boolean().default(false),
  tags: z.array(z.string()).default([]),
  host: z.object({
    name: z.string(),
    isSuperhost: z.boolean().optional(),
    avatar: z.string(),
  }).optional(),
  authorUid: z.string().optional(),
  status: z.string().default("published"),
  createdAt: z.date().optional(),
});

export type Service = z.infer<typeof ServiceSchema>;

// Sub-sub-category Schema
export const SubSubCategorySchema = z.object({
  id: z.string(),
  name: z.string(),
});

export type SubSubCategory = z.infer<typeof SubSubCategorySchema>;

// Sub-category Schema
export const SubCategorySchema = z.object({
  id: z.string(),
  name: z.string(),
  icon: z.string().optional(),
  subCategories: z.array(SubSubCategorySchema).optional(),
});

export type SubCategory = z.infer<typeof SubCategorySchema>;

// Main Category Schema
export const CategorySchema = z.object({
  id: z.string(),
  name: z.string(),
  nameEn: z.string(),
  description: z.string(),
  descriptionEn: z.string(),
  icon: z.string(),
  color: z.string().default("emerald"),
  image: z.string().optional(),
  subCategories: z.array(SubCategorySchema),
});

export type Category = z.infer<typeof CategorySchema>;

// Region Schema
export const RegionSchema = z.object({
  id: z.string(),
  name: z.string(),
  nameEn: z.string().optional(),
  description: z.string(),
  descriptionEn: z.string().optional(),
  image: z.string(),
});

export type Region = z.infer<typeof RegionSchema>;

// Booking Schema
export const BookingSchema = z.object({
  id: z.string(),
  userId: z.string(),
  serviceId: z.string(),
  serviceTitle: z.string(),
  providerId: z.string(),
  checkIn: z.string(),
  checkOut: z.string().optional(),
  guests: z.number().default(1),
  totalPrice: z.number(),
  status: z.enum(["pending", "confirmed", "cancelled", "completed"]),
  createdAt: z.date(),
});

export type Booking = z.infer<typeof BookingSchema>;

// User Schema
export const UserSchema = z.object({
  id: z.string(),
  uid: z.string(),
  email: z.string().email().optional(),
  displayName: z.string().optional(),
  photoURL: z.string().optional(),
  role: z.enum(["user", "provider", "admin"]).default("user"),
  createdAt: z.date().optional(),
});

export type User = z.infer<typeof UserSchema>;

// Message Schema (for AI Chat)
export const MessageSchema = z.object({
  id: z.number(),
  type: z.enum(["user", "agent"]),
  text: z.string(),
});

export type Message = z.infer<typeof MessageSchema>;

// Post Schema (for Community)
export const PostSchema = z.object({
  id: z.string(),
  userId: z.string(),
  title: z.string().optional(),
  content: z.string(),
  images: z.array(z.string()).optional(),
  category: z.string().optional(),
  likesCount: z.number().default(0),
  commentsCount: z.number().default(0),
  createdAt: z.date(),
  authorName: z.string(),
  authorAvatar: z.string().optional(),
});

export type Post = z.infer<typeof PostSchema>;

// Product Schema (for Marketplace)
export const ProductSchema = z.object({
  id: z.string(),
  title: z.string(),
  description: z.string().optional(),
  price: z.number(),
  currency: z.string().default("USD"),
  images: z.array(z.string()),
  category: z.string(),
  location: z.string(),
  sellerName: z.string(),
  sellerId: z.string(),
  rating: z.number().default(4.5),
  reviews: z.number().default(0),
  createdAt: z.date(),
});

export type Product = z.infer<typeof ProductSchema>;
