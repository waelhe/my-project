// Service interface
export interface Service {
  id: string;
  mainCategoryId: string;
  subCategoryId?: string;
  subSubCategoryId?: string;
  title: string;
  location: string;
  price: number;
  originalPrice?: number;
  rating: number;
  reviews: number;
  images: string[];
  type: string;
  amenities?: string[];
  features?: string[];
  isPopular?: boolean;
  isFeatured?: boolean;
  host?: {
    name: string;
    isSuperhost?: boolean;
    avatar: string;
  };
  // Additional fields for extended functionality
  authorUid?: string;
  subSubCategoryId?: string;
  description?: string;
  city?: string;
  tags?: string[];
  status?: string;
  createdAt?: Date;
}

export const INITIAL_SERVICES: Service[] = [
  // ================= TOURISM - RECREATIONAL =================
  {
    id: 't1',
    mainCategoryId: 'tourism',
    subCategoryId: 'recreational',
    subSubCategoryId: 'stays',
    title: 'منتجع الرمال الذهبية الفاخر',
    location: 'طرطوس، الشاطئ الأزرق',
    price: 150,
    originalPrice: 200,
    rating: 4.9,
    reviews: 320,
    images: [
      'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1566073771259-6a8506099945?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'
    ],
    type: 'منتجع',
    amenities: ['مسبح خاص', 'واي فاي سريع', 'إطلالة بحرية', 'سبا ومساج', 'موقف سيارات مجاني', 'مطعم فاخر'],
    features: ['إلغاء مجاني', 'حجز فوري'],
    isPopular: true,
    isFeatured: true,
    host: { name: 'إدارة المنتجع', isSuperhost: true, avatar: 'https://i.pravatar.cc/150?u=t1' }
  },
  {
    id: 't2',
    mainCategoryId: 'tourism',
    subCategoryId: 'recreational',
    subSubCategoryId: 'destinations',
    title: 'جولة القوارب في جزيرة أرواد',
    location: 'طرطوس، جزيرة أرواد',
    price: 25,
    rating: 4.7,
    reviews: 85,
    images: ['https://images.unsplash.com/photo-1544551763-46a013bb70d5?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'],
    type: 'جولة بحرية',
    amenities: ['مرشد سياحي', 'سترات نجاة', 'وجبة خفيفة'],
    features: ['مناسب للأطفال'],
    isPopular: false,
    host: { name: 'الكابتن علي', isSuperhost: false, avatar: 'https://i.pravatar.cc/150?u=t2' }
  },
  {
    id: 't3',
    mainCategoryId: 'tourism',
    subCategoryId: 'recreational',
    subSubCategoryId: 'stays',
    title: 'شاليهات النورس الملكية',
    location: 'اللاذقية، وادي قنديل',
    price: 120,
    rating: 4.8,
    reviews: 210,
    images: ['https://images.unsplash.com/photo-1499793983690-e29da59ef1c2?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'],
    type: 'شاليه',
    amenities: ['شاطئ خاص', 'مطبخ كامل', 'تكييف'],
    features: ['إلغاء مجاني'],
    isPopular: true,
    isFeatured: true,
    host: { name: 'شركة النورس', isSuperhost: true, avatar: 'https://i.pravatar.cc/150?u=t3' }
  },

  // ================= TOURISM - CULTURAL =================
  {
    id: 't4',
    mainCategoryId: 'tourism',
    subCategoryId: 'cultural',
    subSubCategoryId: 'landmarks',
    title: 'فندق بيت المملوكة التراثي',
    location: 'دمشق، باب توما',
    price: 95,
    rating: 4.9,
    reviews: 180,
    images: ['https://images.unsplash.com/photo-1518780664697-55e3ad937233?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'],
    type: 'فندق تراثي',
    amenities: ['فطور دمشقي', 'فناء داخلي', 'واي فاي'],
    features: ['مبنى تاريخي'],
    isPopular: true,
    isFeatured: true,
    host: { name: 'عائلة المملوكة', isSuperhost: true, avatar: 'https://i.pravatar.cc/150?u=t4' }
  },
  {
    id: 't5',
    mainCategoryId: 'tourism',
    subCategoryId: 'cultural',
    subSubCategoryId: 'workshops',
    title: 'ورشة تعليم صناعة الموزاييك',
    location: 'دمشق، التكية السليمانية',
    price: 40,
    rating: 4.6,
    reviews: 55,
    images: ['https://images.unsplash.com/photo-1513519245088-0e12902e5a38?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'],
    type: 'ورشة عمل',
    amenities: ['المواد الأولية', 'شهادة حضور'],
    features: ['صناعة يدوية'],
    isPopular: false,
    host: { name: 'الحرفي أبو محمد', isSuperhost: false, avatar: 'https://i.pravatar.cc/150?u=t5' }
  },

  // ================= TOURISM - NATURE =================
  {
    id: 't6',
    mainCategoryId: 'tourism',
    subCategoryId: 'nature',
    subSubCategoryId: 'adventures',
    title: 'رحلة تخييم في غابات كسب',
    location: 'اللاذقية، كسب',
    price: 50,
    rating: 4.8,
    reviews: 42,
    images: ['https://images.unsplash.com/photo-1478131143081-80f7f84ca84d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'],
    type: 'مغامرة',
    amenities: ['خيمة مجهزة', 'وجبات طعام', 'مرشد جبلي'],
    features: ['إطلالة جبلية'],
    isPopular: true,
    isFeatured: true,
    host: { name: 'فريق مغامرة', isSuperhost: true, avatar: 'https://i.pravatar.cc/150?u=t6' }
  },
  {
    id: 't7',
    mainCategoryId: 'tourism',
    subCategoryId: 'nature',
    subSubCategoryId: 'landmarks',
    title: 'زيارة مغارة الضوايات',
    location: 'طرطوس، مشتى الحلو',
    price: 15,
    rating: 4.5,
    reviews: 120,
    images: ['https://images.unsplash.com/photo-1502726299822-6f583f972e02?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'],
    type: 'معلم طبيعي',
    amenities: ['تذاكر دخول', 'مرشد'],
    features: ['مناسب للعائلات'],
    isPopular: false,
    host: { name: 'بلدية مشتى الحلو', isSuperhost: false, avatar: 'https://i.pravatar.cc/150?u=t7' }
  },

  // ================= MEDICAL - DENTAL =================
  {
    id: 'm1',
    mainCategoryId: 'medical',
    subCategoryId: 'dental',
    subSubCategoryId: 'cosmetic',
    title: 'مركز ابتسامة الشام لطب وتجميل الأسنان',
    location: 'دمشق، المزة',
    price: 1200,
    originalPrice: 1500,
    rating: 4.9,
    reviews: 412,
    images: ['https://images.unsplash.com/photo-1629909613654-28e377c37b09?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'],
    type: 'عيادة تخصصية',
    amenities: ['أشعة بانورامية', 'تخدير بدون ألم', 'تعقيم دولي'],
    features: ['حجز موعد فوري'],
    isPopular: true,
    isFeatured: true,
    host: { name: 'د. سامر', isSuperhost: true, avatar: 'https://i.pravatar.cc/150?u=m1' }
  },
  {
    id: 'm2',
    mainCategoryId: 'medical',
    subCategoryId: 'dental',
    subSubCategoryId: 'implants',
    title: 'مركز النخبة لزراعة الأسنان',
    location: 'حلب، الفرقان',
    price: 800,
    rating: 4.8,
    reviews: 156,
    images: ['https://images.unsplash.com/photo-1588776814546-1ffcf47267a5?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'],
    type: 'مركز زراعة',
    amenities: ['زراعة فورية', 'ضمان مدى الحياة'],
    features: ['أحدث التقنيات'],
    isPopular: false,
    host: { name: 'د. يحيى', isSuperhost: true, avatar: 'https://i.pravatar.cc/150?u=m2' }
  },

  // ================= MEDICAL - EYE =================
  {
    id: 'm3',
    mainCategoryId: 'medical',
    subCategoryId: 'eye',
    subSubCategoryId: 'lasik',
    title: 'المركز الدولي لليزك وجراحة العيون',
    location: 'دمشق، كفرسوسة',
    price: 500,
    rating: 5.0,
    reviews: 850,
    images: ['https://images.unsplash.com/photo-1576091160550-2173dba999ef?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'],
    type: 'مركز جراحي',
    amenities: ['فيمتو ليزك', 'فحوصات شاملة'],
    features: ['نتائج مضمونة'],
    isPopular: true,
    isFeatured: true,
    host: { name: 'د. ريم', isSuperhost: true, avatar: 'https://i.pravatar.cc/150?u=m3' }
  },

  // ================= MEDICAL - ALTERNATIVE =================
  {
    id: 'm4',
    mainCategoryId: 'medical',
    subCategoryId: 'alternative',
    subSubCategoryId: 'spa',
    title: 'مركز استشفاء حمام الملك الظاهر',
    location: 'دمشق، دمشق القديمة',
    price: 30,
    rating: 4.7,
    reviews: 210,
    images: ['https://images.unsplash.com/photo-1544161515-4ab6ce6db874?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'],
    type: 'حمام تراثي',
    amenities: ['تدليك', 'بخار', 'ليفة وصابون غار'],
    features: ['تجربة تاريخية'],
    isPopular: true,
    host: { name: 'إدارة الحمام', isSuperhost: false, avatar: 'https://i.pravatar.cc/150?u=m4' }
  },

  // ================= MEDICAL - FOREIGN PATIENTS =================
  {
    id: 'm5',
    mainCategoryId: 'medical',
    subCategoryId: 'foreign_patients',
    subSubCategoryId: 'arrangements',
    title: 'خدمات ترتيب العلاج للمرضى الأجانب',
    location: 'دمشق، المزة',
    price: 100,
    rating: 4.9,
    reviews: 89,
    images: ['https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'],
    type: 'خدمات طبية',
    amenities: ['ترجمة طبية', 'تنسيق مواعيد', 'نقل من المطار'],
    features: ['خدمة شاملة'],
    isPopular: true,
    host: { name: 'فريق دعم المرضى', isSuperhost: true, avatar: 'https://i.pravatar.cc/150?u=m5' }
  },

  // ================= EDUCATION - LANGUAGES =================
  {
    id: 'e1',
    mainCategoryId: 'education',
    subCategoryId: 'languages',
    subSubCategoryId: 'arabic',
    title: 'معهد الضاد لتعليم العربية للأجانب',
    location: 'دمشق، الميدان',
    price: 450,
    rating: 4.9,
    reviews: 320,
    images: ['https://images.unsplash.com/photo-1546410531-bb4caa6b424d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'],
    type: 'معهد لغات',
    amenities: ['كتب مجانية', 'جولات ثقافية', 'سكن طلابي'],
    features: ['شهادة معتمدة'],
    isPopular: true,
    isFeatured: true,
    host: { name: 'معهد الضاد', isSuperhost: true, avatar: 'https://i.pravatar.cc/150?u=e1' }
  },
  {
    id: 'e2',
    mainCategoryId: 'education',
    subCategoryId: 'languages',
    subSubCategoryId: 'english',
    title: 'مركز أكسفورد للغات',
    location: 'حلب، العزيزية',
    price: 200,
    rating: 4.6,
    reviews: 145,
    images: ['https://images.unsplash.com/photo-1523050335456-c38730b0ebf4?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'],
    type: 'معهد لغات',
    amenities: ['مختبر صوتيات', 'مدرسين أجانب'],
    features: ['تحضير آيلتس'],
    isPopular: false,
    host: { name: 'إدارة المركز', isSuperhost: false, avatar: 'https://i.pravatar.cc/150?u=e2' }
  },

  // ================= EDUCATION - UNIVERSITY =================
  {
    id: 'e3',
    mainCategoryId: 'education',
    subCategoryId: 'university',
    subSubCategoryId: 'registration',
    title: 'خدمات القبول في الجامعات السورية الخاصة',
    location: 'دمشق، المزة',
    price: 100,
    rating: 4.8,
    reviews: 89,
    images: ['https://images.unsplash.com/photo-1523240795612-9a054b0db644?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'],
    type: 'خدمات طلابية',
    amenities: ['استشارات أكاديمية', 'تأمين سكن'],
    features: ['قبول مضمون'],
    isPopular: true,
    isFeatured: true,
    host: { name: 'مكتب الطالب', isSuperhost: true, avatar: 'https://i.pravatar.cc/150?u=e3' }
  },

  // ================= EDUCATION - VOCATIONAL =================
  {
    id: 'e4',
    mainCategoryId: 'education',
    subCategoryId: 'vocational',
    subSubCategoryId: 'technical',
    title: 'معهد التكنولوجيا التطبيقية',
    location: 'حلب، الجميلية',
    price: 150,
    rating: 4.7,
    reviews: 78,
    images: ['https://images.unsplash.com/photo-1516321318423-f06f85e504b3?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'],
    type: 'معهد تقني',
    amenities: ['مختبرات حديثة', 'تدريب عملي', 'شهادات معتمدة'],
    features: ['توظيف بعد التخرج'],
    isPopular: false,
    host: { name: 'إدارة المعهد', isSuperhost: false, avatar: 'https://i.pravatar.cc/150?u=e4' }
  },

  // ================= EDUCATION - ARTS =================
  {
    id: 'e5',
    mainCategoryId: 'education',
    subCategoryId: 'arts',
    subSubCategoryId: 'crafts',
    title: 'ورشة تعليم الحرف التقليدية',
    location: 'دمشق، القنوات',
    price: 35,
    rating: 4.5,
    reviews: 62,
    images: ['https://images.unsplash.com/photo-1452860606245-08befc0ff44b?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'],
    type: 'ورشة حرفية',
    amenities: ['مواد خام', 'أدوات متخصصة', 'شهادة إتمام'],
    features: ['حرفة تقليدية'],
    isPopular: false,
    host: { name: 'الحرفي أبو أحمد', isSuperhost: false, avatar: 'https://i.pravatar.cc/150?u=e5' }
  },

  // ================= EDUCATION - FOREIGN STUDENTS =================
  {
    id: 'e6',
    mainCategoryId: 'education',
    subCategoryId: 'foreign_students',
    subSubCategoryId: 'visas',
    title: 'خدمات التأشيرات الطلابية',
    location: 'دمشق، المزة',
    price: 200,
    rating: 4.8,
    reviews: 156,
    images: ['https://images.unsplash.com/photo-1523240795612-9a054b0db644?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'],
    type: 'خدمات طلابية',
    amenities: ['إصدار تأشيرة', 'تجديد الإقامة', 'تصديق أوراق'],
    features: ['خدمة سريعة'],
    isPopular: true,
    host: { name: 'مكتب الخدمات الطلابية', isSuperhost: true, avatar: 'https://i.pravatar.cc/150?u=e6' }
  },

  // ================= BUSINESS - INVESTMENT =================
  {
    id: 'b1',
    mainCategoryId: 'business',
    subCategoryId: 'investment',
    subSubCategoryId: 'realestate',
    title: 'فرص استثمار عقاري في ماروتا سيتي',
    location: 'دمشق، ماروتا سيتي',
    price: 50000,
    rating: 4.7,
    reviews: 34,
    images: ['https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'],
    type: 'استثمار',
    amenities: ['دراسة جدوى', 'استشارات قانونية'],
    features: ['عائد مرتفع'],
    isPopular: true,
    isFeatured: true,
    host: { name: 'شركة إعمار الشام', isSuperhost: true, avatar: 'https://i.pravatar.cc/150?u=b1' }
  },

  // ================= BUSINESS - SERVICES =================
  {
    id: 'b2',
    mainCategoryId: 'business',
    subCategoryId: 'services',
    subSubCategoryId: 'offices',
    title: 'مساحة عمل مشتركة (Damascus Hub)',
    location: 'دمشق، كفرسوسة',
    price: 25,
    rating: 4.9,
    reviews: 120,
    images: ['https://images.unsplash.com/photo-1497366216548-37526070297c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'],
    type: 'مساحة عمل',
    amenities: ['إنترنت سريع', 'قهوة مجانية', 'قاعات اجتماعات'],
    features: ['دخول 24/7'],
    isPopular: true,
    isFeatured: true,
    host: { name: 'Damascus Hub', isSuperhost: true, avatar: 'https://i.pravatar.cc/150?u=b2' }
  },

  // ================= BUSINESS - CONFERENCES =================
  {
    id: 'b3',
    mainCategoryId: 'business',
    subCategoryId: 'conferences',
    subSubCategoryId: 'trade',
    title: 'معرض دمشق الدولي للتجارة والاستثمار',
    location: 'دمشق، المعارض',
    price: 50,
    rating: 4.6,
    reviews: 245,
    images: ['https://images.unsplash.com/photo-1540575467063-178a50c2df87?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'],
    type: 'معرض تجاري',
    amenities: ['جناح مجهز', 'ترجمة فورية', 'ضيافة'],
    features: ['شبكات أعمال'],
    isPopular: true,
    host: { name: 'إدارة المعرض', isSuperhost: false, avatar: 'https://i.pravatar.cc/150?u=b3' }
  },

  // ================= BUSINESS - PARTNERSHIPS =================
  {
    id: 'b4',
    mainCategoryId: 'business',
    subCategoryId: 'partnerships',
    subSubCategoryId: 'commercial',
    title: 'فرصة شراكة تجارية في قطاع التجزئة',
    location: 'حلب، السليمانية',
    price: 25000,
    rating: 4.5,
    reviews: 28,
    images: ['https://images.unsplash.com/photo-1556761175-4b46a572b786?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'],
    type: 'شراكة تجارية',
    amenities: ['دراسة سوق', 'عقد قانوني', 'دعم تسويقي'],
    features: ['عائد شهري'],
    isPopular: false,
    host: { name: 'شركة الريادة', isSuperhost: true, avatar: 'https://i.pravatar.cc/150?u=b4' }
  }
];

// Helper function to get services by category
export const getServicesByCategory = (categoryId: string): Service[] => {
  return INITIAL_SERVICES.filter(service => service.mainCategoryId === categoryId);
};

// Helper function to get popular services
export const getPopularServices = (): Service[] => {
  return INITIAL_SERVICES.filter(service => service.isPopular);
};

// Helper function to get featured services
export const getFeaturedServices = (): Service[] => {
  return INITIAL_SERVICES.filter(service => service.isFeatured);
};

// Helper function to get service by ID
export const getServiceById = (id: string): Service | undefined => {
  return INITIAL_SERVICES.find(service => service.id === id);
};

// Community Post interface
export interface CommunityPost {
  id: string;
  title?: string;
  content: string;
  authorName: string;
  authorAvatar?: string;
  authorUid?: string;
  category?: string;
  images?: string[];
  likesCount: number;
  commentsCount: number;
  createdAt: string;
  isPinned?: boolean;
  tags?: string[];
}

// Community Posts Data
export const INITIAL_POSTS: CommunityPost[] = [
  {
    id: 'p1',
    title: 'تجربتي في منتجع الرمال الذهبية',
    content: 'قضيت عطلة رائعة في هذا المنتجع الفاخر. الخدمة ممتازة والمسبح خاص وإطلالة بحرية خلابة. أنصح الجميع بزيارته!',
    authorName: 'أحمد الشامي',
    authorAvatar: 'https://i.pravatar.cc/150?u=ahmad',
    category: 'سياحة',
    images: ['https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'],
    likesCount: 45,
    commentsCount: 12,
    createdAt: '2024-01-15T10:30:00Z',
    isPinned: true,
    tags: ['سياحة', 'طرطوس', 'منتجعات']
  },
  {
    id: 'p2',
    title: 'نصائح لتعلم اللغة العربية في دمشق',
    content: 'وصلت إلى دمشق قبل شهرين لتعلم العربية، ووجدت تجربة رائعة. المعهد يوفر برامج ممتازة والناس ودودون جداً. أنصح بزيارة الأسواق القديمة لممارسة اللغة.',
    authorName: 'John Smith',
    authorAvatar: 'https://i.pravatar.cc/150?u=john',
    category: 'تعليم',
    images: ['https://images.unsplash.com/photo-1546410531-bb4caa6b424d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'],
    likesCount: 78,
    commentsCount: 23,
    createdAt: '2024-01-14T14:20:00Z',
    tags: ['تعليم', 'لغة عربية', 'دمشق']
  },
  {
    id: 'p3',
    title: 'تجربتي مع عملية الليزك',
    content: 'أجريت عملية ليزك في المركز الدولي للعيون. الطاقم الطبي محترف جداً والنتائج ممتازة. الآن أرى بوضوح دون نظارات!',
    authorName: 'سارة محمود',
    authorAvatar: 'https://i.pravatar.cc/150?u=sara',
    category: 'علاج',
    images: ['https://images.unsplash.com/photo-1576091160550-2173dba999ef?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'],
    likesCount: 92,
    commentsCount: 31,
    createdAt: '2024-01-13T09:15:00Z',
    tags: ['صحة', 'ليزك', 'دمشق']
  },
  {
    id: 'p4',
    title: 'فرصة استثمارية ممتازة في ماروتا سيتي',
    content: 'استثمرت في مشروع عقاري في ماروتا سيتي والعوائد ممتازة. الفريق يقدم استشارات قانونية شاملة.',
    authorName: 'خالد العمري',
    authorAvatar: 'https://i.pravatar.cc/150?u=khaled',
    category: 'أعمال',
    images: ['https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'],
    likesCount: 34,
    commentsCount: 8,
    createdAt: '2024-01-12T16:45:00Z',
    tags: ['استثمار', 'عقارات', 'دمشق']
  },
  {
    id: 'p5',
    title: 'ورشة الموزاييك تجربة لا تُنسى',
    content: 'شاركت في ورشة صناعة الموزاييك في التكية السليمانية. الحرفيون ماهرون جداً والجو تراثي رائع. تعلمت صناعة لوحة صغيرة بنفسي!',
    authorName: 'فاطمة حسن',
    authorAvatar: 'https://i.pravatar.cc/150?u=fatima',
    category: 'ثقافة',
    images: ['https://images.unsplash.com/photo-1513519245088-0e12902e5a38?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'],
    likesCount: 56,
    commentsCount: 14,
    createdAt: '2024-01-11T11:00:00Z',
    tags: ['ثقافة', 'حرف', 'دمشق']
  }
];

// Product interface for marketplace
export interface Product {
  id: string;
  title: string;
  description?: string;
  price: number;
  originalPrice?: number;
  location: string;
  category: string;
  images: string[];
  rating: number;
  reviews: number;
  seller?: {
    name: string;
    avatar: string;
    isVerified?: boolean;
  };
  inStock?: boolean;
  features?: string[];
  createdAt?: string;
}

// Marketplace Products Data
export const INITIAL_PRODUCTS: Product[] = [
  {
    id: 'pr1',
    title: 'حلويات دمشقية تقليدية',
    description: 'بقلاوة وفستقية حلبي وجميع أنواع الحلويات الشرقية محضرة يدوياً',
    price: 35,
    originalPrice: 45,
    location: 'دمشق، باب توما',
    category: 'أطعمة',
    images: ['https://images.unsplash.com/photo-1519676867240-f03562e64548?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'],
    rating: 4.9,
    reviews: 156,
    seller: { name: 'حلويات أبو جودت', avatar: 'https://i.pravatar.cc/150?u=seller1', isVerified: true },
    inStock: true,
    features: ['توصيل مجاني', 'طلب خاص']
  },
  {
    id: 'pr2',
    title: 'زيت زيتون بكر ممتاز',
    description: 'زيت زيتون فلسطيني معصور بالبارد من أشجار معمرة',
    price: 25,
    location: 'طرطوس، صافيتا',
    category: 'منتجات طبيعية',
    images: ['https://images.unsplash.com/photo-1474979266404-7eaacbcd87c5?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'],
    rating: 4.8,
    reviews: 89,
    seller: { name: 'مزرعة الزيتون', avatar: 'https://i.pravatar.cc/150?u=seller2', isVerified: true },
    inStock: true,
    features: ['عضوي 100%']
  },
  {
    id: 'pr3',
    title: 'صابون غار حلب أصلي',
    description: 'صابون غار حلب التقليدي المصنع يدوياً بالطريقة القديمة',
    price: 8,
    originalPrice: 10,
    location: 'حلب، المدينة القديمة',
    category: 'تجميل',
    images: ['https://images.unsplash.com/photo-1600857062241-98e5dba7f214?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'],
    rating: 4.7,
    reviews: 234,
    seller: { name: 'ورشة الصابون', avatar: 'https://i.pravatar.cc/150?u=seller3', isVerified: true },
    inStock: true,
    features: ['طبيعي', 'تراثي']
  },
  {
    id: 'pr4',
    title: 'أقمشة حريرية سورية',
    description: 'أقمشة حريرية وبروكار دمشقي تقليدي للحفلات والمناسبات',
    price: 120,
    location: 'دمشق، سوق الحميدية',
    category: 'أقمشة',
    images: ['https://images.unsplash.com/photo-1558171813-4c088753af8f?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'],
    rating: 4.6,
    reviews: 67,
    seller: { name: 'محلات الشام', avatar: 'https://i.pravatar.cc/150?u=seller4', isVerified: false },
    inStock: true,
    features: ['مستورد', 'طلب خاص']
  },
  {
    id: 'pr5',
    title: 'تحف خشبية منحوتة',
    description: 'صناديق ولوحات خشبية منحوتة يدوياً بأشكال تراثية',
    price: 75,
    location: 'دمشق، الميدان',
    category: 'حرف يدوية',
    images: ['https://images.unsplash.com/photo-1513519245088-0e12902e5a38?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'],
    rating: 4.9,
    reviews: 45,
    seller: { name: 'الحرفي أبو فادي', avatar: 'https://i.pravatar.cc/150?u=seller5', isVerified: true },
    inStock: true,
    features: ['صناعة يدوية', 'تخصيص']
  },
  {
    id: 'pr6',
    title: 'توابل شامية أصيلة',
    description: 'مجموعة من التوابل السورية الأصيلة: بهار حلب، سماق، زعتر',
    price: 15,
    location: 'حلب، سوق المدينة',
    category: 'أطعمة',
    images: ['https://images.unsplash.com/photo-1596040033229-a9821ebd058d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'],
    rating: 4.8,
    reviews: 178,
    seller: { name: 'عطارة الشام', avatar: 'https://i.pravatar.cc/150?u=seller6', isVerified: true },
    inStock: true,
    features: ['طبيعي', 'طازج']
  }
];
