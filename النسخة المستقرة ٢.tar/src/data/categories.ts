import { Plane, HeartPulse, GraduationCap, Briefcase, LucideIcon } from 'lucide-react';

// Category Icon mapping for Next.js
export const ICON_MAP: Record<string, LucideIcon> = {
  Plane,
  HeartPulse,
  GraduationCap,
  Briefcase,
};

// Sub-sub-category type
export interface SubSubCategory {
  id: string;
  name: string;
}

// Sub-category type
export interface SubCategory {
  id: string;
  name: string;
  icon?: string;
  subCategories?: SubSubCategory[];
}

// Main category type
export interface MainCategory {
  id: string;
  name: string;
  nameEn: string;
  description: string;
  descriptionEn: string;
  icon: string;
  color: string;
  image: string;
  subCategories: SubCategory[];
}

// Main Categories for the platform
export const MAIN_CATEGORIES: MainCategory[] = [
  {
    id: 'tourism',
    name: 'السياحة',
    nameEn: 'Tourism',
    description: 'اكتشف جمال سوريا، تاريخها العريق، وطبيعتها الساحرة',
    descriptionEn: 'Discover the beauty of Syria, its rich history, and stunning nature',
    icon: 'Plane',
    color: 'emerald',
    image: 'https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?w=1200&h=400&fit=crop',
    subCategories: [
      { 
        id: 'recreational', 
        name: 'ترفيهية واستجمام', 
        icon: '🏖️',
        subCategories: [
          { id: 'destinations', name: 'الوجهات' },
          { id: 'stays', name: 'الإقامات' },
          { id: 'activities', name: 'الأنشطة' },
          { id: 'services', name: 'الخدمات' }
        ]
      },
      { 
        id: 'cultural', 
        name: 'ثقافية وتاريخية', 
        icon: '🏛️',
        subCategories: [
          { id: 'landmarks', name: 'المعالم' },
          { id: 'services', name: 'الخدمات' },
          { id: 'workshops', name: 'الورش' }
        ]
      },
      { 
        id: 'religious', 
        name: 'دينية وروحانية', 
        icon: '🕌',
        subCategories: [
          { id: 'landmarks', name: 'المعالم' },
          { id: 'services', name: 'الخدمات' },
          { id: 'programs', name: 'البرامج' }
        ]
      },
      { 
        id: 'nature', 
        name: 'طبيعية ومغامرة', 
        icon: '🏔️',
        subCategories: [
          { id: 'landmarks', name: 'المعالم' },
          { id: 'activities', name: 'الأنشطة' },
          { id: 'adventures', name: 'المغامرات' }
        ]
      }
    ]
  },
  {
    id: 'medical',
    name: 'العلاج',
    nameEn: 'Medical',
    description: 'رعاية صحية متميزة، أطباء خبراء، ومراكز طبية متقدمة',
    descriptionEn: 'Exceptional healthcare, expert doctors, and advanced medical centers',
    icon: 'HeartPulse',
    color: 'blue',
    image: 'https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?w=1200&h=400&fit=crop',
    subCategories: [
      { 
        id: 'medical', 
        name: 'رعاية طبية', 
        icon: '🏥',
        subCategories: [
          { id: 'hospitals', name: 'مستشفيات' },
          { id: 'surgeries', name: 'عمليات جراحية' },
          { id: 'specialized', name: 'علاجات متخصصة' },
          { id: 'diagnosis', name: 'تشخيص ومتابعة' }
        ]
      },
      { 
        id: 'dental', 
        name: 'طب الأسنان', 
        icon: '🦷',
        subCategories: [
          { id: 'clinics', name: 'عيادات متخصصة' },
          { id: 'cosmetic', name: 'تجميل الأسنان' },
          { id: 'implants', name: 'زراعة وتقويم' },
          { id: 'whitening', name: 'تبييض وحشوات' }
        ]
      },
      { 
        id: 'eye', 
        name: 'طب العيون', 
        icon: '👁️',
        subCategories: [
          { id: 'centers', name: 'مراكز دولية' },
          { id: 'lasik', name: 'عمليات الليزر' },
          { id: 'lenses', name: 'عدسات وعلاجات' },
          { id: 'exams', name: 'فحوصات شاملة' }
        ]
      },
      { 
        id: 'alternative', 
        name: 'طب بديل واستشفاء', 
        icon: '🌿',
        subCategories: [
          { id: 'herbal', name: 'مراكز أعشاب' },
          { id: 'natural', name: 'حجامة وعلاجات طبيعية' },
          { id: 'spa', name: 'استشفاء وسبا صحي' },
          { id: 'yoga', name: 'يوغا وتأمل' }
        ]
      },
      {
        id: 'foreign_patients',
        name: 'خدمات المرضى الأجانب',
        icon: '🛠️',
        subCategories: [
          { id: 'arrangements', name: 'ترتيبات العلاج' },
          { id: 'transport', name: 'نقل ومواصلات' },
          { id: 'translation', name: 'ترجمة طبية' },
          { id: 'visas', name: 'تأشيرات علاجية' },
          { id: 'recovery', name: 'إقامة وتعافي' }
        ]
      }
    ]
  },
  {
    id: 'education',
    name: 'الدراسة',
    nameEn: 'Education',
    description: 'جامعات عريقة، معاهد متخصصة، وبرامج تعليمية شاملة',
    descriptionEn: 'Prestigious universities, specialized institutes, and comprehensive educational programs',
    icon: 'GraduationCap',
    color: 'amber',
    image: 'https://images.unsplash.com/photo-1523050854058-8df90110c9f1?w=1200&h=400&fit=crop',
    subCategories: [
      { 
        id: 'university', 
        name: 'تعليم جامعي', 
        icon: '🎓',
        subCategories: [
          { id: 'public', name: 'جامعات حكومية' },
          { id: 'degrees', name: 'بكالوريوس وماجستير' },
          { id: 'specialties', name: 'تخصصات متنوعة' },
          { id: 'registration', name: 'قبول وتسجيل' }
        ]
      },
      { 
        id: 'vocational', 
        name: 'تأهيل مهني', 
        icon: '📜',
        subCategories: [
          { id: 'technical', name: 'معاهد تقنية' },
          { id: 'training', name: 'دورات تأهيل' },
          { id: 'certificates', name: 'شهادات مهنية' },
          { id: 'workshops', name: 'ورش تدريبية' }
        ]
      },
      { 
        id: 'languages', 
        name: 'تعلم اللغات', 
        icon: '🗣️',
        subCategories: [
          { id: 'arabic', name: 'العربية للأجانب' },
          { id: 'english', name: 'الإنجليزية' },
          { id: 'other', name: 'لغات أخرى' },
          { id: 'immersion', name: 'محادثة وانغماس' }
        ]
      },
      { 
        id: 'arts', 
        name: 'حرف وفنون', 
        icon: '🎨',
        subCategories: [
          { id: 'crafts', name: 'ورش حرفية' },
          { id: 'traditional', name: 'فنون تقليدية' },
          { id: 'design', name: 'تصميم وإبداع' },
          { id: 'heritage', name: 'تراث وحرف يدوية' }
        ]
      },
      {
        id: 'foreign_students',
        name: 'خدمات الطلاب الأجانب',
        icon: '🛠️',
        subCategories: [
          { id: 'visas', name: 'تأشيرات طالب' },
          { id: 'housing', name: 'سكن طلابي' },
          { id: 'insurance', name: 'تأمين صحي' },
          { id: 'transport', name: 'تنقلات' },
          { id: 'support', name: 'دعم أكاديمي' }
        ]
      }
    ]
  },
  {
    id: 'business',
    name: 'الأعمال',
    nameEn: 'Business',
    description: 'فرص استثمارية، شراكات استراتيجية، وخدمات أعمال متكاملة',
    descriptionEn: 'Investment opportunities, strategic partnerships, and comprehensive business services',
    icon: 'Briefcase',
    color: 'purple',
    image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=1200&h=400&fit=crop',
    subCategories: [
      { 
        id: 'investment', 
        name: 'فرص استثمارية', 
        icon: '💰',
        subCategories: [
          { id: 'realestate', name: 'عقارات' },
          { id: 'tourism', name: 'سياحي' },
          { id: 'industrial', name: 'صناعي' },
          { id: 'commercial', name: 'تجاري' }
        ]
      },
      { 
        id: 'partnerships', 
        name: 'شراكات تجارية', 
        icon: '🤝',
        subCategories: [
          { id: 'commercial', name: 'شراكات تجارية' },
          { id: 'industrial', name: 'شراكات صناعية' },
          { id: 'services', name: 'شراكات خدمات' },
          { id: 'opportunities', name: 'فرص مشتركة' }
        ]
      },
      { 
        id: 'conferences', 
        name: 'مؤتمرات ومعارض', 
        icon: '📅',
        subCategories: [
          { id: 'trade', name: 'معارض تجارية' },
          { id: 'economic', name: 'مؤتمرات اقتصادية' },
          { id: 'workshops', name: 'ورش عمل' },
          { id: 'networking', name: 'فعاليات التواصل' }
        ]
      },
      { 
        id: 'services', 
        name: 'خدمات أعمال', 
        icon: '🏢',
        subCategories: [
          { id: 'offices', name: 'مكاتب مؤقتة' },
          { id: 'meetings', name: 'قاعات اجتماعات' },
          { id: 'legal', name: 'استشارات قانونية' },
          { id: 'feasibility', name: 'دراسات جدوى' },
          { id: 'translation', name: 'ترجمة معتمدة' },
          { id: 'government', name: 'تسهيلات حكومية' }
        ]
      }
    ]
  }
];

// Syria Regions for Hero slideshow
export const SYRIA_REGIONS = [
  {
    id: 'damascus',
    name: 'دمشق القديمة',
    nameEn: 'Old Damascus',
    description: 'أقدم عاصمة مأهولة في التاريخ',
    descriptionEn: 'The oldest continuously inhabited capital',
    image: 'https://images.unsplash.com/photo-1585076641394-6302f23b7b65?w=1200&q=80'
  },
  {
    id: 'aleppo',
    name: 'قلعة حلب',
    nameEn: 'Aleppo Citadel',
    description: 'رمز الصمود والتاريخ العريق',
    descriptionEn: 'Symbol of resilience and rich history',
    image: 'https://images.unsplash.com/photo-1615811361523-6bd03d7748e7?w=1200&q=80'
  },
  {
    id: 'palmyra',
    name: 'تدمر',
    nameEn: 'Palmyra',
    description: 'عروس البادية ولؤلؤة الصحراء',
    descriptionEn: 'Bride of the Desert and Pearl of the Desert',
    image: 'https://images.unsplash.com/photo-1503917988258-f87a78e3c995?w=1200&q=80'
  },
  {
    id: 'latakia',
    name: 'اللاذقية',
    nameEn: 'Latakia',
    description: 'سحر البحر والجبل',
    descriptionEn: 'The charm of sea and mountain',
    image: 'https://images.unsplash.com/photo-1598335624134-490024f82661?w=1200&q=80'
  },
  {
    id: 'tartus',
    name: 'طرطوس',
    nameEn: 'Tartus',
    description: 'جمال الساحل السوري وجزيرة أرواد',
    descriptionEn: 'Beauty of the Syrian coast and Arwad Island',
    image: 'https://images.unsplash.com/photo-1565674484010-47a339784945?w=1200&q=80'
  }
];

// Helper functions
export const getCategoryColor = (categoryId: string): string => {
  const category = MAIN_CATEGORIES.find((c) => c.id === categoryId);
  return category?.color || 'emerald';
};

export const getCategoryIcon = (categoryId: string): string => {
  const category = MAIN_CATEGORIES.find((c) => c.id === categoryId);
  return category?.icon || 'MapPin';
};

export const getCategoryById = (categoryId: string): MainCategory | undefined => {
  return MAIN_CATEGORIES.find((c) => c.id === categoryId);
};
