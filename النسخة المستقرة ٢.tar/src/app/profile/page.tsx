"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import {
  User, Mail, Phone, MapPin, Camera, Edit2, Save, X,
  Calendar, Star, Heart, Settings, LogOut, Shield, Award
} from "lucide-react";
import Link from "next/link";
import { useAuth } from "@/contexts/AuthContext";
import { useLanguage } from "@/contexts/LanguageContext";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export default function ProfilePage() {
  const { user, loading, updateProfile, logout } = useAuth();
  const { language } = useLanguage();
  const [isEditing, setIsEditing] = useState(false);
  const [editData, setEditData] = useState({
    displayName: user?.displayName || "",
    phone: user?.phone || "",
    city: user?.city || "",
    bio: user?.bio || "",
  });

  const handleSave = async () => {
    await updateProfile(editData);
    setIsEditing(false);
  };

  const handleCancel = () => {
    setEditData({
      displayName: user?.displayName || "",
      phone: user?.phone || "",
      city: user?.city || "",
      bio: user?.bio || "",
    });
    setIsEditing(false);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center pt-16">
        <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-emerald-600" />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center pt-16">
        <div className="text-center p-8 bg-white rounded-2xl shadow-sm max-w-md">
          <User className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <h1 className="text-2xl font-bold text-gray-900 mb-2">
            {language === "ar" ? "يرجى تسجيل الدخول" : "Please Sign In"}
          </h1>
          <p className="text-gray-500 mb-6">
            {language === "ar"
              ? "تحتاج إلى تسجيل الدخول للوصول إلى ملفك الشخصي"
              : "You need to sign in to access your profile"}
          </p>
          <Link
            href="/"
            className="inline-flex items-center bg-emerald-600 text-white px-6 py-3 rounded-xl font-bold hover:bg-emerald-700 transition-colors"
          >
            {language === "ar" ? "العودة للرئيسية" : "Go to Home"}
          </Link>
        </div>
      </div>
    );
  }

  const stats = [
    { label: language === "ar" ? "حجز" : "Bookings", value: 12, icon: Calendar },
    { label: language === "ar" ? "تقييم" : "Reviews", value: 8, icon: Star },
    { label: language === "ar" ? "مفضل" : "Favorites", value: 24, icon: Heart },
  ];

  return (
    <div className="min-h-screen bg-gray-50 pt-16">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Profile Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden mb-6"
        >
          {/* Cover */}
          <div className="h-32 bg-gradient-to-l from-emerald-500 to-teal-600" />

          {/* Avatar and Info */}
          <div className="relative px-6 pb-6">
            <div className="flex flex-col sm:flex-row sm:items-end gap-4">
              {/* Avatar */}
              <div className="-mt-16 relative">
                <img
                  src={user.avatar || "https://i.pravatar.cc/150?u=default"}
                  alt={user.displayName || ""}
                  className="w-28 h-28 rounded-full border-4 border-white shadow-lg object-cover"
                />
                <button className="absolute bottom-0 left-0 p-2 bg-emerald-600 text-white rounded-full shadow-lg hover:bg-emerald-700 transition-colors">
                  <Camera className="w-4 h-4" />
                </button>
              </div>

              {/* Name and Role */}
              <div className="flex-1 pt-4 sm:pt-0">
                <div className="flex items-center gap-2">
                  <h1 className="text-2xl font-bold text-gray-900">
                    {user.displayName || (language === "ar" ? "مستخدم ضيف" : "Dayf User")}
                  </h1>
                  {user.role === "host" && (
                    <span className="flex items-center gap-1 px-2 py-1 bg-amber-100 text-amber-700 text-xs font-bold rounded-full">
                      <Award className="w-3 h-3" />
                      {language === "ar" ? "مضيف" : "Host"}
                    </span>
                  )}
                </div>
                <p className="text-gray-500 flex items-center gap-1">
                  <Mail className="w-4 h-4" />
                  {user.email}
                </p>
              </div>

              {/* Edit Button */}
              {!isEditing && (
                <Button
                  onClick={() => setIsEditing(true)}
                  variant="outline"
                  className="gap-2"
                >
                  <Edit2 className="w-4 h-4" />
                  {language === "ar" ? "تعديل" : "Edit"}
                </Button>
              )}
            </div>
          </div>
        </motion.div>

        {/* Stats */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="grid grid-cols-3 gap-4 mb-6"
        >
          {stats.map((stat, index) => (
            <div
              key={index}
              className="bg-white rounded-xl p-4 text-center border border-gray-200 shadow-sm"
            >
              <stat.icon className="w-6 h-6 text-emerald-600 mx-auto mb-2" />
              <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
              <p className="text-xs text-gray-500">{stat.label}</p>
            </div>
          ))}
        </motion.div>

        {/* Profile Form */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6 mb-6"
        >
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-lg font-bold text-gray-900">
              {language === "ar" ? "المعلومات الشخصية" : "Personal Information"}
            </h2>
            {isEditing && (
              <div className="flex gap-2">
                <Button variant="outline" size="sm" onClick={handleCancel}>
                  <X className="w-4 h-4 mr-1" />
                  {language === "ar" ? "إلغاء" : "Cancel"}
                </Button>
                <Button size="sm" onClick={handleSave} className="bg-emerald-600 hover:bg-emerald-700">
                  <Save className="w-4 h-4 mr-1" />
                  {language === "ar" ? "حفظ" : "Save"}
                </Button>
              </div>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                {language === "ar" ? "الاسم الكامل" : "Full Name"}
              </label>
              {isEditing ? (
                <Input
                  value={editData.displayName}
                  onChange={(e) => setEditData({ ...editData, displayName: e.target.value })}
                  className="w-full"
                />
              ) : (
                <p className="text-gray-900 bg-gray-50 rounded-lg px-4 py-2.5">
                  {user.displayName || "-"}
                </p>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                {language === "ar" ? "البريد الإلكتروني" : "Email"}
              </label>
              <p className="text-gray-900 bg-gray-50 rounded-lg px-4 py-2.5 flex items-center gap-2">
                <Mail className="w-4 h-4 text-gray-400" />
                {user.email}
              </p>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                {language === "ar" ? "رقم الهاتف" : "Phone Number"}
              </label>
              {isEditing ? (
                <Input
                  value={editData.phone}
                  onChange={(e) => setEditData({ ...editData, phone: e.target.value })}
                  className="w-full"
                  placeholder={language === "ar" ? "أدخل رقم الهاتف" : "Enter phone number"}
                />
              ) : (
                <p className="text-gray-900 bg-gray-50 rounded-lg px-4 py-2.5 flex items-center gap-2">
                  <Phone className="w-4 h-4 text-gray-400" />
                  {user.phone || (language === "ar" ? "غير محدد" : "Not specified")}
                </p>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                {language === "ar" ? "المدينة" : "City"}
              </label>
              {isEditing ? (
                <Input
                  value={editData.city}
                  onChange={(e) => setEditData({ ...editData, city: e.target.value })}
                  className="w-full"
                  placeholder={language === "ar" ? "أدخل المدينة" : "Enter city"}
                />
              ) : (
                <p className="text-gray-900 bg-gray-50 rounded-lg px-4 py-2.5 flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-gray-400" />
                  {user.city || (language === "ar" ? "غير محدد" : "Not specified")}
                </p>
              )}
            </div>

            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                {language === "ar" ? "نبذة عني" : "Bio"}
              </label>
              {isEditing ? (
                <textarea
                  value={editData.bio}
                  onChange={(e) => setEditData({ ...editData, bio: e.target.value })}
                  className="w-full px-4 py-2.5 border rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  rows={3}
                  placeholder={language === "ar" ? "اكتب نبذة عن نفسك..." : "Write about yourself..."}
                />
              ) : (
                <p className="text-gray-900 bg-gray-50 rounded-lg px-4 py-2.5">
                  {user.bio || (language === "ar" ? "لا توجد نبذة" : "No bio yet")}
                </p>
              )}
            </div>
          </div>
        </motion.div>

        {/* Quick Actions */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6"
        >
          <h2 className="text-lg font-bold text-gray-900 mb-4">
            {language === "ar" ? "إجراءات سريعة" : "Quick Actions"}
          </h2>
          <div className="space-y-3">
            <Link
              href="/my-bookings"
              className="flex items-center justify-between p-4 bg-gray-50 rounded-xl hover:bg-gray-100 transition-colors group"
            >
              <div className="flex items-center gap-3">
                <Calendar className="w-5 h-5 text-emerald-600" />
                <span className="font-medium text-gray-700">
                  {language === "ar" ? "حجوزاتي" : "My Bookings"}
                </span>
              </div>
              <span className="text-gray-400 group-hover:text-emerald-600">←</span>
            </Link>

            <Link
              href="/favorites"
              className="flex items-center justify-between p-4 bg-gray-50 rounded-xl hover:bg-gray-100 transition-colors group"
            >
              <div className="flex items-center gap-3">
                <Heart className="w-5 h-5 text-red-500" />
                <span className="font-medium text-gray-700">
                  {language === "ar" ? "المفضلة" : "Favorites"}
                </span>
              </div>
              <span className="text-gray-400 group-hover:text-emerald-600">←</span>
            </Link>

            <button
              className="w-full flex items-center justify-between p-4 bg-gray-50 rounded-xl hover:bg-gray-100 transition-colors group"
            >
              <div className="flex items-center gap-3">
                <Settings className="w-5 h-5 text-gray-600" />
                <span className="font-medium text-gray-700">
                  {language === "ar" ? "الإعدادات" : "Settings"}
                </span>
              </div>
              <span className="text-gray-400 group-hover:text-emerald-600">←</span>
            </button>

            <button
              onClick={logout}
              className="w-full flex items-center justify-between p-4 bg-red-50 rounded-xl hover:bg-red-100 transition-colors group"
            >
              <div className="flex items-center gap-3">
                <LogOut className="w-5 h-5 text-red-600" />
                <span className="font-medium text-red-700">
                  {language === "ar" ? "تسجيل الخروج" : "Sign Out"}
                </span>
              </div>
            </button>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
