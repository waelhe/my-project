"use client";

import { useState, useEffect, useRef, useCallback } from "react";
import { useParams, useRouter } from "next/navigation";
import Link from "next/link";
import { motion } from "framer-motion";
import {
  Star, MapPin, Share, Heart, Users, Home, Sparkles, Loader2,
  CheckCircle2, AlertCircle, Wifi, Car, Coffee, Wind, Tv,
  ShieldCheck, Utensils, Waves, Dumbbell, ShoppingBag, Calendar,
  DollarSign, ListChecks, Info, ChevronRight
} from "lucide-react";
import { getServiceById, Service } from "@/data/initialServices";
import { useLanguage } from "@/contexts/LanguageContext";
import { cn } from "@/lib/utils";

// Icon mapping for amenities
const getAmenityIcon = (name: string) => {
  const n = name.toLowerCase();
  if (n.includes('واي فاي') || n.includes('wifi')) return Wifi;
  if (n.includes('تكييف') || n.includes('ac') || n.includes('air')) return Wind;
  if (n.includes('تلفاز') || n.includes('tv') || n.includes('شاشة')) return Tv;
  if (n.includes('قهوة') || n.includes('coffee')) return Coffee;
  if (n.includes('موقف') || n.includes('parking') || n.includes('سيارات')) return Car;
  if (n.includes('أمان') || n.includes('security') || n.includes('حراسة')) return ShieldCheck;
  if (n.includes('مطبخ') || n.includes('kitchen')) return Utensils;
  if (n.includes('مسبح') || n.includes('pool') || n.includes('سباحة')) return Waves;
  if (n.includes('نادي') || n.includes('gym') || n.includes('رياضة')) return Dumbbell;
  return CheckCircle2;
};

export default function ListingDetailsPage() {
  const params = useParams();
  const router = useRouter();
  const { language } = useLanguage();

  const [listing, setListing] = useState<Service | null>(null);
  const [loading, setLoading] = useState(true);
  const [guests, setGuests] = useState(1);
  const [nights] = useState(3);
  const [isBooking, setIsBooking] = useState(false);
  const [bookingStatus, setBookingStatus] = useState<'idle' | 'success' | 'error'>('idle');
  const [saved, setSaved] = useState(false);

  const initialLoadDone = useRef(false);

  // Load listing
  useEffect(() => {
    if (!params.id || initialLoadDone.current) return;
    initialLoadDone.current = true;

    const data = getServiceById(params.id as string);
    if (data) {
      queueMicrotask(() => {
        setListing(data);
        setLoading(false);
      });
    } else {
      queueMicrotask(() => {
        setLoading(false);
      });
    }
  }, [params.id]);

  const handleBooking = useCallback(async () => {
    setIsBooking(true);
    setBookingStatus('idle');

    // Simulate booking process
    await new Promise(resolve => setTimeout(resolve, 1500));

    setBookingStatus('success');
    setIsBooking(false);
  }, []);

  const handleShare = useCallback(() => {
    if (navigator.share) {
      navigator.share({
        title: listing?.title,
        url: window.location.href,
      });
    } else {
      navigator.clipboard.writeText(window.location.href);
    }
  }, [listing?.title]);

  const handleSave = useCallback(() => {
    setSaved(prev => !prev);
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <Loader2 className="w-10 h-10 animate-spin text-emerald-600" />
      </div>
    );
  }

  if (!listing) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center p-8">
          <h1 className="text-2xl font-bold text-gray-900 mb-4">
            {language === "ar" ? "الخدمة غير موجودة" : "Listing Not Found"}
          </h1>
          <Link href="/" className="text-emerald-600 hover:underline">
            {language === "ar" ? "العودة للرئيسية" : "Back to Home"}
          </Link>
        </div>
      </div>
    );
  }

  const totalBase = listing.price * nights;
  const serviceFee = Math.round(totalBase * 0.1);
  const total = totalBase + serviceFee;

  return (
    <div className="min-h-screen bg-white pt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">{listing.title}</h1>
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center gap-4 text-sm font-medium text-gray-700">
              <div className="flex items-center gap-1">
                <Star className="w-4 h-4 text-emerald-500 fill-emerald-500" />
                <span>{listing.rating}</span>
                <span className="text-gray-500 underline cursor-pointer">({listing.reviews} {language === "ar" ? "تقييم" : "reviews"})</span>
              </div>
              <span>·</span>
              <div className="flex items-center gap-1 text-gray-600">
                <MapPin className="w-4 h-4" />
                <span className="underline cursor-pointer">{listing.location}</span>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <button
                onClick={handleShare}
                className="flex items-center gap-2 text-gray-600 hover:text-gray-900 font-medium transition-colors"
              >
                <Share className="w-4 h-4" />
                <span>{language === "ar" ? "مشاركة" : "Share"}</span>
              </button>
              <button
                onClick={handleSave}
                className={cn(
                  "flex items-center gap-2 font-medium transition-colors",
                  saved ? "text-red-500" : "text-gray-600 hover:text-red-500"
                )}
              >
                <Heart className={cn("w-4 h-4", saved && "fill-current")} />
                <span>{language === "ar" ? "حفظ" : "Save"}</span>
              </button>
            </div>
          </div>
        </div>

        {/* Image Gallery */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-2 h-[400px] md:h-[500px] mb-12 rounded-2xl overflow-hidden">
          <div className="md:col-span-2 h-full">
            <img
              src={listing.images[0]}
              alt="Main"
              className="w-full h-full object-cover hover:opacity-90 transition-opacity cursor-pointer"
            />
          </div>
          <div className="hidden md:grid grid-cols-1 gap-2 h-full">
            <img
              src={listing.images[1] || listing.images[0]}
              alt="Gallery 1"
              className="w-full h-full object-cover hover:opacity-90 transition-opacity cursor-pointer"
            />
            <img
              src={listing.images[2] || listing.images[0]}
              alt="Gallery 2"
              className="w-full h-full object-cover hover:opacity-90 transition-opacity cursor-pointer"
            />
          </div>
          <div className="hidden md:grid grid-cols-1 gap-2 h-full">
            <img
              src={listing.images[3] || listing.images[0]}
              alt="Gallery 3"
              className="w-full h-full object-cover hover:opacity-90 transition-opacity cursor-pointer"
            />
            <img
              src={listing.images[4] || listing.images[0]}
              alt="Gallery 4"
              className="w-full h-full object-cover hover:opacity-90 transition-opacity cursor-pointer"
            />
          </div>
        </div>

        {/* Content Split */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          {/* Main Details */}
          <div className="lg:col-span-2">
            {/* Host Info */}
            <div className="flex justify-between items-start sm:items-center pb-6 border-b border-gray-200 gap-4">
              <div className="flex-1 min-w-0">
                <h2 className="text-2xl font-bold text-gray-900 mb-2 truncate">
                  {language === "ar" ? "استضافة بواسطة" : "Hosted by"} {listing.host?.name || (language === "ar" ? "مضيف ضيف" : "Dayf Host")}
                </h2>
                <div className="flex flex-wrap items-center gap-x-4 gap-y-2 text-gray-600 text-sm sm:text-base">
                  <span className="flex items-center gap-1 shrink-0">
                    <Home className="w-4 h-4" /> {listing.type}
                  </span>
                  {listing.features?.map((feature, idx) => (
                    <span key={idx} className="flex items-center gap-1 shrink-0">
                      <Sparkles className="w-4 h-4" /> {feature}
                    </span>
                  ))}
                </div>
              </div>
              <img
                src={listing.host?.avatar || 'https://i.pravatar.cc/150?u=default'}
                alt={listing.host?.name}
                className="w-14 h-14 rounded-full object-cover shrink-0"
              />
            </div>

            {/* AI Insights Section */}
            <div className="py-8 border-b border-gray-200">
              <div className="bg-gradient-to-r from-emerald-50 to-teal-50 rounded-2xl p-6 border border-emerald-100 relative overflow-hidden">
                <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/10 rounded-full blur-3xl -mr-10 -mt-10 pointer-events-none" />
                <div className="flex items-start gap-4 relative z-10">
                  <div className="w-12 h-12 bg-emerald-100 rounded-full flex items-center justify-center shrink-0">
                    <Sparkles className="w-6 h-6 text-emerald-600" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-gray-900 mb-2 flex items-center gap-2">
                      {language === "ar" ? "نظرة سريعة" : "Quick Overview"}
                      <span className="text-xs bg-emerald-100 text-emerald-700 px-2 py-1 rounded-full font-medium">AI</span>
                    </h3>
                    <p className="text-gray-700 leading-relaxed text-sm md:text-base">
                      {language === "ar"
                        ? `${listing.title} - ${listing.type} في ${listing.location}. يتميز بموقع مميز وتقييم عالي ${listing.rating} من ${listing.reviews} تقييم. يوفر تجربة فريدة مع مرافق متكاملة.`
                        : `${listing.title} - ${listing.type} in ${listing.location}. Features an excellent location and high rating of ${listing.rating} from ${listing.reviews} reviews. Offers a unique experience with complete amenities.`}
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Description */}
            <div className="py-8 border-b border-gray-200">
              <h3 className="text-xl font-bold text-gray-900 mb-4">
                {language === "ar" ? "عن هذا المكان" : "About this place"}
              </h3>
              <p className="text-gray-600 leading-relaxed text-lg">
                {language === "ar"
                  ? `${listing.title} - ${listing.type} في ${listing.location}. يوفر هذا المكان تجربة مميزة مع مجموعة من المرافق والخدمات.`
                  : `${listing.title} - ${listing.type} in ${listing.location}. This place offers a unique experience with a range of facilities and services.`}
              </p>
            </div>

            {/* Amenities */}
            <div className="py-8 border-b border-gray-200">
              <h3 className="text-xl font-bold text-gray-900 mb-6">
                {language === "ar" ? "ما يوفره هذا المكان" : "What this place offers"}
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {listing.amenities?.map((amenity, index) => {
                  const Icon = getAmenityIcon(amenity);
                  return (
                    <div key={index} className="flex items-center gap-4 text-gray-700">
                      <Icon className="w-6 h-6 text-emerald-600" />
                      <span className="text-lg">{amenity}</span>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Reviews Section */}
            <div className="py-8 border-b border-gray-200">
              <div className="flex items-center gap-2 mb-6">
                <Star className="w-5 h-5 text-emerald-500 fill-emerald-500" />
                <span className="text-xl font-bold text-gray-900">{listing.rating}</span>
                <span className="text-gray-500">·</span>
                <span className="text-gray-500">{listing.reviews} {language === "ar" ? "تقييم" : "reviews"}</span>
              </div>

              {/* Sample Reviews */}
              <div className="space-y-6">
                {[1, 2, 3].map((_, idx) => (
                  <div key={idx} className="border-b border-gray-100 pb-6 last:border-0">
                    <div className="flex items-center gap-3 mb-3">
                      <img
                        src={`https://i.pravatar.cc/150?u=reviewer${idx}`}
                        alt="Reviewer"
                        className="w-12 h-12 rounded-full"
                      />
                      <div>
                        <p className="font-bold text-gray-900">
                          {language === "ar" ? ["أحمد", "سارة", "محمد"][idx] : ["Ahmad", "Sara", "Mohammed"][idx]}
                        </p>
                        <p className="text-sm text-gray-500">
                          {language === "ar" ? "منذ شهر" : "1 month ago"}
                        </p>
                      </div>
                    </div>
                    <p className="text-gray-600 leading-relaxed">
                      {language === "ar"
                        ? "تجربة رائعة! المكان نظيف ومجهز بكل ما نحتاجه. المضيف متعاون جداً وال موقع ممتاز."
                        : "Great experience! The place is clean and equipped with everything we need. The host is very cooperative and the location is excellent."}
                    </p>
                  </div>
                ))}
              </div>
            </div>

            {/* Community Integration */}
            <div className="py-8">
              <div className="bg-emerald-50 rounded-3xl p-8 border border-emerald-100 flex flex-col md:flex-row items-center justify-between gap-6">
                <div className="flex-1">
                  <h3 className="text-2xl font-bold text-gray-900 mb-2 flex items-center gap-2">
                    <Users className="w-6 h-6 text-emerald-600" />
                    {language === "ar" ? "اسأل مجتمع ضيف" : "Ask Dayf Community"}
                  </h3>
                  <p className="text-gray-600 leading-relaxed">
                    {language === "ar"
                      ? "هل لديك استفسارات حول هذا المكان أو المنطقة المحيطة به؟ تواصل مع ضيوف سابقين أو خبراء محليين."
                      : "Have questions about this place or the surrounding area? Connect with previous guests or local experts."}
                  </p>
                </div>
                <button
                  onClick={() => router.push('/community')}
                  className="shrink-0 bg-emerald-600 text-white px-8 py-3 rounded-xl font-bold hover:bg-emerald-700 transition-colors shadow-lg shadow-emerald-200 w-full md:w-auto text-center"
                >
                  {language === "ar" ? "اذهب إلى المجتمع" : "Go to Community"}
                </button>
              </div>
            </div>
          </div>

          {/* Booking Widget */}
          <div className="lg:col-span-1">
            <div className="sticky top-28 bg-white border border-gray-200 rounded-2xl p-6 shadow-xl">
              <div className="flex justify-between items-end mb-6">
                <div>
                  <span className="text-2xl font-bold text-gray-900">${listing.price}</span>
                  <span className="text-gray-500"> / {language === "ar" ? "ليلة" : "night"}</span>
                </div>
                <div className="flex items-center gap-1 text-sm font-medium">
                  <Star className="w-4 h-4 text-emerald-500 fill-emerald-500" />
                  <span>{listing.rating}</span>
                  <span className="text-gray-500">({listing.reviews})</span>
                </div>
              </div>

              <div className="border border-gray-300 rounded-xl mb-4 overflow-hidden">
                <div className="flex border-b border-gray-300">
                  <div className="flex-1 p-3 border-l border-gray-300">
                    <div className="text-xs font-bold text-gray-900">
                      {language === "ar" ? "تسجيل الوصول" : "Check-in"}
                    </div>
                    <div className="text-gray-500 text-sm mt-1">15 {language === "ar" ? "أكتوبر" : "Oct"} 2026</div>
                  </div>
                  <div className="flex-1 p-3">
                    <div className="text-xs font-bold text-gray-900">
                      {language === "ar" ? "المغادرة" : "Check-out"}
                    </div>
                    <div className="text-gray-500 text-sm mt-1">18 {language === "ar" ? "أكتوبر" : "Oct"} 2026</div>
                  </div>
                </div>
                <div className="p-3">
                  <div className="text-xs font-bold text-gray-900">
                    {language === "ar" ? "الضيوف" : "Guests"}
                  </div>
                  <select
                    className="w-full mt-1 bg-transparent outline-none text-gray-700 text-sm cursor-pointer"
                    value={guests}
                    onChange={(e) => setGuests(Number(e.target.value))}
                  >
                    <option value={1}>{language === "ar" ? "ضيف واحد" : "1 guest"}</option>
                    <option value={2}>{language === "ar" ? "ضيفان" : "2 guests"}</option>
                    <option value={3}>{language === "ar" ? "3 ضيوف" : "3 guests"}</option>
                    <option value={4}>{language === "ar" ? "4 ضيوف" : "4 guests"}</option>
                  </select>
                </div>
              </div>

              {/* Escrow Badge */}
              <div className="bg-blue-50 border border-blue-100 rounded-xl p-3 mb-4 flex items-start gap-2">
                <ShieldCheck className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
                <div>
                  <div className="text-xs font-bold text-blue-800">
                    {language === "ar" ? "حماية ضيف المالية" : "Dayf Financial Protection"}
                  </div>
                  <div className="text-[10px] text-blue-600 leading-tight">
                    {language === "ar"
                      ? "يتم الاحتفاظ بأموالك في حساب وسيط (Escrow) ولا يتم تحويلها للمزود إلا بعد إتمام الخدمة."
                      : "Your money is held in escrow and only released to the provider after service completion."}
                  </div>
                </div>
              </div>

              <button
                onClick={handleBooking}
                disabled={isBooking || bookingStatus === 'success'}
                className={cn(
                  "w-full py-4 rounded-xl font-bold text-lg transition-all mb-4 flex items-center justify-center gap-2",
                  bookingStatus === 'success'
                    ? 'bg-emerald-100 text-emerald-700 cursor-default'
                    : 'bg-emerald-600 text-white hover:bg-emerald-700 active:scale-[0.98]'
                )}
              >
                {isBooking ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    <span>{language === "ar" ? "جاري المعالجة..." : "Processing..."}</span>
                  </>
                ) : bookingStatus === 'success' ? (
                  <>
                    <CheckCircle2 className="w-5 h-5" />
                    <span>{language === "ar" ? "تم الحجز بنجاح!" : "Booked!"}</span>
                  </>
                ) : (
                  language === "ar" ? "احجز الآن" : "Book Now"
                )}
              </button>

              {bookingStatus === 'success' && (
                <div className="bg-emerald-50 text-emerald-700 p-4 rounded-xl text-sm mb-6 flex items-start gap-3 border border-emerald-100">
                  <CheckCircle2 className="w-5 h-5 shrink-0 mt-0.5" />
                  <p>
                    {language === "ar"
                      ? "لقد تم إرسال طلب الحجز الخاص بك بنجاح. يمكنك متابعة حالة الحجز من لوحة التحكم الخاصة بك."
                      : "Your booking request has been sent successfully. You can track the status from your dashboard."}
                  </p>
                </div>
              )}

              {bookingStatus === 'error' && (
                <div className="bg-red-50 text-red-700 p-4 rounded-xl text-sm mb-6 flex items-start gap-3 border border-red-100">
                  <AlertCircle className="w-5 h-5 shrink-0 mt-0.5" />
                  <p>
                    {language === "ar"
                      ? "عذراً، حدث خطأ أثناء محاولة الحجز. يرجى المحاولة مرة أخرى لاحقاً."
                      : "Sorry, an error occurred during booking. Please try again later."}
                  </p>
                </div>
              )}

              <p className="text-center text-gray-500 text-sm mb-6">
                {language === "ar" ? "لن يتم خصم أي مبلغ منك الآن" : "You won't be charged yet"}
              </p>

              <div className="space-y-4 text-gray-600">
                <div className="flex justify-between">
                  <span className="underline">${listing.price} × {nights} {language === "ar" ? "ليالي" : "nights"}</span>
                  <span>${totalBase}</span>
                </div>
                <div className="flex justify-between">
                  <span className="underline">{language === "ar" ? "رسوم خدمة ضيف" : "Service fee"}</span>
                  <span>${serviceFee}</span>
                </div>
              </div>

              <div className="border-t border-gray-200 mt-6 pt-6 flex justify-between font-bold text-lg text-gray-900">
                <span>{language === "ar" ? "الإجمالي" : "Total"}</span>
                <span>${total}</span>
              </div>
            </div>

            {/* Planning Tools Widget */}
            <div className="mt-8 bg-white border border-gray-200 rounded-2xl p-6 shadow-sm">
              <h3 className="text-lg font-bold text-gray-900 mb-4 flex items-center gap-2">
                <ListChecks className="w-5 h-5 text-emerald-600" />
                {language === "ar" ? "أدوات التخطيط" : "Planning Tools"}
              </h3>
              <div className="space-y-4">
                <button className="w-full flex items-center justify-between p-3 bg-gray-50 rounded-xl hover:bg-gray-100 transition-colors group">
                  <div className="flex items-center gap-3">
                    <Calendar className="w-5 h-5 text-gray-400 group-hover:text-emerald-600" />
                    <span className="text-sm font-medium text-gray-700">
                      {language === "ar" ? "بناء برنامج الرحلة" : "Build Itinerary"}
                    </span>
                  </div>
                  <ChevronRight className="w-4 h-4 text-gray-300 rotate-180" />
                </button>
                <button className="w-full flex items-center justify-between p-3 bg-gray-50 rounded-xl hover:bg-gray-100 transition-colors group">
                  <div className="flex items-center gap-3">
                    <DollarSign className="w-5 h-5 text-gray-400 group-hover:text-emerald-600" />
                    <span className="text-sm font-medium text-gray-700">
                      {language === "ar" ? "تقدير الميزانية الكلية" : "Estimate Total Budget"}
                    </span>
                  </div>
                  <ChevronRight className="w-4 h-4 text-gray-300 rotate-180" />
                </button>
                <div className="p-3 bg-amber-50 rounded-xl border border-amber-100">
                  <div className="flex items-center gap-2 text-amber-800 font-bold text-xs mb-1">
                    <Info className="w-3 h-3" />
                    {language === "ar" ? "نصيحة ضيف" : "Dayf Tip"}
                  </div>
                  <p className="text-[11px] text-amber-700 leading-relaxed">
                    {language === "ar"
                      ? "هذا المكان قريب من 3 معالم سياحية مشهورة. ننصح بحجز جولة سياحية معه لتوفير الوقت."
                      : "This place is close to 3 famous landmarks. We recommend booking a tour to save time."}
                  </p>
                </div>
              </div>
            </div>

            {/* Local Market Integration */}
            <div className="mt-8 bg-amber-50 rounded-3xl p-6 border border-amber-100">
              <div className="flex items-start gap-4">
                <ShoppingBag className="w-8 h-8 text-amber-600 shrink-0" />
                <div>
                  <h3 className="text-lg font-bold text-gray-900 mb-2">
                    {language === "ar" ? "تسوق منتجات محلية" : "Shop Local Products"}
                  </h3>
                  <p className="text-gray-600 text-sm mb-4">
                    {language === "ar"
                      ? `اكتشف أفضل المنتجات المحلية في ${listing.location} واطلب توصيلها مباشرة.`
                      : `Discover the best local products in ${listing.location} and get them delivered.`}
                  </p>
                  <button
                    onClick={() => router.push('/marketplace')}
                    className="bg-amber-600 text-white px-6 py-2 rounded-xl font-bold text-sm hover:bg-amber-700 transition-colors"
                  >
                    {language === "ar" ? "تصفح سوق ضيف" : "Browse Market"}
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
