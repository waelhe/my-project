"use client";

import { useState, useMemo, useEffect, useRef, useCallback } from "react";
import { useParams, useSearchParams, useRouter } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";
import { ChevronRight, Filter, Search, Map, SlidersHorizontal, ChevronDown, List, Star, Check, Loader2, MapPin } from "lucide-react";
import Link from "next/link";
import { MAIN_CATEGORIES } from "@/data/categories";
import { getServicesByCategory, Service } from "@/data/initialServices";
import { useLanguage } from "@/contexts/LanguageContext";
import { cn } from "@/lib/utils";

// Icon mapping outside component
const CATEGORY_ICONS: Record<string, string> = {
  Plane: "✈️",
  HeartPulse: "💚",
  GraduationCap: "🎓",
  Briefcase: "💼",
};

// Color classes constants
const COLOR_CLASSES = {
  emerald: {
    bg: 'bg-emerald-600 text-white',
    text: 'text-emerald-600',
    bgLight: 'bg-emerald-50',
    border: 'border-emerald-600',
  },
  blue: {
    bg: 'bg-blue-600 text-white',
    text: 'text-blue-600',
    bgLight: 'bg-blue-50',
    border: 'border-blue-600',
  },
  amber: {
    bg: 'bg-amber-500 text-white',
    text: 'text-amber-600',
    bgLight: 'bg-amber-50',
    border: 'border-amber-500',
  },
  purple: {
    bg: 'bg-purple-600 text-white',
    text: 'text-purple-600',
    bgLight: 'bg-purple-50',
    border: 'border-purple-600',
  },
};

export default function CategoryPage() {
  const params = useParams();
  const searchParams = useSearchParams();
  const router = useRouter();
  const { language } = useLanguage();

  const categoryId = params.id as string;

  // State
  const [services, setServices] = useState<Service[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeSubCategory, setActiveSubCategory] = useState<string>('all');
  const [activeSubSubCategory, setActiveSubSubCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState('recommended');
  const [maxPrice, setMaxPrice] = useState<number>(1000);
  const [showFilters, setShowFilters] = useState(false);
  const [viewMode, setViewMode] = useState<'grid' | 'map'>('grid');

  // Advanced Filters State
  const [selectedAmenities, setSelectedAmenities] = useState<string[]>([]);
  const [minRating, setMinRating] = useState<number>(0);
  const [selectedTypes, setSelectedTypes] = useState<string[]>([]);

  // Refs to avoid cascading renders
  const initialLoadDone = useRef(false);
  const urlParamsProcessed = useRef(false);

  const category = MAIN_CATEGORIES.find(c => c.id === categoryId);

  // Color classes
  const colorKey = (category?.color || 'emerald') as keyof typeof COLOR_CLASSES;
  const activeColorClass = COLOR_CLASSES[colorKey].bg;
  const activeTextClass = COLOR_CLASSES[colorKey].text;
  const activeBorderClass = COLOR_CLASSES[colorKey].border;

  // Load services - use queueMicrotask to avoid cascading renders
  useEffect(() => {
    if (!categoryId) return;

    if (!initialLoadDone.current) {
      initialLoadDone.current = true;
      const data = getServicesByCategory(categoryId);
      queueMicrotask(() => {
        setServices(data);
        setLoading(false);
      });
    }
  }, [categoryId]);

  // Read subcategory from URL
  useEffect(() => {
    if (urlParamsProcessed.current) return;
    urlParamsProcessed.current = true;

    const sub = searchParams.get('sub');
    const subsub = searchParams.get('subsub');
    const searchParam = searchParams.get('search');

    queueMicrotask(() => {
      if (searchParam) {
        setSearchQuery(searchParam);
      }

      if (sub && category?.subCategories.some(s => s.id === sub)) {
        setActiveSubCategory(sub);
        const subCat = category.subCategories.find(s => s.id === sub);
        if (subsub && subCat?.subCategories?.some(ss => ss.id === subsub)) {
          setActiveSubSubCategory(subsub);
        } else {
          setActiveSubSubCategory('all');
        }
      } else {
        setActiveSubCategory('all');
        setActiveSubSubCategory('all');
      }
    });
  }, [searchParams, category]);

  // Extract unique amenities and types
  const { availableAmenities, availableTypes } = useMemo(() => {
    const amenities = new Set<string>();
    const types = new Set<string>();
    services.forEach(s => {
      s.amenities?.forEach(a => amenities.add(a));
      if (s.type) types.add(s.type);
    });
    return {
      availableAmenities: Array.from(amenities),
      availableTypes: Array.from(types)
    };
  }, [services]);

  // Filtering & Sorting Logic
  const filteredAndSortedServices = useMemo(() => {
    if (!category) return [];

    let result = services.filter(service => {
      const matchesMain = service.mainCategoryId === category.id;
      const matchesSub = activeSubCategory === 'all' || service.subCategoryId === activeSubCategory;
      const matchesSubSub = activeSubSubCategory === 'all' || service.subSubCategoryId === activeSubSubCategory;
      const matchesSearch = service.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        service.location.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesPrice = service.price <= maxPrice;
      const matchesRating = service.rating >= minRating;

      const matchesAmenities = selectedAmenities.length === 0 ||
        selectedAmenities.every(amenity => service.amenities?.includes(amenity));

      const matchesTypes = selectedTypes.length === 0 ||
        selectedTypes.includes(service.type);

      return matchesMain && matchesSub && matchesSubSub && matchesSearch && matchesPrice && matchesRating && matchesAmenities && matchesTypes;
    });

    switch (sortBy) {
      case 'price-asc':
        result.sort((a, b) => a.price - b.price);
        break;
      case 'price-desc':
        result.sort((a, b) => b.price - a.price);
        break;
      case 'rating-desc':
        result.sort((a, b) => b.rating - a.rating);
        break;
      case 'recommended':
      default:
        result.sort((a, b) => {
          if (a.isPopular && !b.isPopular) return -1;
          if (!a.isPopular && b.isPopular) return 1;
          return b.rating - a.rating;
        });
        break;
    }

    return result;
  }, [services, category, activeSubCategory, activeSubSubCategory, searchQuery, maxPrice, sortBy, minRating, selectedAmenities, selectedTypes]);

  const toggleAmenity = useCallback((amenity: string) => {
    setSelectedAmenities(prev =>
      prev.includes(amenity) ? prev.filter(a => a !== amenity) : [...prev, amenity]
    );
  }, []);

  const toggleType = useCallback((type: string) => {
    setSelectedTypes(prev =>
      prev.includes(type) ? prev.filter(t => t !== type) : [...prev, type]
    );
  }, []);

  const clearFilters = useCallback(() => {
    setMaxPrice(1000);
    setSearchQuery('');
    setMinRating(0);
    setSelectedAmenities([]);
    setSelectedTypes([]);
  }, []);

  const handleSubCategoryClick = useCallback((subId: string) => {
    setActiveSubCategory(subId);
    setActiveSubSubCategory('all');
    const newUrl = subId === 'all' ? `/category/${category?.id}` : `/category/${category?.id}?sub=${subId}`;
    router.push(newUrl);
  }, [category?.id, router]);

  const handleSubSubCategoryClick = useCallback((subSubId: string) => {
    setActiveSubSubCategory(subSubId);
    const newUrl = subSubId === 'all'
      ? `/category/${category?.id}?sub=${activeSubCategory}`
      : `/category/${category?.id}?sub=${activeSubCategory}&subsub=${subSubId}`;
    router.push(newUrl);
  }, [category?.id, activeSubCategory, router]);

  // Redirect if not found - show not found state
  if (!category) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center p-8">
          <h1 className="text-2xl font-bold text-gray-900 mb-4">
            {language === "ar" ? "التصنيف غير موجود" : "Category Not Found"}
          </h1>
          <Link href="/" className="text-emerald-600 hover:underline">
            {language === "ar" ? "العودة للرئيسية" : "Back to Home"}
          </Link>
        </div>
      </div>
    );
  }

  const currentSubCategory = category.subCategories.find(s => s.id === activeSubCategory);
  const categoryIcon = CATEGORY_ICONS[category.icon] || "📍";

  // Service Card Component - defined as a separate component outside
  const ServiceCard = ({ service }: { service: Service }) => (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="group bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-lg transition-all duration-300 border border-gray-100"
    >
      <Link href={`/listing/${service.id}`}>
        <div className="aspect-[4/3] overflow-hidden relative">
          <img
            src={service.images[0]}
            alt={service.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          />
          {service.isFeatured && (
            <span className={cn("absolute top-3 right-3 px-3 py-1 rounded-full text-xs font-bold", activeColorClass)}>
              {language === "ar" ? "مميز" : "Featured"}
            </span>
          )}
          {service.originalPrice && (
            <span className="absolute top-3 left-3 px-3 py-1 rounded-full text-xs font-bold bg-red-500 text-white">
              {Math.round((1 - service.price / service.originalPrice) * 100)}%
            </span>
          )}
        </div>
        <div className="p-4">
          <div className="flex items-center gap-2 mb-2">
            <span className="text-xs text-gray-500 bg-gray-100 px-2 py-1 rounded-full">
              {service.type}
            </span>
            <div className="flex items-center gap-1">
              <Star className="w-3.5 h-3.5 text-amber-400 fill-current" />
              <span className="text-sm font-medium">{service.rating}</span>
              <span className="text-xs text-gray-400">({service.reviews})</span>
            </div>
          </div>
          <h3 className="font-bold text-gray-900 mb-1 line-clamp-1 group-hover:text-emerald-600 transition-colors">
            {service.title}
          </h3>
          <p className="text-sm text-gray-500 mb-3 truncate">{service.location}</p>
          <div className="flex items-center justify-between">
            <div>
              <span className={cn("font-bold text-lg", activeTextClass)}>${service.price}</span>
              {service.originalPrice && (
                <span className="text-sm text-gray-400 line-through mr-2">${service.originalPrice}</span>
              )}
            </div>
            {service.host?.isSuperhost && (
              <span className="text-xs bg-amber-50 text-amber-700 px-2 py-1 rounded-full font-medium">
                {language === "ar" ? "مضيف متميز" : "Superhost"}
              </span>
            )}
          </div>
        </div>
      </Link>
    </motion.div>
  );

  return (
    <div className="min-h-screen bg-gray-50 pt-16">
      {/* Sticky Top Bar */}
      <div className="sticky top-16 z-40 bg-white border-b border-gray-200 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex flex-col gap-4">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
              {/* Sub-categories Tabs - Level 2 */}
              <div className="flex overflow-x-auto md:flex-wrap hide-scrollbar gap-4 md:gap-6 pb-2 w-full flex-1 snap-x -mx-4 px-4 sm:mx-0 sm:px-0">
                <button
                  onClick={() => handleSubCategoryClick('all')}
                  className={cn(
                    "flex flex-col items-center gap-2 min-w-[70px] pb-3 border-b-2 transition-all shrink-0 snap-start",
                    activeSubCategory === 'all'
                      ? `${activeBorderClass} ${activeTextClass}`
                      : 'border-transparent text-gray-500 hover:text-gray-900 hover:border-gray-300'
                  )}
                >
                  <div className="w-10 h-10 md:w-8 md:h-8 flex items-center justify-center bg-gray-100 rounded-full mb-1">
                    <span>{categoryIcon}</span>
                  </div>
                  <span className="text-xs md:text-sm font-medium whitespace-nowrap">
                    {language === "ar" ? "الكل" : "All"}
                  </span>
                </button>

                {category.subCategories.map((sub) => (
                  <button
                    key={sub.id}
                    onClick={() => handleSubCategoryClick(sub.id)}
                    className={cn(
                      "flex flex-col items-center gap-2 min-w-[70px] pb-3 border-b-2 transition-all shrink-0 snap-start",
                      activeSubCategory === sub.id
                        ? `${activeBorderClass} ${activeTextClass}`
                        : 'border-transparent text-gray-500 hover:text-gray-900 hover:border-gray-300'
                    )}
                  >
                    <div className="text-3xl md:text-2xl mb-1 opacity-80">{sub.icon}</div>
                    <span className="text-xs md:text-sm font-medium whitespace-nowrap">{sub.name}</span>
                  </button>
                ))}
              </div>

              {/* Search & Actions */}
              <div className="flex items-center gap-3 shrink-0">
                <div className="relative">
                  <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <input
                    type="text"
                    placeholder={language === "ar" ? "ابحث عن وجهة أو خدمة..." : "Search for a destination..."}
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-4 pr-10 py-2.5 bg-gray-50 border border-gray-200 rounded-full text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 w-full md:w-64 transition-all"
                  />
                </div>
                <button
                  onClick={() => setShowFilters(!showFilters)}
                  className={cn(
                    "lg:hidden flex items-center justify-center w-10 h-10 border rounded-full transition-colors",
                    showFilters ? activeColorClass : 'bg-white border-gray-200 text-gray-700 hover:bg-gray-50'
                  )}
                >
                  <SlidersHorizontal className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Sub-Sub-categories Tabs - Level 3 */}
            {currentSubCategory && currentSubCategory.subCategories && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                className="flex overflow-x-auto md:flex-wrap hide-scrollbar gap-2 md:gap-3 pb-2 border-t border-gray-50 pt-3 snap-x -mx-4 px-4 sm:mx-0 sm:px-0"
              >
                <button
                  onClick={() => handleSubSubCategoryClick('all')}
                  className={cn(
                    "px-4 py-2 md:py-1.5 rounded-full text-xs md:text-sm font-bold transition-all whitespace-nowrap border shrink-0 snap-start",
                    activeSubSubCategory === 'all'
                      ? `${activeColorClass} border-transparent`
                      : 'bg-gray-50 text-gray-600 border-gray-200 hover:border-gray-300'
                  )}
                >
                  {language === "ar" ? `الكل في ${currentSubCategory.name}` : `All in ${currentSubCategory.name}`}
                </button>
                {currentSubCategory.subCategories.map((ss) => (
                  <button
                    key={ss.id}
                    onClick={() => handleSubSubCategoryClick(ss.id)}
                    className={cn(
                      "px-4 py-2 md:py-1.5 rounded-full text-xs md:text-sm font-bold transition-all whitespace-nowrap border shrink-0 snap-start",
                      activeSubSubCategory === ss.id
                        ? `${activeColorClass} border-transparent`
                        : 'bg-white text-gray-600 border-gray-200 hover:border-gray-300'
                    )}
                  >
                    {ss.name}
                  </button>
                ))}
              </motion.div>
            )}
          </div>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 pb-24 md:pb-8">
        {/* Breadcrumbs & Title */}
        <div className="mb-8">
          <div className="flex items-center gap-2 text-sm text-gray-500 mb-4">
            <Link href="/" className="hover:text-gray-900 transition-colors">
              {language === "ar" ? "الرئيسية" : "Home"}
            </Link>
            <ChevronRight className="w-4 h-4" />
            <span className="font-medium text-gray-900">
              {language === "ar" ? category.name : category.nameEn}
            </span>
          </div>
          <div className="flex flex-col md:flex-row md:justify-between md:items-end gap-4">
            <div className="flex-1 min-w-0">
              <h1 className="text-3xl font-bold text-gray-900 mb-2 leading-tight truncate">
                {language === "ar" ? `${category.name} في سوريا` : `${category.nameEn} in Syria`}
              </h1>
              <p className="text-gray-600 leading-relaxed line-clamp-2 md:line-clamp-none">
                {language === "ar" ? category.description : category.descriptionEn}
              </p>
            </div>

            {/* View Mode Toggle */}
            <div className="flex items-center bg-white border border-gray-200 rounded-xl p-1 shrink-0 self-start md:self-auto shadow-sm">
              <button
                onClick={() => setViewMode('grid')}
                className={cn(
                  "flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors",
                  viewMode === 'grid' ? 'bg-gray-100 text-gray-900' : 'text-gray-500 hover:text-gray-700'
                )}
              >
                <List className="w-4 h-4" />
                <span>{language === "ar" ? "قائمة" : "List"}</span>
              </button>
              <button
                onClick={() => setViewMode('map')}
                className={cn(
                  "flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors",
                  viewMode === 'map' ? 'bg-gray-100 text-gray-900' : 'text-gray-500 hover:text-gray-700'
                )}
              >
                <Map className="w-4 h-4" />
                <span>{language === "ar" ? "خريطة" : "Map"}</span>
              </button>
            </div>
          </div>
        </div>

        <div className="flex flex-col lg:flex-row gap-8">
          {/* Sidebar Filters */}
          <AnimatePresence>
            {(showFilters || (typeof window !== 'undefined' && window.innerWidth >= 1024)) && (
              <motion.aside
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
                className={cn(
                  "lg:w-1/4 shrink-0",
                  showFilters ? 'block' : 'hidden lg:block'
                )}
              >
                <div className="bg-white border border-gray-200 rounded-2xl p-6 sticky top-40 shadow-sm">
                  <div className="flex items-center justify-between mb-6 pb-4 border-b border-gray-100">
                    <h3 className="text-lg font-bold text-gray-900 flex items-center gap-2">
                      <Filter className="w-5 h-5" />
                      {language === "ar" ? "تصفية متقدمة" : "Advanced Filters"}
                    </h3>
                    {showFilters && (
                      <button
                        onClick={() => setShowFilters(false)}
                        className="lg:hidden text-sm text-gray-500 hover:text-gray-900"
                      >
                        {language === "ar" ? "إغلاق" : "Close"}
                      </button>
                    )}
                  </div>

                  {/* Price Filter */}
                  <div className="mb-8">
                    <h4 className="font-semibold text-gray-900 mb-4">
                      {language === "ar" ? "نطاق السعر" : "Price Range"}
                    </h4>
                    <div className="flex items-center justify-between text-sm text-gray-600 mb-3">
                      <span>$0</span>
                      <span className={cn("font-bold", activeTextClass)}>${maxPrice}</span>
                    </div>
                    <input
                      type="range"
                      min="0"
                      max="1000"
                      step="10"
                      value={maxPrice}
                      onChange={(e) => setMaxPrice(Number(e.target.value))}
                      className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-emerald-600"
                    />
                  </div>

                  {/* Rating Filter */}
                  <div className="mb-8">
                    <h4 className="font-semibold text-gray-900 mb-4">
                      {language === "ar" ? "تقييم الضيوف" : "Guest Rating"}
                    </h4>
                    <div className="space-y-2">
                      {[4, 3, 2].map((rating) => (
                        <label key={rating} className="flex items-center gap-3 cursor-pointer group">
                          <div className={cn(
                            "flex items-center justify-center w-5 h-5 border-2 rounded-md transition-colors",
                            minRating === rating ? 'border-emerald-500 bg-emerald-500' : 'border-gray-300 group-hover:border-emerald-500'
                          )}>
                            <input
                              type="radio"
                              name="rating"
                              className="sr-only"
                              checked={minRating === rating}
                              onChange={() => setMinRating(rating)}
                            />
                            {minRating === rating && <Check className="w-3.5 h-3.5 text-white" />}
                          </div>
                          <div className="flex items-center gap-1">
                            <Star className="w-4 h-4 text-amber-400 fill-current" />
                            <span className="text-gray-700 text-sm">{rating}+ {language === "ar" ? "نجوم" : "stars"}</span>
                          </div>
                        </label>
                      ))}
                      <label className="flex items-center gap-3 cursor-pointer group">
                        <div className={cn(
                          "flex items-center justify-center w-5 h-5 border-2 rounded-md transition-colors",
                          minRating === 0 ? 'border-emerald-500 bg-emerald-500' : 'border-gray-300 group-hover:border-emerald-500'
                        )}>
                          <input
                            type="radio"
                            name="rating"
                            className="sr-only"
                            checked={minRating === 0}
                            onChange={() => setMinRating(0)}
                          />
                          {minRating === 0 && <Check className="w-3.5 h-3.5 text-white" />}
                        </div>
                        <span className="text-gray-700 text-sm">{language === "ar" ? "الكل" : "All"}</span>
                      </label>
                    </div>
                  </div>

                  {/* Property Type Filter */}
                  {availableTypes.length > 0 && (
                    <div className="mb-8">
                      <h4 className="font-semibold text-gray-900 mb-4">
                        {language === "ar" ? "نوع المكان" : "Property Type"}
                      </h4>
                      <div className="space-y-3">
                        {availableTypes.map((type, idx) => (
                          <label key={idx} className="flex items-center gap-3 cursor-pointer group">
                            <div className={cn(
                              "flex items-center justify-center w-5 h-5 border-2 rounded-md transition-colors",
                              selectedTypes.includes(type) ? 'border-emerald-500 bg-emerald-500' : 'border-gray-300 group-hover:border-emerald-500'
                            )}>
                              <input
                                type="checkbox"
                                className="sr-only"
                                checked={selectedTypes.includes(type)}
                                onChange={() => toggleType(type)}
                              />
                              {selectedTypes.includes(type) && <Check className="w-3.5 h-3.5 text-white" />}
                            </div>
                            <span className="text-gray-700 text-sm">{type}</span>
                          </label>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Amenities Filter */}
                  {availableAmenities.length > 0 && (
                    <div className="mb-8">
                      <h4 className="font-semibold text-gray-900 mb-4">
                        {language === "ar" ? "المرافق والمميزات" : "Amenities & Features"}
                      </h4>
                      <div className="space-y-3 max-h-48 overflow-y-auto pr-2">
                        {availableAmenities.map((amenity, idx) => (
                          <label key={idx} className="flex items-center gap-3 cursor-pointer group">
                            <div className={cn(
                              "flex items-center justify-center w-5 h-5 border-2 rounded-md transition-colors",
                              selectedAmenities.includes(amenity) ? 'border-emerald-500 bg-emerald-500' : 'border-gray-300 group-hover:border-emerald-500'
                            )}>
                              <input
                                type="checkbox"
                                className="sr-only"
                                checked={selectedAmenities.includes(amenity)}
                                onChange={() => toggleAmenity(amenity)}
                              />
                              {selectedAmenities.includes(amenity) && <Check className="w-3.5 h-3.5 text-white" />}
                            </div>
                            <span className="text-gray-700 text-sm">{amenity}</span>
                          </label>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Reset Button */}
                  <button
                    onClick={clearFilters}
                    className="w-full py-3 text-sm font-bold text-gray-600 bg-gray-50 hover:bg-gray-100 rounded-xl transition-colors border border-gray-200"
                  >
                    {language === "ar" ? "مسح جميع الفلاتر" : "Clear All Filters"}
                  </button>
                </div>
              </motion.aside>
            )}
          </AnimatePresence>

          {/* Results Area */}
          <main className="flex-1 min-w-0">
            {loading ? (
              <div className="w-full py-20 flex flex-col items-center justify-center text-gray-500">
                <Loader2 className="w-10 h-10 animate-spin mb-4 text-emerald-600" />
                <p className="text-lg font-medium">
                  {language === "ar" ? "جاري تحميل الخدمات..." : "Loading services..."}
                </p>
              </div>
            ) : viewMode === 'map' ? (
              <div className="bg-gray-100 rounded-3xl h-[600px] relative overflow-hidden border border-gray-200 shadow-inner flex items-center justify-center">
                <div className="text-center p-8 bg-white/80 backdrop-blur-md rounded-3xl shadow-xl max-w-md border border-white/50">
                  <MapPin className="w-16 h-16 text-emerald-600 mx-auto mb-4" />
                  <h3 className="text-2xl font-bold text-gray-900 mb-2">
                    {language === "ar" ? "خريطة الخدمات" : "Services Map"}
                  </h3>
                  <p className="text-gray-600 mb-6">
                    {language === "ar"
                      ? `عرض ${filteredAndSortedServices.length} خدمة متوفرة في هذه المنطقة`
                      : `Showing ${filteredAndSortedServices.length} services in this area`}
                  </p>
                  <button
                    onClick={() => setViewMode('grid')}
                    className="bg-emerald-600 text-white px-8 py-3 rounded-2xl font-bold hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-200"
                  >
                    {language === "ar" ? "العودة لعرض القائمة" : "Back to List View"}
                  </button>
                </div>
              </div>
            ) : (
              <>
                {/* Results Header */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
                  <p className="text-gray-600 font-medium">
                    {language === "ar" ? (
                      <>تم العثور على <span className="font-bold text-gray-900">{filteredAndSortedServices.length}</span> نتيجة</>
                    ) : (
                      <>Found <span className="font-bold text-gray-900">{filteredAndSortedServices.length}</span> results</>
                    )}
                  </p>

                  <div className="flex items-center gap-2 shrink-0">
                    <span className="text-sm text-gray-500">
                      {language === "ar" ? "ترتيب حسب:" : "Sort by:"}
                    </span>
                    <div className="relative">
                      <select
                        value={sortBy}
                        onChange={(e) => setSortBy(e.target.value)}
                        className="appearance-none bg-white border border-gray-200 text-gray-700 py-2 pl-10 pr-4 rounded-xl text-sm font-medium focus:outline-none focus:ring-2 focus:ring-emerald-500 cursor-pointer"
                      >
                        <option value="recommended">{language === "ar" ? "الأوصى به" : "Recommended"}</option>
                        <option value="price-asc">{language === "ar" ? "السعر: من الأقل للأعلى" : "Price: Low to High"}</option>
                        <option value="price-desc">{language === "ar" ? "السعر: من الأعلى للأقل" : "Price: High to Low"}</option>
                        <option value="rating-desc">{language === "ar" ? "الأعلى تقييماً" : "Highest Rated"}</option>
                      </select>
                      <ChevronDown className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500 pointer-events-none" />
                    </div>
                  </div>
                </div>

                {/* Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                  {filteredAndSortedServices.length > 0 ? (
                    filteredAndSortedServices.map((service) => (
                      <ServiceCard key={service.id} service={service} />
                    ))
                  ) : (
                    <div className="col-span-full py-20 text-center bg-white rounded-3xl border border-gray-100 shadow-sm">
                      <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-gray-50 mb-4">
                        <Search className="w-8 h-8 text-gray-400" />
                      </div>
                      <h3 className="text-xl font-bold text-gray-900 mb-2">
                        {language === "ar" ? "لا توجد نتائج مطابقة" : "No matching results"}
                      </h3>
                      <p className="text-gray-500 max-w-md mx-auto">
                        {language === "ar"
                          ? "حاول تغيير خيارات البحث، أو تقليل الفلاتر المحددة لرؤية المزيد من النتائج المتاحة."
                          : "Try changing your search options or reducing filters to see more available results."}
                      </p>
                      <button
                        onClick={clearFilters}
                        className={cn("mt-6 px-6 py-2.5 rounded-xl font-medium transition-colors shadow-sm", activeColorClass)}
                      >
                        {language === "ar" ? "مسح جميع الفلاتر" : "Clear All Filters"}
                      </button>
                    </div>
                  )}
                </div>
              </>
            )}
          </main>
        </div>
      </div>
    </div>
  );
}
