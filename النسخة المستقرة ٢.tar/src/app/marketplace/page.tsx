"use client";

import { useState } from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import {
  ShoppingBag, Star, MapPin, Search, Filter, Grid, List,
  Package, Truck, ShieldCheck, ChevronDown
} from "lucide-react";
import { INITIAL_PRODUCTS, Product } from "@/data/initialServices";
import { useLanguage } from "@/contexts/LanguageContext";
import { cn } from "@/lib/utils";

export default function MarketplacePage() {
  const { language } = useLanguage();
  const [products] = useState<Product[]>(INITIAL_PRODUCTS);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [sortBy, setSortBy] = useState("popular");
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 200]);

  // Categories
  const categories = [
    { id: "all", name: language === "ar" ? "الكل" : "All", icon: "🛒" },
    { id: "أطعمة", name: language === "ar" ? "أطعمة" : "Food", icon: "🍯" },
    { id: "منتجات طبيعية", name: language === "ar" ? "منتجات طبيعية" : "Natural", icon: "🌿" },
    { id: "تجميل", name: language === "ar" ? "تجميل" : "Beauty", icon: "✨" },
    { id: "أقمشة", name: language === "ar" ? "أقمشة" : "Fabrics", icon: "🧵" },
    { id: "حرف يدوية", name: language === "ar" ? "حرف يدوية" : "Handicrafts", icon: "🎨" },
  ];

  // Filter and sort products
  const filteredProducts = products
    .filter(product => {
      const matchesSearch = product.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        product.description?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        product.location.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesCategory = selectedCategory === "all" || product.category === selectedCategory;
      const matchesPrice = product.price >= priceRange[0] && product.price <= priceRange[1];
      return matchesSearch && matchesCategory && matchesPrice;
    })
    .sort((a, b) => {
      switch (sortBy) {
        case "price-asc":
          return a.price - b.price;
        case "price-desc":
          return b.price - a.price;
        case "rating":
          return b.rating - a.rating;
        case "popular":
        default:
          return b.reviews - a.reviews;
      }
    });

  const ProductCard = ({ product, index }: { product: Product; index: number }) => (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.05 }}
      className="group bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-lg transition-all duration-300 border border-gray-100"
    >
      <Link href={`/marketplace/${product.id}`}>
        <div className="aspect-square overflow-hidden relative">
          <img
            src={product.images[0]}
            alt={product.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          />
          {product.originalPrice && (
            <span className="absolute top-3 left-3 px-3 py-1 rounded-full text-xs font-bold bg-red-500 text-white">
              -{Math.round((1 - product.price / product.originalPrice) * 100)}%
            </span>
          )}
          {product.seller?.isVerified && (
            <span className="absolute top-3 right-3 px-2 py-1 rounded-full text-xs font-bold bg-emerald-500 text-white flex items-center gap-1">
              <ShieldCheck className="w-3 h-3" />
              {language === "ar" ? "موثق" : "Verified"}
            </span>
          )}
        </div>
        <div className="p-4">
          <div className="flex items-center gap-2 mb-2">
            <span className="px-2 py-0.5 bg-emerald-50 text-emerald-700 text-[10px] font-bold rounded-md uppercase tracking-wider">
              {product.category}
            </span>
            {product.inStock === false && (
              <span className="px-2 py-0.5 bg-red-50 text-red-600 text-[10px] font-bold rounded-md">
                {language === "ar" ? "نفذت الكمية" : "Out of Stock"}
              </span>
            )}
          </div>
          <h3 className="font-bold text-gray-900 line-clamp-1 mb-1 group-hover:text-emerald-600 transition-colors">
            {product.title}
          </h3>
          <div className="flex items-center text-gray-500 text-sm mb-3">
            <MapPin className="w-3.5 h-3.5 ml-1" />
            <span className="truncate">{product.location}</span>
          </div>
          <div className="flex items-center gap-2 mb-3">
            <div className="flex items-center gap-1">
              <Star className="w-3.5 h-3.5 text-amber-400 fill-current" />
              <span className="text-sm font-medium">{product.rating}</span>
            </div>
            <span className="text-xs text-gray-400">({product.reviews} {language === "ar" ? "تقييم" : "reviews"})</span>
          </div>
          <div className="flex justify-between items-center">
            <div>
              <span className="font-bold text-lg text-emerald-600">${product.price}</span>
              {product.originalPrice && (
                <span className="text-sm text-gray-400 line-through mr-2">${product.originalPrice}</span>
              )}
            </div>
            {product.features?.[0] && (
              <span className="text-xs bg-gray-100 text-gray-600 px-2 py-1 rounded-full">
                {product.features[0]}
              </span>
            )}
          </div>
        </div>
      </Link>
    </motion.div>
  );

  const ProductListItem = ({ product }: { product: Product }) => (
    <motion.div
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      className="group bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-md transition-all duration-300 border border-gray-100 flex"
    >
      <Link href={`/marketplace/${product.id}`} className="flex w-full">
        <div className="w-40 h-40 shrink-0 overflow-hidden relative">
          <img
            src={product.images[0]}
            alt={product.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          />
        </div>
        <div className="p-4 flex-1 flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="px-2 py-0.5 bg-emerald-50 text-emerald-700 text-[10px] font-bold rounded-md uppercase tracking-wider">
                {product.category}
              </span>
              {product.seller?.isVerified && (
                <span className="px-2 py-0.5 bg-emerald-50 text-emerald-600 text-[10px] font-bold rounded-md flex items-center gap-1">
                  <ShieldCheck className="w-3 h-3" />
                  {language === "ar" ? "موثق" : "Verified"}
                </span>
              )}
            </div>
            <h3 className="font-bold text-gray-900 mb-1 group-hover:text-emerald-600 transition-colors">
              {product.title}
            </h3>
            <p className="text-gray-500 text-sm line-clamp-2 mb-2">{product.description}</p>
            <div className="flex items-center text-gray-500 text-sm">
              <MapPin className="w-3.5 h-3.5 ml-1" />
              <span>{product.location}</span>
            </div>
          </div>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div>
                <span className="font-bold text-xl text-emerald-600">${product.price}</span>
                {product.originalPrice && (
                  <span className="text-sm text-gray-400 line-through mr-2">${product.originalPrice}</span>
                )}
              </div>
              <div className="flex items-center gap-1">
                <Star className="w-4 h-4 text-amber-400 fill-current" />
                <span className="text-sm font-medium">{product.rating}</span>
                <span className="text-xs text-gray-400">({product.reviews})</span>
              </div>
            </div>
            {product.seller && (
              <div className="flex items-center gap-2">
                <img src={product.seller.avatar} alt="" className="w-8 h-8 rounded-full" />
                <span className="text-sm text-gray-600">{product.seller.name}</span>
              </div>
            )}
          </div>
        </div>
      </Link>
    </motion.div>
  );

  return (
    <div className="min-h-screen bg-gray-50 pt-16">
      {/* Header */}
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-6">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <ShoppingBag className="w-6 h-6 text-emerald-600" />
                <span className="text-emerald-600 font-bold uppercase tracking-wider text-sm">
                  {language === "ar" ? "السوق" : "Marketplace"}
                </span>
              </div>
              <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-2">
                {language === "ar" ? "سوق ضيف" : "Dayf Marketplace"}
              </h1>
              <p className="text-gray-600 max-w-2xl">
                {language === "ar"
                  ? "اكتشف أفضل المنتجات المحلية السورية وأطلب توصيلها مباشرة"
                  : "Discover the best Syrian local products and get them delivered directly"}
              </p>
            </div>
            <div className="flex items-center gap-4">
              <div className="flex items-center bg-white border border-gray-200 rounded-xl p-1 shadow-sm">
                <button
                  onClick={() => setViewMode("grid")}
                  className={cn(
                    "flex items-center justify-center w-9 h-9 rounded-lg transition-colors",
                    viewMode === "grid" ? "bg-gray-100 text-gray-900" : "text-gray-500 hover:text-gray-700"
                  )}
                >
                  <Grid className="w-4 h-4" />
                </button>
                <button
                  onClick={() => setViewMode("list")}
                  className={cn(
                    "flex items-center justify-center w-9 h-9 rounded-lg transition-colors",
                    viewMode === "list" ? "bg-gray-100 text-gray-900" : "text-gray-500 hover:text-gray-700"
                  )}
                >
                  <List className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Filters Bar */}
      <div className="sticky top-16 z-40 bg-white border-b border-gray-200 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex flex-col md:flex-row md:items-center gap-4">
            {/* Search */}
            <div className="relative flex-1">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input
                type="text"
                placeholder={language === "ar" ? "ابحث عن منتج..." : "Search products..."}
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-4 pr-10 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>

            {/* Category Pills */}
            <div className="flex overflow-x-auto gap-2 pb-2 md:pb-0 hide-scrollbar">
              {categories.map(cat => (
                <button
                  key={cat.id}
                  onClick={() => setSelectedCategory(cat.id)}
                  className={cn(
                    "flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-colors shrink-0",
                    selectedCategory === cat.id
                      ? "bg-emerald-600 text-white"
                      : "bg-gray-100 text-gray-600 hover:bg-gray-200"
                  )}
                >
                  <span>{cat.icon}</span>
                  <span>{cat.name}</span>
                </button>
              ))}
            </div>

            {/* Sort */}
            <div className="relative">
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                className="appearance-none bg-white border border-gray-200 text-gray-700 py-2 pl-10 pr-4 rounded-xl text-sm font-medium focus:outline-none focus:ring-2 focus:ring-emerald-500 cursor-pointer"
              >
                <option value="popular">{language === "ar" ? "الأكثر شعبية" : "Most Popular"}</option>
                <option value="rating">{language === "ar" ? "الأعلى تقييماً" : "Highest Rated"}</option>
                <option value="price-asc">{language === "ar" ? "السعر: الأقل" : "Price: Low to High"}</option>
                <option value="price-desc">{language === "ar" ? "السعر: الأعلى" : "Price: High to Low"}</option>
              </select>
              <ChevronDown className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500 pointer-events-none" />
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Quick Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <div className="bg-white rounded-2xl p-4 border border-gray-200 flex items-center gap-3">
            <div className="w-12 h-12 bg-emerald-100 rounded-xl flex items-center justify-center">
              <Package className="w-6 h-6 text-emerald-600" />
            </div>
            <div>
              <p className="text-2xl font-bold text-gray-900">{INITIAL_PRODUCTS.length}</p>
              <p className="text-xs text-gray-500">{language === "ar" ? "منتج متوفر" : "Products"}</p>
            </div>
          </div>
          <div className="bg-white rounded-2xl p-4 border border-gray-200 flex items-center gap-3">
            <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
              <Truck className="w-6 h-6 text-blue-600" />
            </div>
            <div>
              <p className="text-2xl font-bold text-gray-900">{language === "ar" ? "توصيل" : "Delivery"}</p>
              <p className="text-xs text-gray-500">{language === "ar" ? "لجميع المناطق" : "All Areas"}</p>
            </div>
          </div>
          <div className="bg-white rounded-2xl p-4 border border-gray-200 flex items-center gap-3">
            <div className="w-12 h-12 bg-amber-100 rounded-xl flex items-center justify-center">
              <ShieldCheck className="w-6 h-6 text-amber-600" />
            </div>
            <div>
              <p className="text-2xl font-bold text-gray-900">100%</p>
              <p className="text-xs text-gray-500">{language === "ar" ? "منتجات أصلية" : "Authentic"}</p>
            </div>
          </div>
          <div className="bg-white rounded-2xl p-4 border border-gray-200 flex items-center gap-3">
            <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center">
              <Star className="w-6 h-6 text-purple-600" />
            </div>
            <div>
              <p className="text-2xl font-bold text-gray-900">4.8</p>
              <p className="text-xs text-gray-500">{language === "ar" ? "متوسط التقييم" : "Avg Rating"}</p>
            </div>
          </div>
        </div>

        {/* Products */}
        {filteredProducts.length > 0 ? (
          viewMode === "grid" ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {filteredProducts.map((product, index) => (
                <ProductCard key={product.id} product={product} index={index} />
              ))}
            </div>
          ) : (
            <div className="space-y-4">
              {filteredProducts.map((product, index) => (
                <ProductListItem key={product.id} product={product} />
              ))}
            </div>
          )
        ) : (
          <div className="text-center py-20 bg-white rounded-2xl border border-gray-200">
            <ShoppingBag className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <h3 className="text-xl font-bold text-gray-900 mb-2">
              {language === "ar" ? "لا توجد منتجات" : "No products found"}
            </h3>
            <p className="text-gray-500 max-w-md mx-auto mb-6">
              {language === "ar"
                ? "حاول تغيير خيارات البحث أو الفلترة"
                : "Try changing your search or filter options"}
            </p>
            <button
              onClick={() => {
                setSearchQuery("");
                setSelectedCategory("all");
                setPriceRange([0, 200]);
              }}
              className="bg-emerald-600 text-white px-6 py-2 rounded-xl font-medium"
            >
              {language === "ar" ? "مسح الفلاتر" : "Clear Filters"}
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
