import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// Generate booking number
const generateBookingNumber = () => {
  const timestamp = Date.now().toString(36).toUpperCase();
  const random = Math.random().toString(36).substring(2, 6).toUpperCase();
  return `DAYF-${timestamp}-${random}`;
};

// GET /api/bookings - Get bookings for a user
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const userId = searchParams.get('userId');
    const status = searchParams.get('status');
    const limit = parseInt(searchParams.get('limit') || '20');
    const offset = parseInt(searchParams.get('offset') || '0');

    if (!userId) {
      return NextResponse.json(
        { error: 'userId is required' },
        { status: 400 }
      );
    }

    const where: any = { userId };

    if (status) {
      where.status = status;
    }

    const [bookings, total] = await Promise.all([
      db.booking.findMany({
        where,
        include: {
          listing: {
            select: {
              id: true,
              title: true,
              city: true,
              images: true,
              basePrice: true,
            },
          },
          activity: {
            select: {
              id: true,
              title: true,
              images: true,
              basePrice: true,
            },
          },
          reviews: true,
        },
        orderBy: { createdAt: 'desc' },
        take: limit,
        skip: offset,
      }),
      db.booking.count({ where }),
    ]);

    // Parse JSON fields in listings
    const parsedBookings = bookings.map(booking => ({
      ...booking,
      listing: booking.listing
        ? {
            ...booking.listing,
            images: booking.listing.images ? JSON.parse(booking.listing.images) : [],
          }
        : null,
      activity: booking.activity
        ? {
            ...booking.activity,
            images: booking.activity.images ? JSON.parse(booking.activity.images) : [],
          }
        : null,
    }));

    return NextResponse.json({
      bookings: parsedBookings,
      total,
      hasMore: offset + limit < total,
    });
  } catch (error) {
    console.error('Error fetching bookings:', error);
    return NextResponse.json(
      { error: 'Failed to fetch bookings' },
      { status: 500 }
    );
  }
}

// POST /api/bookings - Create a new booking
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const {
      userId,
      listingId,
      activityId,
      checkIn,
      checkOut,
      guests,
      adults,
      children,
      infants,
      specialRequests,
      basePrice,
      cleaningFee,
      serviceFee,
      totalPrice,
    } = body;

    const booking = await db.booking.create({
      data: {
        bookingNumber: generateBookingNumber(),
        userId: userId || 'guest-user',
        listingId,
        activityId,
        checkIn: checkIn ? new Date(checkIn) : null,
        checkOut: checkOut ? new Date(checkOut) : null,
        guests: guests || 1,
        adults: adults || 1,
        children: children || 0,
        infants: infants || 0,
        specialRequests,
        basePrice: parseFloat(basePrice) || 0,
        cleaningFee: cleaningFee ? parseFloat(cleaningFee) : null,
        serviceFee: serviceFee ? parseFloat(serviceFee) : null,
        totalPrice: parseFloat(totalPrice) || 0,
        status: 'PENDING',
        paymentStatus: 'PENDING',
      },
      include: {
        listing: {
          select: {
            id: true,
            title: true,
            city: true,
          },
        },
      },
    });

    return NextResponse.json(booking, { status: 201 });
  } catch (error) {
    console.error('Error creating booking:', error);
    return NextResponse.json(
      { error: 'Failed to create booking' },
      { status: 500 }
    );
  }
}
