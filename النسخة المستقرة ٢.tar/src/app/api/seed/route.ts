import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET /api/seed - Seed the database with initial data
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const force = searchParams.get('force') === 'true';

    // Check if already seeded
    const existingCategories = await db.category.count();
    const existingListings = await db.listing.count();

    if (!force && (existingCategories > 0 || existingListings > 0)) {
      return NextResponse.json({
        message: 'Database already seeded',
        categories: existingCategories,
        listings: existingListings,
      });
    }

    // Create categories
    const categories = [
      {
        id: 'tourism',
        name: 'السياحة',
        nameEn: 'Tourism',
        slug: 'tourism',
        description: 'اكتشف جمال سوريا، تاريخها العريق، وطبيعتها الساحرة',
        descriptionEn: 'Discover the beauty of Syria, its rich history, and stunning nature',
        color: 'emerald',
        icon: 'Plane',
      },
      {
        id: 'medical',
        name: 'العلاج',
        nameEn: 'Medical',
        slug: 'medical',
        description: 'رعاية صحية متميزة، أطباء خبراء، ومراكز طبية متقدمة',
        descriptionEn: 'Exceptional healthcare, expert doctors, and advanced medical centers',
        color: 'blue',
        icon: 'HeartPulse',
      },
      {
        id: 'education',
        name: 'الدراسة',
        nameEn: 'Education',
        slug: 'education',
        description: 'جامعات عريقة، معاهد متخصصة، وبرامج تعليمية شاملة',
        descriptionEn: 'Prestigious universities, specialized institutes, and comprehensive educational programs',
        color: 'amber',
        icon: 'GraduationCap',
      },
      {
        id: 'business',
        name: 'الأعمال',
        nameEn: 'Business',
        slug: 'business',
        description: 'فرص استثمارية، شراكات استراتيجية، وخدمات أعمال متكاملة',
        descriptionEn: 'Investment opportunities, strategic partnerships, and comprehensive business services',
        color: 'purple',
        icon: 'Briefcase',
      },
    ];

    for (const cat of categories) {
      await db.category.upsert({
        where: { id: cat.id },
        update: cat,
        create: cat,
      });
    }

    // Create a guest user for listings
    const guestUser = await db.user.upsert({
      where: { id: 'dayf-host' },
      update: {},
      create: {
        id: 'dayf-host',
        email: 'host@dayf.sy',
        displayName: 'مضيف ضيف',
        status: 'ACTIVE',
        role: 'HOST',
      },
    });

    // Create sample listings
    const listings = [
      {
        id: 't1',
        title: 'منتجع الرمال الذهبية الفاخر',
        slug: 'golden-sands-resort',
        description: 'منتجع فاخر على شاطئ طرطوس مع إطلالة بحرية خلابة وخدمات متميزة',
        type: 'HOTEL',
        city: 'طرطوس',
        address: 'الشاطئ الأزرق، طرطوس',
        basePrice: 150,
        maxGuests: 4,
        bedrooms: 2,
        bathrooms: 2,
        amenities: JSON.stringify(['مسبح خاص', 'واي فاي سريع', 'إطلالة بحرية', 'سبا ومساج', 'موقف سيارات مجاني', 'مطعم فاخر']),
        images: JSON.stringify(['https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80']),
        categoryId: 'tourism',
        avgRating: 4.9,
        totalReviews: 320,
        status: 'PUBLISHED',
        verified: true,
        isPopular: true,
      },
      {
        id: 't2',
        title: 'جولة القوارب في جزيرة أرواد',
        slug: 'arwad-island-boat-tour',
        description: 'جولة بحرية ممتعة حول جزيرة أرواد التاريخية مع مرشد سياحي',
        type: 'OTHER',
        city: 'طرطوس',
        address: 'جزيرة أرواد',
        basePrice: 25,
        maxGuests: 8,
        bedrooms: 0,
        bathrooms: 0,
        amenities: JSON.stringify(['مرشد سياحي', 'سترات نجاة', 'وجبة خفيفة']),
        images: JSON.stringify(['https://images.unsplash.com/photo-1544551763-46a013bb70d5?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80']),
        categoryId: 'tourism',
        avgRating: 4.7,
        totalReviews: 85,
        status: 'PUBLISHED',
        verified: true,
      },
      {
        id: 'm1',
        title: 'مركز ابتسامة الشام لطب وتجميل الأسنان',
        slug: 'damascus-smile-dental',
        description: 'مركز متخصص في طب وتجميل الأسنان بأحدث التقنيات',
        type: 'OTHER',
        city: 'دمشق',
        address: 'المزة، دمشق',
        basePrice: 1200,
        maxGuests: 1,
        bedrooms: 0,
        bathrooms: 0,
        amenities: JSON.stringify(['أشعة بانورامية', 'تخدير بدون ألم', 'تعقيم دولي']),
        images: JSON.stringify(['https://images.unsplash.com/photo-1629909613654-28e377c37b09?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80']),
        categoryId: 'medical',
        avgRating: 4.9,
        totalReviews: 412,
        status: 'PUBLISHED',
        verified: true,
        isPopular: true,
      },
      {
        id: 'e1',
        title: 'معهد الضاد لتعليم العربية للأجانب',
        slug: 'dad-arabic-institute',
        description: 'معهد متخصص في تعليم اللغة العربية للناطقين بغيرها',
        type: 'OTHER',
        city: 'دمشق',
        address: 'الميدان، دمشق',
        basePrice: 450,
        maxGuests: 20,
        bedrooms: 0,
        bathrooms: 0,
        amenities: JSON.stringify(['كتب مجانية', 'جولات ثقافية', 'سكن طلابي']),
        images: JSON.stringify(['https://images.unsplash.com/photo-1546410531-bb4caa6b424d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80']),
        categoryId: 'education',
        avgRating: 4.9,
        totalReviews: 320,
        status: 'PUBLISHED',
        verified: true,
        isPopular: true,
      },
      {
        id: 'b1',
        title: 'فرص استثمار عقاري في ماروتا سيتي',
        slug: 'marota-city-investment',
        description: 'فرص استثمارية عقارية في مشروع ماروتا سيتي',
        type: 'OTHER',
        city: 'دمشق',
        address: 'ماروتا سيتي، دمشق',
        basePrice: 50000,
        maxGuests: 1,
        bedrooms: 0,
        bathrooms: 0,
        amenities: JSON.stringify(['دراسة جدوى', 'استشارات قانونية']),
        images: JSON.stringify(['https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80']),
        categoryId: 'business',
        avgRating: 4.7,
        totalReviews: 34,
        status: 'PUBLISHED',
        verified: true,
        isPopular: true,
      },
    ];

    for (const listing of listings) {
      await db.listing.upsert({
        where: { id: listing.id },
        update: {
          ...listing,
          userId: guestUser.id,
        },
        create: {
          ...listing,
          userId: guestUser.id,
        },
      });
    }

    // Create community posts
    const poster = await db.user.upsert({
      where: { id: 'community-user' },
      update: {},
      create: {
        id: 'community-user',
        email: 'community@dayf.sy',
        displayName: 'أحمد الشامي',
        status: 'ACTIVE',
        role: 'USER',
      },
    });

    const posts = [
      {
        id: 'p1',
        title: 'تجربتي في منتجع الرمال الذهبية',
        content: 'قضيت عطلة رائعة في هذا المنتجع الفاخر. الخدمة ممتازة والمسبح خاص وإطلالة بحرية خلابة. أنصح الجميع بزيارته!',
        category: 'سياحة',
        tags: JSON.stringify(['سياحة', 'طرطوس', 'منتجعات']),
        likesCount: 45,
        commentsCount: 12,
        status: 'PUBLISHED',
      },
      {
        id: 'p2',
        title: 'نصائح لتعلم اللغة العربية في دمشق',
        content: 'وصلت إلى دمشق قبل شهرين لتعلم العربية، ووجدت تجربة رائعة. المعهد يوفر برامج ممتازة والناس ودودون جداً.',
        category: 'تعليم',
        tags: JSON.stringify(['تعليم', 'لغة عربية', 'دمشق']),
        likesCount: 78,
        commentsCount: 23,
        status: 'PUBLISHED',
      },
      {
        id: 'p3',
        title: 'تجربتي مع عملية الليزك',
        content: 'أجريت عملية ليزك في المركز الدولي للعيون. الطاقم الطبي محترف جداً والنتائج ممتازة.',
        category: 'علاج',
        tags: JSON.stringify(['صحة', 'ليزك', 'دمشق']),
        likesCount: 92,
        commentsCount: 31,
        status: 'PUBLISHED',
      },
    ];

    for (const post of posts) {
      await db.post.upsert({
        where: { id: post.id },
        update: {
          ...post,
          userId: poster.id,
        },
        create: {
          ...post,
          userId: poster.id,
        },
      });
    }

    return NextResponse.json({
      success: true,
      message: 'Database seeded successfully',
      data: {
        categories: categories.length,
        listings: listings.length,
        posts: posts.length,
      },
    });
  } catch (error) {
    console.error('Error seeding database:', error);
    return NextResponse.json(
      { error: 'Failed to seed database', details: String(error) },
      { status: 500 }
    );
  }
}
