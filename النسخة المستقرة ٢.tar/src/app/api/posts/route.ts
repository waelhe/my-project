import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET /api/posts - Get community posts
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const category = searchParams.get('category');
    const userId = searchParams.get('userId');
    const sortBy = searchParams.get('sortBy') || 'latest';
    const limit = parseInt(searchParams.get('limit') || '20');
    const offset = parseInt(searchParams.get('offset') || '0');

    const where: any = { status: 'PUBLISHED' };

    if (category) where.category = category;
    if (userId) where.userId = userId;

    const orderBy: any = sortBy === 'popular'
      ? { likesCount: 'desc' }
      : { createdAt: 'desc' };

    const [posts, total] = await Promise.all([
      db.post.findMany({
        where,
        include: {
          user: {
            select: {
              id: true,
              displayName: true,
              avatar: true,
            },
          },
          _count: {
            select: {
              comments: true,
            },
          },
        },
        orderBy,
        take: limit,
        skip: offset,
      }),
      db.post.count({ where }),
    ]);

    // Parse JSON fields
    const parsedPosts = posts.map(post => ({
      ...post,
      images: post.images ? JSON.parse(post.images) : [],
      tags: post.tags ? JSON.parse(post.tags) : [],
    }));

    return NextResponse.json({
      posts: parsedPosts,
      total,
      hasMore: offset + limit < total,
    });
  } catch (error) {
    console.error('Error fetching posts:', error);
    return NextResponse.json(
      { error: 'Failed to fetch posts' },
      { status: 500 }
    );
  }
}

// POST /api/posts - Create a new post
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const {
      userId,
      title,
      content,
      images,
      category,
      tags,
      location,
    } = body;

    if (!content) {
      return NextResponse.json(
        { error: 'Content is required' },
        { status: 400 }
      );
    }

    const post = await db.post.create({
      data: {
        userId: userId || 'guest-user',
        title,
        content,
        images: images ? JSON.stringify(images) : null,
        category,
        tags: tags ? JSON.stringify(tags) : null,
        location,
        status: 'PUBLISHED',
      },
      include: {
        user: {
          select: {
            id: true,
            displayName: true,
            avatar: true,
          },
        },
      },
    });

    return NextResponse.json(post, { status: 201 });
  } catch (error) {
    console.error('Error creating post:', error);
    return NextResponse.json(
      { error: 'Failed to create post' },
      { status: 500 }
    );
  }
}
