import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET /api/listings/[id] - Get a single listing
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;

    const listing = await db.listing.findUnique({
      where: { id },
      include: {
        user: {
          select: {
            id: true,
            displayName: true,
            avatar: true,
            bio: true,
          },
        },
        category: {
          select: {
            id: true,
            name: true,
            slug: true,
          },
        },
        destination: {
          select: {
            id: true,
            name: true,
            slug: true,
          },
        },
        reviews: {
          take: 10,
          orderBy: { createdAt: 'desc' },
          include: {
            user: {
              select: {
                id: true,
                displayName: true,
                avatar: true,
              },
            },
          },
        },
        _count: {
          select: {
            reviews: true,
            bookings: true,
          },
        },
      },
    });

    if (!listing) {
      return NextResponse.json(
        { error: 'Listing not found' },
        { status: 404 }
      );
    }

    // Increment view count
    await db.listing.update({
      where: { id },
      data: { viewCount: { increment: 1 } },
    });

    // Parse JSON fields
    const parsedListing = {
      ...listing,
      amenities: listing.amenities ? JSON.parse(listing.amenities) : [],
      images: listing.images ? JSON.parse(listing.images) : [],
      tags: listing.tags ? JSON.parse(listing.tags) : [],
    };

    return NextResponse.json(parsedListing);
  } catch (error) {
    console.error('Error fetching listing:', error);
    return NextResponse.json(
      { error: 'Failed to fetch listing' },
      { status: 500 }
    );
  }
}

// PUT /api/listings/[id] - Update a listing
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await request.json();

    const updateData: any = {};

    if (body.title) updateData.title = body.title;
    if (body.description) updateData.description = body.description;
    if (body.basePrice !== undefined) updateData.basePrice = parseFloat(body.basePrice);
    if (body.maxGuests) updateData.maxGuests = body.maxGuests;
    if (body.bedrooms) updateData.bedrooms = body.bedrooms;
    if (body.bathrooms) updateData.bathrooms = body.bathrooms;
    if (body.amenities) updateData.amenities = JSON.stringify(body.amenities);
    if (body.images) updateData.images = JSON.stringify(body.images);
    if (body.status) updateData.status = body.status;

    const listing = await db.listing.update({
      where: { id },
      data: updateData,
    });

    return NextResponse.json(listing);
  } catch (error) {
    console.error('Error updating listing:', error);
    return NextResponse.json(
      { error: 'Failed to update listing' },
      { status: 500 }
    );
  }
}

// DELETE /api/listings/[id] - Delete a listing
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;

    await db.listing.delete({
      where: { id },
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error deleting listing:', error);
    return NextResponse.json(
      { error: 'Failed to delete listing' },
      { status: 500 }
    );
  }
}
