import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET /api/listings - Get all listings with filters
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const category = searchParams.get('category');
    const city = searchParams.get('city');
    const minPrice = searchParams.get('minPrice');
    const maxPrice = searchParams.get('maxPrice');
    const minRating = searchParams.get('minRating');
    const search = searchParams.get('search');
    const limit = parseInt(searchParams.get('limit') || '20');
    const offset = parseInt(searchParams.get('offset') || '0');

    const where: any = {
      status: 'PUBLISHED',
    };

    if (category) {
      where.category = {
        slug: category,
      };
    }

    if (city) {
      where.city = {
        contains: city,
      };
    }

    if (minPrice || maxPrice) {
      where.basePrice = {};
      if (minPrice) where.basePrice.gte = parseFloat(minPrice);
      if (maxPrice) where.basePrice.lte = parseFloat(maxPrice);
    }

    if (minRating) {
      where.avgRating = {
        gte: parseFloat(minRating),
      };
    }

    if (search) {
      where.OR = [
        { title: { contains: search } },
        { description: { contains: search } },
        { city: { contains: search } },
      ];
    }

    const [listings, total] = await Promise.all([
      db.listing.findMany({
        where,
        include: {
          user: {
            select: {
              id: true,
              displayName: true,
              avatar: true,
            },
          },
          category: {
            select: {
              id: true,
              name: true,
              slug: true,
            },
          },
          _count: {
            select: {
              reviews: true,
              bookings: true,
            },
          },
        },
        orderBy: [
          { isPopular: 'desc' },
          { avgRating: 'desc' },
        ],
        take: limit,
        skip: offset,
      }),
      db.listing.count({ where }),
    ]);

    return NextResponse.json({
      listings,
      total,
      hasMore: offset + limit < total,
    });
  } catch (error) {
    console.error('Error fetching listings:', error);
    return NextResponse.json(
      { error: 'Failed to fetch listings' },
      { status: 500 }
    );
  }
}

// POST /api/listings - Create a new listing
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const {
      userId,
      title,
      description,
      type,
      city,
      address,
      basePrice,
      maxGuests,
      bedrooms,
      bathrooms,
      amenities,
      images,
      categoryId,
    } = body;

    // Generate slug from title
    const slug = title
      .toLowerCase()
      .replace(/[^a-z0-9\u0600-\u06FF]+/g, '-')
      .replace(/^-+|-+$/g, '');

    const listing = await db.listing.create({
      data: {
        userId: userId || 'guest-user',
        title,
        slug: `${slug}-${Date.now()}`,
        description: description || '',
        type: type || 'APARTMENT',
        city: city || 'Damascus',
        address,
        basePrice: parseFloat(basePrice) || 0,
        maxGuests: maxGuests || 2,
        bedrooms: bedrooms || 1,
        bathrooms: bathrooms || 1,
        amenities: amenities ? JSON.stringify(amenities) : null,
        images: images ? JSON.stringify(images) : null,
        categoryId,
        status: 'DRAFT',
      },
      include: {
        user: {
          select: {
            id: true,
            displayName: true,
            avatar: true,
          },
        },
      },
    });

    return NextResponse.json(listing, { status: 201 });
  } catch (error) {
    console.error('Error creating listing:', error);
    return NextResponse.json(
      { error: 'Failed to create listing' },
      { status: 500 }
    );
  }
}
