import { NextRequest, NextResponse } from "next/server";
import { LLM } from "z-ai-web-dev-sdk";

export async function POST(request: NextRequest) {
  try {
    const { message, language = "ar" } = await request.json();

    if (!message) {
      return NextResponse.json(
        { error: "Message is required" },
        { status: 400 }
      );
    }

    // Initialize LLM
    const llm = new LLM();

    // System prompt based on language
    const systemPrompt = language === "ar"
      ? `أنت مساعد ذكي لمنصة "ضيف" (Dayf)، وهي منصة سورية شاملة للسياحة، العلاج، الدراسة، والأعمال.
مهمتك هي مساعدة المستخدمين في:
- التخطيط لرحلاتهم إلى سوريا
- العثور على أفضل الإقامات والفنادق
- التعرف على المعالم السياحية والأماكن التاريخية
- معلومات عن العلاج والدراسة وفرص الأعمال في سوريا

كن مختصراً ومفيداً وودوداً. أجب باللغة العربية دائماً.`
      : `You are an AI assistant for "Dayf" platform, a comprehensive Syrian platform for tourism, medical, education, and business services.
Your task is to help users:
- Plan their trips to Syria
- Find the best accommodations and hotels
- Learn about tourist attractions and historical places
- Information about medical treatment, education, and business opportunities in Syria

Be concise, helpful, and friendly. Always respond in English.`;

    // Generate response
    const response = await llm.chat({
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: message },
      ],
      maxTokens: 500,
      temperature: 0.7,
    });

    return NextResponse.json({
      response: response.choices[0]?.message?.content || 
        (language === "ar" 
          ? "عذراً، لم أتمكن من معالجة طلبك. يرجى المحاولة مرة أخرى."
          : "Sorry, I couldn't process your request. Please try again."),
    });
  } catch (error) {
    console.error("Error in AI chat:", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}
