import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET /api/reviews - Get reviews for a listing
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const listingId = searchParams.get('listingId');
    const userId = searchParams.get('userId');
    const limit = parseInt(searchParams.get('limit') || '10');
    const offset = parseInt(searchParams.get('offset') || '0');

    const where: any = {};

    if (listingId) where.listingId = listingId;
    if (userId) where.userId = userId;

    const [reviews, total] = await Promise.all([
      db.review.findMany({
        where,
        include: {
          user: {
            select: {
              id: true,
              displayName: true,
              avatar: true,
            },
          },
        },
        orderBy: { createdAt: 'desc' },
        take: limit,
        skip: offset,
      }),
      db.review.count({ where }),
    ]);

    return NextResponse.json({
      reviews,
      total,
      hasMore: offset + limit < total,
    });
  } catch (error) {
    console.error('Error fetching reviews:', error);
    return NextResponse.json(
      { error: 'Failed to fetch reviews' },
      { status: 500 }
    );
  }
}

// POST /api/reviews - Create a new review
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const {
      userId,
      listingId,
      bookingId,
      rating,
      ratingCleanliness,
      ratingLocation,
      ratingValue,
      ratingCommunication,
      ratingAccuracy,
      title,
      content,
      images,
    } = body;

    // Check if user already reviewed this listing
    if (listingId && userId) {
      const existingReview = await db.review.findFirst({
        where: {
          userId,
          listingId,
        },
      });

      if (existingReview) {
        return NextResponse.json(
          { error: 'You have already reviewed this listing' },
          { status: 400 }
        );
      }
    }

    const review = await db.review.create({
      data: {
        userId: userId || 'guest-user',
        listingId,
        bookingId,
        rating: parseFloat(rating) || 0,
        ratingCleanliness: ratingCleanliness ? parseFloat(ratingCleanliness) : null,
        ratingLocation: ratingLocation ? parseFloat(ratingLocation) : null,
        ratingValue: ratingValue ? parseFloat(ratingValue) : null,
        ratingCommunication: ratingCommunication ? parseFloat(ratingCommunication) : null,
        ratingAccuracy: ratingAccuracy ? parseFloat(ratingAccuracy) : null,
        title,
        content,
        images: images ? JSON.stringify(images) : null,
        status: 'PUBLISHED',
      },
      include: {
        user: {
          select: {
            id: true,
            displayName: true,
            avatar: true,
          },
        },
      },
    });

    // Update listing average rating
    if (listingId) {
      const avgRating = await db.review.aggregate({
        where: { listingId },
        _avg: { rating: true },
      });

      const reviewCount = await db.review.count({
        where: { listingId },
      });

      await db.listing.update({
        where: { id: listingId },
        data: {
          avgRating: avgRating._avg.rating || 0,
          totalReviews: reviewCount,
        },
      });
    }

    return NextResponse.json(review, { status: 201 });
  } catch (error) {
    console.error('Error creating review:', error);
    return NextResponse.json(
      { error: 'Failed to create review' },
      { status: 500 }
    );
  }
}
