import { NextResponse } from "next/server";
import { MAIN_CATEGORIES } from "@/data/categories";

export async function GET() {
  try {
    return NextResponse.json({
      categories: MAIN_CATEGORIES,
      total: MAIN_CATEGORIES.length,
    });
  } catch (error) {
    console.error("Error fetching categories:", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}
