import type { Metadata } from "next";
import "./globals.css";
import { Toaster } from "@/components/ui/sonner";
import { Providers } from "@/components/providers";

export const metadata: Metadata = {
  title: "ضيف | منصة السياحة السورية الشاملة",
  description: "منصة متكاملة للسياحة، العلاج، الدراسة، وفرص الأعمال في سوريا. اكتشف أفضل الإقامات، الرحلات، والخدمات.",
  keywords: ["ضيف", "Dayf", "سياحة سوريا", "علاج في سوريا", "دراسة في سوريا", "استثمار في سوريا", "حجز فنادق", "سياحة علاجية"],
  authors: [{ name: "فريق ضيف" }],
  icons: {
    icon: "/logo.svg",
  },
  openGraph: {
    title: "ضيف | منصة السياحة السورية الشاملة",
    description: "اكتشف سحر سوريا مع ضيف - منصة متكاملة للسياحة، العلاج، الدراسة، وفرص الأعمال",
    type: "website",
    locale: "ar_SY",
  },
  twitter: {
    card: "summary_large_image",
    title: "ضيف | منصة السياحة السورية الشاملة",
    description: "اكتشف سحر سوريا مع ضيف",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ar" dir="rtl" suppressHydrationWarning>
      <body className="antialiased bg-background text-foreground font-sans">
        <Providers>
          {children}
          <Toaster position="top-center" />
        </Providers>
      </body>
    </html>
  );
}
