"use client";

import { useState } from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import {
  MessageSquare, Heart, User, Bookmark, Share2, Plus,
  Search, TrendingUp, Clock, Filter
} from "lucide-react";
import { INITIAL_POSTS, CommunityPost } from "@/data/initialServices";
import { useLanguage } from "@/contexts/LanguageContext";
import { cn } from "@/lib/utils";

export default function CommunityPage() {
  const { language } = useLanguage();
  const [posts, setPosts] = useState<CommunityPost[]>(INITIAL_POSTS);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [sortBy, setSortBy] = useState<"latest" | "popular">("latest");

  // Categories
  const categories = [
    { id: "all", name: language === "ar" ? "الكل" : "All", icon: "📋" },
    { id: "سياحة", name: language === "ar" ? "سياحة" : "Tourism", icon: "🏖️" },
    { id: "تعليم", name: language === "ar" ? "تعليم" : "Education", icon: "🎓" },
    { id: "علاج", name: language === "ar" ? "علاج" : "Medical", icon: "💚" },
    { id: "أعمال", name: language === "ar" ? "أعمال" : "Business", icon: "💼" },
    { id: "ثقافة", name: language === "ar" ? "ثقافة" : "Culture", icon: "🏛️" },
  ];

  // Filter and sort posts
  const filteredPosts = posts
    .filter(post => {
      const matchesSearch = post.title?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        post.content.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesCategory = selectedCategory === "all" || post.category === selectedCategory;
      return matchesSearch && matchesCategory;
    })
    .sort((a, b) => {
      if (sortBy === "popular") {
        return b.likesCount - a.likesCount;
      }
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    });

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));

    if (days === 0) {
      return language === "ar" ? "اليوم" : "Today";
    } else if (days === 1) {
      return language === "ar" ? "أمس" : "Yesterday";
    } else if (days < 7) {
      return language === "ar" ? `منذ ${days} أيام` : `${days} days ago`;
    } else {
      return date.toLocaleDateString(language === "ar" ? "ar-SY" : "en-US");
    }
  };

  const handleLike = (postId: string) => {
    setPosts(prev => prev.map(post =>
      post.id === postId
        ? { ...post, likesCount: post.likesCount + 1 }
        : post
    ));
  };

  const PostCard = ({ post, index }: { post: CommunityPost; index: number }) => (
    <motion.article
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.05 }}
      className="group bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-md transition-all duration-300 border border-gray-100 flex flex-col"
    >
      {/* Post Image */}
      {post.images && post.images[0] && (
        <Link href={`/community/${post.id}`} className="block shrink-0">
          <div className="aspect-video overflow-hidden">
            <img
              src={post.images[0]}
              alt={post.title || ""}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
            />
          </div>
        </Link>
      )}

      <div className="p-5 flex-1 flex flex-col min-w-0">
        {/* Author Info */}
        <div className="flex items-center gap-3 mb-3">
          {post.authorAvatar ? (
            <img
              src={post.authorAvatar}
              alt={post.authorName}
              className="w-10 h-10 rounded-full object-cover"
            />
          ) : (
            <div className="w-10 h-10 rounded-full bg-emerald-100 flex items-center justify-center text-emerald-600">
              <User className="w-5 h-5" />
            </div>
          )}
          <div className="flex-1 min-w-0">
            <h4 className="font-bold text-gray-900 truncate">{post.authorName}</h4>
            <span className="text-xs text-gray-500">{formatDate(post.createdAt)}</span>
          </div>
          {post.isPinned && (
            <span className="text-xs bg-amber-100 text-amber-700 px-2 py-1 rounded-full font-medium">
              📌 {language === "ar" ? "مثبت" : "Pinned"}
            </span>
          )}
        </div>

        {/* Category Badge */}
        {post.category && (
          <div className="mb-3">
            <span className="text-[10px] px-2 py-1 bg-emerald-50 text-emerald-700 rounded-md font-bold uppercase tracking-wider">
              {post.category}
            </span>
          </div>
        )}

        {/* Title */}
        {post.title && (
          <Link href={`/community/${post.id}`}>
            <h3 className="font-bold text-gray-900 mb-2 line-clamp-2 group-hover:text-emerald-600 transition-colors">
              {post.title}
            </h3>
          </Link>
        )}

        {/* Content Preview */}
        <p className="text-gray-600 text-sm line-clamp-3 mb-4 flex-1">{post.content}</p>

        {/* Tags */}
        {post.tags && post.tags.length > 0 && (
          <div className="flex flex-wrap gap-2 mb-4">
            {post.tags.slice(0, 3).map((tag, idx) => (
              <span key={idx} className="text-xs bg-gray-100 text-gray-600 px-2 py-1 rounded-full">
                #{tag}
              </span>
            ))}
          </div>
        )}

        {/* Engagement Stats */}
        <div className="flex items-center justify-between pt-3 border-t border-gray-100">
          <div className="flex items-center gap-4">
            <button
              onClick={() => handleLike(post.id)}
              className="flex items-center gap-1.5 text-gray-500 hover:text-red-500 transition-colors"
            >
              <Heart className="w-4 h-4" />
              <span className="text-sm font-medium">{post.likesCount}</span>
            </button>
            <button className="flex items-center gap-1.5 text-gray-500 hover:text-emerald-600 transition-colors">
              <MessageSquare className="w-4 h-4" />
              <span className="text-sm font-medium">{post.commentsCount}</span>
            </button>
          </div>
          <div className="flex items-center gap-2">
            <button className="p-2 text-gray-400 hover:text-emerald-600 transition-colors">
              <Bookmark className="w-4 h-4" />
            </button>
            <button className="p-2 text-gray-400 hover:text-emerald-600 transition-colors">
              <Share2 className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </motion.article>
  );

  return (
    <div className="min-h-screen bg-gray-50 pt-16">
      {/* Header */}
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-6">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <MessageSquare className="w-6 h-6 text-emerald-600" />
                <span className="text-emerald-600 font-bold uppercase tracking-wider text-sm">
                  {language === "ar" ? "المجتمع" : "Community"}
                </span>
              </div>
              <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-2">
                {language === "ar" ? "مجتمع ضيف" : "Dayf Community"}
              </h1>
              <p className="text-gray-600 max-w-2xl">
                {language === "ar"
                  ? "شارك تجاربك، اطرح أسئلتك، وتواصل مع المسافرين والخبراء المحليين"
                  : "Share your experiences, ask questions, and connect with travelers and local experts"}
              </p>
            </div>
            <button className="shrink-0 bg-emerald-600 text-white px-6 py-3 rounded-xl font-bold hover:bg-emerald-700 transition-colors shadow-lg shadow-emerald-200 flex items-center gap-2">
              <Plus className="w-5 h-5" />
              {language === "ar" ? "مشاركة جديدة" : "New Post"}
            </button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Sidebar */}
          <aside className="lg:w-64 shrink-0">
            <div className="sticky top-28 space-y-6">
              {/* Search */}
              <div className="relative">
                <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <input
                  type="text"
                  placeholder={language === "ar" ? "ابحث في المجتمع..." : "Search community..."}
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-4 pr-10 py-2.5 bg-white border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              {/* Categories */}
              <div className="bg-white rounded-2xl border border-gray-200 p-4">
                <h3 className="font-bold text-gray-900 mb-4 flex items-center gap-2">
                  <Filter className="w-4 h-4" />
                  {language === "ar" ? "التصنيفات" : "Categories"}
                </h3>
                <div className="space-y-2">
                  {categories.map(cat => (
                    <button
                      key={cat.id}
                      onClick={() => setSelectedCategory(cat.id)}
                      className={cn(
                        "w-full flex items-center gap-3 px-3 py-2 rounded-xl text-sm font-medium transition-colors",
                        selectedCategory === cat.id
                          ? "bg-emerald-50 text-emerald-700"
                          : "text-gray-600 hover:bg-gray-50"
                      )}
                    >
                      <span>{cat.icon}</span>
                      <span>{cat.name}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Sort */}
              <div className="bg-white rounded-2xl border border-gray-200 p-4">
                <h3 className="font-bold text-gray-900 mb-4">
                  {language === "ar" ? "ترتيب حسب" : "Sort by"}
                </h3>
                <div className="space-y-2">
                  <button
                    onClick={() => setSortBy("latest")}
                    className={cn(
                      "w-full flex items-center gap-3 px-3 py-2 rounded-xl text-sm font-medium transition-colors",
                      sortBy === "latest"
                        ? "bg-emerald-50 text-emerald-700"
                        : "text-gray-600 hover:bg-gray-50"
                    )}
                  >
                    <Clock className="w-4 h-4" />
                    {language === "ar" ? "الأحدث" : "Latest"}
                  </button>
                  <button
                    onClick={() => setSortBy("popular")}
                    className={cn(
                      "w-full flex items-center gap-3 px-3 py-2 rounded-xl text-sm font-medium transition-colors",
                      sortBy === "popular"
                        ? "bg-emerald-50 text-emerald-700"
                        : "text-gray-600 hover:bg-gray-50"
                    )}
                  >
                    <TrendingUp className="w-4 h-4" />
                    {language === "ar" ? "الأكثر شعبية" : "Most Popular"}
                  </button>
                </div>
              </div>

              {/* Stats */}
              <div className="bg-gradient-to-br from-emerald-50 to-teal-50 rounded-2xl p-4 border border-emerald-100">
                <h3 className="font-bold text-gray-900 mb-3">
                  {language === "ar" ? "إحصائيات المجتمع" : "Community Stats"}
                </h3>
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center">
                    <p className="text-2xl font-bold text-emerald-600">{INITIAL_POSTS.length}</p>
                    <p className="text-xs text-gray-600">{language === "ar" ? "منشور" : "Posts"}</p>
                  </div>
                  <div className="text-center">
                    <p className="text-2xl font-bold text-emerald-600">
                      {INITIAL_POSTS.reduce((acc, p) => acc + p.likesCount, 0)}
                    </p>
                    <p className="text-xs text-gray-600">{language === "ar" ? "إعجاب" : "Likes"}</p>
                  </div>
                </div>
              </div>
            </div>
          </aside>

          {/* Posts Grid */}
          <main className="flex-1">
            {filteredPosts.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {filteredPosts.map((post, index) => (
                  <PostCard key={post.id} post={post} index={index} />
                ))}
              </div>
            ) : (
              <div className="text-center py-20 bg-white rounded-2xl border border-gray-200">
                <MessageSquare className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-xl font-bold text-gray-900 mb-2">
                  {language === "ar" ? "لا توجد منشورات" : "No posts found"}
                </h3>
                <p className="text-gray-500 max-w-md mx-auto mb-6">
                  {language === "ar"
                    ? "حاول تغيير خيارات البحث أو الفلترة"
                    : "Try changing your search or filter options"}
                </p>
                <button
                  onClick={() => {
                    setSearchQuery("");
                    setSelectedCategory("all");
                  }}
                  className="bg-emerald-600 text-white px-6 py-2 rounded-xl font-medium"
                >
                  {language === "ar" ? "مسح الفلاتر" : "Clear Filters"}
                </button>
              </div>
            )}
          </main>
        </div>
      </div>
    </div>
  );
}
