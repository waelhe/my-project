"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import Link from "next/link";
import {
  Calendar, MapPin, Users, Clock, ChevronRight, Star,
  AlertCircle, CheckCircle2, XCircle, Loader2, Filter
} from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { useLanguage } from "@/contexts/LanguageContext";
import { cn } from "@/lib/utils";
import { INITIAL_SERVICES } from "@/data/initialServices";

type BookingStatus = "all" | "pending" | "confirmed" | "completed" | "cancelled";

export default function MyBookingsPage() {
  const { user, loading } = useAuth();
  const { language } = useLanguage();
  const [statusFilter, setStatusFilter] = useState<BookingStatus>("all");

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center pt-16">
        <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-emerald-600" />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center pt-16">
        <div className="text-center p-8 bg-white rounded-2xl shadow-sm max-w-md">
          <Calendar className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <h1 className="text-2xl font-bold text-gray-900 mb-2">
            {language === "ar" ? "يرجى تسجيل الدخول" : "Please Sign In"}
          </h1>
          <p className="text-gray-500 mb-6">
            {language === "ar"
              ? "تحتاج إلى تسجيل الدخول لعرض حجوزاتك"
              : "You need to sign in to view your bookings"}
          </p>
          <Link
            href="/"
            className="inline-flex items-center bg-emerald-600 text-white px-6 py-3 rounded-xl font-bold hover:bg-emerald-700 transition-colors"
          >
            {language === "ar" ? "العودة للرئيسية" : "Go to Home"}
          </Link>
        </div>
      </div>
    );
  }

  // Mock bookings data
  const mockBookings = [
    {
      id: "b1",
      serviceId: "t1",
      status: "confirmed",
      checkIn: "2024-02-15",
      checkOut: "2024-02-18",
      guests: 2,
      totalPrice: 495,
      createdAt: "2024-01-20",
    },
    {
      id: "b2",
      serviceId: "m1",
      status: "pending",
      checkIn: "2024-03-01",
      checkOut: null,
      guests: 1,
      totalPrice: 1200,
      createdAt: "2024-01-25",
    },
    {
      id: "b3",
      serviceId: "e1",
      status: "completed",
      checkIn: "2024-01-10",
      checkOut: "2024-02-10",
      guests: 1,
      totalPrice: 450,
      createdAt: "2024-01-05",
    },
    {
      id: "b4",
      serviceId: "t2",
      status: "cancelled",
      checkIn: "2024-01-15",
      checkOut: null,
      guests: 4,
      totalPrice: 100,
      createdAt: "2024-01-10",
    },
  ];

  // Filter bookings
  const filteredBookings = mockBookings.filter((booking) => {
    if (statusFilter === "all") return true;
    return booking.status === statusFilter;
  });

  // Get service details
  const getService = (serviceId: string) => {
    return INITIAL_SERVICES.find((s) => s.id === serviceId);
  };

  const statusConfig: Record<string, { color: string; bg: string; icon: typeof CheckCircle2; label: string; labelEn: string }> = {
    pending: {
      color: "text-amber-700",
      bg: "bg-amber-50",
      icon: Clock,
      label: "قيد الانتظار",
      labelEn: "Pending",
    },
    confirmed: {
      color: "text-blue-700",
      bg: "bg-blue-50",
      icon: CheckCircle2,
      label: "مؤكد",
      labelEn: "Confirmed",
    },
    completed: {
      color: "text-emerald-700",
      bg: "bg-emerald-50",
      icon: CheckCircle2,
      label: "مكتمل",
      labelEn: "Completed",
    },
    cancelled: {
      color: "text-red-700",
      bg: "bg-red-50",
      icon: XCircle,
      label: "ملغي",
      labelEn: "Cancelled",
    },
  };

  const filters: { id: BookingStatus; label: string; labelEn: string }[] = [
    { id: "all", label: "الكل", labelEn: "All" },
    { id: "pending", label: "قيد الانتظار", labelEn: "Pending" },
    { id: "confirmed", label: "مؤكد", labelEn: "Confirmed" },
    { id: "completed", label: "مكتمل", labelEn: "Completed" },
    { id: "cancelled", label: "ملغي", labelEn: "Cancelled" },
  ];

  return (
    <div className="min-h-screen bg-gray-50 pt-16">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-6"
        >
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            {language === "ar" ? "حجوزاتي" : "My Bookings"}
          </h1>
          <p className="text-gray-600">
            {language === "ar"
              ? "تتبع جميع حجوزاتك وإدارتها"
              : "Track and manage all your bookings"}
          </p>
        </motion.div>

        {/* Filters */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="flex overflow-x-auto gap-2 pb-4 mb-6 hide-scrollbar"
        >
          {filters.map((filter) => (
            <button
              key={filter.id}
              onClick={() => setStatusFilter(filter.id)}
              className={cn(
                "px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-colors shrink-0",
                statusFilter === filter.id
                  ? "bg-emerald-600 text-white"
                  : "bg-white text-gray-600 hover:bg-gray-100 border border-gray-200"
              )}
            >
              {language === "ar" ? filter.label : filter.labelEn}
            </button>
          ))}
        </motion.div>

        {/* Bookings List */}
        <div className="space-y-4">
          {filteredBookings.length > 0 ? (
            filteredBookings.map((booking, index) => {
              const service = getService(booking.serviceId);
              const config = statusConfig[booking.status];
              const StatusIcon = config.icon;

              return (
                <motion.div
                  key={booking.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                  className="bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden"
                >
                  <Link href={`/listing/${booking.serviceId}`} className="block">
                    <div className="flex flex-col sm:flex-row">
                      {/* Image */}
                      <div className="sm:w-40 h-40 shrink-0">
                        <img
                          src={service?.images[0] || "https://via.placeholder.com/160"}
                          alt={service?.title || ""}
                          className="w-full h-full object-cover"
                        />
                      </div>

                      {/* Content */}
                      <div className="flex-1 p-4">
                        <div className="flex items-start justify-between gap-4">
                          <div>
                            <h3 className="font-bold text-gray-900 mb-1 line-clamp-1">
                              {service?.title || (language === "ar" ? "خدمة" : "Service")}
                            </h3>
                            <p className="text-sm text-gray-500 flex items-center gap-1">
                              <MapPin className="w-3.5 h-3.5" />
                              {service?.location || "-"}
                            </p>
                          </div>
                          <span
                            className={cn(
                              "flex items-center gap-1 px-3 py-1 rounded-full text-xs font-bold shrink-0",
                              config.bg,
                              config.color
                            )}
                          >
                            <StatusIcon className="w-3.5 h-3.5" />
                            {language === "ar" ? config.label : config.labelEn}
                          </span>
                        </div>

                        <div className="flex flex-wrap gap-4 mt-4 text-sm text-gray-600">
                          <div className="flex items-center gap-1">
                            <Calendar className="w-4 h-4 text-gray-400" />
                            <span>
                              {booking.checkIn}
                              {booking.checkOut && ` → ${booking.checkOut}`}
                            </span>
                          </div>
                          <div className="flex items-center gap-1">
                            <Users className="w-4 h-4 text-gray-400" />
                            <span>
                              {booking.guests} {language === "ar" ? "ضيف" : "guests"}
                            </span>
                          </div>
                        </div>

                        <div className="flex items-center justify-between mt-4 pt-4 border-t border-gray-100">
                          <p className="text-lg font-bold text-emerald-600">
                            ${booking.totalPrice}
                          </p>
                          <span className="text-emerald-600 flex items-center gap-1 text-sm font-medium">
                            {language === "ar" ? "عرض التفاصيل" : "View Details"}
                            <ChevronRight className="w-4 h-4 rotate-180" />
                          </span>
                        </div>
                      </div>
                    </div>
                  </Link>
                </motion.div>
              );
            })
          ) : (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-center py-20 bg-white rounded-2xl border border-gray-200"
            >
              <Calendar className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-xl font-bold text-gray-900 mb-2">
                {language === "ar" ? "لا توجد حجوزات" : "No bookings found"}
              </h3>
              <p className="text-gray-500 max-w-md mx-auto mb-6">
                {language === "ar"
                  ? "لم تقم بأي حجوزات بعد. استكشف خدماتنا وابدأ رحلتك!"
                  : "You haven't made any bookings yet. Explore our services and start your journey!"}
              </p>
              <Link
                href="/"
                className="inline-flex items-center bg-emerald-600 text-white px-6 py-3 rounded-xl font-bold hover:bg-emerald-700 transition-colors"
              >
                {language === "ar" ? "استكشف الخدمات" : "Explore Services"}
              </Link>
            </motion.div>
          )}
        </div>
      </div>
    </div>
  );
}
