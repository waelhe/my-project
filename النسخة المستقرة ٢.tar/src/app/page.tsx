"use client";

import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { BottomNav } from "@/components/layout/BottomNav";
import { Hero } from "@/components/home/Hero";
import { MobileCategoryBar } from "@/components/home/MobileCategoryBar";
import { Categories } from "@/components/home/Categories";
import { Featured } from "@/components/home/Featured";
import { MarketHighlights } from "@/components/home/MarketHighlights";
import { CommunityHighlights } from "@/components/home/CommunityHighlights";
import { AIAgent } from "@/components/home/AIAgent";

export default function Home() {
  return (
    <main className="min-h-screen flex flex-col bg-white">
      <Navbar />
      <div className="flex-grow">
        <Hero />
        <MobileCategoryBar />
        <Categories />
        <Featured />
        <MarketHighlights />
        <CommunityHighlights />
      </div>
      <Footer />
      <BottomNav />
      <AIAgent />
    </main>
  );
}
