"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { motion } from "framer-motion";
import {
  ArrowRight, ArrowLeft, Upload, X, Plus, Check,
  MapPin, DollarSign, Users, Home, Image as ImageIcon
} from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { useLanguage } from "@/contexts/LanguageContext";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

const STEPS = [
  { id: 1, title: { ar: "المعلومات الأساسية", en: "Basic Info" } },
  { id: 2, title: { ar: "الموقع", en: "Location" } },
  { id: 3, title: { ar: "التفاصيل", en: "Details" } },
  { id: 4, title: { ar: "الأسعار", en: "Pricing" } },
  { id: 5, title: { ar: "الصور", en: "Photos" } },
];

const CATEGORIES = [
  { id: "tourism", name: { ar: "السياحة", en: "Tourism" } },
  { id: "medical", name: { ar: "العلاج", en: "Medical" } },
  { id: "education", name: { ar: "الدراسة", en: "Education" } },
  { id: "business", name: { ar: "الأعمال", en: "Business" } },
];

const PROPERTY_TYPES = [
  { id: "HOTEL", name: { ar: "فندق", en: "Hotel" } },
  { id: "APARTMENT", name: { ar: "شقة", en: "Apartment" } },
  { id: "HOUSE", name: { ar: "منزل", en: "House" } },
  { id: "VILLA", name: { ar: "فيلا", en: "Villa" } },
  { id: "ROOM", name: { ar: "غرفة", en: "Room" } },
  { id: "OTHER", name: { ar: "أخرى", en: "Other" } },
];

const AMENITIES = [
  { id: "wifi", name: { ar: "واي فاي", en: "WiFi" } },
  { id: "pool", name: { ar: "مسبح", en: "Pool" } },
  { id: "parking", name: { ar: "موقف سيارات", en: "Parking" } },
  { id: "ac", name: { ar: "تكييف", en: "Air Conditioning" } },
  { id: "kitchen", name: { ar: "مطبخ", en: "Kitchen" } },
  { id: "tv", name: { ar: "تلفاز", en: "TV" } },
  { id: "washer", name: { ar: "غسالة", en: "Washer" } },
  { id: "gym", name: { ar: "نادي رياضي", en: "Gym" } },
  { id: "spa", name: { ar: "سبا", en: "Spa" } },
  { id: "breakfast", name: { ar: "فطور", en: "Breakfast" } },
];

export default function NewListingPage() {
  const router = useRouter();
  const { user, loading } = useAuth();
  const { language } = useLanguage();
  const [currentStep, setCurrentStep] = useState(1);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const [formData, setFormData] = useState({
    title: "",
    description: "",
    category: "",
    type: "",
    city: "",
    address: "",
    guests: 2,
    bedrooms: 1,
    bathrooms: 1,
    basePrice: 0,
    cleaningFee: 0,
    amenities: [] as string[],
    images: [] as string[],
  });

  const handleInputChange = (field: string, value: any) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const toggleAmenity = (amenityId: string) => {
    setFormData((prev) => ({
      ...prev,
      amenities: prev.amenities.includes(amenityId)
        ? prev.amenities.filter((a) => a !== amenityId)
        : [...prev.amenities, amenityId],
    }));
  };

  const canProceed = () => {
    switch (currentStep) {
      case 1:
        return formData.title && formData.category && formData.type;
      case 2:
        return formData.city && formData.address;
      case 3:
        return true;
      case 4:
        return formData.basePrice > 0;
      case 5:
        return formData.images.length > 0;
      default:
        return true;
    }
  };

  const handleSubmit = async () => {
    setIsSubmitting(true);
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 2000));
    setIsSubmitting(false);
    router.push("/provider");
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center pt-16">
        <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-emerald-600" />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center pt-16">
        <div className="text-center p-8 bg-white rounded-2xl shadow-sm max-w-md">
          <Home className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <h1 className="text-2xl font-bold text-gray-900 mb-2">
            {language === "ar" ? "يرجى تسجيل الدخول" : "Please Sign In"}
          </h1>
          <Link
            href="/"
            className="inline-flex items-center bg-emerald-600 text-white px-6 py-3 rounded-xl font-bold hover:bg-emerald-700 transition-colors"
          >
            {language === "ar" ? "العودة للرئيسية" : "Go to Home"}
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 pt-16">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Progress Steps */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            {STEPS.map((step, index) => (
              <div key={step.id} className="flex items-center">
                <div
                  className={cn(
                    "w-10 h-10 rounded-full flex items-center justify-center text-sm font-bold transition-colors",
                    currentStep >= step.id
                      ? "bg-emerald-600 text-white"
                      : "bg-gray-200 text-gray-500"
                  )}
                >
                  {currentStep > step.id ? <Check className="w-5 h-5" /> : step.id}
                </div>
                {index < STEPS.length - 1 && (
                  <div
                    className={cn(
                      "w-12 sm:w-20 h-1 mx-1",
                      currentStep > step.id ? "bg-emerald-600" : "bg-gray-200"
                    )}
                  />
                )}
              </div>
            ))}
          </div>
          <div className="flex justify-between mt-2">
            {STEPS.map((step) => (
              <span
                key={step.id}
                className={cn(
                  "text-xs font-medium",
                  currentStep >= step.id ? "text-emerald-600" : "text-gray-400"
                )}
              >
                {language === "ar" ? step.title.ar : step.title.en}
              </span>
            ))}
          </div>
        </div>

        {/* Form Content */}
        <motion.div
          key={currentStep}
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          className="bg-white rounded-2xl border border-gray-200 shadow-sm p-6 sm:p-8"
        >
          {/* Step 1: Basic Info */}
          {currentStep === 1 && (
            <div className="space-y-6">
              <h2 className="text-2xl font-bold text-gray-900">
                {language === "ar" ? "المعلومات الأساسية" : "Basic Information"}
              </h2>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  {language === "ar" ? "عنوان الخدمة" : "Listing Title"}
                </label>
                <Input
                  value={formData.title}
                  onChange={(e) => handleInputChange("title", e.target.value)}
                  placeholder={language === "ar" ? "أدخل عنوان جذاب لخدمتك" : "Enter an attractive title"}
                  className="w-full"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  {language === "ar" ? "التصنيف" : "Category"}
                </label>
                <div className="grid grid-cols-2 gap-3">
                  {CATEGORIES.map((cat) => (
                    <button
                      key={cat.id}
                      type="button"
                      onClick={() => handleInputChange("category", cat.id)}
                      className={cn(
                        "p-4 rounded-xl border-2 text-right transition-colors",
                        formData.category === cat.id
                          ? "border-emerald-500 bg-emerald-50"
                          : "border-gray-200 hover:border-gray-300"
                      )}
                    >
                      <span className="font-medium">
                        {language === "ar" ? cat.name.ar : cat.name.en}
                      </span>
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  {language === "ar" ? "نوع المكان" : "Property Type"}
                </label>
                <div className="grid grid-cols-3 gap-3">
                  {PROPERTY_TYPES.map((type) => (
                    <button
                      key={type.id}
                      type="button"
                      onClick={() => handleInputChange("type", type.id)}
                      className={cn(
                        "p-3 rounded-xl border-2 text-center transition-colors",
                        formData.type === type.id
                          ? "border-emerald-500 bg-emerald-50"
                          : "border-gray-200 hover:border-gray-300"
                      )}
                    >
                      <span className="text-sm font-medium">
                        {language === "ar" ? type.name.ar : type.name.en}
                      </span>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Step 2: Location */}
          {currentStep === 2 && (
            <div className="space-y-6">
              <h2 className="text-2xl font-bold text-gray-900">
                {language === "ar" ? "الموقع" : "Location"}
              </h2>

              <div className="bg-emerald-50 rounded-xl p-4 flex items-center gap-3 mb-4">
                <MapPin className="w-6 h-6 text-emerald-600 shrink-0" />
                <p className="text-sm text-emerald-700">
                  {language === "ar"
                    ? "أدخل موقع خدمتك بدقة ليسهل على الضيوف الوصول إليها"
                    : "Enter your listing's location accurately to help guests find it"}
                </p>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  {language === "ar" ? "المدينة" : "City"}
                </label>
                <Input
                  value={formData.city}
                  onChange={(e) => handleInputChange("city", e.target.value)}
                  placeholder={language === "ar" ? "مثال: دمشق، حلب، طرطوس" : "e.g., Damascus, Aleppo, Tartus"}
                  className="w-full"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  {language === "ar" ? "العنوان التفصيلي" : "Full Address"}
                </label>
                <textarea
                  value={formData.address}
                  onChange={(e) => handleInputChange("address", e.target.value)}
                  placeholder={language === "ar" ? "الحي، الشارع، رقم المبنى" : "Neighborhood, Street, Building Number"}
                  className="w-full px-4 py-3 border rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  rows={3}
                />
              </div>
            </div>
          )}

          {/* Step 3: Details */}
          {currentStep === 3 && (
            <div className="space-y-6">
              <h2 className="text-2xl font-bold text-gray-900">
                {language === "ar" ? "التفاصيل" : "Details"}
              </h2>

              <div className="grid grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    <Users className="w-4 h-4 inline ml-1" />
                    {language === "ar" ? "عدد الضيوف" : "Guests"}
                  </label>
                  <Input
                    type="number"
                    min={1}
                    value={formData.guests}
                    onChange={(e) => handleInputChange("guests", parseInt(e.target.value) || 1)}
                    className="w-full"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    <Home className="w-4 h-4 inline ml-1" />
                    {language === "ar" ? "غرف نوم" : "Bedrooms"}
                  </label>
                  <Input
                    type="number"
                    min={0}
                    value={formData.bedrooms}
                    onChange={(e) => handleInputChange("bedrooms", parseInt(e.target.value) || 0)}
                    className="w-full"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    {language === "ar" ? "حمامات" : "Bathrooms"}
                  </label>
                  <Input
                    type="number"
                    min={0}
                    value={formData.bathrooms}
                    onChange={(e) => handleInputChange("bathrooms", parseInt(e.target.value) || 0)}
                    className="w-full"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-3">
                  {language === "ar" ? "المرافق والمميزات" : "Amenities"}
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                  {AMENITIES.map((amenity) => (
                    <button
                      key={amenity.id}
                      type="button"
                      onClick={() => toggleAmenity(amenity.id)}
                      className={cn(
                        "p-3 rounded-xl border-2 text-center transition-colors",
                        formData.amenities.includes(amenity.id)
                          ? "border-emerald-500 bg-emerald-50 text-emerald-700"
                          : "border-gray-200 hover:border-gray-300 text-gray-600"
                      )}
                    >
                      <span className="text-sm font-medium">
                        {language === "ar" ? amenity.name.ar : amenity.name.en}
                      </span>
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  {language === "ar" ? "وصف الخدمة" : "Description"}
                </label>
                <textarea
                  value={formData.description}
                  onChange={(e) => handleInputChange("description", e.target.value)}
                  placeholder={language === "ar" ? "اكتب وصفاً تفصيلياً عن خدماتك..." : "Write a detailed description..."}
                  className="w-full px-4 py-3 border rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  rows={5}
                />
              </div>
            </div>
          )}

          {/* Step 4: Pricing */}
          {currentStep === 4 && (
            <div className="space-y-6">
              <h2 className="text-2xl font-bold text-gray-900">
                {language === "ar" ? "الأسعار" : "Pricing"}
              </h2>

              <div className="bg-amber-50 rounded-xl p-4 flex items-center gap-3 mb-4">
                <DollarSign className="w-6 h-6 text-amber-600 shrink-0" />
                <p className="text-sm text-amber-700">
                  {language === "ar"
                    ? "حدد أسعاراً تنافسية لجذب المزيد من الضيوف"
                    : "Set competitive prices to attract more guests"}
                </p>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  {language === "ar" ? "السعر الأساسي (لليلة)" : "Base Price (per night)"}
                </label>
                <div className="relative">
                  <span className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-500">$</span>
                  <Input
                    type="number"
                    min={0}
                    value={formData.basePrice}
                    onChange={(e) => handleInputChange("basePrice", parseFloat(e.target.value) || 0)}
                    className="w-full pr-8"
                    placeholder="0"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  {language === "ar" ? "رسوم التنظيف (اختياري)" : "Cleaning Fee (optional)"}
                </label>
                <div className="relative">
                  <span className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-500">$</span>
                  <Input
                    type="number"
                    min={0}
                    value={formData.cleaningFee}
                    onChange={(e) => handleInputChange("cleaningFee", parseFloat(e.target.value) || 0)}
                    className="w-full pr-8"
                    placeholder="0"
                  />
                </div>
              </div>

              <div className="bg-gray-50 rounded-xl p-4">
                <h4 className="font-medium text-gray-900 mb-2">
                  {language === "ar" ? "ملخص الأسعار" : "Price Summary"}
                </h4>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-600">{language === "ar" ? "السعر الأساسي" : "Base Price"}</span>
                    <span className="font-medium">${formData.basePrice}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">{language === "ar" ? "رسوم التنظيف" : "Cleaning Fee"}</span>
                    <span className="font-medium">${formData.cleaningFee}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">{language === "ar" ? "رسوم الخدمة (10%)" : "Service Fee (10%)"}</span>
                    <span className="font-medium">${Math.round(formData.basePrice * 0.1)}</span>
                  </div>
                  <div className="flex justify-between pt-2 border-t border-gray-200 font-bold">
                    <span>{language === "ar" ? "الإجمالي لليلة" : "Total per Night"}</span>
                    <span className="text-emerald-600">
                      ${formData.basePrice + formData.cleaningFee + Math.round(formData.basePrice * 0.1)}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Step 5: Photos */}
          {currentStep === 5 && (
            <div className="space-y-6">
              <h2 className="text-2xl font-bold text-gray-900">
                {language === "ar" ? "الصور" : "Photos"}
              </h2>

              <div className="bg-blue-50 rounded-xl p-4 flex items-center gap-3 mb-4">
                <ImageIcon className="w-6 h-6 text-blue-600 shrink-0" />
                <p className="text-sm text-blue-700">
                  {language === "ar"
                    ? "أضف صوراً عالية الجودة لجذب الضيوف. يفضل إضافة 5 صور على الأقل."
                    : "Add high-quality photos to attract guests. At least 5 photos recommended."}
                </p>
              </div>

              {/* Upload Area */}
              <div className="border-2 border-dashed border-gray-300 rounded-xl p-8 text-center hover:border-emerald-500 transition-colors cursor-pointer">
                <Upload className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-600 mb-2">
                  {language === "ar"
                    ? "اسحب الصور هنا أو انقر للتحميل"
                    : "Drag photos here or click to upload"}
                </p>
                <p className="text-sm text-gray-400">
                  {language === "ar" ? "PNG, JPG حتى 10MB" : "PNG, JPG up to 10MB"}
                </p>
              </div>

              {/* Sample Images */}
              <div className="grid grid-cols-3 gap-4">
                {[
                  "https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?w=400",
                  "https://images.unsplash.com/photo-1566073771259-6a8506099945?w=400",
                  "https://images.unsplash.com/photo-1520250497591-112f2f40a3f4?w=400",
                ].map((img, idx) => (
                  <div key={idx} className="relative aspect-video rounded-xl overflow-hidden group">
                    <img
                      src={img}
                      alt=""
                      className="w-full h-full object-cover"
                    />
                    <button
                      onClick={() => {
                        setFormData((prev) => ({
                          ...prev,
                          images: prev.images.filter((_, i) => i !== idx),
                        }));
                      }}
                      className="absolute top-2 left-2 p-1.5 bg-white rounded-full shadow-md opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                      <X className="w-4 h-4 text-gray-600" />
                    </button>
                    {idx === 0 && (
                      <span className="absolute bottom-2 right-2 px-2 py-1 bg-emerald-600 text-white text-xs font-bold rounded-md">
                        {language === "ar" ? "الرئيسية" : "Cover"}
                      </span>
                    )}
                  </div>
                ))}

                {/* Add More Button */}
                <button className="aspect-video rounded-xl border-2 border-dashed border-gray-300 flex flex-col items-center justify-center hover:border-emerald-500 transition-colors">
                  <Plus className="w-8 h-8 text-gray-400 mb-1" />
                  <span className="text-sm text-gray-500">
                    {language === "ar" ? "إضافة" : "Add"}
                  </span>
                </button>
              </div>
            </div>
          )}

          {/* Navigation Buttons */}
          <div className="flex items-center justify-between mt-8 pt-6 border-t border-gray-200">
            {currentStep > 1 ? (
              <Button
                variant="outline"
                onClick={() => setCurrentStep((prev) => prev - 1)}
                className="gap-2"
              >
                <ArrowRight className="w-4 h-4" />
                {language === "ar" ? "السابق" : "Previous"}
              </Button>
            ) : (
              <div />
            )}

            {currentStep < 5 ? (
              <Button
                onClick={() => setCurrentStep((prev) => prev + 1)}
                disabled={!canProceed()}
                className="gap-2 bg-emerald-600 hover:bg-emerald-700"
              >
                {language === "ar" ? "التالي" : "Next"}
                <ArrowLeft className="w-4 h-4" />
              </Button>
            ) : (
              <Button
                onClick={handleSubmit}
                disabled={!canProceed() || isSubmitting}
                className="gap-2 bg-emerald-600 hover:bg-emerald-700"
              >
                {isSubmitting ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white" />
                    {language === "ar" ? "جاري النشر..." : "Publishing..."}
                  </>
                ) : (
                  <>
                    <Check className="w-4 h-4" />
                    {language === "ar" ? "نشر الخدمة" : "Publish Listing"}
                  </>
                )}
              </Button>
            )}
          </div>
        </motion.div>
      </div>
    </div>
  );
}
