"use client";

import { useState } from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import {
  LayoutDashboard, Calendar, Star, DollarSign, TrendingUp,
  Plus, Eye, Edit2, MoreVertical, ArrowUpRight, ArrowDownRight,
  Users, Home, Clock, ChevronRight, Settings
} from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { useLanguage } from "@/contexts/LanguageContext";
import { cn } from "@/lib/utils";
import { INITIAL_SERVICES } from "@/data/initialServices";

export default function ProviderDashboardPage() {
  const { user, loading } = useAuth();
  const { language } = useLanguage();
  const [activeTab, setActiveTab] = useState("overview");

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center pt-16">
        <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-emerald-600" />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center pt-16">
        <div className="text-center p-8 bg-white rounded-2xl shadow-sm max-w-md">
          <Home className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <h1 className="text-2xl font-bold text-gray-900 mb-2">
            {language === "ar" ? "يرجى تسجيل الدخول" : "Please Sign In"}
          </h1>
          <p className="text-gray-500 mb-6">
            {language === "ar"
              ? "تحتاج إلى تسجيل الدخول للوصول إلى لوحة التحكم"
              : "You need to sign in to access the dashboard"}
          </p>
          <Link
            href="/"
            className="inline-flex items-center bg-emerald-600 text-white px-6 py-3 rounded-xl font-bold hover:bg-emerald-700 transition-colors"
          >
            {language === "ar" ? "العودة للرئيسية" : "Go to Home"}
          </Link>
        </div>
      </div>
    );
  }

  // Mock data for dashboard
  const stats = [
    {
      label: language === "ar" ? "إجمالي الحجوزات" : "Total Bookings",
      value: 48,
      change: 12,
      up: true,
      icon: Calendar,
      color: "emerald",
    },
    {
      label: language === "ar" ? "الإيرادات" : "Revenue",
      value: "$12,450",
      change: 8,
      up: true,
      icon: DollarSign,
      color: "blue",
    },
    {
      label: language === "ar" ? "التقييمات" : "Reviews",
      value: 156,
      change: 24,
      up: true,
      icon: Star,
      color: "amber",
    },
    {
      label: language === "ar" ? "المشاهدات" : "Views",
      value: 2840,
      change: 3,
      up: false,
      icon: Eye,
      color: "purple",
    },
  ];

  const recentBookings = [
    { id: 1, guest: "أحمد محمد", service: "منتجع الرمال الذهبية", date: "2024-02-15", status: "confirmed", amount: 495 },
    { id: 2, guest: "سارة علي", service: "جولة القوارب", date: "2024-02-14", status: "pending", amount: 100 },
    { id: 3, guest: "خالد حسن", service: "منتجع الرمال الذهبية", date: "2024-02-13", status: "completed", amount: 750 },
    { id: 4, guest: "فاطمة أحمد", service: "ورشة الموزاييك", date: "2024-02-12", status: "cancelled", amount: 80 },
  ];

  const myListings = INITIAL_SERVICES.slice(0, 4);

  const tabs = [
    { id: "overview", label: language === "ar" ? "نظرة عامة" : "Overview", icon: LayoutDashboard },
    { id: "listings", label: language === "ar" ? "خدماتي" : "My Listings", icon: Home },
    { id: "bookings", label: language === "ar" ? "الحجوزات" : "Bookings", icon: Calendar },
    { id: "reviews", label: language === "ar" ? "التقييمات" : "Reviews", icon: Star },
  ];

  const statusColors: Record<string, string> = {
    confirmed: "bg-blue-100 text-blue-700",
    pending: "bg-amber-100 text-amber-700",
    completed: "bg-emerald-100 text-emerald-700",
    cancelled: "bg-red-100 text-red-700",
  };

  const statusLabels: Record<string, string> = {
    confirmed: language === "ar" ? "مؤكد" : "Confirmed",
    pending: language === "ar" ? "قيد الانتظار" : "Pending",
    completed: language === "ar" ? "مكتمل" : "Completed",
    cancelled: language === "ar" ? "ملغي" : "Cancelled",
  };

  return (
    <div className="min-h-screen bg-gray-50 pt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">
              {language === "ar" ? "لوحة التحكم" : "Dashboard"}
            </h1>
            <p className="text-gray-600">
              {language === "ar"
                ? "مرحباً بك! إدارة خدماتك وحجوزاتك"
                : "Welcome! Manage your services and bookings"}
            </p>
          </div>
          <Link
            href="/provider/listings/new"
            className="inline-flex items-center gap-2 bg-emerald-600 text-white px-6 py-3 rounded-xl font-bold hover:bg-emerald-700 transition-colors shadow-lg shadow-emerald-200"
          >
            <Plus className="w-5 h-5" />
            {language === "ar" ? "إضافة خدمة جديدة" : "Add New Listing"}
          </Link>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {stats.map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="bg-white rounded-2xl p-6 border border-gray-200 shadow-sm"
            >
              <div className="flex items-center justify-between mb-4">
                <div className={cn(
                  "w-12 h-12 rounded-xl flex items-center justify-center",
                  stat.color === "emerald" && "bg-emerald-100",
                  stat.color === "blue" && "bg-blue-100",
                  stat.color === "amber" && "bg-amber-100",
                  stat.color === "purple" && "bg-purple-100"
                )}>
                  <stat.icon className={cn(
                    "w-6 h-6",
                    stat.color === "emerald" && "text-emerald-600",
                    stat.color === "blue" && "text-blue-600",
                    stat.color === "amber" && "text-amber-600",
                    stat.color === "purple" && "text-purple-600"
                  )} />
                </div>
                <div className={cn(
                  "flex items-center gap-1 text-sm font-medium",
                  stat.up ? "text-emerald-600" : "text-red-600"
                )}>
                  {stat.up ? <ArrowUpRight className="w-4 h-4" /> : <ArrowDownRight className="w-4 h-4" />}
                  {stat.change}%
                </div>
              </div>
              <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
              <p className="text-sm text-gray-500">{stat.label}</p>
            </motion.div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Recent Bookings */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden"
            >
              <div className="p-6 border-b border-gray-100">
                <div className="flex items-center justify-between">
                  <h2 className="text-lg font-bold text-gray-900">
                    {language === "ar" ? "الحجوزات الأخيرة" : "Recent Bookings"}
                  </h2>
                  <Link href="/provider/bookings" className="text-emerald-600 text-sm font-medium hover:underline">
                    {language === "ar" ? "عرض الكل" : "View All"}
                  </Link>
                </div>
              </div>
              <div className="divide-y divide-gray-100">
                {recentBookings.map((booking) => (
                  <div key={booking.id} className="p-4 hover:bg-gray-50 transition-colors">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center">
                          <Users className="w-5 h-5 text-gray-500" />
                        </div>
                        <div>
                          <p className="font-medium text-gray-900">{booking.guest}</p>
                          <p className="text-sm text-gray-500">{booking.service}</p>
                        </div>
                      </div>
                      <div className="text-left">
                        <span className={cn(
                          "inline-block px-2 py-1 rounded-full text-xs font-medium",
                          statusColors[booking.status]
                        )}>
                          {statusLabels[booking.status]}
                        </span>
                        <p className="text-sm font-bold text-gray-900 mt-1">${booking.amount}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>

            {/* My Listings */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden"
            >
              <div className="p-6 border-b border-gray-100">
                <div className="flex items-center justify-between">
                  <h2 className="text-lg font-bold text-gray-900">
                    {language === "ar" ? "خدماتي" : "My Listings"}
                  </h2>
                  <Link href="/provider/listings" className="text-emerald-600 text-sm font-medium hover:underline">
                    {language === "ar" ? "عرض الكل" : "View All"}
                  </Link>
                </div>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 p-4">
                {myListings.map((listing) => (
                  <div key={listing.id} className="group relative bg-gray-50 rounded-xl overflow-hidden">
                    <div className="aspect-video">
                      <img
                        src={listing.images[0]}
                        alt={listing.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                    </div>
                    <div className="p-3">
                      <h3 className="font-medium text-gray-900 line-clamp-1">{listing.title}</h3>
                      <div className="flex items-center justify-between mt-2">
                        <span className="text-emerald-600 font-bold">${listing.price}</span>
                        <div className="flex items-center gap-1 text-sm text-gray-500">
                          <Star className="w-3.5 h-3.5 text-amber-400 fill-current" />
                          {listing.rating}
                        </div>
                      </div>
                    </div>
                    <div className="absolute top-2 left-2 flex gap-1">
                      <button className="p-2 bg-white/90 backdrop-blur-sm rounded-full shadow-sm hover:bg-white transition-colors">
                        <Edit2 className="w-4 h-4 text-gray-600" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Quick Actions */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="bg-white rounded-2xl border border-gray-200 shadow-sm p-6"
            >
              <h2 className="text-lg font-bold text-gray-900 mb-4">
                {language === "ar" ? "إجراءات سريعة" : "Quick Actions"}
              </h2>
              <div className="space-y-3">
                <Link
                  href="/provider/listings/new"
                  className="flex items-center justify-between p-3 bg-emerald-50 rounded-xl hover:bg-emerald-100 transition-colors group"
                >
                  <div className="flex items-center gap-3">
                    <Plus className="w-5 h-5 text-emerald-600" />
                    <span className="font-medium text-gray-700">
                      {language === "ar" ? "إضافة خدمة" : "Add Listing"}
                    </span>
                  </div>
                  <ChevronRight className="w-4 h-4 text-gray-400 rotate-180 group-hover:text-emerald-600" />
                </Link>
                <Link
                  href="/provider/bookings"
                  className="flex items-center justify-between p-3 bg-blue-50 rounded-xl hover:bg-blue-100 transition-colors group"
                >
                  <div className="flex items-center gap-3">
                    <Calendar className="w-5 h-5 text-blue-600" />
                    <span className="font-medium text-gray-700">
                      {language === "ar" ? "إدارة الحجوزات" : "Manage Bookings"}
                    </span>
                  </div>
                  <ChevronRight className="w-4 h-4 text-gray-400 rotate-180 group-hover:text-blue-600" />
                </Link>
                <Link
                  href="/provider/reviews"
                  className="flex items-center justify-between p-3 bg-amber-50 rounded-xl hover:bg-amber-100 transition-colors group"
                >
                  <div className="flex items-center gap-3">
                    <Star className="w-5 h-5 text-amber-600" />
                    <span className="font-medium text-gray-700">
                      {language === "ar" ? "عرض التقييمات" : "View Reviews"}
                    </span>
                  </div>
                  <ChevronRight className="w-4 h-4 text-gray-400 rotate-180 group-hover:text-amber-600" />
                </Link>
                <Link
                  href="/provider/settings"
                  className="flex items-center justify-between p-3 bg-gray-50 rounded-xl hover:bg-gray-100 transition-colors group"
                >
                  <div className="flex items-center gap-3">
                    <Settings className="w-5 h-5 text-gray-600" />
                    <span className="font-medium text-gray-700">
                      {language === "ar" ? "الإعدادات" : "Settings"}
                    </span>
                  </div>
                  <ChevronRight className="w-4 h-4 text-gray-400 rotate-180" />
                </Link>
              </div>
            </motion.div>

            {/* Performance */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="bg-gradient-to-br from-emerald-500 to-teal-600 rounded-2xl p-6 text-white"
            >
              <div className="flex items-center gap-2 mb-4">
                <TrendingUp className="w-5 h-5" />
                <h3 className="font-bold">
                  {language === "ar" ? "أداء هذا الشهر" : "This Month's Performance"}
                </h3>
              </div>
              <div className="space-y-4">
                <div>
                  <p className="text-white/70 text-sm">
                    {language === "ar" ? "معدل الإشغال" : "Occupancy Rate"}
                  </p>
                  <div className="flex items-center gap-2 mt-1">
                    <div className="flex-1 h-2 bg-white/20 rounded-full overflow-hidden">
                      <div className="h-full bg-white w-3/4 rounded-full" />
                    </div>
                    <span className="font-bold">75%</span>
                  </div>
                </div>
                <div>
                  <p className="text-white/70 text-sm">
                    {language === "ar" ? "الهدف الشهري" : "Monthly Goal"}
                  </p>
                  <div className="flex items-center gap-2 mt-1">
                    <div className="flex-1 h-2 bg-white/20 rounded-full overflow-hidden">
                      <div className="h-full bg-white w-[85%] rounded-full" />
                    </div>
                    <span className="font-bold">85%</span>
                  </div>
                </div>
              </div>
            </motion.div>

            {/* Calendar Preview */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              className="bg-white rounded-2xl border border-gray-200 shadow-sm p-6"
            >
              <div className="flex items-center gap-2 mb-4">
                <Clock className="w-5 h-5 text-emerald-600" />
                <h3 className="font-bold text-gray-900">
                  {language === "ar" ? "القادم" : "Upcoming"}
                </h3>
              </div>
              <div className="space-y-3">
                <div className="flex items-center gap-3 p-2 bg-gray-50 rounded-lg">
                  <div className="w-10 h-10 bg-emerald-100 rounded-lg flex items-center justify-center">
                    <span className="text-emerald-700 font-bold text-sm">15</span>
                  </div>
                  <div>
                    <p className="font-medium text-gray-900 text-sm">
                      {language === "ar" ? "وصول ضيف جديد" : "New Guest Arrival"}
                    </p>
                    <p className="text-xs text-gray-500">منتجع الرمال الذهبية</p>
                  </div>
                </div>
                <div className="flex items-center gap-3 p-2 bg-gray-50 rounded-lg">
                  <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                    <span className="text-blue-700 font-bold text-sm">18</span>
                  </div>
                  <div>
                    <p className="font-medium text-gray-900 text-sm">
                      {language === "ar" ? "موعد مغادرة" : "Checkout Date"}
                    </p>
                    <p className="text-xs text-gray-500">منتجع الرمال الذهبية</p>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
}
