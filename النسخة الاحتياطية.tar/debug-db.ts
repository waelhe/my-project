import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

console.log('Prisma client keys:', Object.keys(prisma))
console.log('Has city?', 'city' in prisma)
console.log('Has accommodation?', 'accommodation' in prisma)

prisma.$disconnect()
