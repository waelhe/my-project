// ═══════════════════════════════════════════════════════════════════════════
// Core Module - Main Index
// الوحدة الأساسية - التصدير الرئيسي
// ═══════════════════════════════════════════════════════════════════════════

/**
 * بنية Modular Monolith مع فصل الاهتمامات
 * Modular Monolith Architecture with Separation of Concerns
 * 
 * الطبقات:
 * - Domain: الكيانات والأحداث وقواعد العمل
 * - Application: الخدمات وحالات الاستخدام والواجهات
 * - Infrastructure: قاعدة البيانات والخدمات الخارجية
 */

// ═══════════════════════════════════════════════════════════════════════════
// Domain Layer | طبقة النطاق
// ═══════════════════════════════════════════════════════════════════════════

// Entities | الكيانات
export * from './domain/entities';

// Events | الأحداث
export { 
  DomainEvent, 
  EventTypes, 
  EventFactory, 
  SimpleEventPublisher, 
  eventPublisher 
} from './domain/events';

// ═══════════════════════════════════════════════════════════════════════════
// Application Layer | طبقة التطبيق
// ═══════════════════════════════════════════════════════════════════════════

// Ports | المنافذ (Interfaces)
export type {
  IRepository,
  QueryOptions,
  PaginatedResult,
  ITransaction,
  IEventPublisher,
  EventListener,
  ICacheService,
  ILoggerService,
  IAuthService,
  OTPSendResult,
  AuthResult,
  UserInfo,
  IAIProvider,
  ChatMessage,
  ChatOptions,
  ImageAnalysis,
  TTSOptions,
  IPaymentService,
  PaymentMethodType,
  PaymentInitResult,
  PaymentVerifyResult,
  RefundResult,
  INotificationService,
  NotificationData,
  IUploadService,
  UploadOptions,
  UploadResult,
  IEmailService,
  EmailOptions,
  ISMSService,
  SMSResult,
} from './application/ports';

// Services | الخدمات
export { 
  BasePrismaRepository, 
  MemoryCacheService, 
  ConsoleLoggerService,
  cacheService,
  loggerService 
} from './application/services';

// ═══════════════════════════════════════════════════════════════════════════
// Module Information
// ═══════════════════════════════════════════════════════════════════════════

export const CORE_MODULE_INFO = {
  name: 'Core Module',
  nameAr: 'الوحدة الأساسية',
  version: '1.0.0',
  description: 'Core domain entities, events, and application services',
  architecture: {
    pattern: 'Layered Architecture',
    layers: ['domain', 'application', 'infrastructure'],
    principles: [
      'Separation of Concerns',
      'Dependency Inversion',
      'Interface Abstraction',
      'Event-Driven Communication'
    ]
  }
};
