// ═══════════════════════════════════════════════════════════════════════════
// Extension Points & Hooks - نقاط التوسع والخطافات
// ═══════════════════════════════════════════════════════════════════════════

import { DomainEvent, eventPublisher } from '@/core/domain/events';

/**
 * نظام الخطافات للتوسع المستقبلي
 * Hooks System for Future Extensions
 */

// أنواع الخطافات
export type HookName = 
  | 'beforeBookingCreate'
  | 'afterBookingCreate'
  | 'beforeBookingCancel'
  | 'afterBookingCancel'
  | 'beforePayment'
  | 'afterPayment'
  | 'beforeReviewCreate'
  | 'afterReviewCreate'
  | 'beforeUserRegister'
  | 'afterUserRegister'
  | 'beforeAccommodationCreate'
  | 'afterAccommodationCreate';

// نوع دالة الخطاف
export type HookFunction<T = unknown, R = unknown> = (context: HookContext<T>) => Promise<R | void>;

// سياق الخطاف
export interface HookContext<T = unknown> {
  data: T;
  user?: { id: string; role: string };
  timestamp: Date;
  metadata?: Record<string, unknown>;
}

/**
 * مدير الخطافات
 * Hooks Manager
 */
export class HooksManager {
  private hooks: Map<HookName, Set<HookFunction>> = new Map();

  on<T = unknown>(name: HookName, fn: HookFunction<T>): () => void {
    if (!this.hooks.has(name)) {
      this.hooks.set(name, new Set());
    }
    this.hooks.get(name)!.add(fn as HookFunction);

    return () => {
      this.hooks.get(name)?.delete(fn as HookFunction);
    };
  }

  async execute<T = unknown>(name: HookName, context: HookContext<T>): Promise<HookContext<T>> {
    const hooks = this.hooks.get(name);
    if (!hooks || hooks.size === 0) return context;

    let currentContext = context;
    
    for (const hook of hooks) {
      try {
        await hook(currentContext);
      } catch (error) {
        console.error(`Hook ${name} failed:`, error);
      }
    }

    return currentContext;
  }

  has(name: HookName): boolean {
    const hooks = this.hooks.get(name);
    return hooks !== undefined && hooks.size > 0;
  }

  clear(name?: HookName): void {
    if (name) {
      this.hooks.delete(name);
    } else {
      this.hooks.clear();
    }
  }
}

export const hooksManager = new HooksManager();

// ═══════════════════════════════════════════════════════════════════════════
// Plugin System - نظام الإضافات
// ═══════════════════════════════════════════════════════════════════════════

export interface IPlugin {
  name: string;
  version: string;
  description?: string;
  init?: () => Promise<void>;
  destroy?: () => Promise<void>;
  hooks?: Array<{ name: HookName; handler: HookFunction }>;
  events?: Array<{ type: string; handler: (event: DomainEvent) => Promise<void> }>;
}

export class PluginManager {
  private plugins: Map<string, IPlugin> = new Map();
  private unsubscribers: Map<string, (() => void)[]> = new Map();

  async register(plugin: IPlugin): Promise<void> {
    if (this.plugins.has(plugin.name)) {
      throw new Error(`Plugin ${plugin.name} is already registered`);
    }

    const unsubs: (() => void)[] = [];
    
    if (plugin.hooks) {
      for (const { name, handler } of plugin.hooks) {
        const unsub = hooksManager.on(name, handler);
        unsubs.push(unsub);
      }
    }

    if (plugin.events) {
      for (const { type, handler } of plugin.events) {
        const unsub = eventPublisher.subscribe(type, handler);
        unsubs.push(unsub);
      }
    }

    this.unsubscribers.set(plugin.name, unsubs);
    this.plugins.set(plugin.name, plugin);

    if (plugin.init) {
      await plugin.init();
    }
  }

  async unregister(name: string): Promise<void> {
    const plugin = this.plugins.get(name);
    if (!plugin) return;

    const unsubs = this.unsubscribers.get(name) || [];
    for (const unsub of unsubs) {
      unsub();
    }

    if (plugin.destroy) {
      await plugin.destroy();
    }

    this.plugins.delete(name);
    this.unsubscribers.delete(name);
  }

  get<T extends IPlugin = IPlugin>(name: string): T | undefined {
    return this.plugins.get(name) as T | undefined;
  }

  list(): IPlugin[] {
    return Array.from(this.plugins.values());
  }
}

export const pluginManager = new PluginManager();

// ═══════════════════════════════════════════════════════════════════════════
// Built-in Plugins - الإضافات المدمجة
// ═══════════════════════════════════════════════════════════════════════════

export const notificationsPlugin: IPlugin = {
  name: 'notifications',
  version: '1.0.0',
  description: 'Handles system notifications',
  events: [
    {
      type: 'booking.created',
      handler: async (event) => {
        console.log(`Notification: New booking ${event.aggregateId}`);
      }
    }
  ]
};

export const analyticsPlugin: IPlugin = {
  name: 'analytics',
  version: '1.0.0',
  description: 'Tracks user behavior and metrics',
  events: [
    {
      type: 'accommodation.viewed',
      handler: async (event) => {
        console.log(`Analytics: View ${event.aggregateId}`);
      }
    }
  ]
};
