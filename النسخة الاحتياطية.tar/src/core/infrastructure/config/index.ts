// ═══════════════════════════════════════════════════════════════════════════
// Infrastructure Config - إعدادات البنية التحتية
// ═══════════════════════════════════════════════════════════════════════════

/**
 * إعدادات التطبيق
 * Application Configuration
 */
export const config = {
  // التطبيق
  app: {
    name: process.env.NEXT_PUBLIC_APP_NAME || 'ضيف',
    nameEn: process.env.NEXT_PUBLIC_APP_NAME_EN || 'Dayf',
    url: process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000',
    version: '2.0.0',
    environment: process.env.NODE_ENV || 'development',
  },

  // قاعدة البيانات
  database: {
    url: process.env.DATABASE_URL,
  },

  // المصادقة
  auth: {
    jwtSecret: process.env.JWT_SECRET || 'your-secret-key',
    otpExpiry: parseInt(process.env.OTP_EXPIRY || '300'), // 5 minutes
    sessionExpiry: parseInt(process.env.SESSION_EXPIRY || '604800'), // 7 days
    rememberMeExpiry: parseInt(process.env.REMEMBER_ME_EXPIRY || '2592000'), // 30 days
  },

  // التخزين المؤقت
  cache: {
    defaultTTL: parseInt(process.env.CACHE_TTL || '300'), // 5 minutes
    maxSize: parseInt(process.env.CACHE_MAX_SIZE || '1000'),
  },

  // API
  api: {
    rateLimit: {
      windowMs: parseInt(process.env.RATE_LIMIT_WINDOW || '60000'), // 1 minute
      max: parseInt(process.env.RATE_LIMIT_MAX || '100'), // requests per window
    },
  },

  // الملفات
  upload: {
    maxSize: parseInt(process.env.MAX_FILE_SIZE || '10485760'), // 10MB
    allowedTypes: ['image/jpeg', 'image/png', 'image/webp', 'image/gif'],
  },

  // AI Provider
  ai: {
    provider: process.env.AI_PROVIDER || 'z-ai',
    apiKey: process.env.AI_API_KEY,
    model: process.env.AI_MODEL || 'default',
  },

  // المدفوعات
  payment: {
    methods: ['SYRIATEL', 'MTN', 'BANK_TRANSFER', 'CASH'] as const,
    currency: 'SYP',
    serviceFeePercent: 10,
    guaranteeFeePercent: 5,
  },
} as const;

/**
 * التحقق من البيئة
 * Environment Validation
 */
export function validateEnv(): { valid: boolean; missing: string[] } {
  const required = [
    'DATABASE_URL',
  ];

  const missing = required.filter(key => !process.env[key]);

  return {
    valid: missing.length === 0,
    missing,
  };
}

/**
 * نوع البيئة
 * Environment Type
 */
export type Environment = 'development' | 'staging' | 'production';

export function getEnvironment(): Environment {
  return (process.env.NODE_ENV as Environment) || 'development';
}

export function isDevelopment(): boolean {
  return getEnvironment() === 'development';
}

export function isProduction(): boolean {
  return getEnvironment() === 'production';
}
