// ═══════════════════════════════════════════════════════════════════════════
// Core Domain Events - نظام أحداث النطاق
// ═══════════════════════════════════════════════════════════════════════════

/**
 * الحدث الأساسي
 * Base Event
 */
export interface DomainEvent {
  id: string;
  type: string;
  timestamp: Date;
  aggregateId: string;
  aggregateType: string;
  data: Record<string, unknown>;
  metadata?: Record<string, unknown>;
}

/**
 * أنواع الأحداث
 * Event Types
 */
export const EventTypes = {
  // المستخدمون | Users
  USER_REGISTERED: 'user.registered',
  USER_VERIFIED: 'user.verified',
  USER_UPDATED: 'user.updated',
  USER_BECAME_HOST: 'user.became_host',

  // الإقامات | Accommodations
  ACCOMMODATION_CREATED: 'accommodation.created',
  ACCOMMODATION_APPROVED: 'accommodation.approved',
  ACCOMMODATION_REJECTED: 'accommodation.rejected',
  ACCOMMODATION_UPDATED: 'accommodation.updated',
  ACCOMMODATION_VIEWED: 'accommodation.viewed',

  // الحجوزات | Bookings
  BOOKING_CREATED: 'booking.created',
  BOOKING_CONFIRMED: 'booking.confirmed',
  BOOKING_CANCELLED: 'booking.cancelled',
  BOOKING_COMPLETED: 'booking.completed',
  BOOKING_CHECKED_IN: 'booking.checked_in',
  BOOKING_CHECKED_OUT: 'booking.checked_out',

  // المدفوعات | Payments
  PAYMENT_INITIATED: 'payment.initiated',
  PAYMENT_COMPLETED: 'payment.completed',
  PAYMENT_FAILED: 'payment.failed',
  PAYMENT_REFUNDED: 'payment.refunded',
  PAYOUT_REQUESTED: 'payout.requested',
  PAYOUT_COMPLETED: 'payout.completed',

  // التقييمات | Reviews
  REVIEW_ADDED: 'review.added',
  REVIEW_REPLIED: 'review.replied',

  // الرسائل | Messages
  MESSAGE_SENT: 'message.sent',
  MESSAGE_READ: 'message.read',
  CONVERSATION_CREATED: 'conversation.created',

  // النقل | Transport
  TRANSPORT_CREATED: 'transport.created',
  TRANSPORT_BOOKED: 'transport.booked',

  // الجولات | Tours
  TOUR_CREATED: 'tour.created',
  TOUR_BOOKED: 'tour.booked',

  // الأعمال | Business
  BUSINESS_LISTING_CREATED: 'business.created',
  BUSINESS_INQUIRY_MADE: 'business.inquiry',

  // المجتمع | Community
  POST_CREATED: 'community.post_created',
  POST_LIKED: 'community.post_liked',
  COMMENT_ADDED: 'community.comment_added',

  // النظام | System
  NOTIFICATION_SENT: 'system.notification_sent',
  ERROR_OCCURRED: 'system.error',
} as const;

/**
 * مصنع الأحداث
 * Event Factory
 */
export class EventFactory {
  private static generateId(): string {
    return `evt_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  static create(
    type: string,
    aggregateId: string,
    aggregateType: string,
    data: Record<string, unknown>,
    metadata?: Record<string, unknown>
  ): DomainEvent {
    return {
      id: this.generateId(),
      type,
      timestamp: new Date(),
      aggregateId,
      aggregateType,
      data,
      metadata,
    };
  }

  // أحداث المستخدمين | User Events
  static userRegistered(userId: string, data: { phone: string; name?: string }): DomainEvent {
    return this.create(EventTypes.USER_REGISTERED, userId, 'User', data);
  }

  static userVerified(userId: string): DomainEvent {
    return this.create(EventTypes.USER_VERIFIED, userId, 'User', {});
  }

  // أحداث الإقامات | Accommodation Events
  static accommodationCreated(accommodationId: string, data: { hostId: string; title: string }): DomainEvent {
    return this.create(EventTypes.ACCOMMODATION_CREATED, accommodationId, 'Accommodation', data);
  }

  static accommodationApproved(accommodationId: string, data: { adminId: string }): DomainEvent {
    return this.create(EventTypes.ACCOMMODATION_APPROVED, accommodationId, 'Accommodation', data);
  }

  // أحداث الحجوزات | Booking Events
  static bookingCreated(bookingId: string, data: { 
    guestId: string; 
    accommodationId: string; 
    checkIn: Date; 
    checkOut: Date; 
    totalAmount: number 
  }): DomainEvent {
    return this.create(EventTypes.BOOKING_CREATED, bookingId, 'Booking', {
      ...data,
      checkIn: data.checkIn.toISOString(),
      checkOut: data.checkOut.toISOString(),
    });
  }

  static bookingConfirmed(bookingId: string, data: { hostId: string }): DomainEvent {
    return this.create(EventTypes.BOOKING_CONFIRMED, bookingId, 'Booking', data);
  }

  static bookingCancelled(bookingId: string, data: { reason?: string; cancelledBy: string }): DomainEvent {
    return this.create(EventTypes.BOOKING_CANCELLED, bookingId, 'Booking', data);
  }

  // أحداث الدفع | Payment Events
  static paymentCompleted(paymentId: string, data: { bookingId: string; amount: number; method: string }): DomainEvent {
    return this.create(EventTypes.PAYMENT_COMPLETED, paymentId, 'Payment', data);
  }

  // أحداث الرسائل | Message Events
  static messageSent(messageId: string, data: { conversationId: string; senderId: string; content: string }): DomainEvent {
    return this.create(EventTypes.MESSAGE_SENT, messageId, 'Message', data);
  }

  // أحداث التقييمات | Review Events
  static reviewAdded(reviewId: string, data: { accommodationId: string; userId: string; rating: number }): DomainEvent {
    return this.create(EventTypes.REVIEW_ADDED, reviewId, 'Review', data);
  }
}

/**
 * ناشر الأحداث البسيط
 * Simple Event Publisher
 */
export class SimpleEventPublisher {
  private listeners: Map<string, Set<(event: DomainEvent) => Promise<void> | void>> = new Map();

  subscribe(eventType: string, listener: (event: DomainEvent) => Promise<void> | void): () => void {
    if (!this.listeners.has(eventType)) {
      this.listeners.set(eventType, new Set());
    }
    this.listeners.get(eventType)!.add(listener);

    // إرجاع دالة لإلغاء الاشتراك
    return () => {
      this.listeners.get(eventType)?.delete(listener);
    };
  }

  async publish(event: DomainEvent): Promise<void> {
    const listeners = this.listeners.get(event.type);
    if (listeners) {
      await Promise.all(
        Array.from(listeners).map(listener => listener(event))
      );
    }
  }

  async publishMany(events: DomainEvent[]): Promise<void> {
    await Promise.all(events.map(event => this.publish(event)));
  }
}

// مثيل عام | Global instance
export const eventPublisher = new SimpleEventPublisher();
