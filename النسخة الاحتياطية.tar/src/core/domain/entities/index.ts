// ═══════════════════════════════════════════════════════════════════════════
// Core Domain Entities - كيانات النطاق الأساسية
// ═══════════════════════════════════════════════════════════════════════════

/**
 * كيان المستخدم
 * User Entity
 */
export interface UserEntity {
  id: string;
  phone: string;
  email: string | null;
  name: string | null;
  nameAr: string | null;
  avatar: string | null;
  role: UserRole;
  status: UserStatus;
  isVerified: boolean;
  language: string;
  city: string | null;
  country: string;
  createdAt: Date;
  updatedAt: Date;
  lastLoginAt: Date | null;
}

export type UserRole = 'GUEST' | 'HOST' | 'ADMIN' | 'SUPER_ADMIN';
export type UserStatus = 'ACTIVE' | 'INACTIVE' | 'SUSPENDED' | 'PENDING_VERIFICATION';

/**
 * كيان المدينة
 * City Entity
 */
export interface CityEntity {
  id: string;
  nameAr: string;
  nameEn: string;
  governorate: string;
  region: string | null;
  isPopular: boolean;
  image: string | null;
  createdAt: Date;
}

/**
 * كيان الإقامة
 * Accommodation Entity
 */
export interface AccommodationEntity {
  id: string;
  titleAr: string;
  titleEn: string | null;
  descriptionAr: string | null;
  descriptionEn: string | null;
  type: AccommodationType;
  status: AccommodationStatus;
  
  // الموقع
  addressAr: string | null;
  cityId: string | null;
  latitude: number | null;
  longitude: number | null;
  
  // التفاصيل
  bedrooms: number;
  bathrooms: number;
  maxGuests: number;
  beds: number;
  size: number | null;
  
  // الأسعار
  basePrice: number;
  weekendPrice: number | null;
  cleaningFee: number | null;
  securityDeposit: number | null;
  
  // المعلومات
  amenities: string[];
  images: string[];
  coverImage: string | null;
  
  // التقييم
  rating: number;
  reviewCount: number;
  viewCount: number;
  bookingCount: number;
  
  // العلاقات
  hostId: string;
  cityId: string | null;
  
  createdAt: Date;
  updatedAt: Date;
}

export type AccommodationType = 
  | 'HOTEL' 
  | 'APARTMENT' 
  | 'VILLA' 
  | 'CHALET' 
  | 'CAMP' 
  | 'GUESTHOUSE' 
  | 'HOSTEL' 
  | 'RESORT';

export type AccommodationStatus = 
  | 'DRAFT' 
  | 'PENDING_APPROVAL' 
  | 'ACTIVE' 
  | 'INACTIVE' 
  | 'SUSPENDED';

/**
 * كيان الحجز
 * Booking Entity
 */
export interface BookingEntity {
  id: string;
  confirmationCode: string;
  status: BookingStatus;
  
  // التواريخ
  checkIn: Date;
  checkOut: Date;
  nightsCount: number;
  
  // الضيوف
  guestsCount: number;
  
  // المبالغ
  baseAmount: number;
  cleaningFee: number | null;
  serviceFee: number;
  guaranteeFee: number;
  discount: number;
  totalAmount: number;
  currency: string;
  
  // معلومات الضيف
  guestName: string | null;
  guestPhone: string | null;
  specialRequests: string | null;
  
  // العلاقات
  guestId: string;
  accommodationId: string;
  roomId: string | null;
  
  createdAt: Date;
  updatedAt: Date;
  confirmedAt: Date | null;
  cancelledAt: Date | null;
}

export type BookingStatus = 
  | 'PENDING' 
  | 'CONFIRMED' 
  | 'PAYMENT_PENDING' 
  | 'PAID' 
  | 'CHECKED_IN' 
  | 'CHECKED_OUT' 
  | 'CANCELLED' 
  | 'REFUNDED';

/**
 * كيان النقل
 * Transport Entity
 */
export interface TransportEntity {
  id: string;
  titleAr: string;
  titleEn: string | null;
  descriptionAr: string | null;
  type: TransportType;
  status: TransportStatus;
  
  // تفاصيل المركبة
  brand: string | null;
  model: string | null;
  year: number | null;
  color: string | null;
  seats: number;
  
  // الخدمات
  hasDriver: boolean;
  hasWifi: boolean;
  hasAC: boolean;
  hasGPS: boolean;
  
  // الأسعار
  basePrice: number;
  pricePerKm: number | null;
  pricePerHour: number | null;
  pricePerDay: number | null;
  
  // الوسائط
  images: string[];
  coverImage: string | null;
  
  // التقييم
  rating: number;
  reviewCount: number;
  viewCount: number;
  bookingCount: number;
  
  // العلاقات
  hostId: string;
  cityId: string | null;
  
  createdAt: Date;
  updatedAt: Date;
}

export type TransportType = 
  | 'CAR' 
  | 'CAR_WITH_DRIVER' 
  | 'BUS' 
  | 'MINIVAN' 
  | 'BOAT' 
  | 'HELICOPTER';

export type TransportStatus = 
  | 'DRAFT' 
  | 'PENDING_APPROVAL' 
  | 'ACTIVE' 
  | 'INACTIVE' 
  | 'SUSPENDED';

/**
 * كيان الجولة
 * Tour Entity
 */
export interface TourEntity {
  id: string;
  titleAr: string;
  titleEn: string | null;
  descriptionAr: string | null;
  type: TourType;
  status: TourStatus;
  
  // التفاصيل
  duration: number;
  maxGroupSize: number;
  minGroupSize: number;
  difficulty: string;
  
  // البرنامج
  itineraryAr: string[];
  highlights: string[];
  included: string[];
  excluded: string[];
  meetingPoint: string | null;
  
  // الأسعار
  basePrice: number;
  pricePerPerson: number | null;
  groupDiscount: number | null;
  childPrice: number | null;
  
  // الوسائط
  images: string[];
  coverImage: string | null;
  video: string | null;
  
  // التقييم
  rating: number;
  reviewCount: number;
  viewCount: number;
  bookingCount: number;
  
  // العلاقات
  guideId: string | null;
  cityId: string | null;
  
  createdAt: Date;
  updatedAt: Date;
}

export type TourType = 
  | 'CITY_TOUR' 
  | 'HISTORICAL' 
  | 'RELIGIOUS' 
  | 'ADVENTURE' 
  | 'MEDICAL' 
  | 'WAR_TOURISM' 
  | 'NATURE' 
  | 'FOOD' 
  | 'SHOPPING' 
  | 'CUSTOM';

export type TourStatus = 
  | 'DRAFT' 
  | 'PENDING_APPROVAL' 
  | 'ACTIVE' 
  | 'INACTIVE' 
  | 'SUSPENDED';

/**
 * كيان فرصة الأعمال
 * Business Listing Entity
 */
export interface BusinessListingEntity {
  id: string;
  titleAr: string;
  titleEn: string | null;
  descriptionAr: string | null;
  type: BusinessType;
  status: BusinessStatus;
  
  // التفاصيل
  sector: string | null;
  subsector: string | null;
  
  // للاستثمار
  investmentMin: number | null;
  investmentMax: number | null;
  expectedReturn: number | null;
  investmentPeriod: number | null;
  riskLevel: string | null;
  
  // للعقارات
  propertyType: string | null;
  size: number | null;
  isForSale: boolean;
  isForRent: boolean;
  salePrice: number | null;
  rentPrice: number | null;
  
  // الوسائط
  images: string[];
  coverImage: string | null;
  documents: string[];
  
  // الإحصائيات
  viewCount: number;
  inquiryCount: number;
  
  // العلاقات
  ownerId: string;
  cityId: string | null;
  
  createdAt: Date;
  updatedAt: Date;
}

export type BusinessType = 
  | 'INVESTMENT_OPPORTUNITY' 
  | 'COMMERCIAL_PROPERTY' 
  | 'BUSINESS_SERVICE' 
  | 'PARTNERSHIP' 
  | 'FRANCHISE';

export type BusinessStatus = 
  | 'DRAFT' 
  | 'PENDING_APPROVAL' 
  | 'ACTIVE' 
  | 'CLOSED' 
  | 'SUSPENDED';

/**
 * كيان التقييم
 * Review Entity
 */
export interface ReviewEntity {
  id: string;
  rating: number;
  commentAr: string | null;
  
  // التقييمات الفرعية
  cleanliness: number | null;
  location: number | null;
  value: number | null;
  communication: number | null;
  checkIn: number | null;
  
  isVerified: boolean;
  isVisible: boolean;
  
  // رد المضيف
  hostResponse: string | null;
  hostResponseAt: Date | null;
  
  // العلاقات
  userId: string;
  accommodationId: string;
  bookingId: string;
  
  createdAt: Date;
  updatedAt: Date;
}

/**
 * كيان المحادثة
 * Conversation Entity
 */
export interface ConversationEntity {
  id: string;
  type: string;
  status: string;
  
  // المشاركون
  guestId: string;
  hostId: string | null;
  
  // آخر رسالة
  lastMessage: string | null;
  lastMessageAt: Date | null;
  
  createdAt: Date;
  updatedAt: Date;
}

/**
 * كيان الرسالة
 * Message Entity
 */
export interface MessageEntity {
  id: string;
  content: string;
  type: string;
  isFromGuest: boolean;
  isRead: boolean;
  readAt: Date | null;
  
  // للردود التلقائية
  isAutoReply: boolean;
  
  // العلاقات
  conversationId: string;
  senderId: string;
  bookingId: string | null;
  
  createdAt: Date;
}
