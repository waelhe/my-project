// ═══════════════════════════════════════════════════════════════════════════
// Core Application Services - خدمات التطبيق الأساسية
// ═══════════════════════════════════════════════════════════════════════════

import { db } from '@/lib/db';
import type { 
  IRepository, 
  QueryOptions, 
  PaginatedResult,
  ICacheService,
  ILoggerService 
} from '../ports';

/**
 * مستودع Prisma الأساسي
 * Base Prisma Repository
 */
export abstract class BasePrismaRepository<T> implements IRepository<T> {
  protected abstract model: any;
  protected cache?: ICacheService;
  protected logger?: ILoggerService;

  constructor(cache?: ICacheService, logger?: ILoggerService) {
    this.cache = cache;
    this.logger = logger;
  }

  async findById(id: string): Promise<T | null> {
    try {
      const cacheKey = `${this.model.name}_${id}`;
      
      // تحقق من الكاش
      if (this.cache) {
        const cached = await this.cache.get<T>(cacheKey);
        if (cached) return cached;
      }

      const result = await this.model.findUnique({ where: { id } });
      
      // احفظ في الكاش
      if (result && this.cache) {
        await this.cache.set(cacheKey, result, 300); // 5 دقائق
      }
      
      return result;
    } catch (error) {
      this.logger?.error(`Failed to find ${this.model.name} by id`, error as Error);
      return null;
    }
  }

  async findByIds(ids: string[]): Promise<T[]> {
    if (ids.length === 0) return [];
    return this.model.findMany({ where: { id: { in: ids } } });
  }

  async findAll(options?: QueryOptions): Promise<PaginatedResult<T>> {
    const { filter = {}, sort, pagination = {} } = options || {};
    const { limit = 12, offset = 0 } = pagination;

    const orderBy = sort?.map(s => ({ [s.field]: s.direction })) || [];

    const [data, total] = await Promise.all([
      this.model.findMany({
        where: filter,
        orderBy,
        take: limit,
        skip: offset,
      }),
      this.model.count({ where: filter }),
    ]);

    return {
      data,
      total,
      limit,
      offset,
      hasMore: offset + limit < total,
    };
  }

  async findOne(filter: Record<string, unknown>): Promise<T | null> {
    return this.model.findFirst({ where: filter });
  }

  async count(filter?: Record<string, unknown>): Promise<number> {
    return this.model.count({ where: filter || {} });
  }

  async exists(id: string): Promise<boolean> {
    const count = await this.model.count({ where: { id } });
    return count > 0;
  }

  async create(data: Partial<T>): Promise<T> {
    const result = await this.model.create({ data });
    this.logger?.info(`Created ${this.model.name}`, { id: result.id });
    return result;
  }

  async createMany(data: Partial<T>[]): Promise<T[]> {
    const results = await this.model.createMany({ data, skipDuplicates: true });
    return results;
  }

  async update(id: string, data: Partial<T>): Promise<T> {
    const result = await this.model.update({ where: { id }, data });
    
    // امسح من الكاش
    if (this.cache) {
      await this.cache.delete(`${this.model.name}_${id}`);
    }
    
    this.logger?.info(`Updated ${this.model.name}`, { id });
    return result;
  }

  async updateMany(filter: Record<string, unknown>, data: Partial<T>): Promise<number> {
    const result = await this.model.updateMany({ where: filter, data });
    
    this.logger?.info(`Updated ${result.count} ${this.model.name} records`);
    return result.count;
  }

  async delete(id: string): Promise<boolean> {
    try {
      await this.model.delete({ where: { id } });
      
      if (this.cache) {
        await this.cache.delete(`${this.model.name}_${id}`);
      }
      
      this.logger?.info(`Deleted ${this.model.name}`, { id });
      return true;
    } catch {
      return false;
    }
  }

  async deleteMany(filter: Record<string, unknown>): Promise<number> {
    const result = await this.model.deleteMany({ where: filter });
    this.logger?.info(`Deleted ${result.count} ${this.model.name} records`);
    return result.count;
  }

  async transaction<R>(fn: (tx: any) => Promise<R>): Promise<R> {
    return db.$transaction(fn);
  }
}

/**
 * خدمة التخزين المؤقت في الذاكرة
 * In-Memory Cache Service
 */
export class MemoryCacheService implements ICacheService {
  private cache: Map<string, { value: unknown; expiresAt: number }> = new Map();
  private cleanupInterval: NodeJS.Timeout;

  constructor() {
    // تنظيف كل دقيقة
    this.cleanupInterval = setInterval(() => this.cleanup(), 60000);
  }

  async get<T>(key: string): Promise<T | null> {
    const item = this.cache.get(key);
    if (!item) return null;
    
    if (Date.now() > item.expiresAt) {
      this.cache.delete(key);
      return null;
    }
    
    return item.value as T;
  }

  async set<T>(key: string, value: T, ttl: number = 300): Promise<void> {
    this.cache.set(key, {
      value,
      expiresAt: Date.now() + ttl * 1000,
    });
  }

  async delete(key: string): Promise<void> {
    this.cache.delete(key);
  }

  async deletePattern(pattern: string): Promise<void> {
    const regex = new RegExp(pattern.replace('*', '.*'));
    for (const key of this.cache.keys()) {
      if (regex.test(key)) {
        this.cache.delete(key);
      }
    }
  }

  async exists(key: string): Promise<boolean> {
    const item = this.cache.get(key);
    if (!item) return false;
    
    if (Date.now() > item.expiresAt) {
      this.cache.delete(key);
      return false;
    }
    
    return true;
  }

  private cleanup(): void {
    const now = Date.now();
    for (const [key, item] of this.cache.entries()) {
      if (now > item.expiresAt) {
        this.cache.delete(key);
      }
    }
  }

  destroy(): void {
    clearInterval(this.cleanupInterval);
    this.cache.clear();
  }
}

/**
 * خدمة السجلات البسيطة
 * Simple Logger Service
 */
export class ConsoleLoggerService implements ILoggerService {
  private prefix: string;

  constructor(prefix: string = 'Dayf') {
    this.prefix = prefix;
  }

  private formatMessage(message: string, meta?: Record<string, unknown>): string {
    const timestamp = new Date().toISOString();
    const metaStr = meta ? ` ${JSON.stringify(meta)}` : '';
    return `[${timestamp}] [${this.prefix}] ${message}${metaStr}`;
  }

  debug(message: string, meta?: Record<string, unknown>): void {
    console.debug(this.formatMessage(message, meta));
  }

  info(message: string, meta?: Record<string, unknown>): void {
    console.info(this.formatMessage(message, meta));
  }

  warn(message: string, meta?: Record<string, unknown>): void {
    console.warn(this.formatMessage(message, meta));
  }

  error(message: string, error?: Error, meta?: Record<string, unknown>): void {
    const errorMeta = error ? { ...meta, error: error.message, stack: error.stack } : meta;
    console.error(this.formatMessage(message, errorMeta));
  }
}

// مثيلات عامة | Global instances
export const cacheService = new MemoryCacheService();
export const loggerService = new ConsoleLoggerService();
