// ═══════════════════════════════════════════════════════════════════════════
// Core Application Ports - Dependency Inversion Interfaces
// منافذ التطبيق - واجهات انقلاب الاعتماد
// ═══════════════════════════════════════════════════════════════════════════

/**
 * نمط Repository للوصول للبيانات
 * Repository Pattern for Data Access
 */
export interface IRepository<T, CreateDTO = Partial<T>, UpdateDTO = Partial<T>> {
  // القراءة | Read
  findById(id: string): Promise<T | null>;
  findByIds(ids: string[]): Promise<T[]>;
  findAll(options?: QueryOptions): Promise<PaginatedResult<T>>;
  findOne(filter: Record<string, unknown>): Promise<T | null>;
  count(filter?: Record<string, unknown>): Promise<number>;
  exists(id: string): Promise<boolean>;

  // الكتابة | Write
  create(data: CreateDTO): Promise<T>;
  createMany(data: CreateDTO[]): Promise<T[]>;
  update(id: string, data: UpdateDTO): Promise<T>;
  updateMany(filter: Record<string, unknown>, data: UpdateDTO): Promise<number>;
  delete(id: string): Promise<boolean>;
  deleteMany(filter: Record<string, unknown>): Promise<number>;

  // عمليات خاصة | Special Operations
  transaction<R>(fn: (tx: ITransaction) => Promise<R>): Promise<R>;
}

/**
 * خيارات الاستعلام
 * Query Options
 */
export interface QueryOptions {
  filter?: Record<string, unknown>;
  sort?: { field: string; direction: 'asc' | 'desc' }[];
  pagination?: {
    limit?: number;
    offset?: number;
    cursor?: string;
  };
  include?: string[];
}

/**
 * نتيجة الصفحات
 * Paginated Result
 */
export interface PaginatedResult<T> {
  data: T[];
  total: number;
  limit: number;
  offset: number;
  hasMore: boolean;
}

/**
 * معاملة قاعدة البيانات
 * Database Transaction
 */
export interface ITransaction {
  commit(): Promise<void>;
  rollback(): Promise<void>;
}

/**
 * مستمع الأحداث
 * Event Listener
 */
export type EventListener<T = unknown> = (event: T) => Promise<void> | void;

/**
 * ناشر الأحداث
 * Event Publisher
 */
export interface IEventPublisher {
  publish<T>(eventName: string, data: T): Promise<void>;
  subscribe<T>(eventName: string, listener: EventListener<T>): () => void;
}

/**
 * واجهة التخزين المؤقت
 * Cache Interface
 */
export interface ICacheService {
  get<T>(key: string): Promise<T | null>;
  set<T>(key: string, value: T, ttl?: number): Promise<void>;
  delete(key: string): Promise<void>;
  deletePattern(pattern: string): Promise<void>;
  exists(key: string): Promise<boolean>;
}

/**
 * واجهة السجلات
 * Logger Interface
 */
export interface ILoggerService {
  debug(message: string, meta?: Record<string, unknown>): void;
  info(message: string, meta?: Record<string, unknown>): void;
  warn(message: string, meta?: Record<string, unknown>): void;
  error(message: string, error?: Error, meta?: Record<string, unknown>): void;
}

/**
 * واجهة المصادقة
 * Authentication Interface
 */
export interface IAuthService {
  sendOTP(phone: string, purpose: 'login' | 'register' | 'verify'): Promise<OTPSendResult>;
  verifyOTP(phone: string, code: string): Promise<AuthResult>;
  getCurrentUser(): Promise<UserInfo | null>;
  logout(): Promise<void>;
  refreshSession(): Promise<AuthResult>;
}

export interface OTPSendResult {
  success: boolean;
  message: string;
  expiresIn: number;
}

export interface AuthResult {
  success: boolean;
  user?: UserInfo;
  token?: string;
  isNewUser?: boolean;
  error?: string;
}

export interface UserInfo {
  id: string;
  phone: string;
  name: string | null;
  role: 'GUEST' | 'HOST' | 'ADMIN' | 'SUPER_ADMIN';
  isVerified: boolean;
  avatar: string | null;
}

/**
 * واجهة الذكاء الاصطناعي
 * AI Service Interface
 */
export interface IAIProvider {
  // المحادثة
  chat(messages: ChatMessage[], options?: ChatOptions): Promise<string>;
  streamChat(messages: ChatMessage[], onChunk: (chunk: string) => void): Promise<void>;
  
  // الرؤية
  analyzeImage(image: string | Buffer, prompt?: string): Promise<ImageAnalysis>;
  
  // الصوت
  transcribe(audio: Buffer, language?: string): Promise<string>;
  synthesize(text: string, options?: TTSOptions): Promise<Buffer>;
}

export interface ChatMessage {
  role: 'system' | 'user' | 'assistant';
  content: string;
}

export interface ChatOptions {
  temperature?: number;
  maxTokens?: number;
  model?: string;
}

export interface ImageAnalysis {
  description: string;
  tags: string[];
  landmarks?: string[];
  confidence: number;
}

export interface TTSOptions {
  voice?: string;
  speed?: number;
  language?: string;
}

/**
 * واجهة الدفع
 * Payment Interface
 */
export interface IPaymentService {
  initiatePayment(amount: number, method: PaymentMethodType): Promise<PaymentInitResult>;
  verifyPayment(transactionId: string): Promise<PaymentVerifyResult>;
  refund(transactionId: string, amount?: number): Promise<RefundResult>;
}

export type PaymentMethodType = 'SYRIATEL' | 'MTN' | 'BANK_TRANSFER' | 'CASH';

export interface PaymentInitResult {
  success: boolean;
  transactionId?: string;
  paymentUrl?: string;
  reference?: string;
  error?: string;
}

export interface PaymentVerifyResult {
  success: boolean;
  status: 'pending' | 'completed' | 'failed';
  amount: number;
  paidAt?: Date;
}

export interface RefundResult {
  success: boolean;
  refundId?: string;
  error?: string;
}

/**
 * واجهة الإشعارات
 * Notification Interface
 */
export interface INotificationService {
  send(userId: string, notification: NotificationData): Promise<void>;
  sendToMany(userIds: string[], notification: NotificationData): Promise<void>;
  markAsRead(notificationId: string): Promise<void>;
  markAllAsRead(userId: string): Promise<void>;
}

export interface NotificationData {
  type: 'booking' | 'message' | 'review' | 'payment' | 'system';
  titleAr: string;
  bodyAr: string;
  data?: Record<string, unknown>;
}

/**
 * واجهة الرفع
 * Upload Interface
 */
export interface IUploadService {
  upload(file: File | Buffer, options?: UploadOptions): Promise<UploadResult>;
  delete(url: string): Promise<void>;
  getSignedUrl(key: string, expiresIn?: number): Promise<string>;
}

export interface UploadOptions {
  folder?: string;
  maxSize?: number;
  allowedTypes?: string[];
  public?: boolean;
}

export interface UploadResult {
  url: string;
  key: string;
  size: number;
  mimeType: string;
}

/**
 * واجهة البريد الإلكتروني
 * Email Interface
 */
export interface IEmailService {
  send(to: string, subject: string, body: string, options?: EmailOptions): Promise<void>;
  sendTemplate(to: string, templateId: string, data: Record<string, unknown>): Promise<void>;
}

export interface EmailOptions {
  from?: string;
  replyTo?: string;
  attachments?: Array<{ filename: string; content: Buffer }>;
}

/**
 * واجهة الرسائل النصية
 * SMS Interface
 */
export interface ISMSService {
  send(to: string, message: string): Promise<SMSResult>;
}

export interface SMSResult {
  success: boolean;
  messageId?: string;
  error?: string;
}
