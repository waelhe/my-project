import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET /api/admin/accommodations - Get accommodations for admin
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const status = searchParams.get('status')
    const cityId = searchParams.get('cityId')
    const hostId = searchParams.get('hostId')
    const search = searchParams.get('search')
    const limit = parseInt(searchParams.get('limit') || '20')
    const offset = parseInt(searchParams.get('offset') || '0')

    const whereClause: any = {}

    if (status && status !== 'all') {
      whereClause.status = status
    }

    if (cityId) {
      whereClause.cityId = cityId
    }

    if (hostId) {
      whereClause.hostId = hostId
    }

    if (search) {
      whereClause.OR = [
        { titleAr: { contains: search } },
        { titleEn: { contains: search } },
        { addressAr: { contains: search } }
      ]
    }

    const [accommodations, total] = await Promise.all([
      db.accommodation.findMany({
        where: whereClause,
        include: {
          city: {
            select: { id: true, nameAr: true, governorate: true }
          },
          host: {
            select: {
              id: true,
              name: true,
              nameAr: true,
              phone: true,
              avatar: true
            }
          },
          _count: {
            select: { bookings: true, reviews: true }
          }
        },
        orderBy: { createdAt: 'desc' },
        take: limit,
        skip: offset
      }),
      db.accommodation.count({ where: whereClause })
    ])

    return NextResponse.json({
      accommodations,
      pagination: {
        total,
        limit,
        offset,
        hasMore: offset + accommodations.length < total
      }
    })
  } catch (error) {
    console.error('Get admin accommodations error:', error)
    return NextResponse.json(
      { error: 'حدث خطأ في جلب الإقامات' },
      { status: 500 }
    )
  }
}
