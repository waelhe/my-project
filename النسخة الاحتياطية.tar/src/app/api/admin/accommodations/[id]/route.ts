import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET /api/admin/accommodations/[id] - Get single accommodation details
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params

    const accommodation = await db.accommodation.findUnique({
      where: { id },
      include: {
        city: true,
        host: {
          select: {
            id: true,
            name: true,
            nameAr: true,
            phone: true,
            email: true,
            avatar: true,
            role: true,
            createdAt: true
          }
        },
        rooms: true,
        availability: {
          take: 30,
          orderBy: { date: 'asc' }
        },
        reviews: {
          take: 10,
          orderBy: { createdAt: 'desc' },
          include: {
            user: {
              select: { id: true, name: true, nameAr: true, avatar: true }
            }
          }
        },
        _count: {
          select: { bookings: true, reviews: true, favorites: true }
        }
      }
    })

    if (!accommodation) {
      return NextResponse.json(
        { error: 'الإقامة غير موجودة' },
        { status: 404 }
      )
    }

    return NextResponse.json({ accommodation })
  } catch (error) {
    console.error('Get accommodation error:', error)
    return NextResponse.json(
      { error: 'حدث خطأ في جلب الإقامة' },
      { status: 500 }
    )
  }
}

// PUT /api/admin/accommodations/[id] - Update accommodation status
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const body = await request.json()
    const { status, rejectionReason, featured } = body

    // Check accommodation exists
    const existing = await db.accommodation.findUnique({
      where: { id },
      select: { id: true, hostId: true }
    })

    if (!existing) {
      return NextResponse.json(
        { error: 'الإقامة غير موجودة' },
        { status: 404 }
      )
    }

    // Update accommodation
    const accommodation = await db.accommodation.update({
      where: { id },
      data: {
        ...(status && { status }),
        ...(rejectionReason && { rejectionReason }),
        ...(featured !== undefined && { isFeatured: featured })
      }
    })

    // Create notification for host if approved or rejected
    if (status === 'ACTIVE') {
      await db.notification.create({
        data: {
          type: 'system',
          titleAr: 'تمت الموافقة على إقامتك',
          titleEn: 'Your accommodation has been approved',
          bodyAr: `تمت الموافقة على إقامتك وهي الآن متاحة للحجز`,
          bodyEn: `Your accommodation has been approved and is now available for booking`,
          userId: existing.hostId
        }
      })
    } else if (status === 'SUSPENDED' && rejectionReason) {
      await db.notification.create({
        data: {
          type: 'system',
          titleAr: 'تم رفض إقامتك',
          titleEn: 'Your accommodation has been rejected',
          bodyAr: `تم رفض إقامتك. السبب: ${rejectionReason}`,
          bodyEn: `Your accommodation has been rejected. Reason: ${rejectionReason}`,
          userId: existing.hostId
        }
      })
    }

    return NextResponse.json({
      success: true,
      message: 'تم تحديث حالة الإقامة بنجاح',
      accommodation
    })
  } catch (error) {
    console.error('Update accommodation error:', error)
    return NextResponse.json(
      { error: 'حدث خطأ في تحديث الإقامة' },
      { status: 500 }
    )
  }
}

// DELETE /api/admin/accommodations/[id] - Delete accommodation
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params

    // Check if there are active bookings
    const activeBookings = await db.booking.count({
      where: {
        accommodationId: id,
        status: { in: ['PENDING', 'CONFIRMED', 'CHECKED_IN'] }
      }
    })

    if (activeBookings > 0) {
      return NextResponse.json(
        { error: 'لا يمكن حذف الإقامة لوجود حجوزات نشطة' },
        { status: 400 }
      )
    }

    await db.accommodation.delete({
      where: { id }
    })

    return NextResponse.json({
      success: true,
      message: 'تم حذف الإقامة بنجاح'
    })
  } catch (error) {
    console.error('Delete accommodation error:', error)
    return NextResponse.json(
      { error: 'حدث خطأ في حذف الإقامة' },
      { status: 500 }
    )
  }
}
