import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET /api/admin/stats - Get admin dashboard statistics
export async function GET(request: NextRequest) {
  try {
    // Get all statistics in parallel
    const [
      totalUsers,
      totalHosts,
      totalGuests,
      totalAccommodations,
      pendingAccommodations,
      activeAccommodations,
      totalBookings,
      pendingBookings,
      confirmedBookings,
      completedBookings,
      totalRevenue,
      pendingPayments,
      totalReviews,
      totalConversations,
      recentUsers,
      recentBookings
    ] = await Promise.all([
      // Users count
      db.user.count(),
      db.user.count({ where: { role: 'HOST' } }),
      db.user.count({ where: { role: 'GUEST' } }),
      
      // Accommodations count
      db.accommodation.count(),
      db.accommodation.count({ where: { status: 'PENDING_APPROVAL' } }),
      db.accommodation.count({ where: { status: 'ACTIVE' } }),
      
      // Bookings count
      db.booking.count(),
      db.booking.count({ where: { status: 'PENDING' } }),
      db.booking.count({ where: { status: 'CONFIRMED' } }),
      db.booking.count({ where: { status: 'CHECKED_OUT' } }),
      
      // Revenue
      db.payment.aggregate({
        where: { status: 'COMPLETED' },
        _sum: { amount: true }
      }),
      db.payment.aggregate({
        where: { status: 'PENDING' },
        _sum: { amount: true }
      }),
      
      // Reviews count
      db.review.count(),
      
      // Conversations count
      db.conversation.count(),
      
      // Recent users (last 7 days)
      db.user.count({
        where: {
          createdAt: {
            gte: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)
          }
        }
      }),
      
      // Recent bookings (last 7 days)
      db.booking.count({
        where: {
          createdAt: {
            gte: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)
          }
        }
      })
    ])

    // Get bookings by month for chart
    const sixMonthsAgo = new Date()
    sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6)
    
    const bookingsByMonth = await db.booking.groupBy({
      by: ['status'],
      _count: { id: true },
      where: {
        createdAt: { gte: sixMonthsAgo }
      }
    })

    // Get revenue by month
    const revenueByMonth = await db.payment.groupBy({
      by: ['createdAt'],
      _sum: { amount: true },
      where: {
        status: 'COMPLETED',
        createdAt: { gte: sixMonthsAgo }
      }
    })

    // Get top cities
    const topCities = await db.city.findMany({
      include: {
        _count: {
          select: { accommodations: true }
        }
      },
      orderBy: {
        accommodations: { _count: 'desc' }
      },
      take: 5
    })

    // Get top accommodation types
    const accommodationTypes = await db.accommodation.groupBy({
      by: ['type'],
      _count: { id: true }
    })

    return NextResponse.json({
      users: {
        total: totalUsers,
        hosts: totalHosts,
        guests: totalGuests,
        recent: recentUsers
      },
      accommodations: {
        total: totalAccommodations,
        pending: pendingAccommodations,
        active: activeAccommodations
      },
      bookings: {
        total: totalBookings,
        pending: pendingBookings,
        confirmed: confirmedBookings,
        completed: completedBookings,
        recent: recentBookings,
        byStatus: bookingsByMonth
      },
      revenue: {
        total: totalRevenue._sum.amount || 0,
        pending: pendingPayments._sum.amount || 0
      },
      reviews: totalReviews,
      conversations: totalConversations,
      topCities: topCities.map(city => ({
        id: city.id,
        name: city.nameAr,
        count: city._count.accommodations
      })),
      accommodationTypes: accommodationTypes.map(t => ({
        type: t.type,
        count: t._count.id
      }))
    })
  } catch (error) {
    console.error('Get admin stats error:', error)
    return NextResponse.json(
      { error: 'حدث خطأ في جلب الإحصائيات' },
      { status: 500 }
    )
  }
}
