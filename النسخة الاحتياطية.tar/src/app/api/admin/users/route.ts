import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET /api/admin/users - Get all users with filters
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const role = searchParams.get('role')
    const status = searchParams.get('status')
    const search = searchParams.get('search')
    const limit = parseInt(searchParams.get('limit') || '20')
    const offset = parseInt(searchParams.get('offset') || '0')

    const whereClause: any = {}

    if (role && role !== 'all') {
      whereClause.role = role
    }

    if (status && status !== 'all') {
      whereClause.status = status
    }

    if (search) {
      whereClause.OR = [
        { name: { contains: search } },
        { nameAr: { contains: search } },
        { phone: { contains: search } },
        { email: { contains: search } }
      ]
    }

    const [users, total] = await Promise.all([
      db.user.findMany({
        where: whereClause,
        select: {
          id: true,
          phone: true,
          name: true,
          nameAr: true,
          email: true,
          avatar: true,
          role: true,
          status: true,
          isVerified: true,
          city: true,
          createdAt: true,
          lastLoginAt: true,
          _count: {
            select: {
              accommodations: true,
              bookingsAsGuest: true,
              reviews: true
            }
          }
        },
        orderBy: { createdAt: 'desc' },
        take: limit,
        skip: offset
      }),
      db.user.count({ where: whereClause })
    ])

    return NextResponse.json({
      users,
      pagination: {
        total,
        limit,
        offset,
        hasMore: offset + users.length < total
      }
    })
  } catch (error) {
    console.error('Get admin users error:', error)
    return NextResponse.json(
      { error: 'حدث خطأ في جلب المستخدمين' },
      { status: 500 }
    )
  }
}
