import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET /api/admin/users/[id] - Get single user details
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params

    const user = await db.user.findUnique({
      where: { id },
      select: {
        id: true,
        phone: true,
        name: true,
        nameAr: true,
        email: true,
        avatar: true,
        role: true,
        status: true,
        isVerified: true,
        language: true,
        city: true,
        country: true,
        businessName: true,
        businessNameAr: true,
        businessType: true,
        commercialReg: true,
        createdAt: true,
        updatedAt: true,
        lastLoginAt: true,
        _count: {
          select: {
            accommodations: true,
            bookingsAsGuest: true,
            reviews: true,
            sentMessages: true,
            notifications: true,
            favorites: true,
            sessions: true
          }
        },
        accommodations: {
          take: 5,
          select: {
            id: true,
            titleAr: true,
            status: true,
            rating: true,
            _count: { select: { bookings: true } }
          }
        },
        bookingsAsGuest: {
          take: 5,
          orderBy: { createdAt: 'desc' },
          select: {
            id: true,
            status: true,
            totalAmount: true,
            createdAt: true,
            accommodation: { select: { titleAr: true } }
          }
        }
      }
    })

    if (!user) {
      return NextResponse.json(
        { error: 'المستخدم غير موجود' },
        { status: 404 }
      )
    }

    return NextResponse.json({ user })
  } catch (error) {
    console.error('Get user error:', error)
    return NextResponse.json(
      { error: 'حدث خطأ في جلب المستخدم' },
      { status: 500 }
    )
  }
}

// PUT /api/admin/users/[id] - Update user (role, status)
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const body = await request.json()
    const { role, status, suspensionReason } = body

    const user = await db.user.findUnique({
      where: { id },
      select: { id: true, name: true, nameAr: true, email: true, phone: true }
    })

    if (!user) {
      return NextResponse.json(
        { error: 'المستخدم غير موجود' },
        { status: 404 }
      )
    }

    // Update user
    const updatedUser = await db.user.update({
      where: { id },
      data: {
        ...(role && { role }),
        ...(status && { status }),
        ...(status === 'SUSPENDED' && suspensionReason && {
          // Store suspension reason in a log or notification
        })
      }
    })

    // Create notification for user
    if (status === 'SUSPENDED') {
      await db.notification.create({
        data: {
          type: 'system',
          titleAr: 'تم تعليق حسابك',
          titleEn: 'Your account has been suspended',
          bodyAr: suspensionReason || 'تم تعليق حسابك لانتهاك شروط الاستخدام',
          bodyEn: suspensionReason || 'Your account has been suspended for violating terms of use',
          userId: id
        }
      })
    } else if (status === 'ACTIVE') {
      await db.notification.create({
        data: {
          type: 'system',
          titleAr: 'تم تفعيل حسابك',
          titleEn: 'Your account has been activated',
          bodyAr: 'تم تفعيل حسابك ويمكنك الآن استخدام جميع الخدمات',
          bodyEn: 'Your account has been activated and you can now use all services',
          userId: id
        }
      })
    }

    return NextResponse.json({
      success: true,
      message: 'تم تحديث المستخدم بنجاح',
      user: updatedUser
    })
  } catch (error) {
    console.error('Update user error:', error)
    return NextResponse.json(
      { error: 'حدث خطأ في تحديث المستخدم' },
      { status: 500 }
    )
  }
}

// DELETE /api/admin/users/[id] - Delete user (soft delete)
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params

    // Check for active bookings
    const activeBookings = await db.booking.count({
      where: {
        OR: [
          { guestId: id },
          { accommodation: { hostId: id } }
        ],
        status: { in: ['PENDING', 'CONFIRMED', 'CHECKED_IN'] }
      }
    })

    if (activeBookings > 0) {
      return NextResponse.json(
        { error: 'لا يمكن حذف المستخدم لوجود حجوزات نشطة' },
        { status: 400 }
      )
    }

    // Delete user sessions first
    await db.session.deleteMany({
      where: { userId: id }
    })

    // Delete user (this will cascade delete related records)
    await db.user.delete({
      where: { id }
    })

    return NextResponse.json({
      success: true,
      message: 'تم حذف المستخدم بنجاح'
    })
  } catch (error) {
    console.error('Delete user error:', error)
    return NextResponse.json(
      { error: 'حدث خطأ في حذف المستخدم' },
      { status: 500 }
    )
  }
}
