import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { requireHost } from '@/lib/auth-middleware';
import { z } from 'zod';

// Valid transport types
const transportTypes = [
  'CAR',
  'CAR_WITH_DRIVER',
  'BUS',
  'MINIVAN',
  'BOAT',
  'HELICOPTER'
] as const;

/**
 * Transport filter validation schema
 * التحقق من صحة فلترة المركبات
 */
const transportFilterSchema = z.object({
  cityId: z.string().cuid({ message: 'معرف المدينة غير صالح' }).optional(),
  type: z.enum(transportTypes, { message: 'نوع المركبة غير صالح' }).optional(),
  hasDriver: z
    .string()
    .transform(val => val === 'true')
    .optional(),
  minPrice: z
    .number()
    .positive({ message: 'الحد الأدنى للسعر يجب أن يكون موجباً' })
    .optional(),
  maxPrice: z
    .number()
    .positive({ message: 'الحد الأقصى للسعر يجب أن يكون موجباً' })
    .optional(),
  limit: z
    .number()
    .int()
    .min(1, { message: 'الحد الأدنى للنتائج 1' })
    .max(100, { message: 'الحد الأقصى للنتائج 100' })
    .optional()
    .default(12),
  offset: z
    .number()
    .int()
    .min(0, { message: 'الإزاحة لا يمكن أن تكون سالبة' })
    .optional()
    .default(0)
});

/**
 * Create transport validation schema
 * التحقق من صحة إنشاء مركبة جديدة
 */
const createTransportSchema = z.object({
  // Title (required)
  titleAr: z
    .string('العنوان بالعربية مطلوب')
    .trim()
    .min(3, { message: 'العنوان بالعربية يجب أن يكون 3 أحرف على الأقل' })
    .max(100, { message: 'العنوان بالعربية طويل جداً' }),
  
  titleEn: z
    .string()
    .trim()
    .min(3, { message: 'English title must be at least 3 characters' })
    .max(100, { message: 'English title is too long' })
    .optional()
    .or(z.literal('')),

  // Description
  descriptionAr: z
    .string()
    .trim()
    .max(2000, { message: 'الوصف طويل جداً' })
    .optional()
    .or(z.literal('')),
  
  descriptionEn: z
    .string()
    .trim()
    .max(2000, { message: 'Description is too long' })
    .optional()
    .or(z.literal('')),

  // Type (required)
  type: z
    .enum(transportTypes, { message: 'نوع المركبة غير صالح' }),

  // Vehicle details
  brand: z
    .string()
    .trim()
    .max(50, { message: 'الماركة طويلة جداً' })
    .optional()
    .or(z.literal('')),
  
  model: z
    .string()
    .trim()
    .max(50, { message: 'الموديل طويل جداً' })
    .optional()
    .or(z.literal('')),
  
  year: z
    .number()
    .int({ message: 'سنة الصنع يجب أن تكون رقماً صحيحاً' })
    .min(1990, { message: 'سنة الصنع يجب أن تكون 1990 أو أحدث' })
    .max(new Date().getFullYear() + 1, { message: 'سنة الصنع غير صالحة' })
    .optional(),
  
  color: z
    .string()
    .trim()
    .max(30, { message: 'اللون طويل جداً' })
    .optional()
    .or(z.literal('')),
  
  plateNumber: z
    .string()
    .trim()
    .max(20, { message: 'رقم اللوحة طويل جداً' })
    .optional()
    .or(z.literal('')),
  
  seats: z
    .number()
    .int({ message: 'عدد المقاعد يجب أن يكون رقماً صحيحاً' })
    .min(1, { message: 'يجب أن يكون مقعد واحد على الأقل' })
    .max(100, { message: 'عدد المقاعد كبير جداً' })
    .optional()
    .default(4),
  
  transmission: z
    .enum(['auto', 'manual'], { message: 'ناقل الحركة غير صالح' })
    .optional(),
  
  fuelType: z
    .string()
    .trim()
    .max(20, { message: 'نوع الوقود طويل جداً' })
    .optional()
    .or(z.literal('')),

  // Location
  cityId: z
    .string()
    .cuid({ message: 'معرف المدينة غير صالح' })
    .optional(),
  
  addressAr: z
    .string()
    .trim()
    .max(200, { message: 'العنوان طويل جداً' })
    .optional()
    .or(z.literal('')),
  
  addressEn: z
    .string()
    .trim()
    .max(200, { message: 'Address is too long' })
    .optional()
    .or(z.literal('')),

  // Services
  hasDriver: z.boolean().optional().default(false),
  hasWifi: z.boolean().optional().default(false),
  hasAC: z.boolean().optional().default(true),
  hasGPS: z.boolean().optional().default(false),
  allowsPets: z.boolean().optional().default(false),
  allowsSmoking: z.boolean().optional().default(false),

  // Pricing (required)
  basePrice: z
    .number('السعر الأساسي مطلوب')
    .positive({ message: 'السعر الأساسي يجب أن يكون رقماً موجباً' })
    .max(100000000, { message: 'السعر كبير جداً' }),
  
  pricePerKm: z
    .number()
    .positive({ message: 'سعر الكيلومتر يجب أن يكون رقماً موجباً' })
    .max(1000000, { message: 'السعر كبير جداً' })
    .optional(),
  
  pricePerHour: z
    .number()
    .positive({ message: 'سعر الساعة يجب أن يكون رقماً موجباً' })
    .max(1000000, { message: 'السعر كبير جداً' })
    .optional(),
  
  pricePerDay: z
    .number()
    .positive({ message: 'سعر اليوم يجب أن يكون رقماً موجباً' })
    .max(10000000, { message: 'السعر كبير جداً' })
    .optional(),
  
  deposit: z
    .number()
    .min(0, { message: 'التأمين لا يمكن أن يكون سالباً' })
    .max(100000000, { message: 'التأمين كبير جداً' })
    .optional(),

  // Media
  images: z
    .array(
      z.string().url({ message: 'رابط الصورة غير صالح' })
    )
    .max(20, { message: 'عدد الصور كبير جداً' })
    .optional()
    .default([]),
  
  coverImage: z
    .string()
    .url({ message: 'رابط صورة الغلاف غير صالح' })
    .optional()
    .or(z.literal(''))
});

/**
 * Sanitize string input to prevent XSS
 * ينظّح النص لمنع هجمات XSS
 */
function sanitizeString(input: string): string {
  return input
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#x27;')
    .replace(/\//g, '&#x2F;');
}

/**
 * GET /api/transports - List transports (Public)
 * الحصول على قائمة المركبات (عام)
 */
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    
    // Parse query parameters
    const queryParams = {
      cityId: searchParams.get('cityId') || undefined,
      type: searchParams.get('type') || undefined,
      hasDriver: searchParams.get('hasDriver') || undefined,
      minPrice: searchParams.get('minPrice') ? parseFloat(searchParams.get('minPrice')!) : undefined,
      maxPrice: searchParams.get('maxPrice') ? parseFloat(searchParams.get('maxPrice')!) : undefined,
      limit: parseInt(searchParams.get('limit') || '12'),
      offset: parseInt(searchParams.get('offset') || '0')
    };

    // Validate query parameters
    const parseResult = transportFilterSchema.safeParse(queryParams);
    if (!parseResult.success) {
      const firstError = parseResult.error.issues[0]?.message || 'بيانات غير صالحة';
      return NextResponse.json(
        { error: firstError },
        { status: 400 }
      );
    }

    const { cityId, type, hasDriver, minPrice, maxPrice, limit, offset } = parseResult.data;

    // Build filter
    const where: Record<string, unknown> = {
      status: 'ACTIVE'
    };

    if (cityId) {
      where.cityId = cityId;
    }

    if (type) {
      where.type = type;
    }

    if (hasDriver !== undefined) {
      where.hasDriver = hasDriver;
    }

    if (minPrice || maxPrice) {
      where.basePrice = {
        ...(minPrice && { gte: minPrice }),
        ...(maxPrice && { lte: maxPrice })
      };
    }

    // Fetch transports
    const transports = await db.transport.findMany({
      where,
      take: limit,
      skip: offset,
      orderBy: [
        { rating: 'desc' },
        { createdAt: 'desc' }
      ],
      include: {
        city: true,
        host: {
          select: {
            id: true,
            name: true,
            avatar: true
          }
        }
      }
    });

    // Get total count for pagination
    const total = await db.transport.count({ where });

    return NextResponse.json({
      transports: transports.map(transport => ({
        ...transport,
        images: transport.images ? JSON.parse(transport.images) : []
      })),
      pagination: {
        total,
        limit,
        offset,
        hasMore: offset + limit < total
      }
    });

  } catch (error) {
    console.error('Get transports error:', error);
    return NextResponse.json(
      { error: 'حدث خطأ في جلب البيانات' },
      { status: 500 }
    );
  }
}

/**
 * POST /api/transports - Create transport (Host only)
 * إنشاء مركبة جديدة (للمضيفين فقط)
 */
export async function POST(request: NextRequest) {
  try {
    // Require host authentication
    const authResult = await requireHost(request);
    
    if (authResult instanceof NextResponse) {
      return authResult; // Return error response
    }

    const { user } = authResult;

    // Parse request body
    let body;
    try {
      body = await request.json();
    } catch {
      return NextResponse.json(
        { error: 'بيانات غير صالحة' },
        { status: 400 }
      );
    }

    // Validate input
    const parseResult = createTransportSchema.safeParse(body);
    if (!parseResult.success) {
      const firstError = parseResult.error.issues[0]?.message || 'بيانات غير صالحة';
      return NextResponse.json(
        { error: firstError },
        { status: 400 }
      );
    }

    const validatedData = parseResult.data;

    // Verify city exists if provided
    if (validatedData.cityId) {
      const city = await db.city.findUnique({
        where: { id: validatedData.cityId }
      });

      if (!city) {
        return NextResponse.json(
          { error: 'المدينة غير موجودة' },
          { status: 400 }
        );
      }
    }

    // Create transport
    const transport = await db.transport.create({
      data: {
        titleAr: sanitizeString(validatedData.titleAr),
        titleEn: validatedData.titleEn ? sanitizeString(validatedData.titleEn) : null,
        descriptionAr: validatedData.descriptionAr ? sanitizeString(validatedData.descriptionAr) : null,
        descriptionEn: validatedData.descriptionEn ? sanitizeString(validatedData.descriptionEn) : null,
        type: validatedData.type as 'CAR' | 'CAR_WITH_DRIVER' | 'BUS' | 'MINIVAN' | 'BOAT' | 'HELICOPTER',
        brand: validatedData.brand || null,
        model: validatedData.model || null,
        year: validatedData.year || null,
        color: validatedData.color || null,
        plateNumber: validatedData.plateNumber || null,
        seats: validatedData.seats || 4,
        transmission: validatedData.transmission || null,
        fuelType: validatedData.fuelType || null,
        cityId: validatedData.cityId || null,
        addressAr: validatedData.addressAr || null,
        addressEn: validatedData.addressEn || null,
        hasDriver: validatedData.hasDriver || false,
        hasWifi: validatedData.hasWifi || false,
        hasAC: validatedData.hasAC ?? true,
        hasGPS: validatedData.hasGPS || false,
        allowsPets: validatedData.allowsPets || false,
        allowsSmoking: validatedData.allowsSmoking || false,
        basePrice: validatedData.basePrice,
        pricePerKm: validatedData.pricePerKm || null,
        pricePerHour: validatedData.pricePerHour || null,
        pricePerDay: validatedData.pricePerDay || null,
        deposit: validatedData.deposit || null,
        images: validatedData.images && validatedData.images.length > 0 
          ? JSON.stringify(validatedData.images) 
          : null,
        coverImage: validatedData.coverImage || null,
        hostId: user.id,
        status: 'PENDING_APPROVAL'
      },
      include: {
        city: true,
        host: {
          select: {
            id: true,
            name: true,
            avatar: true
          }
        }
      }
    });

    return NextResponse.json({
      success: true,
      message: 'تم إنشاء إعلان المركبة بنجاح وهو قيد المراجعة',
      transport: {
        ...transport,
        images: transport.images ? JSON.parse(transport.images) : []
      }
    }, { status: 201 });

  } catch (error) {
    console.error('Create transport error:', error);
    return NextResponse.json(
      { error: 'حدث خطأ في إنشاء الإعلان' },
      { status: 500 }
    );
  }
}
