// ═══════════════════════════════════════════════════════════════════════════
// Transport Details API
// واجهة تفاصيل المركبة
// ═══════════════════════════════════════════════════════════════════════════

import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

interface RouteParams {
  params: Promise<{ id: string }>;
}

/**
 * GET - Get transport by ID
 * الحصول على تفاصيل المركبة
 */
export async function GET(request: NextRequest, { params }: RouteParams) {
  try {
    const { id } = await params;

    const transport = await db.transport.findUnique({
      where: { id },
      include: {
        city: {
          select: { 
            id: true, 
            nameAr: true, 
            nameEn: true, 
            governorate: true,
            image: true 
          }
        },
        host: {
          select: {
            id: true,
            name: true,
            avatar: true,
            phone: true,
            createdAt: true,
            transports: {
              where: { status: 'ACTIVE' },
              select: { id: true, rating: true, reviewCount: true }
            }
          }
        }
      }
    });

    if (!transport) {
      return NextResponse.json(
        { success: false, error: 'المركبة غير موجودة' },
        { status: 404 }
      );
    }

    // Increment view count
    await db.transport.update({
      where: { id },
      data: { viewCount: { increment: 1 } }
    });

    // Calculate host stats
    const hostStats = {
      totalListings: transport.host.transports.length,
      averageRating: transport.host.transports.length > 0
        ? transport.host.transports.reduce((sum, t) => sum + t.rating, 0) / transport.host.transports.length
        : 0,
      totalReviews: transport.host.transports.reduce((sum, t) => sum + t.reviewCount, 0),
      hostingSince: transport.host.createdAt
    };

    // Parse JSON fields
    const parsedTransport = {
      ...transport,
      images: transport.images ? JSON.parse(transport.images) : [],
      reviews: [] // Empty for now, will be fetched separately
    };

    return NextResponse.json({
      success: true,
      transport: parsedTransport,
      hostStats
    });

  } catch (error) {
    console.error('Get transport error:', error);
    return NextResponse.json(
      { success: false, error: 'حدث خطأ في جلب البيانات' },
      { status: 500 }
    );
  }
}
