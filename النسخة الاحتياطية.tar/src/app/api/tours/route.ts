import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { requireHost } from '@/lib/auth-middleware';

// Valid tour types from schema
const tourTypes = [
  'CITY_TOUR',
  'HISTORICAL',
  'RELIGIOUS',
  'ADVENTURE',
  'MEDICAL',
  'WAR_TOURISM',
  'NATURE',
  'FOOD',
  'SHOPPING',
  'CUSTOM'
] as const;

/**
 * GET /api/tours - List tours (Public)
 * الحصول على قائمة الجولات السياحية (عام)
 */
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    
    // Parse query parameters
    const cityId = searchParams.get('cityId') || undefined;
    const type = searchParams.get('type') || undefined;
    const duration = searchParams.get('duration') ? parseInt(searchParams.get('duration')!) : undefined;
    const minPrice = searchParams.get('minPrice') ? parseFloat(searchParams.get('minPrice')!) : undefined;
    const maxPrice = searchParams.get('maxPrice') ? parseFloat(searchParams.get('maxPrice')!) : undefined;
    const limit = parseInt(searchParams.get('limit') || '12');
    const offset = parseInt(searchParams.get('offset') || '0');

    // Build filter
    const where: Record<string, unknown> = {
      status: 'ACTIVE'
    };

    if (cityId) {
      where.cityId = cityId;
    }

    if (type && tourTypes.includes(type as typeof tourTypes[number])) {
      where.type = type;
    }

    if (duration) {
      where.duration = duration;
    }

    if (minPrice || maxPrice) {
      where.basePrice = {
        ...(minPrice && { gte: minPrice }),
        ...(maxPrice && { lte: maxPrice })
      };
    }

    // Fetch tours
    const tours = await db.tour.findMany({
      where,
      take: limit,
      skip: offset,
      orderBy: [
        { rating: 'desc' },
        { createdAt: 'desc' }
      ],
      include: {
        city: true,
        guide: {
          select: {
            id: true,
            name: true,
            avatar: true,
            phone: true
          }
        }
      }
    });

    // Get total count for pagination
    const total = await db.tour.count({ where });

    return NextResponse.json({
      tours: tours.map(tour => ({
        ...tour,
        images: tour.images ? JSON.parse(tour.images) : [],
        itineraryAr: tour.itineraryAr ? JSON.parse(tour.itineraryAr) : [],
        itineraryEn: tour.itineraryEn ? JSON.parse(tour.itineraryEn) : [],
        highlights: tour.highlights ? JSON.parse(tour.highlights) : [],
        included: tour.included ? JSON.parse(tour.included) : [],
        excluded: tour.excluded ? JSON.parse(tour.excluded) : [],
        languages: tour.languages ? JSON.parse(tour.languages) : []
      })),
      pagination: {
        total,
        limit,
        offset,
        hasMore: offset + limit < total
      }
    });

  } catch (error) {
    console.error('Get tours error:', error);
    return NextResponse.json(
      { error: 'حدث خطأ في جلب البيانات' },
      { status: 500 }
    );
  }
}

/**
 * POST /api/tours - Create tour (Host only)
 * إنشاء جولة سياحية جديدة (للمضيفين فقط)
 */
export async function POST(request: NextRequest) {
  try {
    // Require host authentication
    const authResult = await requireHost(request);
    
    if (authResult instanceof NextResponse) {
      return authResult; // Return error response
    }

    const { user } = authResult;

    // Parse request body
    let body;
    try {
      body = await request.json();
    } catch {
      return NextResponse.json(
        { error: 'بيانات غير صالحة' },
        { status: 400 }
      );
    }

    // Validate required fields
    const requiredFields = ['titleAr', 'type', 'duration', 'basePrice'];
    for (const field of requiredFields) {
      if (!body[field]) {
        return NextResponse.json(
          { error: `الحقل ${field} مطلوب` },
          { status: 400 }
        );
      }
    }

    // Validate tour type
    if (!tourTypes.includes(body.type)) {
      return NextResponse.json(
        { error: 'نوع الجولة غير صالح' },
        { status: 400 }
      );
    }

    // Validate duration
    if (typeof body.duration !== 'number' || body.duration < 1) {
      return NextResponse.json(
        { error: 'مدة الجولة يجب أن تكون رقماً موجباً' },
        { status: 400 }
      );
    }

    // Validate basePrice
    if (typeof body.basePrice !== 'number' || body.basePrice < 0) {
      return NextResponse.json(
        { error: 'السعر الأساسي يجب أن يكون رقماً موجباً' },
        { status: 400 }
      );
    }

    // Verify city exists if provided
    if (body.cityId) {
      const city = await db.city.findUnique({
        where: { id: body.cityId }
      });

      if (!city) {
        return NextResponse.json(
          { error: 'المدينة غير موجودة' },
          { status: 400 }
        );
      }
    }

    // Create tour
    const tour = await db.tour.create({
      data: {
        titleAr: body.titleAr,
        titleEn: body.titleEn || null,
        descriptionAr: body.descriptionAr || null,
        descriptionEn: body.descriptionEn || null,
        type: body.type,
        status: 'PENDING_APPROVAL',
        duration: body.duration,
        maxGroupSize: body.maxGroupSize || 10,
        minGroupSize: body.minGroupSize || 1,
        difficulty: body.difficulty || 'easy',
        itineraryAr: body.itineraryAr ? JSON.stringify(body.itineraryAr) : null,
        itineraryEn: body.itineraryEn ? JSON.stringify(body.itineraryEn) : null,
        highlights: body.highlights ? JSON.stringify(body.highlights) : null,
        included: body.included ? JSON.stringify(body.included) : null,
        excluded: body.excluded ? JSON.stringify(body.excluded) : null,
        meetingPoint: body.meetingPoint || null,
        cityId: body.cityId || null,
        region: body.region || null,
        languages: body.languages ? JSON.stringify(body.languages) : null,
        basePrice: body.basePrice,
        pricePerPerson: body.pricePerPerson || null,
        groupDiscount: body.groupDiscount || null,
        childPrice: body.childPrice || null,
        currency: body.currency || 'SYP',
        images: body.images ? JSON.stringify(body.images) : null,
        coverImage: body.coverImage || null,
        video: body.video || null,
        guideId: body.guideId || user.id
      },
      include: {
        city: true,
        guide: {
          select: {
            id: true,
            name: true,
            avatar: true,
            phone: true
          }
        }
      }
    });

    return NextResponse.json({
      success: true,
      message: 'تم إنشاء الجولة بنجاح وهي قيد المراجعة',
      tour: {
        ...tour,
        images: tour.images ? JSON.parse(tour.images) : [],
        itineraryAr: tour.itineraryAr ? JSON.parse(tour.itineraryAr) : [],
        itineraryEn: tour.itineraryEn ? JSON.parse(tour.itineraryEn) : [],
        highlights: tour.highlights ? JSON.parse(tour.highlights) : [],
        included: tour.included ? JSON.parse(tour.included) : [],
        excluded: tour.excluded ? JSON.parse(tour.excluded) : [],
        languages: tour.languages ? JSON.parse(tour.languages) : []
      }
    }, { status: 201 });

  } catch (error) {
    console.error('Create tour error:', error);
    return NextResponse.json(
      { error: 'حدث خطأ في إنشاء الجولة' },
      { status: 500 }
    );
  }
}
