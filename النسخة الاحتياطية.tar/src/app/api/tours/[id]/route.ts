// ═══════════════════════════════════════════════════════════════════════════
// Tour Details API
// واجهة تفاصيل الجولة السياحية
// ═══════════════════════════════════════════════════════════════════════════

import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

interface RouteParams {
  params: Promise<{ id: string }>;
}

/**
 * GET - Get tour by ID
 * الحصول على تفاصيل الجولة السياحية
 */
export async function GET(request: NextRequest, { params }: RouteParams) {
  try {
    const { id } = await params;

    const tour = await db.tour.findUnique({
      where: { id },
      include: {
        city: {
          select: {
            id: true,
            nameAr: true,
            nameEn: true,
            governorate: true,
            image: true
          }
        },
        guide: {
          select: {
            id: true,
            name: true,
            avatar: true,
            phone: true,
            createdAt: true,
            tours: {
              where: { status: 'ACTIVE' },
              select: { id: true, rating: true, reviewCount: true }
            }
          }
        }
      }
    });

    if (!tour) {
      return NextResponse.json(
        { success: false, error: 'الجولة غير موجودة' },
        { status: 404 }
      );
    }

    // Increment view count
    await db.tour.update({
      where: { id },
      data: { viewCount: { increment: 1 } }
    });

    // Calculate guide stats
    const guideStats = {
      totalTours: tour.guide.tours.length,
      averageRating: tour.guide.tours.length > 0
        ? tour.guide.tours.reduce((sum, t) => sum + t.rating, 0) / tour.guide.tours.length
        : 0,
      totalReviews: tour.guide.tours.reduce((sum, t) => sum + t.reviewCount, 0),
      guidingSince: tour.guide.createdAt
    };

    // Parse JSON fields
    const parsedTour = {
      ...tour,
      images: tour.images ? JSON.parse(tour.images) : [],
      itineraryAr: tour.itineraryAr ? JSON.parse(tour.itineraryAr) : [],
      itineraryEn: tour.itineraryEn ? JSON.parse(tour.itineraryEn) : [],
      highlights: tour.highlights ? JSON.parse(tour.highlights) : [],
      included: tour.included ? JSON.parse(tour.included) : [],
      excluded: tour.excluded ? JSON.parse(tour.excluded) : [],
      languages: tour.languages ? JSON.parse(tour.languages) : [],
      reviews: [] // Empty for now, will be fetched separately
    };

    return NextResponse.json({
      success: true,
      tour: parsedTour,
      guideStats
    });

  } catch (error) {
    console.error('Get tour error:', error);
    return NextResponse.json(
      { success: false, error: 'حدث خطأ في جلب البيانات' },
      { status: 500 }
    );
  }
}
