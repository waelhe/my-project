import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getClientIP, RateLimiter, createRateLimitHeaders } from '@/lib/rate-limiter';

const postLimiter = new RateLimiter({
  windowMs: 60 * 1000, // 1 minute
  maxRequests: 5,
  prefix: 'community-post'
});

/**
 * GET /api/community/posts
 * جلب المشاركات
 */
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const categoryId = searchParams.get('categoryId');
    const type = searchParams.get('type') as 'DISCUSSION' | 'QUESTION' | 'STORY' | 'ANNOUNCEMENT' | 'GUIDE' | null;
    const authorId = searchParams.get('authorId');
    const limit = parseInt(searchParams.get('limit') || '20');
    const offset = parseInt(searchParams.get('offset') || '0');
    const sort = searchParams.get('sort') || 'latest'; // latest, popular, featured

    const where: any = { status: 'PUBLISHED' };
    
    if (categoryId) where.categoryId = categoryId;
    if (type) where.type = type;
    if (authorId) where.authorId = authorId;

    // Sorting
    let orderBy: any[] = [
      { isPinned: 'desc' as const }
    ];

    switch (sort) {
      case 'popular':
        orderBy.push({ likeCount: 'desc' as const });
        orderBy.push({ commentCount: 'desc' as const });
        break;
      case 'featured':
        orderBy.push({ isFeatured: 'desc' as const });
        break;
      default:
        orderBy.push({ createdAt: 'desc' as const });
    }

    const [posts, total] = await Promise.all([
      db.communityPost.findMany({
        where,
        orderBy,
        take: limit,
        skip: offset,
        include: {
          author: {
            select: {
              id: true,
              name: true,
              nameAr: true,
              avatar: true,
              role: true
            }
          },
          category: {
            select: {
              id: true,
              nameAr: true,
              nameEn: true,
              icon: true,
              color: true
            }
          },
          _count: {
            select: {
              comments: { where: { isHidden: false } },
              likes: true
            }
          }
        }
      }),
      db.communityPost.count({ where })
    ]);

    // Format posts
    const formattedPosts = posts.map(post => ({
      id: post.id,
      titleAr: post.titleAr,
      titleEn: post.titleEn,
      contentAr: post.contentAr.substring(0, 200) + (post.contentAr.length > 200 ? '...' : ''),
      contentEn: post.contentEn?.substring(0, 200),
      type: post.type,
      viewCount: post.viewCount,
      likeCount: post.likeCount,
      commentCount: post.commentCount,
      isPinned: post.isPinned,
      isFeatured: post.isFeatured,
      tags: post.tags ? JSON.parse(post.tags) : [],
      images: post.images ? JSON.parse(post.images) : [],
      createdAt: post.createdAt,
      author: post.author,
      category: post.category,
      _count: post._count
    }));

    return NextResponse.json({
      success: true,
      posts: formattedPosts,
      pagination: {
        total,
        limit,
        offset,
        hasMore: offset + limit < total
      }
    });

  } catch (error) {
    console.error('Get posts error:', error);
    return NextResponse.json(
      { error: 'حدث خطأ في جلب المشاركات' },
      { status: 500 }
    );
  }
}

/**
 * POST /api/community/posts
 * إنشاء مشاركة جديدة
 */
export async function POST(request: NextRequest) {
  try {
    // Rate limiting
    const clientIP = getClientIP(request);
    const rateLimitResult = await postLimiter.check(clientIP);
    
    if (!rateLimitResult.success) {
      return NextResponse.json(
        { error: 'طلبات كثيرة جداً، يرجى الانتظار' },
        { 
          status: 429,
          headers: createRateLimitHeaders(rateLimitResult)
        }
      );
    }

    const body = await request.json();
    const { 
      titleAr, 
      titleEn, 
      contentAr, 
      contentEn, 
      type = 'DISCUSSION',
      categoryId,
      tags,
      images,
      authorId // سيتم استبداله بالـ user من الجلسة
    } = body;

    if (!titleAr || !contentAr) {
      return NextResponse.json(
        { error: 'العنوان والمحتوى بالعربية مطلوبان' },
        { status: 400 }
      );
    }

    if (!authorId) {
      return NextResponse.json(
        { error: 'يجب تسجيل الدخول للمشاركة' },
        { status: 401 }
      );
    }

    if (!db.communityPost) {
      return NextResponse.json(
        { error: 'الخدمة غير متاحة حالياً' },
        { status: 503 }
      );
    }

    const post = await db.communityPost.create({
      data: {
        titleAr,
        titleEn,
        contentAr,
        contentEn,
        type,
        categoryId,
        authorId,
        tags: tags ? JSON.stringify(tags) : null,
        images: images ? JSON.stringify(images) : null,
        status: 'PUBLISHED'
      },
      include: {
        author: {
          select: {
            id: true,
            name: true,
            nameAr: true,
            avatar: true
          }
        }
      }
    });

    // Update user reputation if model exists
    if (db.userReputation) {
      await db.userReputation.upsert({
        where: { userId: authorId },
        create: {
          userId: authorId,
          communityPoints: 10,
          postsCount: 1
        },
        update: {
          communityPoints: { increment: 10 },
          postsCount: { increment: 1 }
        }
      });
    }

    return NextResponse.json({
      success: true,
      post: {
        id: post.id,
        titleAr: post.titleAr,
        titleEn: post.titleEn,
        contentAr: post.contentAr,
        type: post.type,
        createdAt: post.createdAt,
        author: post.author
      }
    }, {
      headers: createRateLimitHeaders(rateLimitResult)
    });

  } catch (error) {
    console.error('Create post error:', error);
    return NextResponse.json(
      { error: 'حدث خطأ في إنشاء المشاركة' },
      { status: 500 }
    );
  }
}
