import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET /api/conversations/[id] - Get conversation with messages
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')
    const limit = parseInt(searchParams.get('limit') || '50')
    const before = searchParams.get('before') // message ID for pagination

    const conversation = await db.conversation.findUnique({
      where: { id },
      include: {
        guest: {
          select: { id: true, name: true, nameAr: true, avatar: true, phone: true }
        },
        host: {
          select: { id: true, name: true, nameAr: true, avatar: true, phone: true }
        },
        booking: {
          include: {
            accommodation: {
              select: { id: true, titleAr: true, coverImage: true, city: { select: { nameAr: true } } }
            }
          }
        }
      }
    })

    if (!conversation) {
      return NextResponse.json(
        { error: 'المحادثة غير موجودة' },
        { status: 404 }
      )
    }

    // Build messages query
    const messagesWhere: Record<string, unknown> = { conversationId: id }
    if (before) {
      messagesWhere.id = { lt: before }
    }

    const messages = await db.message.findMany({
      where: messagesWhere,
      include: {
        sender: {
          select: { id: true, name: true, nameAr: true, avatar: true }
        }
      },
      orderBy: { createdAt: 'desc' },
      take: limit
    })

    // Mark messages as read if user is the recipient
    if (userId) {
      const isGuest = conversation.guestId === userId
      await db.message.updateMany({
        where: {
          conversationId: id,
          isFromGuest: !isGuest,
          isRead: false
        },
        data: {
          isRead: true,
          readAt: new Date()
        }
      })
    }

    // Reverse messages to show oldest first
    const sortedMessages = messages.reverse()

    return NextResponse.json({
      conversation,
      messages: sortedMessages,
      hasMore: messages.length === limit
    })
  } catch (error) {
    console.error('Error fetching conversation:', error)
    return NextResponse.json(
      { error: 'حدث خطأ أثناء جلب المحادثة' },
      { status: 500 }
    )
  }
}

// POST /api/conversations/[id] - Send message
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const body = await request.json()
    const { senderId, content, type = 'text' } = body

    if (!senderId || !content) {
      return NextResponse.json(
        { error: 'بيانات غير مكتملة' },
        { status: 400 }
      )
    }

    // Get conversation
    const conversation = await db.conversation.findUnique({
      where: { id },
      include: {
        guest: { select: { id: true } },
        host: { select: { id: true } }
      }
    })

    if (!conversation) {
      return NextResponse.json(
        { error: 'المحادثة غير موجودة' },
        { status: 404 }
      )
    }

    // Determine if sender is guest or host
    const isFromGuest = conversation.guestId === senderId
    if (!isFromGuest && conversation.hostId !== senderId) {
      return NextResponse.json(
        { error: 'غير مصرح لك بإرسال رسالة في هذه المحادثة' },
        { status: 403 }
      )
    }

    // Create message
    const message = await db.message.create({
      data: {
        conversationId: id,
        senderId,
        content,
        type,
        isFromGuest,
        isRead: false
      },
      include: {
        sender: {
          select: { id: true, name: true, nameAr: true, avatar: true }
        }
      }
    })

    // Update conversation's last message
    await db.conversation.update({
      where: { id },
      data: {
        lastMessage: content.substring(0, 100),
        lastMessageAt: new Date()
      }
    })

    // Create notification for recipient
    const recipientId = isFromGuest ? conversation.hostId : conversation.guestId
    await db.notification.create({
      data: {
        userId: recipientId,
        type: 'message',
        titleAr: 'رسالة جديدة',
        bodyAr: content.substring(0, 100),
        data: JSON.stringify({ conversationId: id, messageId: message.id })
      }
    })

    return NextResponse.json({
      success: true,
      message
    })
  } catch (error) {
    console.error('Error sending message:', error)
    return NextResponse.json(
      { error: 'حدث خطأ أثناء إرسال الرسالة' },
      { status: 500 }
    )
  }
}
