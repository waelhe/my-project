import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET /api/conversations - Get user conversations
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')
    const type = searchParams.get('type') || 'all' // all, guest, host
    const limit = parseInt(searchParams.get('limit') || '20')
    const offset = parseInt(searchParams.get('offset') || '0')

    if (!userId) {
      return NextResponse.json(
        { error: 'معرف المستخدم مطلوب' },
        { status: 400 }
      )
    }

    const where: Record<string, unknown> = {}

    if (type === 'guest') {
      where.guestId = userId
    } else if (type === 'host') {
      where.hostId = userId
    } else {
      where.OR = [
        { guestId: userId },
        { hostId: userId }
      ]
    }

    const conversations = await db.conversation.findMany({
      where,
      include: {
        guest: {
          select: { id: true, name: true, nameAr: true, avatar: true, phone: true }
        },
        host: {
          select: { id: true, name: true, nameAr: true, avatar: true, phone: true }
        },
        messages: {
          orderBy: { createdAt: 'desc' },
          take: 1,
          select: {
            id: true,
            content: true,
            createdAt: true,
            isFromGuest: true,
            isRead: true
          }
        },
        booking: {
          include: {
            accommodation: {
              select: { id: true, titleAr: true, coverImage: true }
            }
          }
        }
      },
      orderBy: { updatedAt: 'desc' },
      take: limit,
      skip: offset
    })

    // Count unread messages
    const conversationsWithUnread = conversations.map(conv => {
      const lastMessage = conv.messages[0]
      const isCurrentUserGuest = conv.guestId === userId
      const isUnread = lastMessage && 
        ((isCurrentUserGuest && !lastMessage.isFromGuest && !lastMessage.isRead) ||
         (!isCurrentUserGuest && lastMessage.isFromGuest && !lastMessage.isRead))

      return {
        ...conv,
        hasUnread: !!isUnread
      }
    })

    return NextResponse.json({
      conversations: conversationsWithUnread
    })
  } catch (error) {
    console.error('Error fetching conversations:', error)
    return NextResponse.json(
      { error: 'حدث خطأ أثناء جلب المحادثات' },
      { status: 500 }
    )
  }
}

// POST /api/conversations - Create new conversation
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { guestId, hostId, bookingId, type = 'inquiry' } = body

    if (!guestId || !hostId) {
      return NextResponse.json(
        { error: 'بيانات غير مكتملة' },
        { status: 400 }
      )
    }

    // Check if conversation already exists
    const existingConv = await db.conversation.findFirst({
      where: {
        guestId,
        hostId,
        bookingId: bookingId || null
      }
    })

    if (existingConv) {
      return NextResponse.json({
        success: true,
        conversation: existingConv,
        isNew: false
      })
    }

    // Create new conversation
    const conversation = await db.conversation.create({
      data: {
        guestId,
        hostId,
        bookingId: bookingId || null,
        type,
        status: 'active'
      },
      include: {
        guest: {
          select: { id: true, name: true, nameAr: true, avatar: true }
        },
        host: {
          select: { id: true, name: true, nameAr: true, avatar: true }
        }
      }
    })

    return NextResponse.json({
      success: true,
      conversation,
      isNew: true
    })
  } catch (error) {
    console.error('Error creating conversation:', error)
    return NextResponse.json(
      { error: 'حدث خطأ أثناء إنشاء المحادثة' },
      { status: 500 }
    )
  }
}
