import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET /api/notifications - Get user notifications
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')
    const unreadOnly = searchParams.get('unreadOnly') === 'true'
    const type = searchParams.get('type')
    const limit = parseInt(searchParams.get('limit') || '20')
    const offset = parseInt(searchParams.get('offset') || '0')

    if (!userId) {
      return NextResponse.json(
        { error: 'معرف المستخدم مطلوب' },
        { status: 400 }
      )
    }

    const where: Record<string, unknown> = { userId }
    
    if (unreadOnly) {
      where.isRead = false
    }
    
    if (type) {
      where.type = type
    }

    const [notifications, unreadCount] = await Promise.all([
      db.notification.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        take: limit,
        skip: offset
      }),
      db.notification.count({
        where: { userId, isRead: false }
      })
    ])

    return NextResponse.json({
      notifications,
      unreadCount,
      pagination: {
        limit,
        offset,
        hasMore: notifications.length === limit
      }
    })
  } catch (error) {
    console.error('Error fetching notifications:', error)
    return NextResponse.json(
      { error: 'حدث خطأ أثناء جلب الإشعارات' },
      { status: 500 }
    )
  }
}

// PUT /api/notifications - Mark notifications as read
export async function PUT(request: NextRequest) {
  try {
    const body = await request.json()
    const { userId, notificationIds, markAllAsRead } = body

    if (!userId) {
      return NextResponse.json(
        { error: 'معرف المستخدم مطلوب' },
        { status: 400 }
      )
    }

    if (markAllAsRead) {
      await db.notification.updateMany({
        where: { userId, isRead: false },
        data: {
          isRead: true,
          readAt: new Date()
        }
      })

      return NextResponse.json({
        success: true,
        message: 'تم تحديد جميع الإشعارات كمقروءة'
      })
    }

    if (notificationIds && Array.isArray(notificationIds)) {
      await db.notification.updateMany({
        where: {
          id: { in: notificationIds },
          userId
        },
        data: {
          isRead: true,
          readAt: new Date()
        }
      })

      return NextResponse.json({
        success: true,
        message: 'تم تحديد الإشعارات كمقروءة'
      })
    }

    return NextResponse.json(
      { error: 'لم يتم تحديد أي إشعارات' },
      { status: 400 }
    )
  } catch (error) {
    console.error('Error updating notifications:', error)
    return NextResponse.json(
      { error: 'حدث خطأ أثناء تحديث الإشعارات' },
      { status: 500 }
    )
  }
}

// DELETE /api/notifications - Delete notifications
export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')
    const notificationIds = searchParams.get('ids')?.split(',')
    const clearAll = searchParams.get('clearAll') === 'true'

    if (!userId) {
      return NextResponse.json(
        { error: 'معرف المستخدم مطلوب' },
        { status: 400 }
      )
    }

    if (clearAll) {
      await db.notification.deleteMany({
        where: { userId }
      })

      return NextResponse.json({
        success: true,
        message: 'تم حذف جميع الإشعارات'
      })
    }

    if (notificationIds && notificationIds.length > 0) {
      await db.notification.deleteMany({
        where: {
          id: { in: notificationIds },
          userId
        }
      })

      return NextResponse.json({
        success: true,
        message: 'تم حذف الإشعارات المحددة'
      })
    }

    return NextResponse.json(
      { error: 'لم يتم تحديد أي إشعارات للحذف' },
      { status: 400 }
    )
  } catch (error) {
    console.error('Error deleting notifications:', error)
    return NextResponse.json(
      { error: 'حدث خطأ أثناء حذف الإشعارات' },
      { status: 500 }
    )
  }
}
