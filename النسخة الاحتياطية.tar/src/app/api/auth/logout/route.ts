import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// POST /api/auth/logout - Logout user
export async function POST(request: NextRequest) {
  try {
    const token = request.headers.get('Authorization')?.replace('Bearer ', '')

    if (token) {
      // Delete session
      await db.session.deleteMany({
        where: { token }
      })
    }

    return NextResponse.json({
      success: true,
      message: 'تم تسجيل الخروج'
    })
  } catch (error) {
    console.error('Logout error:', error)
    return NextResponse.json(
      { error: 'حدث خطأ' },
      { status: 500 }
    )
  }
}
