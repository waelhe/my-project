import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { randomInt } from 'crypto'

// POST /api/auth/register - Register new user
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { phone, name, nameAr, email, role = 'GUEST' } = body

    // Validate required fields
    if (!phone) {
      return NextResponse.json(
        { error: 'رقم الهاتف مطلوب' },
        { status: 400 }
      )
    }

    // Check if user already exists
    const existingUser = await db.user.findUnique({
      where: { phone }
    })

    if (existingUser) {
      return NextResponse.json(
        { error: 'رقم الهاتف مسجل مسبقاً' },
        { status: 400 }
      )
    }

    // Create user
    const user = await db.user.create({
      data: {
        phone,
        name: name || null,
        nameAr: nameAr || name || null,
        email: email || null,
        role: role as 'GUEST' | 'HOST',
        status: 'PENDING_VERIFICATION',
        isVerified: false
      }
    })

    // Generate OTP
    const otpCode = randomInt(100000, 999999).toString()
    const expiresAt = new Date(Date.now() + 5 * 60 * 1000) // 5 minutes

    await db.oTPCode.create({
      data: {
        phone,
        code: otpCode,
        purpose: 'verify',
        expiresAt,
        userId: user.id
      }
    })

    // In production, send OTP via SMS
    // For demo, return the OTP
    console.log(`OTP for ${phone}: ${otpCode}`)

    return NextResponse.json({
      success: true,
      message: 'تم إرسال رمز التحقق',
      userId: user.id,
      // Remove in production
      otp: otpCode
    })
  } catch (error) {
    console.error('Registration error:', error)
    return NextResponse.json(
      { error: 'حدث خطأ أثناء التسجيل' },
      { status: 500 }
    )
  }
}
