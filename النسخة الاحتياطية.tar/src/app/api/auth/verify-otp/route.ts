import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { randomBytes } from 'crypto'

// POST /api/auth/verify-otp - Verify OTP code and login/register user
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { phone, code, name, role = 'GUEST' } = body

    if (!phone || !code) {
      return NextResponse.json(
        { error: 'رقم الهاتف والرمز مطلوبان' },
        { status: 400 }
      )
    }

    // Find valid OTP (any purpose - login or register)
    const otpRecord = await db.oTPCode.findFirst({
      where: {
        phone,
        code,
        used: false,
        expiresAt: { gt: new Date() }
      },
      include: { user: true }
    })

    if (!otpRecord) {
      return NextResponse.json(
        { error: 'رمز التحقق غير صالح أو منتهي' },
        { status: 400 }
      )
    }

    // Mark OTP as used
    await db.oTPCode.update({
      where: { id: otpRecord.id },
      data: {
        used: true,
        isSuccess: true
      }
    })

    let user = otpRecord.user

    // Create new user if doesn't exist
    if (!user) {
      // Check if user exists by phone
      user = await db.user.findUnique({
        where: { phone }
      })

      if (!user) {
        // Create new user
        if (!name) {
          return NextResponse.json(
            { error: 'الاسم مطلوب للمستخدم الجديد' },
            { status: 400 }
          )
        }

        user = await db.user.create({
          data: {
            phone,
            name,
            nameAr: name, // Use same name for Arabic by default
            role: role as 'GUEST' | 'HOST',
            status: 'ACTIVE',
            isVerified: true,
            lastLoginAt: new Date()
          }
        })
      }
    } else {
      // Update existing user
      await db.user.update({
        where: { id: user.id },
        data: {
          status: 'ACTIVE',
          isVerified: true,
          lastLoginAt: new Date(),
          // Update name if provided
          ...(name && { name, nameAr: name }),
          // Update role if provided and different
          ...(role && role !== user.role && { role: role as 'GUEST' | 'HOST' })
        }
      })
    }

    // Generate session token
    const sessionToken = randomBytes(32).toString('hex')
    const expiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000) // 30 days

    // Create session
    await db.session.create({
      data: {
        token: sessionToken,
        userId: user.id,
        expiresAt,
        isPersistent: true
      }
    })

    // Get user with full data
    const fullUser = await db.user.findUnique({
      where: { id: user.id },
      select: {
        id: true,
        phone: true,
        name: true,
        nameAr: true,
        email: true,
        avatar: true,
        role: true,
        status: true,
        isVerified: true,
        city: true
      }
    })

    return NextResponse.json({
      success: true,
      message: 'تم التحقق بنجاح',
      user: fullUser,
      token: sessionToken
    })
  } catch (error) {
    console.error('OTP verification error:', error)
    return NextResponse.json(
      { error: 'حدث خطأ أثناء التحقق' },
      { status: 500 }
    )
  }
}
