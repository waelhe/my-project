import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { randomInt } from 'crypto'

// POST /api/auth/login - Request login OTP
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { phone } = body

    if (!phone) {
      return NextResponse.json(
        { error: 'رقم الهاتف مطلوب' },
        { status: 400 }
      )
    }

    // Check if user exists
    const user = await db.user.findUnique({
      where: { phone }
    })

    if (!user) {
      return NextResponse.json(
        { error: 'رقم الهاتف غير مسجل' },
        { status: 404 }
      )
    }

    // Generate OTP
    const otpCode = randomInt(100000, 999999).toString()
    const expiresAt = new Date(Date.now() + 5 * 60 * 1000) // 5 minutes

    await db.oTPCode.create({
      data: {
        phone,
        code: otpCode,
        purpose: 'login',
        expiresAt,
        userId: user.id
      }
    })

    // In production, send OTP via SMS
    console.log(`Login OTP for ${phone}: ${otpCode}`)

    return NextResponse.json({
      success: true,
      message: 'تم إرسال رمز التحقق',
      userId: user.id,
      // Remove in production
      otp: otpCode
    })
  } catch (error) {
    console.error('Login error:', error)
    return NextResponse.json(
      { error: 'حدث خطأ أثناء تسجيل الدخول' },
      { status: 500 }
    )
  }
}
