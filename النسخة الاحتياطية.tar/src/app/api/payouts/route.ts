import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET /api/payouts - Get payouts list for host
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const hostId = searchParams.get('hostId')
    const status = searchParams.get('status')
    const limit = parseInt(searchParams.get('limit') || '20')
    const offset = parseInt(searchParams.get('offset') || '0')

    if (!hostId) {
      return NextResponse.json(
        { error: 'معرف المضيف مطلوب' },
        { status: 400 }
      )
    }

    const whereClause: any = { hostId }
    if (status) {
      whereClause.status = status
    }

    const [payouts, total] = await Promise.all([
      db.payout.findMany({
        where: whereClause,
        orderBy: { createdAt: 'desc' },
        take: limit,
        skip: offset
      }),
      db.payout.count({ where: whereClause })
    ])

    // Calculate totals
    const stats = await db.payout.aggregate({
      where: { hostId },
      _sum: {
        amount: true
      },
      _count: {
        _all: true
      }
    })

    const pendingTotal = await db.payout.aggregate({
      where: { hostId, status: 'pending' },
      _sum: { amount: true }
    })

    const completedTotal = await db.payout.aggregate({
      where: { hostId, status: 'completed' },
      _sum: { amount: true }
    })

    return NextResponse.json({
      payouts,
      stats: {
        totalAmount: stats._sum.amount || 0,
        totalCount: stats._count._all,
        pendingAmount: pendingTotal._sum.amount || 0,
        completedAmount: completedTotal._sum.amount || 0
      },
      pagination: {
        total,
        limit,
        offset,
        hasMore: offset + payouts.length < total
      }
    })
  } catch (error) {
    console.error('Get payouts error:', error)
    return NextResponse.json(
      { error: 'حدث خطأ في جلب المدفوعات' },
      { status: 500 }
    )
  }
}

// POST /api/payouts - Request new payout (host)
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const {
      hostId,
      amount,
      method,
      accountDetails // bank account or mobile wallet details
    } = body

    if (!hostId || !amount || !method) {
      return NextResponse.json(
        { error: 'جميع الحقول مطلوبة' },
        { status: 400 }
      )
    }

    // Check host has enough balance
    // In production, this would check actual balance from completed bookings
    const completedPayments = await db.payment.findMany({
      where: {
        booking: { accommodation: { hostId } },
        status: 'COMPLETED',
        isGuarantee: false
      },
      include: { booking: { include: { accommodation: true } } }
    })

    const totalEarnings = completedPayments.reduce((sum, p) => sum + p.amount, 0)

    // Get existing payouts
    const existingPayouts = await db.payout.findMany({
      where: { hostId, status: { in: ['pending', 'processing', 'completed'] } }
    })
    const totalPaidOut = existingPayouts.reduce((sum, p) => sum + p.amount, 0)

    const availableBalance = totalEarnings - totalPaidOut

    if (amount > availableBalance) {
      return NextResponse.json(
        { error: `المبلغ المتاح للسحب: ${availableBalance.toLocaleString()} ل.س` },
        { status: 400 }
      )
    }

    // Create payout request
    const payout = await db.payout.create({
      data: {
        amount,
        currency: 'SYP',
        status: 'pending',
        method,
        details: JSON.stringify(accountDetails),
        hostId
      }
    })

    return NextResponse.json({
      success: true,
      message: 'تم تقديم طلب السحب بنجاح',
      payout
    })
  } catch (error) {
    console.error('Create payout error:', error)
    return NextResponse.json(
      { error: 'حدث خطأ في تقديم طلب السحب' },
      { status: 500 }
    )
  }
}
