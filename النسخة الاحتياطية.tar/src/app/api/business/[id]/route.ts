// ═══════════════════════════════════════════════════════════════════════════
// Business Listing Details API
// واجهة تفاصيل فرصة الأعمال
// ═══════════════════════════════════════════════════════════════════════════

import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

interface RouteParams {
  params: Promise<{ id: string }>;
}

/**
 * GET - Get business listing by ID
 * الحصول على تفاصيل فرصة الأعمال
 */
export async function GET(request: NextRequest, { params }: RouteParams) {
  try {
    const { id } = await params;

    const business = await db.businessListing.findUnique({
      where: { id },
      include: {
        city: {
          select: { 
            id: true, 
            nameAr: true, 
            nameEn: true, 
            governorate: true,
            image: true 
          }
        },
        owner: {
          select: {
            id: true,
            name: true,
            nameAr: true,
            avatar: true,
            phone: true,
            email: true,
            businessName: true,
            businessNameAr: true,
            createdAt: true,
            businessListings: {
              where: { status: 'ACTIVE' },
              select: { id: true }
            }
          }
        }
      }
    });

    if (!business) {
      return NextResponse.json(
        { success: false, error: 'فرصة الأعمال غير موجودة' },
        { status: 404 }
      );
    }

    // Increment view count
    await db.businessListing.update({
      where: { id },
      data: { viewCount: { increment: 1 } }
    });

    // Calculate owner stats
    const ownerStats = {
      totalListings: business.owner.businessListings.length,
      memberSince: business.owner.createdAt
    };

    // Parse JSON fields
    const parsedBusiness = {
      ...business,
      images: business.images ? JSON.parse(business.images) : [],
      documents: business.documents ? JSON.parse(business.documents) : []
    };

    return NextResponse.json({
      success: true,
      business: parsedBusiness,
      ownerStats
    });

  } catch (error) {
    console.error('Get business listing error:', error);
    return NextResponse.json(
      { success: false, error: 'حدث خطأ في جلب البيانات' },
      { status: 500 }
    );
  }
}
