import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { requireAuth } from '@/lib/auth-middleware';

/**
 * GET /api/business - List business opportunities (Public)
 * الحصول على قائمة فرص الأعمال والاستثمار (عام)
 */
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    
    // Parse query parameters
    const queryParams = {
      cityId: searchParams.get('cityId') || undefined,
      type: searchParams.get('type') || undefined,
      sector: searchParams.get('sector') || undefined,
      minPrice: searchParams.get('minPrice') ? parseFloat(searchParams.get('minPrice')!) : undefined,
      maxPrice: searchParams.get('maxPrice') ? parseFloat(searchParams.get('maxPrice')!) : undefined,
      status: searchParams.get('status') || 'ACTIVE',
      limit: parseInt(searchParams.get('limit') || '12'),
      offset: parseInt(searchParams.get('offset') || '0')
    };

    const { cityId, type, sector, minPrice, maxPrice, status, limit, offset } = queryParams;

    // Build filter
    const where: Record<string, unknown> = {};

    // Status filter (default to ACTIVE for public access)
    if (status) {
      where.status = status;
    }

    if (cityId) {
      where.cityId = cityId;
    }

    if (type) {
      where.type = type;
    }

    if (sector) {
      where.sector = sector;
    }

    if (minPrice || maxPrice) {
      where.price = {
        ...(minPrice && { gte: minPrice }),
        ...(maxPrice && { lte: maxPrice })
      };
    }

    // Fetch business listings
    const businesses = await db.businessListing.findMany({
      where,
      take: limit,
      skip: offset,
      orderBy: [
        { createdAt: 'desc' }
      ],
      include: {
        city: true,
        owner: {
          select: {
            id: true,
            name: true,
            phone: true,
            avatar: true
          }
        }
      }
    });

    // Get total count for pagination
    const total = await db.businessListing.count({ where });

    // Parse JSON fields
    const parsedBusinesses = businesses.map(business => ({
      ...business,
      images: business.images ? JSON.parse(business.images) : [],
      documents: business.documents ? JSON.parse(business.documents) : []
    }));

    return NextResponse.json({
      businesses: parsedBusinesses,
      pagination: {
        total,
        limit,
        offset,
        hasMore: offset + limit < total
      }
    });

  } catch (error) {
    console.error('Get business listings error:', error);
    return NextResponse.json(
      { error: 'حدث خطأ في جلب البيانات' },
      { status: 500 }
    );
  }
}

/**
 * POST /api/business - Create business opportunity (Authenticated users)
 * إنشاء فرصة أعمال جديدة (للمستخدمين المسجلين)
 */
export async function POST(request: NextRequest) {
  try {
    // Require authentication
    const authResult = await requireAuth(request);
    
    if (authResult instanceof NextResponse) {
      return authResult; // Return error response
    }

    const { user } = authResult;

    // Parse request body
    let body;
    try {
      body = await request.json();
    } catch {
      return NextResponse.json(
        { error: 'بيانات غير صالحة' },
        { status: 400 }
      );
    }

    // Validate required fields
    const requiredFields = ['titleAr', 'type'];
    const missingFields = requiredFields.filter(field => !body[field]);
    
    if (missingFields.length > 0) {
      return NextResponse.json(
        { error: `الحقول التالية مطلوبة: ${missingFields.join(', ')}` },
        { status: 400 }
      );
    }

    // Verify city exists if provided
    if (body.cityId) {
      const city = await db.city.findUnique({
        where: { id: body.cityId }
      });

      if (!city) {
        return NextResponse.json(
          { error: 'المدينة غير موجودة' },
          { status: 400 }
        );
      }
    }

    // Create business listing
    const business = await db.businessListing.create({
      data: {
        titleAr: body.titleAr,
        titleEn: body.titleEn || null,
        descriptionAr: body.descriptionAr || null,
        descriptionEn: body.descriptionEn || null,
        type: body.type,
        status: 'PENDING_APPROVAL',
        
        // Sector information
        sector: body.sector || null,
        subsector: body.subsector || null,
        
        // Investment details
        investmentMin: body.investmentMin || null,
        investmentMax: body.investmentMax || null,
        expectedReturn: body.expectedReturn || null,
        investmentPeriod: body.investmentPeriod || null,
        riskLevel: body.riskLevel || null,
        
        // Commercial property details
        propertyType: body.propertyType || null,
        size: body.size || null,
        isForSale: body.isForSale || false,
        isForRent: body.isForRent || false,
        salePrice: body.salePrice || null,
        rentPrice: body.rentPrice || null,
        
        // Service details
        serviceType: body.serviceType || null,
        
        // Location
        cityId: body.cityId || null,
        addressAr: body.addressAr || null,
        addressEn: body.addressEn || null,
        latitude: body.latitude || null,
        longitude: body.longitude || null,
        
        // Financial information
        price: body.price || null,
        currency: body.currency || 'SYP',
        
        // Media
        images: body.images && body.images.length > 0 
          ? JSON.stringify(body.images) 
          : null,
        coverImage: body.coverImage || null,
        documents: body.documents && body.documents.length > 0 
          ? JSON.stringify(body.documents) 
          : null,
        
        // Contact information
        contactName: body.contactName || null,
        contactPhone: body.contactPhone || null,
        contactEmail: body.contactEmail || null,
        
        // Owner
        ownerId: user.id
      },
      include: {
        city: true,
        owner: {
          select: {
            id: true,
            name: true,
            phone: true,
            avatar: true
          }
        }
      }
    });

    return NextResponse.json({
      success: true,
      message: 'تم إنشاء فرصة الأعمال بنجاح وهي قيد المراجعة',
      business: {
        ...business,
        images: business.images ? JSON.parse(business.images) : [],
        documents: business.documents ? JSON.parse(business.documents) : []
      }
    }, { status: 201 });

  } catch (error) {
    console.error('Create business listing error:', error);
    return NextResponse.json(
      { error: 'حدث خطأ في إنشاء فرصة الأعمال' },
      { status: 500 }
    );
  }
}
