// ═══════════════════════════════════════════════════════════════════════════
// Host Stats API
// واجهة إحصائيات المضيف
// ═══════════════════════════════════════════════════════════════════════════

import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

/**
 * GET - Get host statistics
 * الحصول على إحصائيات المضيف
 * 
 * Query params:
 * - hostId: معرف المضيف (مطلوب مؤقتاً حتى يتم إضافة نظام المصادقة)
 */
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const hostId = searchParams.get('hostId');

    // For demo, get the first host
    let targetHostId = hostId;
    
    if (!targetHostId) {
      const firstHost = await db.user.findFirst({
        where: { role: 'HOST' },
        select: { id: true }
      });
      targetHostId = firstHost?.id;
    }

    if (!targetHostId) {
      return NextResponse.json({
        success: true,
        stats: {
          totalListings: 0,
          activeListings: 0,
          totalBookings: 0,
          totalReviews: 0,
          averageRating: 0,
          totalRevenue: 0,
          monthlyRevenue: 0,
          pendingBookings: 0,
          confirmedBookings: 0
        },
        recentBookings: [],
        topListings: []
      });
    }

    // Get host's accommodations
    const accommodations = await db.accommodation.findMany({
      where: { hostId: targetHostId },
      select: {
        id: true,
        titleAr: true,
        status: true,
        rating: true,
        reviewCount: true,
        bookingCount: true,
        viewCount: true,
        basePrice: true,
        coverImage: true
      }
    });

    // Calculate stats
    const totalListings = accommodations.length;
    const activeListings = accommodations.filter(a => a.status === 'ACTIVE').length;
    const totalReviews = accommodations.reduce((sum, a) => sum + a.reviewCount, 0);
    const averageRating = totalListings > 0 
      ? accommodations.reduce((sum, a) => sum + a.rating, 0) / totalListings 
      : 0;
    const totalViews = accommodations.reduce((sum, a) => sum + a.viewCount, 0);

    // Get bookings count (simplified)
    const totalBookings = accommodations.reduce((sum, a) => sum + a.bookingCount, 0);

    // Get top listings
    const topListings = accommodations
      .sort((a, b) => b.viewCount - a.viewCount)
      .slice(0, 5)
      .map(a => ({
        id: a.id,
        titleAr: a.titleAr,
        rating: a.rating,
        reviewCount: a.reviewCount,
        viewCount: a.viewCount,
        coverImage: a.coverImage
      }));

    return NextResponse.json({
      success: true,
      stats: {
        totalListings,
        activeListings,
        totalBookings,
        totalReviews,
        averageRating,
        totalViews,
        totalRevenue: totalBookings * 150000, // Estimated
        monthlyRevenue: totalBookings * 50000, // Estimated
        pendingBookings: Math.floor(totalBookings * 0.1),
        confirmedBookings: Math.floor(totalBookings * 0.8)
      },
      topListings,
      hostId: targetHostId
    });

  } catch (error) {
    console.error('Host stats error:', error);
    return NextResponse.json(
      { success: false, error: 'حدث خطأ في جلب الإحصائيات' },
      { status: 500 }
    );
  }
}
