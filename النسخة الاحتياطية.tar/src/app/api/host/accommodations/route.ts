// ═══════════════════════════════════════════════════════════════════════════
// Host Accommodations API
// واجهة إقامات المضيف
// ═══════════════════════════════════════════════════════════════════════════

import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

/**
 * GET - Get host's accommodations
 * الحصول على إقامات المضيف
 */
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const hostId = searchParams.get('hostId');

    // For demo, get the first host
    let targetHostId = hostId;
    
    if (!targetHostId) {
      const firstHost = await db.user.findFirst({
        where: { role: 'HOST' },
        select: { id: true }
      });
      targetHostId = firstHost?.id;
    }

    if (!targetHostId) {
      return NextResponse.json({
        success: true,
        accommodations: []
      });
    }

    const accommodations = await db.accommodation.findMany({
      where: { hostId: targetHostId },
      include: {
        city: {
          select: { id: true, nameAr: true, nameEn: true }
        }
      },
      orderBy: { createdAt: 'desc' }
    });

    return NextResponse.json({
      success: true,
      accommodations: accommodations.map(acc => ({
        ...acc,
        amenities: acc.amenities ? JSON.parse(acc.amenities) : [],
        images: acc.images ? JSON.parse(acc.images) : []
      }))
    });

  } catch (error) {
    console.error('Get host accommodations error:', error);
    return NextResponse.json(
      { success: false, error: 'حدث خطأ في جلب البيانات' },
      { status: 500 }
    );
  }
}

/**
 * POST - Create new accommodation
 * إنشاء إقامة جديدة
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    
    // Get first host for demo
    let hostId = body.hostId;
    if (!hostId) {
      const firstHost = await db.user.findFirst({
        where: { role: 'HOST' },
        select: { id: true }
      });
      hostId = firstHost?.id;
    }

    if (!hostId) {
      return NextResponse.json(
        { success: false, error: 'المضيف غير موجود' },
        { status: 400 }
      );
    }

    const {
      titleAr,
      titleEn,
      descriptionAr,
      descriptionEn,
      type,
      addressAr,
      cityId,
      basePrice,
      weekendPrice,
      cleaningFee,
      bedrooms,
      bathrooms,
      maxGuests,
      beds,
      size,
      amenities,
      checkInTime,
      checkOutTime,
      minNights,
      smokingAllowed,
      petsAllowed,
      partiesAllowed,
      coverImage,
      images
    } = body;

    // Validate required fields
    if (!titleAr || !type || !basePrice) {
      return NextResponse.json(
        { success: false, error: 'يرجى ملء جميع الحقول المطلوبة' },
        { status: 400 }
      );
    }

    const accommodation = await db.accommodation.create({
      data: {
        titleAr,
        titleEn: titleEn || null,
        descriptionAr: descriptionAr || null,
        descriptionEn: descriptionEn || null,
        type: type as any,
        addressAr: addressAr || null,
        cityId: cityId || null,
        basePrice: parseFloat(basePrice),
        weekendPrice: weekendPrice ? parseFloat(weekendPrice) : null,
        cleaningFee: cleaningFee ? parseFloat(cleaningFee) : null,
        bedrooms: bedrooms ? parseInt(bedrooms) : 1,
        bathrooms: bathrooms ? parseInt(bathrooms) : 1,
        maxGuests: maxGuests ? parseInt(maxGuests) : 2,
        beds: beds ? parseInt(beds) : 1,
        size: size ? parseFloat(size) : null,
        amenities: amenities && amenities.length > 0 ? JSON.stringify(amenities) : null,
        checkInTime: checkInTime || '14:00',
        checkOutTime: checkOutTime || '12:00',
        minNights: minNights ? parseInt(minNights) : 1,
        smokingAllowed: smokingAllowed || false,
        petsAllowed: petsAllowed || false,
        partiesAllowed: partiesAllowed || false,
        coverImage: coverImage || '/images/default-accommodation.png',
        images: images && images.length > 0 ? JSON.stringify(images) : null,
        hostId,
        status: 'PENDING_APPROVAL'
      },
      include: {
        city: true
      }
    });

    return NextResponse.json({
      success: true,
      message: 'تم إنشاء الإعلان بنجاح وهو قيد المراجعة',
      accommodation: {
        ...accommodation,
        amenities: accommodation.amenities ? JSON.parse(accommodation.amenities) : [],
        images: accommodation.images ? JSON.parse(accommodation.images) : []
      }
    }, { status: 201 });

  } catch (error) {
    console.error('Create accommodation error:', error);
    return NextResponse.json(
      { success: false, error: 'حدث خطأ في إنشاء الإعلان' },
      { status: 500 }
    );
  }
}
