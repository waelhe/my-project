// ═══════════════════════════════════════════════════════════════════════════
// Accommodations Search API
// واجهة البحث المتقدم في أماكن الإقامة
// ═══════════════════════════════════════════════════════════════════════════

import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { Prisma } from '@prisma/client';

/**
 * GET - Search accommodations with filters
 * البحث في أماكن الإقامة مع فلاتر متقدمة
 */
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    
    // Extract search parameters
    const query = searchParams.get('q') || '';
    const cityId = searchParams.get('cityId');
    const type = searchParams.get('type');
    const minPrice = searchParams.get('minPrice');
    const maxPrice = searchParams.get('maxPrice');
    const minRating = searchParams.get('minRating');
    const bedrooms = searchParams.get('bedrooms');
    const maxGuests = searchParams.get('maxGuests');
    const amenities = searchParams.get('amenities'); // comma separated
    const sortBy = searchParams.get('sortBy') || 'rating';
    const sortOrder = searchParams.get('sortOrder') || 'desc';
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '12');
    const skip = (page - 1) * limit;

    // Build where clause
    const where: Prisma.AccommodationWhereInput = {
      status: 'ACTIVE'
    };

    // Text search
    if (query) {
      where.OR = [
        { titleAr: { contains: query } },
        { titleEn: { contains: query } },
        { descriptionAr: { contains: query } },
        { descriptionEn: { contains: query } },
        { addressAr: { contains: query } },
        { city: { nameAr: { contains: query } } },
        { city: { nameEn: { contains: query } } }
      ];
    }

    // City filter
    if (cityId) {
      where.cityId = cityId;
    }

    // Type filter
    if (type) {
      where.type = type as any;
    }

    // Price range
    if (minPrice || maxPrice) {
      where.basePrice = {};
      if (minPrice) where.basePrice.gte = parseFloat(minPrice);
      if (maxPrice) where.basePrice.lte = parseFloat(maxPrice);
    }

    // Rating filter
    if (minRating) {
      where.rating = { gte: parseFloat(minRating) };
    }

    // Bedrooms filter
    if (bedrooms) {
      where.bedrooms = { gte: parseInt(bedrooms) };
    }

    // Max guests filter
    if (maxGuests) {
      where.maxGuests = { gte: parseInt(maxGuests) };
    }

    // Amenities filter
    if (amenities) {
      const amenitiesList = amenities.split(',');
      // Simple check - in production, use proper JSON query
      where.amenities = { contains: amenitiesList[0] };
    }

    // Build orderBy
    let orderBy: Prisma.AccommodationOrderByWithRelationInput = {};
    switch (sortBy) {
      case 'price':
        orderBy = { basePrice: sortOrder as 'asc' | 'desc' };
        break;
      case 'rating':
        orderBy = { rating: sortOrder as 'asc' | 'desc' };
        break;
      case 'reviews':
        orderBy = { reviewCount: sortOrder as 'asc' | 'desc' };
        break;
      case 'newest':
        orderBy = { createdAt: sortOrder as 'asc' | 'desc' };
        break;
      default:
        orderBy = { rating: 'desc' };
    }

    // Execute queries
    const [accommodations, total] = await Promise.all([
      db.accommodation.findMany({
        where,
        include: {
          city: {
            select: { id: true, nameAr: true, nameEn: true }
          },
          host: {
            select: { id: true, name: true, nameAr: true, avatar: true }
          }
        },
        orderBy,
        skip,
        take: limit
      }),
      db.accommodation.count({ where })
    ]);

    // Calculate pagination info
    const totalPages = Math.ceil(total / limit);
    const hasNextPage = page < totalPages;
    const hasPrevPage = page > 1;

    return NextResponse.json({
      success: true,
      accommodations: accommodations.map(acc => ({
        id: acc.id,
        titleAr: acc.titleAr,
        titleEn: acc.titleEn,
        type: acc.type,
        addressAr: acc.addressAr,
        basePrice: acc.basePrice,
        currency: acc.currency,
        rating: acc.rating,
        reviewCount: acc.reviewCount,
        coverImage: acc.coverImage,
        images: acc.images ? JSON.parse(acc.images) : [],
        bedrooms: acc.bedrooms,
        bathrooms: acc.bathrooms,
        maxGuests: acc.maxGuests,
        amenities: acc.amenities ? JSON.parse(acc.amenities) : [],
        city: acc.city,
        host: acc.host
      })),
      pagination: {
        page,
        limit,
        total,
        totalPages,
        hasNextPage,
        hasPrevPage
      },
      filters: {
        query,
        cityId,
        type,
        minPrice,
        maxPrice,
        minRating,
        bedrooms,
        maxGuests,
        amenities,
        sortBy,
        sortOrder
      }
    });

  } catch (error) {
    console.error('Search accommodations error:', error);
    return NextResponse.json(
      { success: false, error: 'حدث خطأ في البحث' },
      { status: 500 }
    );
  }
}
