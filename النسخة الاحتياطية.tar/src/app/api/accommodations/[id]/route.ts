// ═══════════════════════════════════════════════════════════════════════════
// Accommodation Details API
// واجهة تفاصيل مكان الإقامة
// ═══════════════════════════════════════════════════════════════════════════

import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

interface RouteParams {
  params: Promise<{ id: string }>;
}

/**
 * GET - Get accommodation by ID
 * الحصول على تفاصيل مكان الإقامة
 */
export async function GET(request: NextRequest, { params }: RouteParams) {
  try {
    const { id } = await params;

    const accommodation = await db.accommodation.findUnique({
      where: { id },
      include: {
        city: {
          select: { 
            id: true, 
            nameAr: true, 
            nameEn: true, 
            governorate: true,
            image: true 
          }
        },
        host: {
          select: {
            id: true,
            name: true,
            avatar: true,
            phone: true,
            createdAt: true,
            accommodations: {
              where: { status: 'ACTIVE' },
              select: { id: true, rating: true, reviewCount: true }
            }
          }
        }
      }
    });

    if (!accommodation) {
      return NextResponse.json(
        { success: false, error: 'مكان الإقامة غير موجود' },
        { status: 404 }
      );
    }

    // Increment view count
    await db.accommodation.update({
      where: { id },
      data: { viewCount: { increment: 1 } }
    });

    // Calculate host stats
    const hostStats = {
      totalListings: accommodation.host.accommodations.length,
      averageRating: accommodation.host.accommodations.length > 0
        ? accommodation.host.accommodations.reduce((sum, a) => sum + a.rating, 0) / accommodation.host.accommodations.length
        : 0,
      totalReviews: accommodation.host.accommodations.reduce((sum, a) => sum + a.reviewCount, 0),
      hostingSince: accommodation.host.createdAt
    };

    // Parse JSON fields
    const parsedAccommodation = {
      ...accommodation,
      amenities: accommodation.amenities ? JSON.parse(accommodation.amenities) : [],
      images: accommodation.images ? JSON.parse(accommodation.images) : [],
      houseRules: accommodation.houseRules ? JSON.parse(accommodation.houseRules) : [],
      reviews: [] // Empty for now, will be fetched separately
    };

    return NextResponse.json({
      success: true,
      accommodation: parsedAccommodation,
      hostStats
    });

  } catch (error) {
    console.error('Get accommodation error:', error);
    return NextResponse.json(
      { success: false, error: 'حدث خطأ في جلب البيانات' },
      { status: 500 }
    );
  }
}
