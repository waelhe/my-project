import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET /api/bookings/[id] - Get booking details
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params

    const booking = await db.booking.findUnique({
      where: { id },
      include: {
        accommodation: {
          include: {
            city: { select: { nameAr: true, nameEn: true } },
            host: {
              select: { id: true, name: true, nameAr: true, phone: true, avatar: true }
            },
            images: true
          }
        },
        room: { select: { id: true, nameAr: true, nameEn: true } },
        guest: {
          select: { id: true, name: true, nameAr: true, phone: true, email: true, avatar: true }
        },
        payments: {
          orderBy: { createdAt: 'desc' }
        },
        review: true
      }
    })

    if (!booking) {
      return NextResponse.json(
        { error: 'الحجز غير موجود' },
        { status: 404 }
      )
    }

    return NextResponse.json({ booking })
  } catch (error) {
    console.error('Error fetching booking:', error)
    return NextResponse.json(
      { error: 'حدث خطأ أثناء جلب الحجز' },
      { status: 500 }
    )
  }
}

// PUT /api/bookings/[id] - Update booking status
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const body = await request.json()
    const { status, cancelledBy, cancellationReason } = body

    const booking = await db.booking.findUnique({
      where: { id },
      include: {
        accommodation: { select: { id: true, titleAr: true, hostId: true } }
      }
    })

    if (!booking) {
      return NextResponse.json(
        { error: 'الحجز غير موجود' },
        { status: 404 }
      )
    }

    // Status transition validation
    const validTransitions: Record<string, string[]> = {
      'PENDING': ['CONFIRMED', 'CANCELLED'],
      'CONFIRMED': ['PAYMENT_PENDING', 'CANCELLED'],
      'PAYMENT_PENDING': ['PAID', 'CANCELLED'],
      'PAID': ['CHECKED_IN', 'CANCELLED', 'REFUNDED'],
      'CHECKED_IN': ['CHECKED_OUT'],
      'CHECKED_OUT': [],
      'CANCELLED': [],
      'REFUNDED': [],
      'DISPUTED': ['REFUNDED']
    }

    if (status && !validTransitions[booking.status]?.includes(status)) {
      return NextResponse.json(
        { error: 'لا يمكن تغيير حالة الحجز إلى هذه الحالة' },
        { status: 400 }
      )
    }

    const updateData: Record<string, unknown> = {}
    
    if (status) {
      updateData.status = status
    }

    if (status === 'CANCELLED') {
      updateData.cancelledAt = new Date()
      updateData.cancelledBy = cancelledBy || 'guest'
      updateData.cancellationReason = cancellationReason

      // Notify the other party
      const notifyUserId = cancelledBy === 'host' ? booking.guestId : booking.accommodation.hostId
      await db.notification.create({
        data: {
          userId: notifyUserId,
          type: 'booking',
          titleAr: 'إلغاء الحجز',
          bodyAr: `تم إلغاء الحجز رقم ${booking.confirmationCode}`,
          data: JSON.stringify({ bookingId: booking.id })
        }
      })
    }

    if (status === 'CONFIRMED') {
      updateData.confirmedAt = new Date()
      
      // Notify guest
      await db.notification.create({
        data: {
          userId: booking.guestId,
          type: 'booking',
          titleAr: 'تم تأكيد الحجز',
          bodyAr: `تم تأكيد حجزك في ${booking.accommodation.titleAr}`,
          data: JSON.stringify({ bookingId: booking.id })
        }
      })
    }

    const updatedBooking = await db.booking.update({
      where: { id },
      data: updateData,
      include: {
        accommodation: {
          include: {
            city: { select: { nameAr: true } },
            host: { select: { id: true, name: true, nameAr: true } }
          }
        },
        guest: { select: { id: true, name: true, nameAr: true } }
      }
    })

    return NextResponse.json({
      success: true,
      booking: updatedBooking,
      message: 'تم تحديث الحجز بنجاح'
    })
  } catch (error) {
    console.error('Error updating booking:', error)
    return NextResponse.json(
      { error: 'حدث خطأ أثناء تحديث الحجز' },
      { status: 500 }
    )
  }
}

// DELETE /api/bookings/[id] - Cancel booking
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const { searchParams } = new URL(request.url)
    const cancelledBy = searchParams.get('cancelledBy') || 'guest'
    const reason = searchParams.get('reason') || ''

    const booking = await db.booking.findUnique({
      where: { id },
      include: {
        accommodation: { select: { id: true, titleAr: true, hostId: true } }
      }
    })

    if (!booking) {
      return NextResponse.json(
        { error: 'الحجز غير موجود' },
        { status: 404 }
      )
    }

    // Check if booking can be cancelled
    if (['CANCELLED', 'REFUNDED', 'CHECKED_OUT'].includes(booking.status)) {
      return NextResponse.json(
        { error: 'لا يمكن إلغاء هذا الحجز' },
        { status: 400 }
      )
    }

    const updatedBooking = await db.booking.update({
      where: { id },
      data: {
        status: 'CANCELLED',
        cancelledAt: new Date(),
        cancelledBy,
        cancellationReason: reason
      }
    })

    // Notify the other party
    const notifyUserId = cancelledBy === 'host' ? booking.guestId : booking.accommodation.hostId
    await db.notification.create({
      data: {
        userId: notifyUserId,
        type: 'booking',
        titleAr: 'إلغاء الحجز',
        bodyAr: `تم إلغاء الحجز رقم ${booking.confirmationCode}`,
        data: JSON.stringify({ bookingId: booking.id })
      }
    })

    return NextResponse.json({
      success: true,
      message: 'تم إلغاء الحجز بنجاح'
    })
  } catch (error) {
    console.error('Error cancelling booking:', error)
    return NextResponse.json(
      { error: 'حدث خطأ أثناء إلغاء الحجز' },
      { status: 500 }
    )
  }
}
