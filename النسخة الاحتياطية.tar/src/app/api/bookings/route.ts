import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET /api/bookings - Get bookings list
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')
    const hostId = searchParams.get('hostId')
    const status = searchParams.get('status')
    const accommodationId = searchParams.get('accommodationId')
    const upcoming = searchParams.get('upcoming')
    const past = searchParams.get('past')
    const limit = parseInt(searchParams.get('limit') || '20')
    const offset = parseInt(searchParams.get('offset') || '0')

    // Build filter conditions
    const where: Record<string, unknown> = {}

    // If hostId is provided, get bookings for host's accommodations
    if (hostId) {
      const hostAccommodations = await db.accommodation.findMany({
        where: { hostId },
        select: { id: true }
      })
      const accommodationIds = hostAccommodations.map(a => a.id)
      where.accommodationId = { in: accommodationIds }
    } else if (userId) {
      where.guestId = userId
    }

    if (status) {
      where.status = status
    }

    if (accommodationId) {
      where.accommodationId = accommodationId
    }

    // Date filters
    const now = new Date()
    if (upcoming === 'true') {
      where.checkIn = { gte: now }
    } else if (past === 'true') {
      where.checkOut = { lt: now }
    }

    const [bookings, total] = await Promise.all([
      db.booking.findMany({
        where,
        include: {
          accommodation: {
            include: {
              city: {
                select: { nameAr: true, nameEn: true }
              },
              host: {
                select: { id: true, name: true, nameAr: true, phone: true }
              }
            }
          },
          room: { select: { id: true, nameAr: true, nameEn: true } },
          guest: {
            select: { id: true, name: true, nameAr: true, phone: true, email: true, avatar: true }
          },
          payments: {
            select: { id: true, amount: true, status: true, method: true, createdAt: true }
          }
        },
        orderBy: { createdAt: 'desc' },
        take: limit,
        skip: offset
      }),
      db.booking.count({ where })
    ])

    return NextResponse.json({
      bookings,
      pagination: {
        total,
        limit,
        offset,
        hasMore: total > offset + limit
      }
    })
  } catch (error) {
    console.error('Error fetching bookings:', error)
    return NextResponse.json(
      { error: 'حدث خطأ أثناء جلب الحجوزات' },
      { status: 500 }
    )
  }
}

// POST /api/bookings - Create new booking
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const {
      accommodationId,
      roomId,
      guestId,
      checkIn,
      checkOut,
      guestsCount,
      guestName,
      guestPhone,
      guestEmail,
      specialRequests
    } = body

    // Validate required fields
    if (!accommodationId || !guestId || !checkIn || !checkOut) {
      return NextResponse.json(
        { error: 'بيانات غير مكتملة' },
        { status: 400 }
      )
    }

    // Get accommodation details
    const accommodation = await db.accommodation.findUnique({
      where: { id: accommodationId },
      include: { city: { select: { nameAr: true } } }
    })

    if (!accommodation) {
      return NextResponse.json(
        { error: 'الإقامة غير موجودة' },
        { status: 404 }
      )
    }

    if (accommodation.status !== 'ACTIVE') {
      return NextResponse.json(
        { error: 'هذه الإقامة غير متاحة للحجز حالياً' },
        { status: 400 }
      )
    }

    // Parse dates
    const checkInDate = new Date(checkIn)
    const checkOutDate = new Date(checkOut)
    const now = new Date()

    // Validate dates
    if (checkInDate < now) {
      return NextResponse.json(
        { error: 'تاريخ الوصول يجب أن يكون في المستقبل' },
        { status: 400 }
      )
    }

    if (checkOutDate <= checkInDate) {
      return NextResponse.json(
        { error: 'تاريخ المغادرة يجب أن يكون بعد تاريخ الوصول' },
        { status: 400 }
      )
    }

    // Calculate nights
    const nightsCount = Math.ceil(
      (checkOutDate.getTime() - checkInDate.getTime()) / (1000 * 60 * 60 * 24)
    )

    // Validate minimum nights
    if (nightsCount < accommodation.minNights) {
      return NextResponse.json(
        { error: `الحد الأدنى للإقامة ${accommodation.minNights} ليالي` },
        { status: 400 }
      )
    }

    // Validate max nights
    if (accommodation.maxNights && nightsCount > accommodation.maxNights) {
      return NextResponse.json(
        { error: `الحد الأقصى للإقامة ${accommodation.maxNights} ليالي` },
        { status: 400 }
      )
    }

    // Validate guests count
    if (guestsCount > accommodation.maxGuests) {
      return NextResponse.json(
        { error: `الحد الأقصى للضيوف ${accommodation.maxGuests} أشخاص` },
        { status: 400 }
      )
    }

    // Check availability
    const conflictingBookings = await db.booking.findMany({
      where: {
        accommodationId,
        status: { in: ['PENDING', 'CONFIRMED', 'PAYMENT_PENDING', 'PAID'] },
        OR: [
          {
            AND: [
              { checkIn: { lt: checkOutDate } },
              { checkOut: { gt: checkInDate } }
            ]
          }
        ]
      }
    })

    if (conflictingBookings.length > 0) {
      return NextResponse.json(
        { error: 'هذه الفترة محجوزة مسبقاً' },
        { status: 400 }
      )
    }

    // Check availability table
    const unavailableDates = await db.availability.findMany({
      where: {
        accommodationId,
        date: {
          gte: checkInDate,
          lt: checkOutDate
        },
        isAvailable: false
      }
    })

    if (unavailableDates.length > 0) {
      return NextResponse.json(
        { error: 'هناك أيام غير متاحة في الفترة المحددة' },
        { status: 400 }
      )
    }

    // Calculate pricing
    let basePrice = accommodation.basePrice
    const dayOfWeek = checkInDate.getDay()
    const isWeekend = dayOfWeek === 4 || dayOfWeek === 5 // Thursday, Friday in Arab world
    
    if (isWeekend && accommodation.weekendPrice) {
      basePrice = accommodation.weekendPrice
    }

    const baseAmount = basePrice * nightsCount
    const cleaningFee = accommodation.cleaningFee || 0
    const serviceFee = baseAmount * 0.1 // 10% service fee
    const guaranteeFee = baseAmount * 0.05 // 5% guarantee fee
    const totalAmount = baseAmount + cleaningFee + serviceFee + guaranteeFee

    // Create booking
    const booking = await db.booking.create({
      data: {
        accommodationId,
        roomId: roomId || null,
        guestId,
        checkIn: checkInDate,
        checkOut: checkOutDate,
        nightsCount,
        guestsCount: guestsCount || 1,
        baseAmount,
        cleaningFee,
        serviceFee,
        guaranteeFee,
        totalAmount,
        currency: accommodation.currency,
        guestName,
        guestPhone,
        guestEmail,
        specialRequests,
        status: 'PENDING'
      },
      include: {
        accommodation: {
          include: {
            city: { select: { nameAr: true } },
            host: { select: { id: true, name: true, nameAr: true, phone: true } }
          }
        }
      }
    })

    // Create notification for host
    await db.notification.create({
      data: {
        userId: accommodation.hostId,
        type: 'booking',
        titleAr: 'حجز جديد',
        bodyAr: `لديك طلب حجز جديد في ${accommodation.titleAr}`,
        data: JSON.stringify({ bookingId: booking.id })
      }
    })

    return NextResponse.json({
      success: true,
      booking,
      message: 'تم إنشاء الحجز بنجاح'
    })
  } catch (error) {
    console.error('Error creating booking:', error)
    return NextResponse.json(
      { error: 'حدث خطأ أثناء إنشاء الحجز' },
      { status: 500 }
    )
  }
}
