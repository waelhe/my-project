// ═══════════════════════════════════════════════════════════════════════════
// Vision API - Image Analysis for Tourism
// واجهة تحليل الصور للسياحة
// ═══════════════════════════════════════════════════════════════════════════

import { NextRequest, NextResponse } from 'next/server';
import ZAI from 'z-ai-web-dev-sdk';
import { tourismAgentLimiter, getClientIP, createRateLimitHeaders } from '@/lib/rate-limiter';
import { IMAGE_ANALYSIS_PROMPT } from '@/modules/ai/lib/prompts';

// Initialize ZAI instance
let zaiInstance: Awaited<ReturnType<typeof ZAI.create>> | null = null;

async function getZAI() {
  if (!zaiInstance) {
    zaiInstance = await ZAI.create();
  }
  return zaiInstance;
}

/**
 * POST - Analyze image for tourism context
 * تحليل الصورة للسياق السياحي
 */
export async function POST(request: NextRequest) {
  try {
    // Rate limiting check
    const clientIP = getClientIP(request);
    const rateLimitResult = await tourismAgentLimiter.check(clientIP);
    
    if (!rateLimitResult.success) {
      return NextResponse.json(
        { 
          error: 'طلبات كثيرة جداً. يرجى الانتظار قبل المحاولة مجدداً',
          retryAfter: rateLimitResult.retryAfter 
        },
        { 
          status: 429,
          headers: createRateLimitHeaders(rateLimitResult)
        }
      );
    }

    const body = await request.json();
    const { image, message, sessionId } = body;

    if (!image) {
      return NextResponse.json(
        { error: 'الصورة مطلوبة' },
        { status: 400 }
      );
    }

    const zai = await getZAI();

    // Build vision messages
    const visionMessages = [
      {
        role: 'user' as const,
        content: [
          { type: 'text', text: IMAGE_ANALYSIS_PROMPT },
          { type: 'image_url', image_url: { url: image } }
        ]
      }
    ];

    // Analyze image with vision model
    const visionResponse = await zai.chat.completions.createVision({
      model: 'gpt-4o',
      messages: visionMessages as any,
      thinking: { type: 'disabled' }
    });

    const imageAnalysis = visionResponse.choices[0]?.message?.content || '';

    // If there's a follow-up message, process it
    let finalResponse = imageAnalysis;
    
    if (message) {
      // Combine analysis with user's question
      const followUpMessages = [
        {
          role: 'assistant' as const,
          content: `تحليل الصورة: ${imageAnalysis}`
        },
        {
          role: 'user' as const,
          content: message
        }
      ];

      const followUpResponse = await zai.chat.completions.create({
        messages: followUpMessages as any,
        thinking: { type: 'disabled' }
      });

      finalResponse = followUpResponse.choices[0]?.message?.content || imageAnalysis;
    }

    return NextResponse.json({
      success: true,
      analysis: finalResponse,
      imageAnalysis: imageAnalysis,
      timestamp: new Date().toISOString()
    }, {
      headers: createRateLimitHeaders(rateLimitResult)
    });

  } catch (error) {
    console.error('Vision API error:', error);
    return NextResponse.json(
      { 
        success: false,
        error: 'حدث خطأ في تحليل الصورة. يرجى المحاولة مرة أخرى.',
        details: error instanceof Error ? error.message : 'Unknown error'
      },
      { status: 500 }
    );
  }
}

/**
 * GET - Vision API info
 */
export async function GET() {
  return NextResponse.json({
    success: true,
    message: 'AI Vision API - ضيف',
    capabilities: [
      'تحليل صور المعالم السياحية',
      'التعرف على الأماكن السورية',
      'تقديم معلومات عن المواقع',
      'توصيات سياحية بناءً على الصور'
    ],
    supportedFormats: ['jpg', 'jpeg', 'png', 'gif', 'webp']
  });
}
