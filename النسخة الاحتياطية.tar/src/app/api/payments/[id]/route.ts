import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET /api/payments/[id] - Get single payment
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params

    const payment = await db.payment.findUnique({
      where: { id },
      include: {
        booking: {
          include: {
            accommodation: {
              select: {
                id: true,
                titleAr: true,
                titleEn: true,
                city: { select: { nameAr: true } },
                host: {
                  select: { id: true, name: true, nameAr: true, phone: true }
                }
              }
            },
            guest: {
              select: { id: true, name: true, nameAr: true, phone: true }
            }
          }
        },
        user: {
          select: { id: true, name: true, nameAr: true, phone: true }
        }
      }
    })

    if (!payment) {
      return NextResponse.json(
        { error: 'الدفع غير موجود' },
        { status: 404 }
      )
    }

    return NextResponse.json({ payment })
  } catch (error) {
    console.error('Get payment error:', error)
    return NextResponse.json(
      { error: 'حدث خطأ في جلب الدفع' },
      { status: 500 }
    )
  }
}

// PUT /api/payments/[id] - Update payment status
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const body = await request.json()
    const {
      status,
      transactionId,
      paymentDetails,
      releaseDate
    } = body

    // Check payment exists
    const existingPayment = await db.payment.findUnique({
      where: { id },
      include: { booking: true }
    })

    if (!existingPayment) {
      return NextResponse.json(
        { error: 'الدفع غير موجود' },
        { status: 404 }
      )
    }

    // Update payment
    const payment = await db.payment.update({
      where: { id },
      data: {
        ...(status && { status }),
        ...(transactionId && { transactionId }),
        ...(paymentDetails && { paymentDetails: JSON.stringify(paymentDetails) }),
        ...(releaseDate && { releaseDate: new Date(releaseDate) }),
        ...(status === 'COMPLETED' && { completedAt: new Date() })
      },
      include: {
        booking: {
          include: {
            accommodation: {
              select: { id: true, titleAr: true }
            }
          }
        }
      }
    })

    // If payment is completed and is guarantee, update booking
    if (status === 'COMPLETED' && existingPayment.isGuarantee && existingPayment.booking) {
      await db.booking.update({
        where: { id: existingPayment.bookingId },
        data: { status: 'CONFIRMED' }
      })
    }

    return NextResponse.json({
      success: true,
      message: 'تم تحديث الدفع بنجاح',
      payment
    })
  } catch (error) {
    console.error('Update payment error:', error)
    return NextResponse.json(
      { error: 'حدث خطأ في تحديث الدفع' },
      { status: 500 }
    )
  }
}

// DELETE /api/payments/[id] - Cancel/Delete payment
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params

    const payment = await db.payment.findUnique({
      where: { id }
    })

    if (!payment) {
      return NextResponse.json(
        { error: 'الدفع غير موجود' },
        { status: 404 }
      )
    }

    // Can only cancel pending payments
    if (payment.status !== 'PENDING') {
      return NextResponse.json(
        { error: 'لا يمكن إلغاء دفع تمت معالجته' },
        { status: 400 }
      )
    }

    // Update status to cancelled instead of deleting
    await db.payment.update({
      where: { id },
      data: { status: 'CANCELLED' }
    })

    return NextResponse.json({
      success: true,
      message: 'تم إلغاء الدفع بنجاح'
    })
  } catch (error) {
    console.error('Delete payment error:', error)
    return NextResponse.json(
      { error: 'حدث خطأ في إلغاء الدفع' },
      { status: 500 }
    )
  }
}
