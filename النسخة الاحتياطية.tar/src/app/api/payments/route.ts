import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET /api/payments - Get payments list
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')
    const role = searchParams.get('role') // 'guest' or 'host'
    const status = searchParams.get('status')
    const limit = parseInt(searchParams.get('limit') || '20')
    const offset = parseInt(searchParams.get('offset') || '0')

    if (!userId) {
      return NextResponse.json(
        { error: 'معرف المستخدم مطلوب' },
        { status: 400 }
      )
    }

    const whereClause: any = {}

    if (role === 'host') {
      // Get payments for host's accommodations
      whereClause.booking = {
        accommodation: { hostId: userId }
      }
    } else {
      // Get payments for guest's bookings
      whereClause.userId = userId
    }

    if (status) {
      whereClause.status = status
    }

    const [payments, total] = await Promise.all([
      db.payment.findMany({
        where: whereClause,
        include: {
          booking: {
            include: {
              accommodation: {
                select: {
                  id: true,
                  titleAr: true,
                  city: { select: { nameAr: true } }
                }
              },
              guest: {
                select: { id: true, name: true, nameAr: true, phone: true }
              }
            }
          },
          user: {
            select: { id: true, name: true, nameAr: true, phone: true }
          }
        },
        orderBy: { createdAt: 'desc' },
        take: limit,
        skip: offset
      }),
      db.payment.count({ where: whereClause })
    ])

    return NextResponse.json({
      payments,
      pagination: {
        total,
        limit,
        offset,
        hasMore: offset + payments.length < total
      }
    })
  } catch (error) {
    console.error('Get payments error:', error)
    return NextResponse.json(
      { error: 'حدث خطأ في جلب المدفوعات' },
      { status: 500 }
    )
  }
}

// POST /api/payments - Create new payment
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const {
      bookingId,
      userId,
      amount,
      method,
      isGuarantee = false,
      paymentDetails
    } = body

    // Validate required fields
    if (!bookingId || !userId || !amount || !method) {
      return NextResponse.json(
        { error: 'جميع الحقول مطلوبة' },
        { status: 400 }
      )
    }

    // Check booking exists
    const booking = await db.booking.findUnique({
      where: { id: bookingId },
      include: { accommodation: true }
    })

    if (!booking) {
      return NextResponse.json(
        { error: 'الحجز غير موجود' },
        { status: 404 }
      )
    }

    // Create payment
    const payment = await db.payment.create({
      data: {
        amount,
        currency: 'SYP',
        status: 'PENDING',
        method: method as any,
        isGuarantee,
        transactionId: paymentDetails?.transactionId,
        paymentProvider: method,
        paymentDetails: paymentDetails ? JSON.stringify(paymentDetails) : null,
        releaseDate: isGuarantee
          ? new Date(booking.checkOut.getTime() + 24 * 60 * 60 * 1000) // Release 24h after checkout
          : null,
        bookingId,
        userId
      },
      include: {
        booking: {
          include: {
            accommodation: {
              select: { id: true, titleAr: true }
            }
          }
        }
      }
    })

    return NextResponse.json({
      success: true,
      message: 'تم إنشاء الدفع بنجاح',
      payment
    })
  } catch (error) {
    console.error('Create payment error:', error)
    return NextResponse.json(
      { error: 'حدث خطأ في إنشاء الدفع' },
      { status: 500 }
    )
  }
}
