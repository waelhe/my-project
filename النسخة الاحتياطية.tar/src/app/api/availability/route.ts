import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET /api/availability - Check availability for accommodation
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const accommodationId = searchParams.get('accommodationId')
    const startDate = searchParams.get('startDate')
    const endDate = searchParams.get('endDate')
    const months = parseInt(searchParams.get('months') || '3')

    if (!accommodationId) {
      return NextResponse.json(
        { error: 'معرف الإقامة مطلوب' },
        { status: 400 }
      )
    }

    // Calculate date range
    const start = startDate ? new Date(startDate) : new Date()
    const end = endDate ? new Date(endDate) : new Date(start)
    if (!endDate) {
      end.setMonth(end.getMonth() + months)
    }

    // Get accommodation
    const accommodation = await db.accommodation.findUnique({
      where: { id: accommodationId },
      select: { minNights: true, maxNights: true }
    })

    if (!accommodation) {
      return NextResponse.json(
        { error: 'الإقامة غير موجودة' },
        { status: 404 }
      )
    }

    // Get existing bookings in the date range
    const bookings = await db.booking.findMany({
      where: {
        accommodationId,
        status: { in: ['PENDING', 'CONFIRMED', 'PAYMENT_PENDING', 'PAID', 'CHECKED_IN'] },
        OR: [
          {
            AND: [
              { checkIn: { lt: end } },
              { checkOut: { gt: start } }
            ]
          }
        ]
      },
      select: {
        checkIn: true,
        checkOut: true
      }
    })

    // Get blocked dates from availability table
    const blockedDates = await db.availability.findMany({
      where: {
        accommodationId,
        date: {
          gte: start,
          lt: end
        },
        isAvailable: false
      },
      select: { date: true }
    })

    // Create a set of booked dates
    const bookedDates = new Set<string>()
    
    bookings.forEach(booking => {
      const current = new Date(booking.checkIn)
      while (current < booking.checkOut) {
        bookedDates.add(current.toISOString().split('T')[0])
        current.setDate(current.getDate() + 1)
      }
    })

    blockedDates.forEach(({ date }) => {
      bookedDates.add(date.toISOString().split('T')[0])
    })

    // Generate calendar data
    const calendar: Array<{
      date: string
      available: boolean
      price: number | null
    }> = []

    const current = new Date(start)
    while (current < end) {
      const dateStr = current.toISOString().split('T')[0]
      const available = !bookedDates.has(dateStr)
      
      // Check if date is in the past
      const isPast = current < new Date()
      
      calendar.push({
        date: dateStr,
        available: available && !isPast,
        price: null // Could be enhanced with dynamic pricing
      })
      
      current.setDate(current.getDate() + 1)
    }

    return NextResponse.json({
      accommodationId,
      minNights: accommodation.minNights,
      maxNights: accommodation.maxNights,
      calendar,
      bookedDates: Array.from(bookedDates)
    })
  } catch (error) {
    console.error('Error checking availability:', error)
    return NextResponse.json(
      { error: 'حدث خطأ أثناء التحقق من التوفر' },
      { status: 500 }
    )
  }
}

// POST /api/availability - Block/unblock dates
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { accommodationId, dates, isAvailable, hostId } = body

    if (!accommodationId || !dates || !Array.isArray(dates)) {
      return NextResponse.json(
        { error: 'بيانات غير مكتملة' },
        { status: 400 }
      )
    }

    // Verify host owns this accommodation
    const accommodation = await db.accommodation.findFirst({
      where: { id: accommodationId, hostId }
    })

    if (!accommodation) {
      return NextResponse.json(
        { error: 'غير مصرح لك بتعديل هذه الإقامة' },
        { status: 403 }
      )
    }

    // Create/update availability records
    const operations = dates.map((dateStr: string) => ({
      where: {
        date_accommodationId: {
          date: new Date(dateStr),
          accommodationId
        }
      },
      update: { isAvailable },
      create: {
        date: new Date(dateStr),
        accommodationId,
        isAvailable
      }
    }))

    await Promise.all(
      operations.map(op => db.availability.upsert(op))
    )

    return NextResponse.json({
      success: true,
      message: isAvailable ? 'تم إتاحة التواريخ' : 'تم حجز التواريخ',
      affectedDates: dates.length
    })
  } catch (error) {
    console.error('Error updating availability:', error)
    return NextResponse.json(
      { error: 'حدث خطأ أثناء تحديث التوفر' },
      { status: 500 }
    )
  }
}
