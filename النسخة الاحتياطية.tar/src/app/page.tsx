'use client'

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { toast } from "sonner"
import {
  Search,
  MapPin,
  Star,
  Heart,
  Shield,
  MessageCircle,
  Phone,
  Home as HomeIcon,
  Car,
  Compass,
  Building2,
  Users,
  CheckCircle2,
  ArrowLeft,
  Menu,
  X,
  Loader2,
  AlertCircle,
  ChevronLeft,
  ChevronRight,
  Sparkles,
  MessageSquare,
  ThumbsUp,
  Eye,
  Clock,
  Award,
  TrendingUp,
  Bookmark,
  Share2,
  MoreHorizontal,
  Send,
  Smile,
  PenSquare,
  Filter,
  SortAsc,
  Plus,
  User,
  Settings,
  LogOut,
  Bell,
  HelpCircle,
  Megaphone,
  BookOpen,
  Lightbulb,
  Calendar,
  Image as ImageIcon,
  Trash2,
  Edit,
  Moon,
  Wallet,
  CreditCard
} from "lucide-react"
import { useState, useEffect, createContext, useContext, useRef } from "react"
import { TourismAgent } from "@/modules/ai/components/TourismAgent"

// ==================== Navigation Context ====================

type PageType = 'home' | 'community' | 'community-post' | 'accommodations' | 'accommodation-detail' | 'search' | 'host-reviews' | 'profile' | 'host-dashboard' | 'add-accommodation' | 'my-bookings' | 'booking-detail' | 'host-bookings' | 'inbox' | 'conversation' | 'notifications' | 'login' | 'register' | 'verify-otp' | 'payment' | 'payment-history' | 'payouts' | 'admin' | 'admin-users' | 'admin-accommodations' | 'admin-bookings' | 'how-it-works' | 'transport' | 'transport-detail' | 'tours' | 'tour-detail' | 'business' | 'business-detail'

interface NavigationContextType {
  currentPage: PageType
  setCurrentPage: (page: PageType) => void
  pageParams: Record<string, string>
  setPageParams: (params: Record<string, string>) => void
  navigate: (page: PageType, params?: Record<string, string>) => void
}

const NavigationContext = createContext<NavigationContextType | null>(null)

function useNavigation() {
  const context = useContext(NavigationContext)
  if (!context) {
    throw new Error('useNavigation must be used within NavigationProvider')
  }
  return context
}

// ==================== Types ====================

// Skeleton Components for Loading States
function SkeletonCard({ className = "" }: { className?: string }) {
  return (
    <div className={`animate-pulse bg-gray-100 rounded-xl overflow-hidden ${className}`}>
      <div className="h-full bg-gradient-to-b from-gray-200 via-gray-100 to-gray-200 bg-[length:200%_100%] animate-shimmer" />
    </div>
  )
}

function SkeletonText({ width = "w-full", height = "h-4" }: { width?: string; height?: string }) {
  return <div className={`animate-pulse bg-gray-200 rounded ${width} ${height}`} />
}

function SkeletonCircle({ size = "w-12" }: { size?: string }) {
  return <div className={`animate-pulse bg-gray-200 rounded-full ${size} ${size.replace('w', 'h')}`} />
}

// Empty State Component
function EmptyState({ 
  icon: Icon, 
  title, 
  description, 
  action,
  actionLabel
}: { 
  icon: React.ElementType
  title: string
  description: string
  action?: () => void
  actionLabel?: string
}) {
  return (
    <Card className="text-center py-16 border-0 shadow-sm">
      <CardContent className="flex flex-col items-center">
        <div className="w-20 h-20 bg-gradient-to-br from-gray-100 to-gray-50 rounded-full flex items-center justify-center mb-6">
          <Icon className="w-10 h-10 text-gray-300" />
        </div>
        <h3 className="text-xl font-semibold text-gray-700 mb-2">{title}</h3>
        <p className="text-gray-500 mb-6 max-w-md">{description}</p>
        {action && actionLabel && (
          <Button onClick={action} className="bg-amber-500 hover:bg-amber-600 text-white">
            {actionLabel}
          </Button>
        )}
      </CardContent>
    </Card>
  )
}

// Animated Counter Component
function AnimatedCounter({ value, suffix = "", duration = 2000 }: { value: number; suffix?: string; duration?: number }) {
  const [count, setCount] = useState(0)
  
  useEffect(() => {
    let startTime: number
    let animationFrame: number
    
    const animate = (timestamp: number) => {
      if (!startTime) startTime = timestamp
      const progress = Math.min((timestamp - startTime) / duration, 1)
      setCount(Math.floor(progress * value))
      
      if (progress < 1) {
        animationFrame = requestAnimationFrame(animate)
      }
    }
    
    animationFrame = requestAnimationFrame(animate)
    return () => cancelAnimationFrame(animationFrame)
  }, [value, duration])
  
  return <span>{count.toLocaleString()}{suffix}</span>
}

// Fade In Animation Wrapper
function FadeIn({ children, delay = 0, className = "" }: { children: React.ReactNode; delay?: number; className?: string }) {
  const [isVisible, setIsVisible] = useState(false)
  
  useEffect(() => {
    const timer = setTimeout(() => setIsVisible(true), delay)
    return () => clearTimeout(timer)
  }, [delay])
  
  return (
    <div className={`transition-all duration-700 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'} ${className}`}>
      {children}
    </div>
  )
}

interface City {
  id: string
  nameAr: string
  nameEn: string
  governorate: string
  isPopular: boolean
  image: string | null
  _count: {
    accommodations: number
  }
}

interface Accommodation {
  id: string
  titleAr: string
  titleEn: string | null
  type: string
  addressAr: string | null
  basePrice: number
  rating: number
  reviewCount: number
  coverImage: string | null
  images: string[]
  city: {
    nameAr: string
    nameEn: string
  } | null
}

// ==================== Interactive Map Component ====================

// Syrian cities coordinates
const SYRIAN_CITIES: Record<string, { lat: number; lng: number }> = {
  'دمشق': { lat: 33.5138, lng: 36.2765 },
  'حلب': { lat: 36.2021, lng: 37.1343 },
  'حمص': { lat: 34.7384, lng: 36.7128 },
  'حماة': { lat: 35.1318, lng: 36.7498 },
  'اللاذقية': { lat: 35.5378, lng: 35.7937 },
  'طرطوس': { lat: 34.8959, lng: 35.8867 },
  'تدمر': { lat: 34.5491, lng: 38.2833 },
  'صافيتا': { lat: 34.8556, lng: 36.1169 },
  'معلولا': { lat: 33.8794, lng: 36.5728 },
}

function InteractiveMap({ lat, lng, title, city }: { lat: number; lng: number; title: string; city?: string }) {
  const mapRef = useRef<HTMLDivElement>(null)
  const [mapLoaded, setMapLoaded] = useState(false)

  useEffect(() => {
    if (!mapRef.current || mapLoaded) return

    // Dynamically import Leaflet
    import('leaflet').then((L) => {
      if (!mapRef.current) return

      // Set default icon path
      delete (L.Icon.Default.prototype as any)._getIconUrl
      L.Icon.Default.mergeOptions({
        iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon-2x.png',
        iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon.png',
        shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-shadow.png',
      })

      // Create custom icon
      const customIcon = L.divIcon({
        className: 'custom-marker',
        html: `<div style="
          background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%);
          width: 40px;
          height: 40px;
          border-radius: 50% 50% 50% 0;
          transform: rotate(-45deg);
          display: flex;
          align-items: center;
          justify-content: center;
          box-shadow: 0 4px 12px rgba(245, 158, 11, 0.4);
          border: 3px solid white;
        "><svg style="transform: rotate(45deg)" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg></div>`,
        iconSize: [40, 40],
        iconAnchor: [20, 40],
        popupAnchor: [0, -40],
      })

      // Initialize map
      const map = L.map(mapRef.current, {
        center: [lat, lng],
        zoom: 14,
        scrollWheelZoom: false,
      })

      // Add OpenStreetMap tiles
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
        maxZoom: 19,
      }).addTo(map)

      // Add marker
      const marker = L.marker([lat, lng], { icon: customIcon }).addTo(map)
      marker.bindPopup(`
        <div style="text-align: right; direction: rtl; padding: 8px;">
          <strong style="font-size: 14px; color: #1f2937;">${title}</strong>
          ${city ? `<br><span style="color: #6b7280; font-size: 12px;">📍 ${city}</span>` : ''}
        </div>
      `)

      setMapLoaded(true)

      // Cleanup
      return () => {
        map.remove()
      }
    })
  }, [lat, lng, title, city, mapLoaded])

  return (
    <div
      ref={mapRef}
      className="w-full h-80 bg-gray-100 rounded-xl"
      style={{ minHeight: '320px' }}
    />
  )
}

// Map for multiple accommodations
function AccommodationsMap({ accommodations }: { accommodations: Accommodation[] }) {
  const mapRef = useRef<HTMLDivElement>(null)
  const [mapLoaded, setMapLoaded] = useState(false)

  useEffect(() => {
    if (!mapRef.current || mapLoaded || accommodations.length === 0) return

    import('leaflet').then((L) => {
      if (!mapRef.current) return

      const map = L.map(mapRef.current, {
        center: [35.0, 38.0], // Center of Syria
        zoom: 6,
        scrollWheelZoom: false,
      })

      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; OpenStreetMap',
        maxZoom: 19,
      }).addTo(map)

      const bounds: [number, number][] = []

      accommodations.forEach((acc) => {
        const lat = acc.latitude || SYRIAN_CITIES[acc.city?.nameAr || '']?.lat || 33.5
        const lng = acc.longitude || SYRIAN_CITIES[acc.city?.nameAr || '']?.lng || 36.3

        const customIcon = L.divIcon({
          className: 'custom-marker',
          html: `<div style="
            background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%);
            width: 32px;
            height: 32px;
            border-radius: 50% 50% 50% 0;
            transform: rotate(-45deg);
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 2px 8px rgba(245, 158, 11, 0.4);
            border: 2px solid white;
            font-size: 12px;
            color: white;
            font-weight: bold;
          ">${acc.basePrice / 1000}K</div>`,
          iconSize: [32, 32],
          iconAnchor: [16, 32],
          popupAnchor: [0, -32],
        })

        const marker = L.marker([lat, lng], { icon: customIcon }).addTo(map)
        marker.bindPopup(`
          <div style="text-align: right; direction: rtl; padding: 8px; min-width: 150px;">
            <strong style="font-size: 13px; color: #1f2937;">${acc.titleAr}</strong>
            <br>
            <span style="color: #f59e0b; font-weight: bold;">${acc.basePrice.toLocaleString()} ل.س</span>
            <br>
            <span style="color: #6b7280; font-size: 11px;">⭐ ${acc.rating.toFixed(1)} • ${acc.city?.nameAr || ''}</span>
          </div>
        `)

        bounds.push([lat, lng])
      })

      if (bounds.length > 0) {
        map.fitBounds(bounds as L.LatLngBoundsExpression, { padding: [50, 50] })
      }

      setMapLoaded(true)

      return () => {
        map.remove()
      }
    })
  }, [accommodations, mapLoaded])

  return (
    <div
      ref={mapRef}
      className="w-full h-96 bg-gray-100 rounded-xl"
      style={{ minHeight: '380px' }}
    />
  )
}

interface CommunityPost {
  id: string
  titleAr: string
  titleEn: string | null
  contentAr: string
  type: string
  viewCount: number
  likeCount: number
  commentCount: number
  isPinned: boolean
  isFeatured: boolean
  tags: string[]
  createdAt: string
  author: {
    id: string
    name: string | null
    nameAr: string | null
    avatar: string | null
    role: string
  }
  category: {
    id: string
    nameAr: string
    nameEn: string | null
    icon: string | null
    color: string | null
  } | null
  _count: {
    comments: number
    likes: number
  }
}

interface CommunityCategory {
  id: string
  nameAr: string
  nameEn: string | null
  descriptionAr: string | null
  icon: string | null
  color: string | null
  isPopular: boolean
  postsCount?: number
}

interface HostReview {
  id: string
  communication: number
  cleanliness: number
  accuracy: number
  value: number
  location: number
  checkIn: number
  overallRating: number
  commentAr: string | null
  isVerified: boolean
  hostResponse: string | null
  hostResponseAt: string | null
  createdAt: string
  reviewer: {
    id: string
    name: string | null
    nameAr: string | null
    avatar: string | null
  }
  host: {
    id: string
    name: string | null
    nameAr: string | null
    avatar: string | null
  }
}

// ==================== Home View Components ====================

function HeroSection({ totalAccommodations, totalCities, onSearch }: { totalAccommodations: number; totalCities: number; onSearch: () => void }) {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedType, setSelectedType] = useState("all")
  const [currentSlide, setCurrentSlide] = useState(0)
  const [isTransitioning, setIsTransitioning] = useState(false)

  const destinations = [
    { name: "دمشق", description: "أقدم عاصمة مأهولة في العالم - الجامع الأموي والأسواق التاريخية", image: "/images/cities/damascus.png" },
    { name: "حلب", description: "قلعة حلب - من أعظم القلاع في العالم", image: "/images/cities/aleppo.png" },
    { name: "اللاذقية", description: "سحر البحر المتوسط - شواطئ خلابة ومنتجعات سياحية", image: "/images/cities/latakia.png" },
    { name: "تدمر", description: "عروس الصحراء - آثار رومانية تراث عالمي", image: "/images/cities/palmyra.png" },
    { name: "معلولا", description: "دير مار تقلا - مدينة الكهوف والتاريخ", image: "/images/cities/maaloula.png" },
    { name: "حمص", description: "قلعة الحصن - كراك دي شوفالييه العظيمة", image: "/images/cities/homs.png" },
  ]

  const searchTypes = [
    { id: "all", label: "الكل" },
    { id: "hotel", label: "فنادق" },
    { id: "apartment", label: "شقق" },
    { id: "chalet", label: "شاليهات" },
    { id: "tour", label: "جولات" },
  ]

  useEffect(() => {
    const interval = setInterval(() => {
      setIsTransitioning(true)
      setTimeout(() => {
        setCurrentSlide((prev) => (prev + 1) % destinations.length)
        setIsTransitioning(false)
      }, 500)
    }, 5000)
    return () => clearInterval(interval)
  }, [destinations.length])

  const goToSlide = (index: number) => {
    setIsTransitioning(true)
    setTimeout(() => {
      setCurrentSlide(index)
      setIsTransitioning(false)
    }, 500)
  }

  return (
    <section className="relative min-h-[60vh] md:min-h-[75vh] flex items-center justify-center overflow-hidden">
      {destinations.map((dest, index) => (
        <div
          key={index}
          className={`absolute inset-0 bg-cover bg-center transition-all duration-1000 ease-in-out ${
            index === currentSlide ? 'opacity-100 scale-100' : 'opacity-0 scale-105'
          }`}
          style={{ backgroundImage: `url('${dest.image}')` }}
        />
      ))}
      
      <div className="absolute inset-0 bg-gradient-to-b from-black/50 via-black/30 to-black/80" />
      
      <div className="relative z-10 w-full max-w-7xl mx-auto px-4 sm:px-6 text-center pt-8 sm:pt-12">
        <div className="mb-4 sm:mb-6 flex justify-center">
          <div className="bg-white/20 backdrop-blur-md rounded-full px-4 sm:px-6 py-2 sm:py-3 flex items-center gap-2">
            <Sparkles className="w-4 h-4 sm:w-5 sm:h-5 text-amber-400" />
            <span className="text-white text-sm sm:text-base font-medium">منصة ضيف السياحية</span>
          </div>
        </div>
        
        <h2 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-4 sm:mb-6 leading-tight px-2">
          اكتشف جمال <span className="bg-gradient-to-r from-amber-300 to-orange-300 bg-clip-text text-transparent">سوريا</span>
        </h2>
        
        <div className={`mb-4 sm:mb-6 transition-all duration-1000 ${isTransitioning ? 'opacity-0 translate-y-2' : 'opacity-100 translate-y-0'}`}>
          <div className="flex items-center justify-center gap-2 mb-2">
            <MapPin className="w-5 h-5 sm:w-6 sm:h-6 text-amber-300" />
            <span className="text-xl sm:text-2xl md:text-3xl font-bold text-white">{destinations[currentSlide].name}</span>
          </div>
          <p className="text-white/90 text-sm sm:text-base md:text-lg max-w-2xl mx-auto px-4 font-medium leading-relaxed drop-shadow-md">
            {destinations[currentSlide].description}
          </p>
        </div>
        
        <div className="w-full max-w-4xl mx-auto bg-white/95 backdrop-blur-sm rounded-2xl shadow-2xl p-4 sm:p-6 md:p-8 mb-6 sm:mb-8 border border-amber-100">
          <div className="text-center mb-4 sm:mb-6">
            <p className="text-base sm:text-lg md:text-xl text-gray-800 font-semibold leading-relaxed">
              احجز إقامتك وجولاتك بكل أمان مع أفضل المضيفين المحليين
            </p>
            <div className="flex items-center justify-center gap-4 mt-3">
              <div className="flex items-center gap-1.5">
                <Shield className="w-4 h-4 text-emerald-500" />
                <span className="text-sm text-gray-700">حجز آمن</span>
              </div>
              <div className="w-1 h-1 rounded-full bg-emerald-300" />
              <div className="flex items-center gap-1.5">
                <Users className="w-4 h-4 text-emerald-500" />
                <span className="text-sm text-gray-700">مضيفون موثوقون</span>
              </div>
            </div>
          </div>
          
          <div className="flex flex-wrap gap-2 mb-4 sm:mb-6 justify-center">
            {searchTypes.map((type) => (
              <Button
                key={type.id}
                variant={selectedType === type.id ? "default" : "outline"}
                onClick={() => setSelectedType(type.id)}
                className={`rounded-full px-4 sm:px-6 text-sm sm:text-base ${selectedType === type.id ? "bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white border-0" : "border-emerald-200 text-gray-700 hover:bg-emerald-50"}`}
              >
                {type.label}
              </Button>
            ))}
          </div>
          
          <div className="flex flex-col sm:flex-row gap-3 sm:gap-4">
            <div className="flex-1 relative">
              <Search className="absolute right-3 sm:right-4 top-1/2 -translate-y-1/2 text-emerald-500 w-4 h-4 sm:w-5 sm:h-5" />
              <Input
                type="text"
                placeholder="ابحث عن وجهتك..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="h-12 sm:h-14 pr-10 sm:pr-12 text-base sm:text-lg border-emerald-200 rounded-xl focus:border-emerald-500 focus:ring-emerald-500"
              />
            </div>
            <Button size="lg" onClick={onSearch} className="h-12 sm:h-14 px-6 sm:px-8 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white rounded-xl shadow-lg shadow-amber-500/25">
              <Search className="w-4 h-4 sm:w-5 sm:h-5 ml-2" />
              بحث
            </Button>
          </div>
          
          <div className="flex flex-wrap justify-center gap-4 sm:gap-8 mt-4 sm:mt-6 pt-4 sm:pt-6 border-t border-emerald-100">
            <div className="text-center">
              <div className="text-xl sm:text-2xl font-bold text-emerald-600">+{totalAccommodations}</div>
              <div className="text-xs sm:text-sm text-gray-600">مكان إقامة</div>
            </div>
            <div className="text-center">
              <div className="text-xl sm:text-2xl font-bold text-teal-600">+{totalCities}</div>
              <div className="text-xs sm:text-sm text-gray-600">وجهة سياحية</div>
            </div>
            <div className="text-center">
              <div className="text-xl sm:text-2xl font-bold text-amber-500">+10,000</div>
              <div className="text-xs sm:text-sm text-gray-600">ضيف سعيد</div>
            </div>
          </div>
        </div>
      </div>
      
      <button onClick={() => goToSlide((currentSlide - 1 + destinations.length) % destinations.length)} className="absolute right-4 sm:right-8 top-1/2 -translate-y-1/2 z-20 w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-white/10 backdrop-blur-md hover:bg-white/20 flex items-center justify-center transition-all duration-300 group">
        <ChevronRight className="w-5 h-5 sm:w-6 sm:h-6 text-white group-hover:scale-110 transition-transform" />
      </button>
      <button onClick={() => goToSlide((currentSlide + 1) % destinations.length)} className="absolute left-4 sm:left-8 top-1/2 -translate-y-1/2 z-20 w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-white/10 backdrop-blur-md hover:bg-white/20 flex items-center justify-center transition-all duration-300 group">
        <ChevronLeft className="w-5 h-5 sm:w-6 sm:h-6 text-white group-hover:scale-110 transition-transform" />
      </button>
      
      <div className="absolute bottom-6 sm:bottom-8 left-1/2 -translate-x-1/2 z-20 flex items-center gap-2">
        {destinations.map((_, index) => (
          <button key={index} onClick={() => goToSlide(index)} className={`h-2 rounded-full transition-all duration-300 ${index === currentSlide ? 'w-6 bg-white' : 'w-2 bg-white/50 hover:bg-white/70'}`} />
        ))}
      </div>
    </section>
  )
}

function ServicesSection({ onNavigate }: { onNavigate: (page: PageType) => void }) {
  const services = [
    { icon: HomeIcon, title: "السكن", description: "فنادق، شقق مفروشة، شاليهات، ومخيمات في جميع أنحاء سوريا", color: "bg-amber-500", page: 'accommodations' as PageType },
    { icon: Car, title: "النقل", description: "سيارات مع أو بدون سائق، باصات، وخدمات نقل آمنة", color: "bg-emerald-500", page: 'transport' as PageType },
    { icon: Compass, title: "السياحة", description: "جولات سياحية، معالم تاريخية، سياحة علاجية وسياحة حرب", color: "bg-sky-500", page: 'tours' as PageType },
    { icon: Building2, title: "الأعمال", description: "فرص استثمارية، خدمات للأعمال، وشراكات تجارية", color: "bg-violet-500", page: 'business' as PageType }
  ]

  return (
    <section className="py-20 bg-gradient-to-b from-gray-50 to-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <Badge className="mb-4 bg-amber-100 text-amber-700 hover:bg-amber-100">خدماتنا</Badge>
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">كل ما تحتاجه لرحلتك في مكان واحد</h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">نقدم لك مجموعة متكاملة من الخدمات لتجعل رحلتك إلى سوريا تجربة لا تُنسى</p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {services.map((service, index) => (
            <Card key={index} className="group hover:shadow-xl transition-all duration-300 border-0 bg-white cursor-pointer overflow-hidden" onClick={() => onNavigate(service.page)}>
              <CardContent className="p-6">
                <div className={`w-14 h-14 ${service.color} rounded-2xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                  <service.icon className="w-7 h-7 text-white" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">{service.title}</h3>
                <p className="text-gray-500 text-sm mb-4">{service.description}</p>
                <Button variant="ghost" className="text-amber-600 hover:text-amber-700 p-0 group/btn">
                  اكتشف المزيد
                  <ArrowLeft className="w-4 h-4 mr-2 group-hover/btn:-translate-x-1 transition-transform" />
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}

function PopularDestinations({ cities, loading, error, onNavigate }: { cities: City[]; loading: boolean; error: string | null; onNavigate?: (page: PageType, params?: Record<string, string>) => void }) {
  const defaultCityImages: Record<string, string> = {
    "دمشق": "/images/cities/damascus.png",
    "حلب": "/images/cities/aleppo.png",
    "اللاذقية": "/images/cities/latakia.png",
    "طرطوس": "/images/cities/tartus.png",
    "تدمر": "/images/cities/palmyra.png",
    "معلولا": "/images/cities/maaloula.png",
  }
  const defaultImage = "/images/cities/damascus.png"

  const handleCityClick = (cityId: string) => {
    if (onNavigate) {
      onNavigate('accommodations', { cityId })
    }
  }

  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <Badge className="mb-4 bg-sky-100 text-sky-700 hover:bg-sky-100">وجهات مميزة</Badge>
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">اكتشف أجمل الأماكن في سوريا</h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">من المدن التاريخية إلى السواحل الخلابة، سوريا تنتظرك</p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {loading ? (
            [1, 2, 3, 4, 5, 6].map((i) => <div key={i} className="h-64 bg-gray-100 rounded-xl animate-pulse overflow-hidden"><div className="h-full bg-gradient-to-b from-gray-200 to-gray-100" /></div>)
          ) : (
            cities.slice(0, 6).map((city) => (
              <Card key={city.id} className="group overflow-hidden border-0 shadow-lg hover:shadow-2xl transition-all duration-300 cursor-pointer" onClick={() => handleCityClick(city.id)}>
                <div className="relative h-64 overflow-hidden bg-gray-200">
                  <img src={city.image || defaultCityImages[city.nameAr] || defaultImage} alt={`صورة لمدينة ${city.nameAr}`} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" loading="lazy" onError={(e) => { e.currentTarget.src = defaultImage }} />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent" />
                  <div className="absolute bottom-0 right-0 left-0 p-6">
                    <h3 className="text-2xl font-bold text-white mb-1">{city.nameAr}</h3>
                    <p className="text-white/80 text-sm mb-2">{city.governorate}</p>
                    <div className="flex items-center text-white/70 text-sm">
                      <HomeIcon className="w-4 h-4 ml-1" />
                      <span>{city._count.accommodations} مكان إقامة</span>
                    </div>
                  </div>
                </div>
              </Card>
            ))
          )}
        </div>
      </div>
    </section>
  )
}

function FeaturedAccommodations({ accommodations, loading, error, onNavigate }: { accommodations: Accommodation[]; loading: boolean; error: string | null; onNavigate?: (page: PageType, params?: Record<string, string>) => void }) {
  const [favorites, setFavorites] = useState<Set<string>>(new Set())
  const typeLabels: Record<string, string> = { HOTEL: "فندق", APARTMENT: "شقة", VILLA: "فيلا", CHALET: "شاليه", CAMP: "مخيم", GUESTHOUSE: "نزل", HOSTEL: "سكن شباب", RESORT: "منتجع" }

  if (loading) {
    return (
      <section className="py-20 bg-gradient-to-b from-white to-gray-50">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[1, 2, 3, 4].map((i) => <div key={i} className="bg-gray-100 rounded-xl animate-pulse"><div className="h-48 bg-gray-200 rounded-t-xl" /><div className="p-4 space-y-2"><div className="h-4 bg-gray-200 rounded w-3/4" /><div className="h-4 bg-gray-200 rounded w-1/2" /></div></div>)}
          </div>
        </div>
      </section>
    )
  }

  const handleCardClick = (id: string) => {
    if (onNavigate) {
      onNavigate('accommodation-detail', { id })
    }
  }

  const toggleFavorite = (e: React.MouseEvent, id: string) => {
    e.stopPropagation()
    setFavorites(prev => {
      const newFavorites = new Set(prev)
      if (newFavorites.has(id)) {
        newFavorites.delete(id)
        toast.success('تمت الإزالة من المفضلة')
      } else {
        newFavorites.add(id)
        toast.success('تمت الإضافة للمفضلة', { description: 'يمكنك مشاهدة المفضلة من ملفك الشخصي' })
      }
      return newFavorites
    })
  }

  return (
    <section className="py-20 bg-gradient-to-b from-white to-gray-50">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-end mb-12">
          <div>
            <Badge className="mb-4 bg-amber-100 text-amber-700 hover:bg-amber-100">أماكن مميزة</Badge>
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900">أماكن الإقامة الأكثر طلباً</h2>
          </div>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {accommodations.slice(0, 4).map((acc) => {
            const displayImage = getAccommodationImage(acc)
            const location = acc.city ? `${acc.city.nameAr}${acc.addressAr ? '، ' + acc.addressAr : ''}` : acc.addressAr || 'سوريا'
            const isFavorite = favorites.has(acc.id)
            
            return (
              <Card key={acc.id} className="group overflow-hidden border-0 shadow-md hover:shadow-xl transition-all duration-300 cursor-pointer bg-white" onClick={() => handleCardClick(acc.id)}>
                <div className="relative h-48 overflow-hidden">
                  <img src={displayImage} alt={`صورة ${acc.titleAr}`} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" loading="lazy" />
                  {acc.rating >= 4.8 && <Badge className="absolute top-3 right-3 bg-amber-500 text-white">مميز</Badge>}
                  <Button variant="ghost" size="icon" className={`absolute top-3 left-3 ${isFavorite ? 'bg-red-50' : 'bg-white/80'} hover:bg-white rounded-full h-8 w-8 transition-all duration-300`} onClick={(e) => toggleFavorite(e, acc.id)}>
                    <Heart className={`w-4 h-4 transition-all duration-300 ${isFavorite ? 'text-red-500 fill-red-500 scale-110' : 'text-gray-600 hover:text-red-500'}`} />
                  </Button>
                </div>
                <CardContent className="p-4">
                  <div className="flex items-center text-sm text-gray-500 mb-2"><MapPin className="w-3 h-3 ml-1" />{location}</div>
                  <h3 className="font-semibold text-gray-900 mb-2 line-clamp-1">{acc.titleAr}</h3>
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center">
                      <Star className="w-4 h-4 text-amber-400 fill-amber-400 ml-1" />
                      <span className="font-medium text-sm">{acc.rating.toFixed(1)}</span>
                      <span className="text-gray-400 text-sm mr-1">({acc.reviewCount})</span>
                    </div>
                    <Badge variant="secondary" className="text-xs">{typeLabels[acc.type] || acc.type}</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="font-bold text-lg text-gray-900">{acc.basePrice.toLocaleString()}</span>
                      <span className="text-gray-500 text-sm mr-1">ل.س / ليلة</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </div>
      </div>
    </section>
  )
}

function HowItWorks() {
  const steps = [
    { number: "01", title: "ابحث واختر", description: "تصفح مئات الخيارات وابحث عن المكان المناسب لرحلتك", icon: Search },
    { number: "02", title: "احجز بسهولة", description: "أكمل الحجز بخطوات بسيطة مع خيارات دفع متعددة", icon: CheckCircle2 },
    { number: "03", title: "استمتع برحلتك", description: "تواصل مع المضيف واستمتع بإقامتك مع ضمان ضيف", icon: Heart }
  ]

  return (
    <section className="py-20 bg-gradient-to-br from-amber-50 to-orange-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <Badge className="mb-4 bg-amber-100 text-amber-700 hover:bg-amber-100">كيف يعمل</Badge>
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">احجز رحلتك في 3 خطوات بسيطة</h2>
        </div>
        
        <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
          {steps.map((step, index) => (
            <div key={index} className="text-center relative">
              <div className="w-20 h-20 bg-white rounded-2xl shadow-lg flex items-center justify-center mx-auto mb-6 relative">
                <step.icon className="w-8 h-8 text-amber-500" />
                <div className="absolute -top-2 -right-2 w-8 h-8 bg-amber-500 text-white rounded-full flex items-center justify-center text-sm font-bold">{step.number}</div>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">{step.title}</h3>
              <p className="text-gray-600">{step.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

function TrustSection() {
  const features = [
    { icon: Shield, title: "ضمان الحجز", description: "نظام ضمان يحمي حقوق الضيف والمضيف على حد سواء" },
    { icon: Users, title: "مضيفون موثوقون", description: "جميع المضيفين مُتحقق منهم لضمان تجربة آمنة" },
    { icon: MessageCircle, title: "دعم على مدار الساعة", description: "فريق دعم متخصص جاهز لمساعدتك في أي وقت" },
    { icon: Phone, title: "تواصل آمن", description: "تواصل مع المضيفين دون الحاجة لكشف معلوماتك الشخصية" }
  ]

  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <Badge className="mb-4 bg-emerald-100 text-emerald-700 hover:bg-emerald-100">لماذا ضيف؟</Badge>
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">رحلتك بأمان مع ضيف</h2>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <div key={index} className="text-center p-6 rounded-2xl bg-gray-50 hover:bg-gray-100 transition-colors">
              <div className="w-16 h-16 bg-emerald-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <feature.icon className="w-8 h-8 text-emerald-600" />
              </div>
              <h3 className="text-lg font-bold text-gray-900 mb-2">{feature.title}</h3>
              <p className="text-gray-600 text-sm">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

function CTASection({ onNavigate }: { onNavigate?: (page: PageType) => void }) {
  return (
    <section className="py-20 bg-gradient-to-r from-amber-500 to-orange-500">
      <div className="container mx-auto px-4 text-center">
        <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">هل أنت مستعد لاستكشاف سوريا؟</h2>
        <p className="text-white/90 text-lg mb-8 max-w-2xl mx-auto">انضم إلى آلاف الضيوف الذين اكتشفوا جمال سوريا معنا</p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button size="lg" className="bg-white text-amber-600 hover:bg-gray-100 rounded-full px-8" onClick={() => onNavigate?.('accommodations')}>ابدأ البحث الآن</Button>
          <Button size="lg" className="bg-transparent border-2 border-white text-white hover:bg-white/20 rounded-full px-8" onClick={() => onNavigate?.('how-it-works')}>كيف تعمل المنصة؟</Button>
        </div>
      </div>
    </section>
  )
}

function HostCTA({ onNavigate }: { onNavigate?: (page: PageType) => void }) {
  return (
    <section className="py-20 bg-gray-900">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div>
            <Badge className="mb-4 bg-amber-500/20 text-amber-400 hover:bg-amber-500/20">كن مضيفاً</Badge>
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">شارك مكانك مع ضيوف من جميع أنحاء العالم</h2>
            <p className="text-gray-400 text-lg mb-8">سواء كان لديك فندق، شقة، شاليه، أو حتى مخيم، انضم إلى منصة ضيف وابدأ بتقديم خدمتك للضيوف</p>
            <ul className="space-y-4 mb-8">
              {["إدارة سهلة للحجوزات عبر واتساب", "نظام ضمان يحمي حقوقك", "دعم فني متواصل", "تحصيل آمن للمدفوعات"].map((item, i) => (
                <li key={i} className="flex items-center text-gray-300">
                  <CheckCircle2 className="w-5 h-5 text-amber-500 ml-3" />
                  {item}
                </li>
              ))}
            </ul>
            <Button size="lg" className="bg-amber-500 hover:bg-amber-600 text-white rounded-full px-8" onClick={() => onNavigate?.('register')}>سجل كمضيف الآن</Button>
          </div>
          <div className="relative">
            <div className="bg-gradient-to-br from-amber-500/20 to-orange-500/20 rounded-3xl p-8 backdrop-blur-sm border border-amber-500/20">
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-gray-800 rounded-2xl p-6 text-center"><div className="text-3xl font-bold text-amber-400 mb-2">0%</div><div className="text-gray-400 text-sm">عمولة للأشهر الـ 3 الأولى</div></div>
                <div className="bg-gray-800 rounded-2xl p-6 text-center"><div className="text-3xl font-bold text-emerald-400 mb-2">24/7</div><div className="text-gray-400 text-sm">دعم فني مستمر</div></div>
                <div className="bg-gray-800 rounded-2xl p-6 text-center"><div className="text-3xl font-bold text-sky-400 mb-2">+500</div><div className="text-gray-400 text-sm">مضيف نشط</div></div>
                <div className="bg-gray-800 rounded-2xl p-6 text-center"><div className="text-3xl font-bold text-violet-400 mb-2">8%</div><div className="text-gray-400 text-sm">عمولة بعد الترويج</div></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

// ==================== Community View ====================

function CommunityView() {
  const [posts, setPosts] = useState<CommunityPost[]>([])
  const [categories, setCategories] = useState<CommunityCategory[]>([])
  const [loading, setLoading] = useState(true)
  const [activeCategory, setActiveCategory] = useState<string | null>(null)
  const [activeTab, setActiveTab] = useState("latest")
  const [showNewPostModal, setShowNewPostModal] = useState(false)
  const { navigate } = useNavigation()

  useEffect(() => {
    const fetchCommunityData = async () => {
      try {
        const [postsRes, categoriesRes] = await Promise.all([
          fetch('/api/community/posts?limit=12&sort=latest'),
          fetch('/api/community/categories?includeStats=true')
        ])

        if (postsRes.ok) {
          const data = await postsRes.json()
          setPosts(data.posts || [])
        }

        if (categoriesRes.ok) {
          const data = await categoriesRes.json()
          setCategories(data.categories || [])
        }
      } catch (error) {
        console.error('Error fetching community data:', error)
      } finally {
        setLoading(false)
      }
    }

    fetchCommunityData()
  }, [])

  const typeLabels: Record<string, { label: string; icon: any; color: string }> = {
    DISCUSSION: { label: 'نقاش', icon: MessageSquare, color: 'bg-sky-100 text-sky-700' },
    QUESTION: { label: 'سؤال', icon: MessageCircle, color: 'bg-amber-100 text-amber-700' },
    STORY: { label: 'تجربة', icon: Heart, color: 'bg-rose-100 text-rose-700' },
    ANNOUNCEMENT: { label: 'إعلان', icon: Megaphone, color: 'bg-violet-100 text-violet-700' },
    GUIDE: { label: 'دليل', icon: BookOpen, color: 'bg-emerald-100 text-emerald-700' }
  }

  const formatTimeAgo = (dateString: string) => {
    const date = new Date(dateString)
    const now = new Date()
    const diff = now.getTime() - date.getTime()
    const minutes = Math.floor(diff / 60000)
    const hours = Math.floor(diff / 3600000)
    const days = Math.floor(diff / 86400000)
    
    if (minutes < 60) return `منذ ${minutes} دقيقة`
    if (hours < 24) return `منذ ${hours} ساعة`
    if (days < 7) return `منذ ${days} يوم`
    return date.toLocaleDateString('ar-SY')
  }

  const filteredPosts = activeCategory ? posts.filter(p => p.category?.id === activeCategory) : posts

  const handlePostClick = (postId: string) => {
    navigate('community-post', { id: postId })
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Community Header */}
      <div className="bg-gradient-to-r from-violet-600 to-purple-600 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div>
              <h1 className="text-3xl md:text-4xl font-bold mb-2">مجتمع ضيف</h1>
              <p className="text-white/80 text-lg">شارك تجاربك واستفد من خبرات الآخرين</p>
            </div>
            <Button size="lg" className="bg-white text-violet-600 hover:bg-gray-100 rounded-full" onClick={() => setShowNewPostModal(true)}>
              <Plus className="w-4 h-4 ml-2" />
              مشاركة جديدة
            </Button>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Sidebar - Categories */}
          <aside className="lg:w-64 shrink-0">
            <Card className="sticky top-24 border-0 shadow-md">
              <CardContent className="p-4">
                <h3 className="font-bold text-gray-900 mb-4 flex items-center gap-2">
                  <Bookmark className="w-4 h-4" />
                  الأقسام
                </h3>
                <div className="space-y-1">
                  <button
                    onClick={() => setActiveCategory(null)}
                    className={`w-full text-right px-3 py-2 rounded-lg transition-colors ${
                      activeCategory === null ? 'bg-violet-100 text-violet-700' : 'hover:bg-gray-100 text-gray-700'
                    }`}
                  >
                    جميع المواضيع
                  </button>
                  {categories.map((cat) => (
                    <button
                      key={cat.id}
                      onClick={() => setActiveCategory(cat.id)}
                      className={`w-full text-right px-3 py-2 rounded-lg transition-colors flex items-center justify-between ${
                        activeCategory === cat.id ? 'bg-violet-100 text-violet-700' : 'hover:bg-gray-100 text-gray-700'
                      }`}
                    >
                      <span>{cat.nameAr}</span>
                      {cat.postsCount !== undefined && (
                        <span className="text-xs bg-gray-200 px-2 py-0.5 rounded-full">{cat.postsCount}</span>
                      )}
                    </button>
                  ))}
                </div>
              </CardContent>
            </Card>
          </aside>

          {/* Main Content */}
          <main className="flex-1">
            {/* Tabs */}
            <Tabs value={activeTab} onValueChange={setActiveTab} className="mb-6">
              <TabsList className="bg-white border shadow-sm">
                <TabsTrigger value="latest" className="gap-2">
                  <Clock className="w-4 h-4" />
                  الأحدث
                </TabsTrigger>
                <TabsTrigger value="popular" className="gap-2">
                  <TrendingUp className="w-4 h-4" />
                  الأكثر تفاعلاً
                </TabsTrigger>
                <TabsTrigger value="featured" className="gap-2">
                  <Star className="w-4 h-4" />
                  المميزة
                </TabsTrigger>
              </TabsList>
            </Tabs>

            {/* Posts Grid */}
            {loading ? (
              <div className="space-y-4">
                {[1, 2, 3, 4].map((i) => (
                  <Card key={i} className="border-0 shadow-md">
                    <CardContent className="p-5">
                      <div className="h-4 bg-gray-200 rounded w-3/4 mb-3 animate-pulse" />
                      <div className="h-3 bg-gray-100 rounded w-full mb-2 animate-pulse" />
                      <div className="h-3 bg-gray-100 rounded w-2/3 animate-pulse" />
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : filteredPosts.length > 0 ? (
              <div className="space-y-4">
                {filteredPosts.map((post) => {
                  const typeInfo = typeLabels[post.type] || typeLabels.DISCUSSION
                  return (
                    <Card 
                      key={post.id} 
                      className={`group border-0 shadow-md hover:shadow-xl transition-all duration-300 cursor-pointer ${
                        post.isPinned ? 'ring-2 ring-amber-400 bg-amber-50/30' : ''
                      }`}
                      onClick={() => navigate('community-post', { id: post.id })}
                    >
                      <CardContent className="p-5">
                        <div className="flex items-start gap-4">
                          {/* Author Avatar */}
                          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-amber-400 to-orange-500 flex items-center justify-center text-white font-bold shrink-0">
                            {post.author.name?.charAt(0) || post.author.nameAr?.charAt(0) || 'ض'}
                          </div>
                          
                          <div className="flex-1 min-w-0">
                            {/* Header */}
                            <div className="flex items-center justify-between mb-2">
                              <div className="flex items-center gap-2">
                                <p className="font-medium text-gray-900">{post.author.nameAr || post.author.name || 'ضيف'}</p>
                                <span className="text-gray-400">•</span>
                                <p className="text-sm text-gray-500">{formatTimeAgo(post.createdAt)}</p>
                                {post.isPinned && (
                                  <Badge className="bg-amber-100 text-amber-700 text-xs">
                                    <Bookmark className="w-3 h-3 ml-1" />
                                    مثبت
                                  </Badge>
                                )}
                              </div>
                              <Badge className={typeInfo.color}>
                                <typeInfo.icon className="w-3 h-3 ml-1" />
                                {typeInfo.label}
                              </Badge>
                            </div>

                            {/* Content */}
                            <h3 className="font-bold text-lg text-gray-900 mb-2 group-hover:text-violet-600 transition-colors">
                              {post.titleAr}
                            </h3>
                            <p className="text-gray-600 line-clamp-2 mb-3">{post.contentAr}</p>

                            {/* Category & Tags */}
                            <div className="flex items-center gap-2 mb-3">
                              {post.category && (
                                <span 
                                  className="text-xs px-2 py-1 rounded-full"
                                  style={{ backgroundColor: post.category.color || '#f3f4f6', color: '#374151' }}
                                >
                                  {post.category.nameAr}
                                </span>
                              )}
                              {post.tags.slice(0, 3).map((tag, i) => (
                                <span key={i} className="text-xs text-gray-500 bg-gray-100 px-2 py-1 rounded-full">
                                  #{tag}
                                </span>
                              ))}
                            </div>

                            {/* Footer Stats */}
                            <div className="flex items-center justify-between pt-3 border-t border-gray-100">
                              <div className="flex items-center gap-4 text-sm text-gray-500">
                                <span className="flex items-center gap-1"><Eye className="w-4 h-4" />{post.viewCount}</span>
                                <span className="flex items-center gap-1"><ThumbsUp className="w-4 h-4" />{post.likeCount}</span>
                                <span className="flex items-center gap-1"><MessageSquare className="w-4 h-4" />{post._count.comments}</span>
                              </div>
                              <Button variant="ghost" size="sm" className="text-violet-600 hover:text-violet-700" onClick={(e) => { e.stopPropagation(); handlePostClick(post.id) }}>
                                اقرأ المزيد
                                <ArrowLeft className="w-4 h-4 mr-1" />
                              </Button>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  )
                })}
              </div>
            ) : (
              <div className="text-center py-12">
                <MessageSquare className="w-12 h-12 text-gray-300 mx-auto mb-4" />
                <p className="text-gray-500">لا توجد مشاركات في هذا القسم</p>
              </div>
            )}
          </main>
        </div>
      </div>
    </div>
  )
}

// ==================== Community Post View ====================

function CommunityPostView() {
  const { pageParams, navigate } = useNavigation()
  const [post, setPost] = useState<CommunityPost | null>(null)
  const [loading, setLoading] = useState(true)
  const [comment, setComment] = useState("")

  useEffect(() => {
    const fetchPost = async () => {
      if (!pageParams.id) return
      
      try {
        const response = await fetch(`/api/community/posts/${pageParams.id}`)
        if (response.ok) {
          const data = await response.json()
          setPost(data.post)
        }
      } catch (error) {
        console.error('Error fetching post:', error)
      } finally {
        setLoading(false)
      }
    }

    fetchPost()
  }, [pageParams.id])

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto">
            <div className="h-8 bg-gray-200 rounded w-1/2 mb-4 animate-pulse" />
            <div className="h-4 bg-gray-100 rounded w-full mb-2 animate-pulse" />
            <div className="h-4 bg-gray-100 rounded w-2/3 animate-pulse" />
          </div>
        </div>
      </div>
    )
  }

  if (!post) {
    return (
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="container mx-auto px-4">
          <div className="text-center">
            <AlertCircle className="w-12 h-12 text-gray-300 mx-auto mb-4" />
            <p className="text-gray-500">المشاركة غير موجودة</p>
            <Button variant="outline" className="mt-4" onClick={() => navigate('community')}>
              العودة للمجتمع
            </Button>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto">
          <Button variant="ghost" className="mb-4" onClick={() => navigate('community')}>
            <ArrowLeft className="w-4 h-4 ml-2" />
            العودة للمجتمع
          </Button>

          <Card className="border-0 shadow-lg">
            <CardContent className="p-6">
              {/* Post Header */}
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-amber-400 to-orange-500 flex items-center justify-center text-white text-lg font-bold">
                  {post.author.name?.charAt(0) || 'ض'}
                </div>
                <div>
                  <p className="font-bold text-gray-900">{post.author.nameAr || post.author.name || 'ضيف'}</p>
                  <p className="text-sm text-gray-500">{new Date(post.createdAt).toLocaleDateString('ar-SY', { year: 'numeric', month: 'long', day: 'numeric' })}</p>
                </div>
              </div>

              {/* Post Title */}
              <h1 className="text-2xl font-bold text-gray-900 mb-4">{post.titleAr}</h1>

              {/* Post Content */}
              <div className="prose prose-lg max-w-none mb-6">
                <p className="text-gray-700 whitespace-pre-wrap">{post.contentAr}</p>
              </div>

              {/* Tags */}
              <div className="flex flex-wrap gap-2 mb-6">
                {post.tags.map((tag, i) => (
                  <span key={i} className="text-sm text-gray-600 bg-gray-100 px-3 py-1 rounded-full">#{tag}</span>
                ))}
              </div>

              {/* Stats */}
              <div className="flex items-center gap-6 py-4 border-t border-b border-gray-100 mb-6">
                <button className="flex items-center gap-2 text-gray-600 hover:text-violet-600 transition-colors">
                  <ThumbsUp className="w-5 h-5" />
                  <span>{post.likeCount} إعجاب</span>
                </button>
                <span className="flex items-center gap-2 text-gray-600">
                  <MessageSquare className="w-5 h-5" />
                  <span>{post._count.comments} تعليق</span>
                </span>
                <span className="flex items-center gap-2 text-gray-600">
                  <Eye className="w-5 h-5" />
                  <span>{post.viewCount} مشاهدة</span>
                </span>
              </div>

              {/* Comment Input */}
              <div className="mb-6">
                <div className="flex gap-3">
                  <div className="w-10 h-10 rounded-full bg-gray-200 flex items-center justify-center shrink-0">
                    <User className="w-5 h-5 text-gray-500" />
                  </div>
                  <div className="flex-1">
                    <Input
                      placeholder="أضف تعليقاً..."
                      value={comment}
                      onChange={(e) => setComment(e.target.value)}
                      className="mb-2"
                    />
                    {comment && (
                      <Button className="bg-violet-600 hover:bg-violet-700">
                        <Send className="w-4 h-4 ml-2" />
                        نشر التعليق
                      </Button>
                    )}
                  </div>
                </div>
              </div>

              {/* Comments Section */}
              <div className="space-y-4">
                <h3 className="font-bold text-gray-900">التعليقات ({post._count.comments})</h3>
                <div className="text-center py-8 text-gray-500">
                  <MessageSquare className="w-8 h-8 mx-auto mb-2 text-gray-300" />
                  <p>لا توجد تعليقات بعد. كن أول من يعلق!</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

// ==================== Host Reviews View ====================

function HostReviewsView() {
  const [reviews, setReviews] = useState<HostReview[]>([])
  const [loading, setLoading] = useState(true)
  const { navigate } = useNavigation()

  useEffect(() => {
    const fetchReviews = async () => {
      try {
        const response = await fetch('/api/host-reviews?limit=20')
        if (response.ok) {
          const data = await response.json()
          setReviews(data.reviews || [])
        }
      } catch (error) {
        console.error('Error fetching reviews:', error)
      } finally {
        setLoading(false)
      }
    }

    fetchReviews()
  }, [])

  const renderStars = (rating: number) => (
    <div className="flex items-center gap-0.5">
      {[1, 2, 3, 4, 5].map((star) => (
        <Star key={star} className={`w-4 h-4 ${star <= rating ? 'text-amber-400 fill-amber-400' : 'text-gray-300'}`} />
      ))}
    </div>
  )

  const formatDate = (dateString: string) => new Date(dateString).toLocaleDateString('ar-SY', { year: 'numeric', month: 'long', day: 'numeric' })

  const avgRating = reviews.length > 0 ? (reviews.reduce((sum, r) => sum + r.overallRating, 0) / reviews.length).toFixed(1) : '0.0'

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-emerald-600 to-teal-600 text-white py-12">
        <div className="container mx-auto px-4">
          <Button variant="ghost" className="text-white mb-4" onClick={() => navigate('home')}>
            <ArrowLeft className="w-4 h-4 ml-2" />
            العودة للرئيسية
          </Button>
          <h1 className="text-3xl md:text-4xl font-bold mb-2">تقييمات المضيفين</h1>
          <p className="text-white/80 text-lg">تقييمات حقيقية من ضيوف حقيقيين</p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        {/* Stats Overview */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <Card className="border-0 shadow-md">
            <CardContent className="p-4 text-center">
              <div className="text-3xl font-bold text-amber-500 mb-1">{avgRating}</div>
              <div className="text-gray-600 text-sm">متوسط التقييم</div>
              <div className="flex justify-center mt-2">{renderStars(Math.round(parseFloat(avgRating)))}</div>
            </CardContent>
          </Card>
          <Card className="border-0 shadow-md">
            <CardContent className="p-4 text-center">
              <div className="text-3xl font-bold text-emerald-500 mb-1">{reviews.length}</div>
              <div className="text-gray-600 text-sm">تقييم إجمالي</div>
            </CardContent>
          </Card>
          <Card className="border-0 shadow-md">
            <CardContent className="p-4 text-center">
              <div className="text-3xl font-bold text-sky-500 mb-1">4.8</div>
              <div className="text-gray-600 text-sm">متوسط النظافة</div>
            </CardContent>
          </Card>
          <Card className="border-0 shadow-md">
            <CardContent className="p-4 text-center">
              <div className="text-3xl font-bold text-violet-500 mb-1">4.9</div>
              <div className="text-gray-600 text-sm">متوسط التواصل</div>
            </CardContent>
          </Card>
        </div>

        {/* Reviews List */}
        {loading ? (
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <Card key={i} className="border-0 shadow-md">
                <CardContent className="p-5">
                  <div className="h-4 bg-gray-200 rounded w-1/2 mb-3 animate-pulse" />
                  <div className="h-3 bg-gray-100 rounded w-full mb-2 animate-pulse" />
                </CardContent>
              </Card>
            ))}
          </div>
        ) : reviews.length > 0 ? (
          <div className="grid md:grid-cols-2 gap-6">
            {reviews.map((review) => (
              <Card key={review.id} className="border-0 shadow-md hover:shadow-xl transition-all duration-300">
                <CardContent className="p-5">
                  {/* Header */}
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-gradient-to-br from-emerald-400 to-teal-500 flex items-center justify-center text-white font-bold">
                        {review.reviewer.name?.charAt(0) || 'ض'}
                      </div>
                      <div>
                        <p className="font-medium text-gray-900">{review.reviewer.name}</p>
                        <p className="text-xs text-gray-500">{formatDate(review.createdAt)}</p>
                      </div>
                    </div>
                    {review.isVerified && (
                      <Badge className="bg-emerald-100 text-emerald-700 text-xs">
                        <CheckCircle2 className="w-3 h-3 ml-1" />
                        حجز موثق
                      </Badge>
                    )}
                  </div>

                  {/* Rating */}
                  <div className="flex items-center gap-2 mb-3">
                    {renderStars(Math.round(review.overallRating))}
                    <span className="font-bold text-gray-900">{review.overallRating.toFixed(1)}</span>
                  </div>

                  {/* Sub-ratings */}
                  <div className="grid grid-cols-3 gap-2 mb-4 text-xs">
                    <div className="text-center p-2 bg-gray-50 rounded">
                      <span className="font-medium text-amber-500">{review.cleanliness}</span>
                      <p className="text-gray-500">نظافة</p>
                    </div>
                    <div className="text-center p-2 bg-gray-50 rounded">
                      <span className="font-medium text-amber-500">{review.communication}</span>
                      <p className="text-gray-500">تواصل</p>
                    </div>
                    <div className="text-center p-2 bg-gray-50 rounded">
                      <span className="font-medium text-amber-500">{review.value}</span>
                      <p className="text-gray-500">قيمة</p>
                    </div>
                  </div>

                  {/* Comment */}
                  {review.commentAr && (
                    <p className="text-gray-600 text-sm line-clamp-3 mb-4">"{review.commentAr}"</p>
                  )}

                  {/* Host Response */}
                  {review.hostResponse && (
                    <div className="bg-gray-50 rounded-lg p-3 mt-3">
                      <p className="text-xs text-gray-500 mb-1">رد المضيف:</p>
                      <p className="text-sm text-gray-700 line-clamp-2">{review.hostResponse}</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <Star className="w-12 h-12 text-gray-300 mx-auto mb-4" />
            <p className="text-gray-500">لا توجد تقييمات حالياً</p>
          </div>
        )}
      </div>
    </div>
  )
}

// ==================== How It Works View ====================

function HowItWorksView() {
  const { navigate } = useNavigation()

  const guestSteps = [
    { icon: Search, title: "ابحث واستكشف", description: "تصفح مئات الإقامات والجولات السياحية في مختلف المدن السورية. استخدم الفلاتر للعثور على ما يناسبك.", color: "bg-amber-500" },
    { icon: Calendar, title: "احجز بسهولة", description: "اختر التواريخ المناسبة وأكمل الحجز بخطوات بسيطة. نوفر لك خيارات دفع متعددة تناسبك.", color: "bg-emerald-500" },
    { icon: MessageCircle, title: "تواصل مع المضيف", description: "تواصل مباشرة مع المضيف للاستفسار عن أي تفاصيل. فريق الدعم متاح على مدار الساعة.", color: "bg-sky-500" },
    { icon: CheckCircle2, title: "استمتع بإقامتك", description: "وصل للمكان واستمتع بتجربتك. نظام الضمان يحمي حقوقك ويضمن لك تجربة آمنة.", color: "bg-violet-500" },
  ]

  const hostSteps = [
    { icon: Building2, title: "سجل كمضيف", description: "أنشئ حسابك كمضيف وأضف معلوماتك الأساسية. التسجيل مجاني وسريع.", color: "bg-amber-500" },
    { icon: ImageIcon, title: "أضف إقامتك", description: "أضف صوراً جذابة ووصفاً تفصيلياً لمكانك. حدد الأسعار والتوفر.", color: "bg-emerald-500" },
    { icon: Bell, title: "استقبل الطلبات", description: "سيتواصل معك الضيوف المهتمون. راجع طلبات الحجز ووافق عليها.", color: "bg-sky-500" },
    { icon: Wallet, title: "احصل على أرباحك", description: "نظام دفع آمن وسريع. احصل على مستحقاتك بطرق دفع متعددة.", color: "bg-violet-500" },
  ]

  const features = [
    { icon: Shield, title: "نظام ضمان ذكي", description: "يتم احتجاز المبلغ حتى تأكدك من جودة الإقامة" },
    { icon: Users, title: "مضيفون موثوقون", description: "جميع المضيفين مُتحقق منهم لضمان تجربة آمنة" },
    { icon: CreditCard, title: "دفع آمن", description: "خيارات دفع متعددة تناسب السوق السوري" },
    { icon: MessageCircle, title: "دعم متواصل", description: "فريق دعم متخصص جاهز لمساعدتك 24/7" },
  ]

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero */}
      <div className="bg-gradient-to-r from-amber-500 to-orange-500 text-white py-16">
        <div className="container mx-auto px-4">
          <Button variant="ghost" className="text-white mb-4 hover:bg-white/20" onClick={() => navigate('home')}>
            <ArrowLeft className="w-4 h-4 ml-2" />
            العودة للرئيسية
          </Button>
          <h1 className="text-3xl md:text-5xl font-bold mb-4">كيف تعمل منصة ضيف؟</h1>
          <p className="text-white/90 text-lg md:text-xl max-w-2xl">
            منصة سهلة الاستخدام تربط الضيوف بأفضل المضيفين في سوريا. تعرف على كيفية عملها في دقائق.
          </p>
        </div>
      </div>

      {/* Guest Steps */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <Badge className="mb-4 bg-amber-100 text-amber-700">للضيوف</Badge>
            <h2 className="text-2xl md:text-3xl font-bold text-gray-900 mb-2">كيف تحجز إقامتك؟</h2>
            <p className="text-gray-600">4 خطوات بسيطة للحصول على إقامتك المثالية</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-6xl mx-auto">
            {guestSteps.map((step, index) => (
              <div key={index} className="relative">
                <div className="bg-white border rounded-2xl p-6 hover:shadow-xl transition-all duration-300 h-full">
                  <div className={`w-16 h-16 ${step.color} rounded-2xl flex items-center justify-center mb-4`}>
                    <step.icon className="w-8 h-8 text-white" />
                  </div>
                  <div className="absolute top-4 left-4 w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center text-sm font-bold text-gray-600">
                    {index + 1}
                  </div>
                  <h3 className="text-lg font-bold text-gray-900 mb-2">{step.title}</h3>
                  <p className="text-gray-600 text-sm">{step.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Host Steps */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <Badge className="mb-4 bg-emerald-100 text-emerald-700">للمضيفين</Badge>
            <h2 className="text-2xl md:text-3xl font-bold text-gray-900 mb-2">كيف تصبح مضيفاً؟</h2>
            <p className="text-gray-600">ابدأ باستقبال الضيوف وكسب الدخل من مكانك</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-6xl mx-auto">
            {hostSteps.map((step, index) => (
              <div key={index} className="relative">
                <div className="bg-white border rounded-2xl p-6 hover:shadow-xl transition-all duration-300 h-full">
                  <div className={`w-16 h-16 ${step.color} rounded-2xl flex items-center justify-center mb-4`}>
                    <step.icon className="w-8 h-8 text-white" />
                  </div>
                  <div className="absolute top-4 left-4 w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center text-sm font-bold text-gray-600">
                    {index + 1}
                  </div>
                  <h3 className="text-lg font-bold text-gray-900 mb-2">{step.title}</h3>
                  <p className="text-gray-600 text-sm">{step.description}</p>
                </div>
              </div>
            ))}
          </div>

          <div className="text-center mt-8">
            <Button size="lg" className="bg-amber-500 hover:bg-amber-600 text-white rounded-full px-8" onClick={() => navigate('register')}>
              سجل كمضيف الآن
            </Button>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <Badge className="mb-4 bg-sky-100 text-sky-700">لماذا ضيف؟</Badge>
            <h2 className="text-2xl md:text-3xl font-bold text-gray-900 mb-2">مميزات تجعل تجربتك أفضل</h2>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-5xl mx-auto">
            {features.map((feature, index) => (
              <Card key={index} className="border-0 shadow-md hover:shadow-xl transition-all duration-300 text-center">
                <CardContent className="p-6">
                  <div className="w-14 h-14 bg-amber-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
                    <feature.icon className="w-7 h-7 text-amber-600" />
                  </div>
                  <h3 className="font-bold text-gray-900 mb-2">{feature.title}</h3>
                  <p className="text-gray-600 text-sm">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 bg-gradient-to-r from-gray-900 to-gray-800 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-2xl md:text-3xl font-bold mb-4">جاهز للبدء؟</h2>
          <p className="text-gray-300 mb-8 max-w-lg mx-auto">ابدأ الآن واستكشف أفضل الإقامات في سوريا أو انضم كمضيف</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="bg-amber-500 hover:bg-amber-600 text-white rounded-full px-8" onClick={() => navigate('accommodations')}>
              ابحث عن إقامة
            </Button>
            <Button size="lg" variant="outline" className="border-white text-white hover:bg-white/10 rounded-full px-8" onClick={() => navigate('register')}>
              كن مضيفاً
            </Button>
          </div>
        </div>
      </section>
    </div>
  )
}

// ==================== Accommodations View ====================

// Helper function to generate unique images
const getAccommodationImage = (acc: { id: string; type: string; coverImage: string | null; images: string[] }) => {
  if (acc.coverImage) return acc.coverImage
  if (acc.images && acc.images.length > 0) return acc.images[0]
  
  // Generate unique placeholder image based on id
  const typeSeeds: Record<string, number> = {
    HOTEL: 1,
    APARTMENT: 2,
    VILLA: 3,
    CHALET: 4,
    CAMP: 5,
    GUESTHOUSE: 6,
    HOSTEL: 7,
    RESORT: 8
  }
  const typeNum = typeSeeds[acc.type] || 1
  const numericId = parseInt(acc.id.replace(/\D/g, '').slice(-3) || '1')
  return `https://picsum.photos/seed/${typeNum}${numericId}/600/400`
}

function AccommodationsView() {
  const [accommodations, setAccommodations] = useState<Accommodation[]>([])
  const [loading, setLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedType, setSelectedType] = useState<string | null>(null)
  const [selectedCityName, setSelectedCityName] = useState<string | null>(null)
  const [favorites, setFavorites] = useState<Set<string>>(new Set())
  const { navigate, pageParams } = useNavigation()

  const typeLabels: Record<string, string> = {
    HOTEL: "فندق", APARTMENT: "شقة", VILLA: "فيلا", CHALET: "شاليه",
    CAMP: "مخيم", GUESTHOUSE: "نزل", HOSTEL: "سكن شباب", RESORT: "منتجع"
  }

  useEffect(() => {
    const fetchAccommodations = async () => {
      try {
        // Build URL with city filter if provided
        let url = '/api/accommodations?limit=50'
        if (pageParams.cityId) {
          url += `&cityId=${pageParams.cityId}`
        }
        
        const response = await fetch(url)
        if (response.ok) {
          const data = await response.json()
          setAccommodations(data.accommodations || [])
          
          // Set city name if filtering by city
          if (pageParams.cityId && data.accommodations?.length > 0) {
            const city = data.accommodations[0].city
            if (city) {
              setSelectedCityName(city.nameAr)
            }
          }
        }
      } catch (error) {
        console.error('Error fetching accommodations:', error)
      } finally {
        setLoading(false)
      }
    }

    fetchAccommodations()
  }, [pageParams.cityId])

  const toggleFavorite = (e: React.MouseEvent, id: string) => {
    e.stopPropagation()
    setFavorites(prev => {
      const newFavorites = new Set(prev)
      if (newFavorites.has(id)) {
        newFavorites.delete(id)
        toast.success('تمت الإزالة من المفضلة')
      } else {
        newFavorites.add(id)
        toast.success('تمت الإضافة للمفضلة')
      }
      return newFavorites
    })
  }

  const filteredAccommodations = accommodations.filter(acc => {
    const matchesSearch = !searchQuery || 
      acc.titleAr.toLowerCase().includes(searchQuery.toLowerCase()) ||
      acc.city?.nameAr.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesType = !selectedType || acc.type === selectedType
    return matchesSearch && matchesType
  })

  // Generate dynamic page title based on filter
  const pageTitle = selectedCityName 
    ? `أماكن الإقامة في ${selectedCityName}`
    : 'أماكن الإقامة'
  const pageDesc = selectedCityName
    ? `اكتشف أفضل أماكن الإقامة في ${selectedCityName}`
    : 'اكتشف أفضل أماكن الإقامة في سوريا'

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-amber-500 to-orange-500 text-white py-12">
        <div className="container mx-auto px-4">
          <Button variant="ghost" className="text-white mb-4 hover:bg-white/20" onClick={() => navigate('home')}>
            <ArrowLeft className="w-4 h-4 ml-2" />
            العودة للرئيسية
          </Button>
          <h1 className="text-3xl md:text-4xl font-bold mb-2">{pageTitle}</h1>
          <p className="text-white/80 text-lg">{pageDesc}</p>
          {selectedCityName && (
            <Button 
              variant="outline" 
              className="mt-4 border-white/50 text-white hover:bg-white/20"
              onClick={() => { navigate('accommodations') }}
            >
              <X className="w-4 h-4 ml-2" />
              إزالة فلتر {selectedCityName}
            </Button>
          )}
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        {/* Filters */}
        <div className="flex flex-col md:flex-row gap-4 mb-8">
          <div className="flex-1 relative">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
            <Input
              placeholder="ابحث عن مكان إقامة..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pr-10"
            />
          </div>
          <div className="flex gap-2 flex-wrap">
            <Button
              variant={selectedType === null ? "default" : "outline"}
              onClick={() => setSelectedType(null)}
              className={selectedType === null ? "bg-amber-500 hover:bg-amber-600" : ""}
            >
              الكل
            </Button>
            {Object.entries(typeLabels).slice(0, 4).map(([type, label]) => (
              <Button
                key={type}
                variant={selectedType === type ? "default" : "outline"}
                onClick={() => setSelectedType(type)}
                className={selectedType === type ? "bg-amber-500 hover:bg-amber-600" : ""}
              >
                {label}
              </Button>
            ))}
          </div>
        </div>

        {/* Results Count */}
        <p className="text-gray-600 mb-4">عرض {filteredAccommodations.length} مكان إقامة</p>

        {/* Accommodations Grid */}
        {loading ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {[1, 2, 3, 4, 5, 6, 7, 8].map((i) => (
              <div key={i} className="bg-gray-100 rounded-xl animate-pulse">
                <div className="h-48 bg-gray-200 rounded-t-xl" />
                <div className="p-4 space-y-2">
                  <div className="h-4 bg-gray-200 rounded w-3/4" />
                  <div className="h-4 bg-gray-200 rounded w-1/2" />
                </div>
              </div>
            ))}
          </div>
        ) : filteredAccommodations.length > 0 ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredAccommodations.map((acc) => {
              const displayImage = getAccommodationImage(acc)
              const location = acc.city ? `${acc.city.nameAr}` : 'سوريا'
              const isFavorite = favorites.has(acc.id)
              
              return (
                <Card 
                  key={acc.id} 
                  className="group overflow-hidden border-0 shadow-md hover:shadow-xl transition-all duration-300 cursor-pointer bg-white"
                  onClick={() => navigate('accommodation-detail', { id: acc.id })}
                >
                  <div className="relative h-48 overflow-hidden">
                    <img src={displayImage} alt={acc.titleAr} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" loading="lazy" />
                    {acc.rating >= 4.8 && <Badge className="absolute top-3 right-3 bg-amber-500 text-white">مميز</Badge>}
                    <Button variant="ghost" size="icon" className={`absolute top-3 left-3 ${isFavorite ? 'bg-red-50' : 'bg-white/80'} hover:bg-white rounded-full h-8 w-8 transition-all duration-300`} onClick={(e) => toggleFavorite(e, acc.id)}>
                      <Heart className={`w-4 h-4 transition-all duration-300 ${isFavorite ? 'text-red-500 fill-red-500 scale-110' : 'text-gray-600 hover:text-red-500'}`} />
                    </Button>
                  </div>
                  <CardContent className="p-4">
                    <div className="flex items-center text-sm text-gray-500 mb-2">
                      <MapPin className="w-3 h-3 ml-1" />
                      {location}
                    </div>
                    <h3 className="font-semibold text-gray-900 mb-2 line-clamp-1">{acc.titleAr}</h3>
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center">
                        <Star className="w-4 h-4 text-amber-400 fill-amber-400 ml-1" />
                        <span className="font-medium text-sm">{acc.rating.toFixed(1)}</span>
                        <span className="text-gray-400 text-sm mr-1">({acc.reviewCount})</span>
                      </div>
                      <Badge variant="secondary" className="text-xs">{typeLabels[acc.type] || acc.type}</Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <div>
                        <span className="font-bold text-lg text-gray-900">{acc.basePrice.toLocaleString()}</span>
                        <span className="text-gray-500 text-sm mr-1">ل.س / ليلة</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        ) : (
          <div className="text-center py-12">
            <HomeIcon className="w-12 h-12 text-gray-300 mx-auto mb-4" />
            <p className="text-gray-500">لا توجد أماكن إقامة تطابق بحثك</p>
          </div>
        )}
      </div>
    </div>
  )
}

// ==================== Accommodation Detail View ====================

interface AccommodationDetail {
  id: string
  titleAr: string
  titleEn: string | null
  descriptionAr: string | null
  type: string
  addressAr: string | null
  basePrice: number
  currency: string
  rating: number
  reviewCount: number
  viewCount: number
  coverImage: string | null
  images: string[]
  bedrooms: number
  bathrooms: number
  maxGuests: number
  beds: number
  size: number | null
  amenities: string[]
  checkInTime: string
  checkOutTime: string
  minNights: number
  houseRules: string[]
  smokingAllowed: boolean
  petsAllowed: boolean
  city: {
    id: string
    nameAr: string
    nameEn: string | null
    governorate: string | null
  } | null
  host: {
    id: string
    name: string | null
    nameAr: string | null
    avatar: string | null
  }
  reviews: Array<{
    id: string
    rating: number
    commentAr: string | null
    createdAt: string
    user: {
      id: string
      name: string | null
      nameAr: string | null
      avatar: string | null
    }
  }>
}

function AccommodationDetailView() {
  const { pageParams, navigate } = useNavigation()
  const [accommodation, setAccommodation] = useState<AccommodationDetail | null>(null)
  const [hostStats, setHostStats] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [selectedImage, setSelectedImage] = useState(0)
  const [showAllAmenities, setShowAllAmenities] = useState(false)
  
  // Booking state
  const [checkIn, setCheckIn] = useState('')
  const [checkOut, setCheckOut] = useState('')
  const [guestsCount, setGuestsCount] = useState(1)
  const [bookingLoading, setBookingLoading] = useState(false)
  const [showBookingSuccess, setShowBookingSuccess] = useState(false)
  const [newBookingId, setNewBookingId] = useState('')
  const [showDatePicker, setShowDatePicker] = useState(false)

  useEffect(() => {
    const fetchAccommodation = async () => {
      if (!pageParams.id) return
      
      try {
        const response = await fetch(`/api/accommodations/${pageParams.id}`)
        const data = await response.json()
        
        if (data.success) {
          setAccommodation(data.accommodation)
          setHostStats(data.hostStats)
        }
      } catch (error) {
        console.error('Error fetching accommodation:', error)
      } finally {
        setLoading(false)
      }
    }

    fetchAccommodation()
  }, [pageParams.id])

  const typeLabels: Record<string, string> = {
    HOTEL: "فندق", APARTMENT: "شقة", VILLA: "فيلا",
    CHALET: "شاليه", CAMP: "مخيم", GUESTHOUSE: "نزل",
    HOSTEL: "سكن شباب", RESORT: "منتجع"
  }

  const amenityIcons: Record<string, any> = {
    wifi: "📶", ac: "❄️", parking: "🚗", pool: "🏊", 
    kitchen: "🍳", tv: "📺", washer: "🧺", heating: "🔥",
    wifi_internet: "📶", air_conditioning: "❄️", swimming_pool: "🏊"
  }

  // Calculate nights and pricing
  const calculatePricing = () => {
    if (!checkIn || !checkOut || !accommodation) return null
    
    const checkInDate = new Date(checkIn)
    const checkOutDate = new Date(checkOut)
    const nightsCount = Math.ceil((checkOutDate.getTime() - checkInDate.getTime()) / (1000 * 60 * 60 * 24))
    
    if (nightsCount <= 0) return null
    
    const baseAmount = accommodation.basePrice * nightsCount
    const cleaningFee = (accommodation as any).cleaningFee || 0
    const serviceFee = baseAmount * 0.1
    const guaranteeFee = baseAmount * 0.05
    const totalAmount = baseAmount + cleaningFee + serviceFee + guaranteeFee
    
    return { nightsCount, baseAmount, cleaningFee, serviceFee, guaranteeFee, totalAmount }
  }

  const pricing = calculatePricing()

  // Handle booking creation
  const handleBooking = async () => {
    if (!checkIn || !checkOut || !accommodation) return
    
    setBookingLoading(true)
    try {
      const response = await fetch('/api/bookings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          accommodationId: accommodation.id,
          guestId: 'demo-user', // In real app, get from auth
          checkIn,
          checkOut,
          guestsCount,
          guestName: 'ضيف تجريبي',
          guestPhone: '+963999999999'
        })
      })
      
      const data = await response.json()
      
      if (data.success) {
        setNewBookingId(data.booking.id)
        setShowBookingSuccess(true)
      } else {
        alert(data.error || 'حدث خطأ أثناء إنشاء الحجز')
      }
    } catch (error) {
      console.error('Booking error:', error)
      alert('حدث خطأ أثناء إنشاء الحجز')
    } finally {
      setBookingLoading(false)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 pt-8">
        <div className="container mx-auto px-4">
          <div className="animate-pulse space-y-4">
            <div className="h-8 bg-gray-200 rounded w-1/2" />
            <div className="h-96 bg-gray-200 rounded-xl" />
            <div className="grid md:grid-cols-3 gap-4">
              <div className="h-32 bg-gray-200 rounded" />
              <div className="h-32 bg-gray-200 rounded" />
              <div className="h-32 bg-gray-200 rounded" />
            </div>
          </div>
        </div>
      </div>
    )
  }

  if (!accommodation) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <AlertCircle className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <h2 className="text-xl font-semibold text-gray-700 mb-2">مكان الإقامة غير موجود</h2>
          <Button onClick={() => navigate('accommodations')} className="mt-4">العودة للإقامات</Button>
        </div>
      </div>
    )
  }

  const allImages = accommodation.coverImage 
    ? [accommodation.coverImage, ...accommodation.images.filter(img => img !== accommodation.coverImage)]
    : accommodation.images

  const displayAmenities = showAllAmenities 
    ? accommodation.amenities 
    : accommodation.amenities.slice(0, 8)

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Image Gallery */}
      <div className="bg-gray-900">
        <div className="container mx-auto px-4 py-4">
          <button 
            onClick={() => navigate('accommodations')}
            className="flex items-center gap-2 text-white mb-4 hover:text-amber-400 transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            العودة للبحث
          </button>
          
          <div className="grid md:grid-cols-4 gap-2 rounded-xl overflow-hidden">
            {/* Main Image */}
            <div className="md:col-span-2 md:row-span-2">
              <img 
                src={allImages[selectedImage] || '/images/default-accommodation.png'} 
                alt={accommodation.titleAr}
                className="w-full h-64 md:h-full object-cover cursor-pointer hover:opacity-95 transition-opacity"
              />
            </div>
            {/* Thumbnail Grid */}
            {allImages.slice(1, 5).map((img, idx) => (
              <div key={idx} className="relative">
                <img 
                  src={img || '/images/default-accommodation.png'} 
                  alt={`${accommodation.titleAr} - صورة ${idx + 2}`}
                  className="w-full h-32 md:h-40 object-cover cursor-pointer hover:opacity-80 transition-opacity"
                  onClick={() => setSelectedImage(idx + 1)}
                />
                {idx === 3 && allImages.length > 5 && (
                  <div 
                    className="absolute inset-0 bg-black/50 flex items-center justify-center cursor-pointer"
                    onClick={() => setSelectedImage(idx + 1)}
                  >
                    <span className="text-white font-semibold">+{allImages.length - 5} صور</span>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Title & Info */}
            <div className="bg-white rounded-xl p-6 shadow-sm">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <Badge className="mb-2 bg-amber-100 text-amber-700">{typeLabels[accommodation.type] || accommodation.type}</Badge>
                  <h1 className="text-2xl md:text-3xl font-bold text-gray-900">{accommodation.titleAr}</h1>
                </div>
                <div className="flex items-center gap-2">
                  <Button variant="ghost" size="icon" className="rounded-full">
                    <Heart className="w-5 h-5" />
                  </Button>
                  <Button variant="ghost" size="icon" className="rounded-full">
                    <Share2 className="w-5 h-5" />
                  </Button>
                </div>
              </div>
              
              <div className="flex flex-wrap items-center gap-4 text-gray-600">
                <div className="flex items-center gap-1">
                  <Star className="w-5 h-5 text-amber-400 fill-amber-400" />
                  <span className="font-semibold">{accommodation.rating.toFixed(1)}</span>
                  <span className="text-gray-400">({accommodation.reviewCount} تقييم)</span>
                </div>
                <div className="flex items-center gap-1">
                  <MapPin className="w-4 h-4" />
                  <span>{accommodation.city?.nameAr || 'سوريا'}</span>
                </div>
                <div className="flex items-center gap-1">
                  <Eye className="w-4 h-4" />
                  <span>{accommodation.viewCount} مشاهدة</span>
                </div>
              </div>
            </div>

            {/* Property Details */}
            <div className="bg-white rounded-xl p-6 shadow-sm">
              <h2 className="text-xl font-bold text-gray-900 mb-4">تفاصيل المكان</h2>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="text-center p-4 bg-gray-50 rounded-xl">
                  <HomeIcon className="w-8 h-8 mx-auto mb-2 text-amber-500" />
                  <p className="text-2xl font-bold">{accommodation.bedrooms}</p>
                  <p className="text-sm text-gray-500">غرفة نوم</p>
                </div>
                <div className="text-center p-4 bg-gray-50 rounded-xl">
                  <Users className="w-8 h-8 mx-auto mb-2 text-amber-500" />
                  <p className="text-2xl font-bold">{accommodation.maxGuests}</p>
                  <p className="text-sm text-gray-500">ضيف</p>
                </div>
                <div className="text-center p-4 bg-gray-50 rounded-xl">
                  <Building2 className="w-8 h-8 mx-auto mb-2 text-amber-500" />
                  <p className="text-2xl font-bold">{accommodation.bathrooms}</p>
                  <p className="text-sm text-gray-500">حمام</p>
                </div>
                <div className="text-center p-4 bg-gray-50 rounded-xl">
                  <Compass className="w-8 h-8 mx-auto mb-2 text-amber-500" />
                  <p className="text-2xl font-bold">{accommodation.size || '-'}</p>
                  <p className="text-sm text-gray-500">م²</p>
                </div>
              </div>
            </div>

            {/* Description */}
            {accommodation.descriptionAr && (
              <div className="bg-white rounded-xl p-6 shadow-sm">
                <h2 className="text-xl font-bold text-gray-900 mb-4">الوصف</h2>
                <p className="text-gray-600 leading-relaxed whitespace-pre-line">{accommodation.descriptionAr}</p>
              </div>
            )}

            {/* Amenities */}
            {accommodation.amenities.length > 0 && (
              <div className="bg-white rounded-xl p-6 shadow-sm">
                <h2 className="text-xl font-bold text-gray-900 mb-4">المرافق والخدمات</h2>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  {displayAmenities.map((amenity, idx) => (
                    <div key={idx} className="flex items-center gap-2 p-3 bg-gray-50 rounded-lg">
                      <span className="text-lg">{amenityIcons[amenity.toLowerCase().replace(/\s/g, '_')] || '✓'}</span>
                      <span className="text-sm text-gray-700">{amenity}</span>
                    </div>
                  ))}
                </div>
                {accommodation.amenities.length > 8 && (
                  <Button 
                    variant="ghost" 
                    className="mt-4 text-amber-600"
                    onClick={() => setShowAllAmenities(!showAllAmenities)}
                  >
                    {showAllAmenities ? 'عرض أقل' : `عرض الكل (${accommodation.amenities.length})`}
                  </Button>
                )}
              </div>
            )}

            {/* House Rules */}
            <div className="bg-white rounded-xl p-6 shadow-sm">
              <h2 className="text-xl font-bold text-gray-900 mb-4">قواعد المنزل</h2>
              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <Clock className="w-5 h-5 text-amber-500" />
                  <span>تسجيل الوصول: {accommodation.checkInTime}</span>
                </div>
                <div className="flex items-center gap-3">
                  <Clock className="w-5 h-5 text-amber-500" />
                  <span>تسجيل المغادرة: {accommodation.checkOutTime}</span>
                </div>
                <div className="flex items-center gap-3">
                  <Calendar className="w-5 h-5 text-amber-500" />
                  <span>الحد الأدنى للإقامة: {accommodation.minNights} ليلة</span>
                </div>
                <div className="flex items-center gap-3">
                  {accommodation.smokingAllowed ? <CheckCircle2 className="w-5 h-5 text-green-500" /> : <X className="w-5 h-5 text-red-500" />}
                  <span>التدخين {accommodation.smokingAllowed ? 'مسموح' : 'غير مسموح'}</span>
                </div>
                <div className="flex items-center gap-3">
                  {accommodation.petsAllowed ? <CheckCircle2 className="w-5 h-5 text-green-500" /> : <X className="w-5 h-5 text-red-500" />}
                  <span>الحيوانات الأليفة {accommodation.petsAllowed ? 'مسموحة' : 'غير مسموحة'}</span>
                </div>
              </div>
            </div>

            {/* Reviews */}
            {accommodation.reviews.length > 0 && (
              <div className="bg-white rounded-xl p-6 shadow-sm">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl font-bold text-gray-900">التقييمات</h2>
                  <div className="flex items-center gap-2">
                    <Star className="w-5 h-5 text-amber-400 fill-amber-400" />
                    <span className="font-bold text-lg">{accommodation.rating.toFixed(1)}</span>
                    <span className="text-gray-500">({accommodation.reviewCount} تقييم)</span>
                  </div>
                </div>
                <div className="space-y-4">
                  {accommodation.reviews.slice(0, 3).map((review) => (
                    <div key={review.id} className="border-b pb-4 last:border-0">
                      <div className="flex items-start gap-3">
                        <div className="w-10 h-10 rounded-full bg-gradient-to-br from-amber-400 to-orange-500 flex items-center justify-center text-white font-bold">
                          {review.user.nameAr?.charAt(0) || review.user.name?.charAt(0) || 'ض'}
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center justify-between">
                            <p className="font-medium">{review.user.nameAr || review.user.name || 'ضيف'}</p>
                            <div className="flex items-center gap-1">
                              <Star className="w-4 h-4 text-amber-400 fill-amber-400" />
                              <span>{review.rating}</span>
                            </div>
                          </div>
                          {review.commentAr && (
                            <p className="text-gray-600 mt-2 text-sm">{review.commentAr}</p>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
                {accommodation.reviews.length > 3 && (
                  <Button variant="outline" className="w-full mt-4">عرض كل التقييمات</Button>
                )}
              </div>
            )}
          </div>

          {/* Booking Sidebar */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-xl p-6 shadow-lg sticky top-24">
              {showBookingSuccess ? (
                <div className="text-center py-8">
                  <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <CheckCircle2 className="w-8 h-8 text-green-600" />
                  </div>
                  <h3 className="text-xl font-bold text-gray-900 mb-2">تم إنشاء الحجز!</h3>
                  <p className="text-gray-600 mb-4">تم إرسال طلب الحجز بنجاح</p>
                  <p className="text-sm text-gray-500 mb-4">رقم الحجز: {newBookingId.slice(0, 8).toUpperCase()}</p>
                  <div className="flex gap-2">
                    <Button 
                      variant="outline" 
                      className="flex-1"
                      onClick={() => navigate('my-bookings')}
                    >
                      حجوزاتي
                    </Button>
                    <Button 
                      className="flex-1 bg-amber-500 hover:bg-amber-600"
                      onClick={() => setShowBookingSuccess(false)}
                    >
                      حجز آخر
                    </Button>
                  </div>
                </div>
              ) : (
                <>
                  <div className="flex items-baseline justify-between mb-6">
                    <div>
                      <span className="text-3xl font-bold text-gray-900">{accommodation.basePrice.toLocaleString()}</span>
                      <span className="text-gray-500 mr-1">ل.س / ليلة</span>
                    </div>
                    <Badge className="bg-green-100 text-green-700">متاح</Badge>
                  </div>

                  {/* Date Pickers */}
                  <div className="grid grid-cols-2 gap-2 mb-4">
                    <div>
                      <label className="text-xs text-gray-500 block mb-1">تاريخ الوصول</label>
                      <input
                        type="date"
                        value={checkIn}
                        onChange={(e) => setCheckIn(e.target.value)}
                        min={new Date().toISOString().split('T')[0]}
                        className="w-full border rounded-lg p-3 focus:border-amber-400 focus:outline-none cursor-pointer"
                      />
                    </div>
                    <div>
                      <label className="text-xs text-gray-500 block mb-1">تاريخ المغادرة</label>
                      <input
                        type="date"
                        value={checkOut}
                        onChange={(e) => setCheckOut(e.target.value)}
                        min={checkIn || new Date().toISOString().split('T')[0]}
                        className="w-full border rounded-lg p-3 focus:border-amber-400 focus:outline-none cursor-pointer"
                      />
                    </div>
                  </div>

                  {/* Guests */}
                  <div className="border rounded-lg p-3 mb-4">
                    <label className="text-xs text-gray-500 block mb-2">عدد الضيوف</label>
                    <div className="flex items-center justify-between">
                      <Button
                        variant="outline"
                        size="icon"
                        onClick={() => setGuestsCount(Math.max(1, guestsCount - 1))}
                        disabled={guestsCount <= 1}
                      >
                        -
                      </Button>
                      <span className="font-semibold text-lg">{guestsCount} ضيف</span>
                      <Button
                        variant="outline"
                        size="icon"
                        onClick={() => setGuestsCount(Math.min(accommodation.maxGuests, guestsCount + 1))}
                        disabled={guestsCount >= accommodation.maxGuests}
                      >
                        +
                      </Button>
                    </div>
                    <p className="text-xs text-gray-400 mt-1 text-center">الحد الأقصى: {accommodation.maxGuests} ضيوف</p>
                  </div>

                  <Button 
                    className="w-full h-12 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white rounded-xl text-lg font-semibold"
                    onClick={handleBooking}
                    disabled={!checkIn || !checkOut || bookingLoading}
                  >
                    {bookingLoading ? (
                      <><Loader2 className="w-5 h-5 animate-spin ml-2" /> جاري الحجز...</>
                    ) : (
                      'احجز الآن'
                    )}
                  </Button>

                  <p className="text-center text-gray-500 text-sm mt-3">لن يتم الدفع الآن</p>

                  {/* Price Breakdown */}
                  {pricing ? (
                    <div className="border-t mt-6 pt-6 space-y-3">
                      <div className="flex justify-between">
                        <span className="text-gray-600">{accommodation.basePrice.toLocaleString()} ل.س × {pricing.nightsCount} ليالي</span>
                        <span>{pricing.baseAmount.toLocaleString()} ل.س</span>
                      </div>
                      {pricing.cleaningFee > 0 && (
                        <div className="flex justify-between">
                          <span className="text-gray-600">رسوم التنظيف</span>
                          <span>{pricing.cleaningFee.toLocaleString()} ل.س</span>
                        </div>
                      )}
                      <div className="flex justify-between">
                        <span className="text-gray-600">رسوم الخدمة (10%)</span>
                        <span>{pricing.serviceFee.toLocaleString()} ل.س</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">رسوم الضمان (5%)</span>
                        <span>{pricing.guaranteeFee.toLocaleString()} ل.س</span>
                      </div>
                      <div className="flex justify-between font-bold pt-3 border-t text-lg">
                        <span>المجموع</span>
                        <span className="text-amber-600">{pricing.totalAmount.toLocaleString()} ل.س</span>
                      </div>
                    </div>
                  ) : (
                    <div className="border-t mt-6 pt-6 space-y-3">
                      <div className="flex justify-between">
                        <span className="text-gray-600">{accommodation.basePrice.toLocaleString()} ل.س × 1 ليلة</span>
                        <span>{accommodation.basePrice.toLocaleString()} ل.س</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">رسوم الخدمة</span>
                        <span>يُحسب عند اختيار التواريخ</span>
                      </div>
                      <div className="flex justify-between font-bold pt-3 border-t">
                        <span>المجموع</span>
                        <span>--</span>
                      </div>
                    </div>
                  )}
                </>
              )}

              {/* Host Info */}
              <div className="border-t mt-6 pt-6">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-full bg-gradient-to-br from-amber-400 to-orange-500 flex items-center justify-center text-white font-bold text-lg">
                    {accommodation.host.nameAr?.charAt(0) || accommodation.host.name?.charAt(0) || 'م'}
                  </div>
                  <div>
                    <p className="font-semibold">{accommodation.host.nameAr || accommodation.host.name || 'المضيف'}</p>
                    <p className="text-sm text-gray-500">
                      {hostStats?.totalListings || 1} إعلان • {hostStats?.averageRating?.toFixed(1) || accommodation.rating} ⭐
                    </p>
                  </div>
                </div>
                <Button variant="outline" className="w-full mt-4">
                  <MessageCircle className="w-4 h-4 ml-2" />
                  تواصل مع المضيف
                </Button>
              </div>
            </div>
          </div>
        </div>

        {/* Map Section */}
        <div className="container mx-auto px-4 py-8">
          <Card className="border-0 shadow-sm">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MapPin className="w-5 h-5 text-amber-500" />
                الموقع على الخريطة
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="rounded-xl overflow-hidden border border-gray-200">
                <InteractiveMap
                  lat={accommodation.latitude || 33.5138}
                  lng={accommodation.longitude || 36.2765}
                  title={accommodation.titleAr}
                  city={accommodation.city?.nameAr}
                />
              </div>
              <div className="mt-4 flex flex-wrap gap-2">
                <Badge variant="outline" className="gap-1">
                  <MapPin className="w-3 h-3" />
                  {accommodation.city?.nameAr || 'سوريا'}
                </Badge>
                {accommodation.addressAr && (
                  <span className="text-sm text-gray-600">{accommodation.addressAr}</span>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

// ==================== Search View (Advanced Search) ====================

function SearchView() {
  const { navigate } = useNavigation()
  const [accommodations, setAccommodations] = useState<Accommodation[]>([])
  const [loading, setLoading] = useState(true)
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid')
  
  // Filters
  const [searchQuery, setSearchQuery] = useState('')
  const [selectedCity, setSelectedCity] = useState<string>('')
  const [selectedType, setSelectedType] = useState<string>('')
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 1000000])
  const [minRating, setMinRating] = useState<string>('')
  const [sortBy, setSortBy] = useState('rating')
  const [showFilters, setShowFilters] = useState(false)
  
  const [cities, setCities] = useState<City[]>([])
  const [pagination, setPagination] = useState({
    page: 1,
    totalPages: 1,
    total: 0,
    hasNextPage: false
  })

  const typeLabels: Record<string, string> = {
    HOTEL: "فندق", APARTMENT: "شقة", VILLA: "فيلا",
    CHALET: "شاليه", CAMP: "مخيم", GUESTHOUSE: "نزل",
    HOSTEL: "سكن شباب", RESORT: "منتجع"
  }

  const accommodationTypes = Object.entries(typeLabels)

  useEffect(() => {
    // Fetch cities for filter
    fetch('/api/cities')
      .then(res => res.json())
      .then(data => setCities(data.cities || []))
      .catch(console.error)
  }, [])

  useEffect(() => {
    searchAccommodations()
  }, [selectedCity, selectedType, sortBy, minRating])

  const searchAccommodations = async (page = 1) => {
    setLoading(true)
    try {
      const params = new URLSearchParams()
      if (searchQuery) params.append('q', searchQuery)
      if (selectedCity) params.append('cityId', selectedCity)
      if (selectedType) params.append('type', selectedType)
      if (minRating) params.append('minRating', minRating)
      params.append('sortBy', sortBy)
      params.append('page', page.toString())
      params.append('limit', '12')

      const response = await fetch(`/api/accommodations/search?${params}`)
      const data = await response.json()

      if (data.success) {
        setAccommodations(data.accommodations)
        setPagination(data.pagination)
      }
    } catch (error) {
      console.error('Search error:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleSearch = () => {
    searchAccommodations(1)
  }

  const defaultImage = '/images/default-accommodation.png'

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Search Header */}
      <div className="bg-gradient-to-r from-amber-500 to-orange-500 text-white py-8">
        <div className="container mx-auto px-4">
          <h1 className="text-3xl font-bold mb-6">ابحث عن إقامتك المثالية</h1>
          
          {/* Main Search Bar */}
          <div className="bg-white rounded-2xl p-4 shadow-lg">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1 relative">
                <Search className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
                <Input
                  type="text"
                  placeholder="ابحث بالاسم أو الموقع..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
                  className="h-12 pr-10 text-gray-900"
                />
              </div>
              
              <select
                value={selectedCity}
                onChange={(e) => setSelectedCity(e.target.value)}
                className="h-12 px-4 rounded-lg border border-gray-200 text-gray-700 min-w-[150px]"
              >
                <option value="">كل المدن</option>
                {cities.map(city => (
                  <option key={city.id} value={city.id}>{city.nameAr}</option>
                ))}
              </select>
              
              <select
                value={selectedType}
                onChange={(e) => setSelectedType(e.target.value)}
                className="h-12 px-4 rounded-lg border border-gray-200 text-gray-700 min-w-[150px]"
              >
                <option value="">كل الأنواع</option>
                {accommodationTypes.map(([key, label]) => (
                  <option key={key} value={key}>{label}</option>
                ))}
              </select>
              
              <Button 
                onClick={handleSearch}
                className="h-12 px-8 bg-amber-500 hover:bg-amber-600 text-white"
              >
                <Search className="w-5 h-5 ml-2" />
                بحث
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        {/* Results Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
          <div>
            <p className="text-gray-600">
              {pagination.total} نتيجة 
              {selectedCity && ` في ${cities.find(c => c.id === selectedCity)?.nameAr || ''}`}
            </p>
          </div>
          
          <div className="flex items-center gap-4">
            {/* Sort */}
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="h-10 px-4 rounded-lg border border-gray-200 text-gray-700"
            >
              <option value="rating">الأعلى تقييماً</option>
              <option value="price">السعر: من الأقل للأعلى</option>
              <option value="price_desc">السعر: من الأعلى للأقل</option>
              <option value="newest">الأحدث</option>
            </select>
            
            {/* View Mode */}
            <div className="flex border rounded-lg overflow-hidden">
              <button
                onClick={() => setViewMode('grid')}
                className={`p-2 ${viewMode === 'grid' ? 'bg-amber-500 text-white' : 'bg-white text-gray-600'}`}
              >
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z" />
                </svg>
              </button>
              <button
                onClick={() => setViewMode('list')}
                className={`p-2 ${viewMode === 'list' ? 'bg-amber-500 text-white' : 'bg-white text-gray-600'}`}
              >
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 10h16M4 14h16M4 18h16" />
                </svg>
              </button>
            </div>
            
            {/* Filter Toggle */}
            <Button 
              variant="outline" 
              onClick={() => setShowFilters(!showFilters)}
              className="gap-2"
            >
              <Filter className="w-4 h-4" />
              فلاتر
            </Button>
          </div>
        </div>

        {/* Advanced Filters */}
        {showFilters && (
          <div className="bg-white rounded-xl p-6 shadow-sm mb-6">
            <div className="grid md:grid-cols-4 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">الحد الأدنى للسعر</label>
                <Input
                  type="number"
                  placeholder="0"
                  value={priceRange[0]}
                  onChange={(e) => setPriceRange([parseInt(e.target.value) || 0, priceRange[1]])}
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">الحد الأقصى للسعر</label>
                <Input
                  type="number"
                  placeholder="1000000"
                  value={priceRange[1]}
                  onChange={(e) => setPriceRange([priceRange[0], parseInt(e.target.value) || 1000000])}
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">التقييم</label>
                <select
                  value={minRating}
                  onChange={(e) => setMinRating(e.target.value)}
                  className="w-full h-10 px-4 rounded-lg border border-gray-200"
                >
                  <option value="">الكل</option>
                  <option value="4.5">4.5+ ممتاز</option>
                  <option value="4.0">4.0+ جيد جداً</option>
                  <option value="3.5">3.5+ جيد</option>
                </select>
              </div>
              <div className="flex items-end">
                <Button onClick={handleSearch} className="w-full bg-amber-500 hover:bg-amber-600">
                  تطبيق الفلاتر
                </Button>
              </div>
            </div>
          </div>
        )}

        {/* Results Grid */}
        {loading ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {[1, 2, 3, 4, 5, 6, 7, 8].map(i => (
              <div key={i} className="bg-white rounded-xl overflow-hidden shadow-sm">
                <div className="h-48 bg-gray-200 animate-pulse" />
                <div className="p-4 space-y-2">
                  <div className="h-4 bg-gray-100 rounded animate-pulse" />
                  <div className="h-4 bg-gray-100 rounded w-2/3 animate-pulse" />
                </div>
              </div>
            ))}
          </div>
        ) : accommodations.length > 0 ? (
          <div className={viewMode === 'grid' 
            ? "grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
            : "space-y-4"
          }>
            {accommodations.map((acc) => {
              const displayImage = acc.coverImage || (acc.images && acc.images[0]) || defaultImage
              const location = acc.city ? `${acc.city.nameAr}` : 'سوريا'
              
              if (viewMode === 'list') {
                return (
                  <Card 
                    key={acc.id} 
                    className="flex overflow-hidden cursor-pointer hover:shadow-lg transition-shadow"
                    onClick={() => navigate('accommodation-detail', { id: acc.id })}
                  >
                    <div className="w-48 h-32 shrink-0">
                      <img src={displayImage} alt={acc.titleAr} className="w-full h-full object-cover" />
                    </div>
                    <CardContent className="flex-1 p-4">
                      <div className="flex justify-between">
                        <div>
                          <Badge variant="secondary" className="mb-1">{typeLabels[acc.type] || acc.type}</Badge>
                          <h3 className="font-semibold text-gray-900">{acc.titleAr}</h3>
                          <p className="text-sm text-gray-500 flex items-center gap-1">
                            <MapPin className="w-3 h-3" />{location}
                          </p>
                        </div>
                        <div className="text-left">
                          <div className="flex items-center gap-1">
                            <Star className="w-4 h-4 text-amber-400 fill-amber-400" />
                            <span className="font-medium">{acc.rating.toFixed(1)}</span>
                          </div>
                          <p className="font-bold text-lg mt-2">{acc.basePrice.toLocaleString()} ل.س</p>
                          <p className="text-xs text-gray-500">/ لليلة</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                )
              }

              return (
                <Card 
                  key={acc.id} 
                  className="group overflow-hidden border-0 shadow-md hover:shadow-xl transition-all duration-300 cursor-pointer bg-white"
                  onClick={() => navigate('accommodation-detail', { id: acc.id })}
                >
                  <div className="relative h-48 overflow-hidden">
                    <img 
                      src={displayImage} 
                      alt={acc.titleAr} 
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" 
                      loading="lazy" 
                    />
                    {acc.rating >= 4.8 && (
                      <Badge className="absolute top-3 right-3 bg-amber-500 text-white">مميز</Badge>
                    )}
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="absolute top-3 left-3 bg-white/80 hover:bg-white rounded-full h-8 w-8"
                      onClick={(e) => { e.stopPropagation(); }}
                    >
                      <Heart className="w-4 h-4 text-gray-600" />
                    </Button>
                  </div>
                  <CardContent className="p-4">
                    <div className="flex items-center text-sm text-gray-500 mb-2">
                      <MapPin className="w-3 h-3 ml-1" />{location}
                    </div>
                    <h3 className="font-semibold text-gray-900 mb-2 line-clamp-1">{acc.titleAr}</h3>
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center">
                        <Star className="w-4 h-4 text-amber-400 fill-amber-400 ml-1" />
                        <span className="font-medium text-sm">{acc.rating.toFixed(1)}</span>
                        <span className="text-gray-400 text-sm mr-1">({acc.reviewCount})</span>
                      </div>
                      <Badge variant="secondary" className="text-xs">{typeLabels[acc.type] || acc.type}</Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <div>
                        <span className="font-bold text-lg text-gray-900">{acc.basePrice.toLocaleString()}</span>
                        <span className="text-gray-500 text-sm mr-1">ل.س / ليلة</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        ) : (
          <div className="text-center py-16">
            <Search className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-gray-700 mb-2">لا توجد نتائج</h3>
            <p className="text-gray-500 mb-4">جرب تغيير معايير البحث</p>
            <Button 
              variant="outline" 
              onClick={() => {
                setSearchQuery('')
                setSelectedCity('')
                setSelectedType('')
                setMinRating('')
                searchAccommodations()
              }}
            >
              مسح الفلاتر
            </Button>
          </div>
        )}

        {/* Pagination */}
        {pagination.totalPages > 1 && (
          <div className="flex justify-center items-center gap-2 mt-8">
            <Button
              variant="outline"
              disabled={pagination.page === 1}
              onClick={() => searchAccommodations(pagination.page - 1)}
            >
              السابق
            </Button>
            <span className="px-4">
              صفحة {pagination.page} من {pagination.totalPages}
            </span>
            <Button
              variant="outline"
              disabled={!pagination.hasNextPage}
              onClick={() => searchAccommodations(pagination.page + 1)}
            >
              التالي
            </Button>
          </div>
        )}
      </div>
    </div>
  )
}

// ==================== Host Dashboard View ====================

function HostDashboardView() {
  const { navigate } = useNavigation()
  const [stats, setStats] = useState<any>(null)
  const [topListings, setTopListings] = useState<any[]>([])
  const [accommodations, setAccommodations] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [statsRes, accRes] = await Promise.all([
          fetch('/api/host/stats'),
          fetch('/api/host/accommodations')
        ])

        if (statsRes.ok) {
          const data = await statsRes.json()
          setStats(data.stats)
          setTopListings(data.topListings || [])
        }

        if (accRes.ok) {
          const data = await accRes.json()
          setAccommodations(data.accommodations || [])
        }
      } catch (error) {
        console.error('Error fetching host data:', error)
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [])

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 pt-8">
        <div className="container mx-auto px-4">
          <div className="animate-pulse space-y-4">
            <div className="h-8 bg-gray-200 rounded w-1/3" />
            <div className="grid grid-cols-4 gap-4">
              {[1, 2, 3, 4].map(i => <div key={i} className="h-24 bg-gray-200 rounded" />)}
            </div>
          </div>
        </div>
      </div>
    )
  }

  const statCards = [
    { label: 'إعلاناتي', value: stats?.totalListings || 0, icon: HomeIcon, color: 'bg-amber-500' },
    { label: 'الحجوزات', value: stats?.totalBookings || 0, icon: Calendar, color: 'bg-emerald-500' },
    { label: 'التقييمات', value: stats?.totalReviews || 0, icon: Star, color: 'bg-sky-500' },
    { label: 'التقييم العام', value: stats?.averageRating?.toFixed(1) || '0.0', icon: Award, color: 'bg-violet-500' }
  ]

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-gray-800 to-gray-900 text-white py-8">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between">
            <div>
              <Button variant="ghost" className="text-white/70 mb-2" onClick={() => navigate('home')}>
                <ArrowLeft className="w-4 h-4 ml-2" />
                الرئيسية
              </Button>
              <h1 className="text-3xl font-bold">لوحة تحكم المضيف</h1>
              <p className="text-gray-400 mt-1">إدارة إعلاناتك وحجوزاتك</p>
            </div>
            <Button 
              className="bg-amber-500 hover:bg-amber-600 text-white"
              onClick={() => navigate('add-accommodation')}
            >
              <Plus className="w-4 h-4 ml-2" />
              إضافة إعلان جديد
            </Button>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        {/* Stats Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          {statCards.map((stat, idx) => (
            <Card key={idx} className="border-0 shadow-sm">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-500 text-sm">{stat.label}</p>
                    <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                  </div>
                  <div className={`w-12 h-12 ${stat.color} rounded-xl flex items-center justify-center`}>
                    <stat.icon className="w-6 h-6 text-white" />
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Revenue Overview */}
        <div className="grid md:grid-cols-2 gap-6 mb-8">
          <Card className="border-0 shadow-sm">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-emerald-500" />
                نظرة عامة على الإيرادات
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-gray-500">إجمالي الإيرادات</span>
                  <span className="text-xl font-bold text-emerald-600">
                    {(stats?.totalRevenue || 0).toLocaleString()} ل.س
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-500">إيرادات هذا الشهر</span>
                  <span className="font-semibold">
                    {(stats?.monthlyRevenue || 0).toLocaleString()} ل.س
                  </span>
                </div>
                <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                  <div className="h-full bg-emerald-500 rounded-full" style={{ width: '65%' }} />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-sm cursor-pointer hover:shadow-md transition-shadow" onClick={() => navigate('host-bookings')}>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg flex items-center gap-2">
                <Clock className="w-5 h-5 text-amber-500" />
                حالة الحجوزات
                <ArrowLeft className="w-4 h-4 mr-auto text-gray-400" />
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full bg-emerald-500" />
                    <span className="text-gray-600">مؤكدة</span>
                  </div>
                  <span className="font-semibold">{stats?.confirmedBookings || 0}</span>
                </div>
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full bg-amber-500" />
                    <span className="text-gray-600">قيد الانتظار</span>
                  </div>
                  <span className="font-semibold">{stats?.pendingBookings || 0}</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* My Listings */}
        <Card className="border-0 shadow-sm">
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="text-lg">إعلاناتي</CardTitle>
            <Button variant="outline" size="sm" onClick={() => navigate('add-accommodation')}>
              <Plus className="w-4 h-4 ml-1" />
              إضافة
            </Button>
          </CardHeader>
          <CardContent>
            {accommodations.length === 0 ? (
              <div className="text-center py-8">
                <HomeIcon className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                <p className="text-gray-500 mb-4">لا توجد إعلانات بعد</p>
                <Button onClick={() => navigate('add-accommodation')} className="bg-amber-500 hover:bg-amber-600">
                  أضف إعلانك الأول
                </Button>
              </div>
            ) : (
              <div className="space-y-3">
                {accommodations.map((acc: any) => (
                  <div 
                    key={acc.id} 
                    className="flex items-center gap-4 p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors cursor-pointer"
                    onClick={() => navigate('accommodation-detail', { id: acc.id })}
                  >
                    <img 
                      src={acc.coverImage || '/images/default-accommodation.png'} 
                      alt={acc.titleAr}
                      className="w-16 h-16 rounded-lg object-cover"
                    />
                    <div className="flex-1">
                      <h3 className="font-semibold text-gray-900">{acc.titleAr}</h3>
                      <div className="flex items-center gap-3 text-sm text-gray-500">
                        <span>{acc.city?.nameAr || 'سوريا'}</span>
                        <span className="flex items-center gap-1">
                          <Star className="w-3 h-3 text-amber-400 fill-amber-400" />
                          {acc.rating.toFixed(1)}
                        </span>
                        <span>{acc.viewCount} مشاهدة</span>
                      </div>
                    </div>
                    <div className="text-left">
                      <p className="font-bold text-gray-900">{acc.basePrice.toLocaleString()} ل.س</p>
                      <Badge className={acc.status === 'ACTIVE' ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'}>
                        {acc.status === 'ACTIVE' ? 'نشط' : 'قيد المراجعة'}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

// ==================== Add Accommodation View ====================

function AddAccommodationView() {
  const { navigate } = useNavigation()
  const [loading, setLoading] = useState(false)
  const [cities, setCities] = useState<City[]>([])
  
  // Form state
  const [formData, setFormData] = useState({
    titleAr: '',
    titleEn: '',
    descriptionAr: '',
    type: 'APARTMENT',
    addressAr: '',
    cityId: '',
    basePrice: '',
    bedrooms: '1',
    bathrooms: '1',
    maxGuests: '2',
    amenities: [] as string[],
    checkInTime: '14:00',
    checkOutTime: '12:00',
    minNights: '1',
    smokingAllowed: false,
    petsAllowed: false,
    partiesAllowed: false
  })

  useEffect(() => {
    fetch('/api/cities')
      .then(res => res.json())
      .then(data => setCities(data.cities || []))
      .catch(console.error)
  }, [])

  const typeLabels: Record<string, string> = {
    HOTEL: "فندق", APARTMENT: "شقة", VILLA: "فيلا", CHALET: "شاليه",
    CAMP: "مخيم", GUESTHOUSE: "نزل", HOSTEL: "سكن شباب", RESORT: "منتجع"
  }

  const amenityOptions = [
    'واي فاي', 'مكيف', 'موقف سيارات', 'مسبح', 'مطبخ', 'تلفزيون', 
    'غسالة', 'تدفئة', 'إفطار', 'إطلالة', 'تراس', 'حديقة'
  ]

  const toggleAmenity = (amenity: string) => {
    setFormData(prev => ({
      ...prev,
      amenities: prev.amenities.includes(amenity)
        ? prev.amenities.filter(a => a !== amenity)
        : [...prev.amenities, amenity]
    }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    try {
      const response = await fetch('/api/host/accommodations', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
      })

      const data = await response.json()

      if (data.success) {
        alert('تم إنشاء الإعلان بنجاح!')
        navigate('host-dashboard')
      } else {
        alert(data.error || 'حدث خطأ')
      }
    } catch (error) {
      alert('حدث خطأ في الاتصال')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b sticky top-16 z-40">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button variant="ghost" onClick={() => navigate('host-dashboard')}>
                <ArrowLeft className="w-4 h-4 ml-2" />
                العودة
              </Button>
              <h1 className="text-xl font-bold">إضافة إعلان جديد</h1>
            </div>
          </div>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="container mx-auto px-4 py-8">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Form */}
          <div className="lg:col-span-2 space-y-6">
            {/* Basic Info */}
            <Card className="border-0 shadow-sm">
              <CardHeader>
                <CardTitle className="text-lg">معلومات أساسية</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    عنوان الإعلان (بالعربية) *
                  </label>
                  <Input
                    value={formData.titleAr}
                    onChange={(e) => setFormData({ ...formData, titleAr: e.target.value })}
                    placeholder="مثال: شقة فاخرة في قلب دمشق"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    العنوان بالإنجليزية (اختياري)
                  </label>
                  <Input
                    value={formData.titleEn}
                    onChange={(e) => setFormData({ ...formData, titleEn: e.target.value })}
                    placeholder="Luxury apartment in the heart of Damascus"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    نوع الإقامة *
                  </label>
                  <div className="grid grid-cols-4 gap-2">
                    {Object.entries(typeLabels).map(([key, label]) => (
                      <button
                        key={key}
                        type="button"
                        onClick={() => setFormData({ ...formData, type: key })}
                        className={`p-3 rounded-lg border text-sm transition-colors ${
                          formData.type === key 
                            ? 'border-amber-500 bg-amber-50 text-amber-700' 
                            : 'border-gray-200 hover:border-amber-300'
                        }`}
                      >
                        {label}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    وصف الإقامة
                  </label>
                  <textarea
                    value={formData.descriptionAr}
                    onChange={(e) => setFormData({ ...formData, descriptionAr: e.target.value })}
                    placeholder="اكتب وصفاً تفصيلياً عن مكان الإقامة..."
                    rows={4}
                    className="w-full border rounded-lg p-3 focus:ring-amber-500 focus:border-amber-500"
                  />
                </div>
              </CardContent>
            </Card>

            {/* Location */}
            <Card className="border-0 shadow-sm">
              <CardHeader>
                <CardTitle className="text-lg">الموقع</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">المدينة</label>
                    <select
                      value={formData.cityId}
                      onChange={(e) => setFormData({ ...formData, cityId: e.target.value })}
                      className="w-full h-10 px-3 border rounded-lg"
                    >
                      <option value="">اختر المدينة</option>
                      {cities.map(city => (
                        <option key={city.id} value={city.id}>{city.nameAr}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">العنوان التفصيلي</label>
                    <Input
                      value={formData.addressAr}
                      onChange={(e) => setFormData({ ...formData, addressAr: e.target.value })}
                      placeholder="الحي، الشارع..."
                    />
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Details */}
            <Card className="border-0 shadow-sm">
              <CardHeader>
                <CardTitle className="text-lg">تفاصيل المكان</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">غرف النوم</label>
                    <Input
                      type="number"
                      min="1"
                      value={formData.bedrooms}
                      onChange={(e) => setFormData({ ...formData, bedrooms: e.target.value })}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">الحمامات</label>
                    <Input
                      type="number"
                      min="1"
                      value={formData.bathrooms}
                      onChange={(e) => setFormData({ ...formData, bathrooms: e.target.value })}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">عدد الضيوف</label>
                    <Input
                      type="number"
                      min="1"
                      value={formData.maxGuests}
                      onChange={(e) => setFormData({ ...formData, maxGuests: e.target.value })}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">الحد الأدنى (ليالٍ)</label>
                    <Input
                      type="number"
                      min="1"
                      value={formData.minNights}
                      onChange={(e) => setFormData({ ...formData, minNights: e.target.value })}
                    />
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Amenities */}
            <Card className="border-0 shadow-sm">
              <CardHeader>
                <CardTitle className="text-lg">المرافق والخدمات</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-3 md:grid-cols-4 gap-2">
                  {amenityOptions.map(amenity => (
                    <button
                      key={amenity}
                      type="button"
                      onClick={() => toggleAmenity(amenity)}
                      className={`p-3 rounded-lg border text-sm transition-colors ${
                        formData.amenities.includes(amenity)
                          ? 'border-emerald-500 bg-emerald-50 text-emerald-700'
                          : 'border-gray-200 hover:border-gray-300'
                      }`}
                    >
                      {amenity}
                    </button>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* House Rules */}
            <Card className="border-0 shadow-sm">
              <CardHeader>
                <CardTitle className="text-lg">قواعد المنزل</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-gray-700">يُسمح بالتدخين</span>
                  <button
                    type="button"
                    onClick={() => setFormData({ ...formData, smokingAllowed: !formData.smokingAllowed })}
                    className={`w-12 h-6 rounded-full transition-colors ${
                      formData.smokingAllowed ? 'bg-emerald-500' : 'bg-gray-300'
                    }`}
                  >
                    <div className={`w-5 h-5 bg-white rounded-full transition-transform ${
                      formData.smokingAllowed ? 'translate-x-6' : 'translate-x-0.5'
                    }`} />
                  </button>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-700">يُسمح بالحيوانات الأليفة</span>
                  <button
                    type="button"
                    onClick={() => setFormData({ ...formData, petsAllowed: !formData.petsAllowed })}
                    className={`w-12 h-6 rounded-full transition-colors ${
                      formData.petsAllowed ? 'bg-emerald-500' : 'bg-gray-300'
                    }`}
                  >
                    <div className={`w-5 h-5 bg-white rounded-full transition-transform ${
                      formData.petsAllowed ? 'translate-x-6' : 'translate-x-0.5'
                    }`} />
                  </button>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-700">يُسمح بالحفلات</span>
                  <button
                    type="button"
                    onClick={() => setFormData({ ...formData, partiesAllowed: !formData.partiesAllowed })}
                    className={`w-12 h-6 rounded-full transition-colors ${
                      formData.partiesAllowed ? 'bg-emerald-500' : 'bg-gray-300'
                    }`}
                  >
                    <div className={`w-5 h-5 bg-white rounded-full transition-transform ${
                      formData.partiesAllowed ? 'translate-x-6' : 'translate-x-0.5'
                    }`} />
                  </button>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar - Pricing */}
          <div className="lg:col-span-1">
            <div className="sticky top-32 space-y-6">
              <Card className="border-0 shadow-sm">
                <CardHeader>
                  <CardTitle className="text-lg">الأسعار</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      السعر الأساسي (ل.س / ليلة) *
                    </label>
                    <Input
                      type="number"
                      value={formData.basePrice}
                      onChange={(e) => setFormData({ ...formData, basePrice: e.target.value })}
                      placeholder="100000"
                      required
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">تسجيل الوصول</label>
                      <Input
                        type="time"
                        value={formData.checkInTime}
                        onChange={(e) => setFormData({ ...formData, checkInTime: e.target.value })}
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">تسجيل المغادرة</label>
                      <Input
                        type="time"
                        value={formData.checkOutTime}
                        onChange={(e) => setFormData({ ...formData, checkOutTime: e.target.value })}
                      />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Button 
                type="submit"
                className="w-full h-12 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white text-lg font-semibold"
                disabled={loading}
              >
                {loading ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin ml-2" />
                    جاري الحفظ...
                  </>
                ) : (
                  'نشر الإعلان'
                )}
              </Button>

              <p className="text-xs text-gray-500 text-center">
                سيتم مراجعة إعلانك خلال 24 ساعة
              </p>
            </div>
          </div>
        </div>
      </form>
    </div>
  )
}

// ==================== Header Component ====================

function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const [showNotifications, setShowNotifications] = useState(false)
  const [showUserMenu, setShowUserMenu] = useState(false)
  const { currentPage, navigate } = useNavigation()
  const { user, isAuthenticated, logout, isLoading } = useAuth()

  const navItems = [
    { id: 'home' as PageType, label: 'الرئيسية' },
    { id: 'accommodations' as PageType, label: 'الإقامات' },
    { id: 'community' as PageType, label: 'المجتمع' },
    { id: 'host-reviews' as PageType, label: 'التقييمات' },
  ]

  const handleLogout = async () => {
    setShowUserMenu(false)
    await logout()
  }

  return (
    <header className="fixed top-0 right-0 left-0 z-50 bg-white/80 backdrop-blur-md border-b">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center gap-2 cursor-pointer" onClick={() => navigate('home')}>
            <h1 className="text-2xl font-bold text-amber-600">ضيف</h1>
          </div>

          <nav className="hidden md:flex items-center gap-6">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => navigate(item.id)}
                className={`transition-colors bg-transparent cursor-pointer ${
                  currentPage === item.id
                    ? 'text-amber-600 font-medium'
                    : 'text-gray-600 hover:text-amber-600'
                }`}
              >
                {item.label}
              </button>
            ))}
          </nav>

          <div className="hidden md:flex items-center gap-2">
            {isAuthenticated ? (
              <>
                {/* Messages Icon */}
                <Button
                  variant="ghost"
                  size="icon"
                  className="relative cursor-pointer"
                  onClick={() => navigate('inbox')}
                >
                  <MessageCircle className="w-5 h-5 text-gray-600" />
                  <span className="absolute -top-1 -right-1 w-4 h-4 bg-amber-500 rounded-full text-[10px] text-white flex items-center justify-center">
                    2
                  </span>
                </Button>

                {/* Notifications Icon */}
                <div className="relative">
                  <Button
                    variant="ghost"
                    size="icon"
                    className="relative cursor-pointer"
                    onClick={() => setShowNotifications(!showNotifications)}
                  >
                    <Bell className="w-5 h-5 text-gray-600" />
                    <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full text-[10px] text-white flex items-center justify-center">
                      3
                    </span>
                  </Button>

                  {/* Notifications Dropdown */}
                  {showNotifications && (
                    <div className="absolute left-0 top-full mt-2 w-80 bg-white rounded-xl shadow-lg border overflow-hidden z-50">
                      <div className="p-3 border-b flex items-center justify-between">
                        <h3 className="font-semibold">الإشعارات</h3>
                        <Button variant="ghost" size="sm" onClick={() => navigate('notifications')}>
                          الكل
                        </Button>
                      </div>
                      <div className="max-h-80 overflow-y-auto">
                        {[
                          { type: 'booking', title: 'حجز جديد', body: 'لديك طلب حجز جديد', time: 'منذ 5 دقائق' },
                          { type: 'message', title: 'رسالة جديدة', body: 'مرحباً، هل الإقامة متاحة؟', time: 'منذ ساعة' },
                          { type: 'review', title: 'تقييم جديد', body: 'حصلت على تقييم 5 نجوم', time: 'منذ يوم' },
                        ].map((notif, idx) => (
                          <div
                            key={idx}
                            className="p-3 border-b last:border-0 hover:bg-gray-50 cursor-pointer"
                            onClick={() => { navigate('notifications'); setShowNotifications(false) }}
                          >
                            <div className="flex items-start gap-3">
                              <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                                notif.type === 'booking' ? 'bg-amber-100' :
                                notif.type === 'message' ? 'bg-blue-100' : 'bg-yellow-100'
                              }`}>
                                {notif.type === 'booking' && <Calendar className="w-4 h-4 text-amber-600" />}
                                {notif.type === 'message' && <MessageCircle className="w-4 h-4 text-blue-600" />}
                                {notif.type === 'review' && <Star className="w-4 h-4 text-yellow-600" />}
                              </div>
                              <div className="flex-1">
                                <p className="font-medium text-sm">{notif.title}</p>
                                <p className="text-xs text-gray-500">{notif.body}</p>
                                <p className="text-xs text-gray-400 mt-1">{notif.time}</p>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                {/* User Menu */}
                <div className="relative">
                  <button
                    onClick={() => setShowUserMenu(!showUserMenu)}
                    className="flex items-center gap-2 p-1.5 rounded-full hover:bg-gray-100 transition-colors"
                  >
                    {user?.avatar ? (
                      <img src={user.avatar} alt={user.name || ''} className="w-8 h-8 rounded-full object-cover" />
                    ) : (
                      <div className="w-8 h-8 rounded-full bg-gradient-to-br from-amber-400 to-orange-500 flex items-center justify-center text-white text-sm font-bold">
                        {user?.name?.charAt(0) || user?.nameAr?.charAt(0) || 'ض'}
                      </div>
                    )}
                    <ChevronLeft className={`w-4 h-4 text-gray-600 transition-transform ${showUserMenu ? 'rotate-90' : ''}`} />
                  </button>

                  {/* User Dropdown */}
                  {showUserMenu && (
                    <div className="absolute left-0 top-full mt-2 w-64 bg-white rounded-xl shadow-lg border overflow-hidden z-50">
                      <div className="p-4 border-b bg-gray-50">
                        <p className="font-semibold text-gray-900">{user?.nameAr || user?.name || 'ضيف'}</p>
                        <p className="text-sm text-gray-500">{user?.phone}</p>
                        {user?.role === 'HOST' && (
                          <Badge className="mt-1 bg-amber-100 text-amber-700 text-xs">مضيف</Badge>
                        )}
                      </div>
                      <div className="py-2">
                        <button
                          onClick={() => { navigate('profile'); setShowUserMenu(false) }}
                          className="w-full px-4 py-2 text-right hover:bg-gray-50 flex items-center gap-3"
                        >
                          <User className="w-4 h-4 text-gray-500" />
                          <span>الملف الشخصي</span>
                        </button>
                        <button
                          onClick={() => { navigate('my-bookings'); setShowUserMenu(false) }}
                          className="w-full px-4 py-2 text-right hover:bg-gray-50 flex items-center gap-3"
                        >
                          <Calendar className="w-4 h-4 text-gray-500" />
                          <span>حجوزاتي</span>
                        </button>
                        {user?.role === 'HOST' && (
                          <button
                            onClick={() => { navigate('host-dashboard'); setShowUserMenu(false) }}
                            className="w-full px-4 py-2 text-right hover:bg-gray-50 flex items-center gap-3"
                          >
                            <Building2 className="w-4 h-4 text-gray-500" />
                            <span>لوحة المضيف</span>
                          </button>
                        )}
                        {user?.role !== 'HOST' && (
                          <button
                            onClick={() => { navigate('host-dashboard'); setShowUserMenu(false) }}
                            className="w-full px-4 py-2 text-right hover:bg-gray-50 flex items-center gap-3 text-amber-600"
                          >
                            <Sparkles className="w-4 h-4" />
                            <span>كن مضيفاً</span>
                          </button>
                        )}
                        <hr className="my-2" />
                        <button
                          onClick={() => { navigate('notifications'); setShowUserMenu(false) }}
                          className="w-full px-4 py-2 text-right hover:bg-gray-50 flex items-center gap-3"
                        >
                          <Bell className="w-4 h-4 text-gray-500" />
                          <span>الإشعارات</span>
                        </button>
                        <button
                          onClick={() => { navigate('inbox'); setShowUserMenu(false) }}
                          className="w-full px-4 py-2 text-right hover:bg-gray-50 flex items-center gap-3"
                        >
                          <MessageCircle className="w-4 h-4 text-gray-500" />
                          <span>الرسائل</span>
                        </button>
                        <hr className="my-2" />
                        <button
                          onClick={handleLogout}
                          className="w-full px-4 py-2 text-right hover:bg-red-50 flex items-center gap-3 text-red-600"
                        >
                          <LogOut className="w-4 h-4" />
                          <span>تسجيل الخروج</span>
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              </>
            ) : (
              <>
                <Button
                  variant="ghost"
                  className="text-gray-600 cursor-pointer"
                  onClick={() => navigate('login')}
                >
                  تسجيل الدخول
                </Button>
                <Button
                  className="bg-amber-500 hover:bg-amber-600 text-white rounded-full cursor-pointer"
                  onClick={() => navigate('register')}
                >
                  إنشاء حساب
                </Button>
              </>
            )}
          </div>

          <Button
            variant="ghost"
            size="icon"
            className="md:hidden cursor-pointer"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </Button>
        </div>

        {mobileMenuOpen && (
          <div className="md:hidden py-4 border-t">
            <nav className="flex flex-col gap-4">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => { navigate(item.id); setMobileMenuOpen(false) }}
                  className={`text-right py-2 bg-transparent cursor-pointer ${
                    currentPage === item.id ? 'text-amber-600 font-medium' : 'text-gray-600 hover:text-amber-600'
                  }`}
                >
                  {item.label}
                </button>
              ))}

              {isAuthenticated ? (
                <>
                  <div className="flex gap-4 pt-4 border-t">
                    <button
                      className="flex items-center gap-2 text-gray-600"
                      onClick={() => { navigate('inbox'); setMobileMenuOpen(false) }}
                    >
                      <MessageCircle className="w-5 h-5" />
                      الرسائل
                    </button>
                    <button
                      className="flex items-center gap-2 text-gray-600"
                      onClick={() => { navigate('notifications'); setMobileMenuOpen(false) }}
                    >
                      <Bell className="w-5 h-5" />
                      الإشعارات
                    </button>
                  </div>
                  <div className="flex items-center gap-3 pt-4 border-t">
                    {user?.avatar ? (
                      <img src={user.avatar} alt={user.name || ''} className="w-10 h-10 rounded-full object-cover" />
                    ) : (
                      <div className="w-10 h-10 rounded-full bg-gradient-to-br from-amber-400 to-orange-500 flex items-center justify-center text-white font-bold">
                        {user?.name?.charAt(0) || user?.nameAr?.charAt(0) || 'ض'}
                      </div>
                    )}
                    <div>
                      <p className="font-semibold">{user?.nameAr || user?.name || 'ضيف'}</p>
                      <p className="text-sm text-gray-500">{user?.phone}</p>
                    </div>
                  </div>
                  <div className="flex flex-col gap-2 pt-4 border-t">
                    <Button
                      variant="outline"
                      className="w-full justify-center cursor-pointer"
                      onClick={() => { navigate('profile'); setMobileMenuOpen(false) }}
                    >
                      <User className="w-4 h-4 ml-2" />
                      الملف الشخصي
                    </Button>
                    <Button
                      variant="outline"
                      className="w-full justify-center cursor-pointer"
                      onClick={() => { navigate('my-bookings'); setMobileMenuOpen(false) }}
                    >
                      <Calendar className="w-4 h-4 ml-2" />
                      حجوزاتي
                    </Button>
                    <Button
                      variant="destructive"
                      className="w-full justify-center cursor-pointer"
                      onClick={() => { handleLogout(); setMobileMenuOpen(false) }}
                    >
                      <LogOut className="w-4 h-4 ml-2" />
                      تسجيل الخروج
                    </Button>
                  </div>
                </>
              ) : (
                <div className="flex flex-col gap-2 pt-4 border-t">
                  <Button
                    variant="outline"
                    className="w-full justify-center cursor-pointer"
                    onClick={() => { navigate('login'); setMobileMenuOpen(false) }}
                  >
                    تسجيل الدخول
                  </Button>
                  <Button
                    className="w-full bg-amber-500 hover:bg-amber-600 text-white cursor-pointer"
                    onClick={() => { navigate('register'); setMobileMenuOpen(false) }}
                  >
                    إنشاء حساب جديد
                  </Button>
                </div>
              )}
            </nav>
          </div>
        )}
      </div>
    </header>
  )
}

// ==================== Footer Component ====================

function Footer() {
  const { navigate } = useNavigation()

  const quickLinks = [
    { label: 'الرئيسية', page: 'home' as PageType },
    { label: 'الإقامات', page: 'accommodations' as PageType },
    { label: 'المجتمع', page: 'community' as PageType },
    { label: 'التقييمات', page: 'host-reviews' as PageType },
  ]

  const hostLinks = [
    { label: 'لوحة التحكم', page: 'host-dashboard' as PageType },
    { label: 'إضافة إقامة', page: 'add-accommodation' as PageType },
    { label: 'إدارة الحجوزات', page: 'host-bookings' as PageType },
  ]

  const guestLinks = [
    { label: 'حجوزاتي', page: 'my-bookings' as PageType },
    { label: 'الرسائل', page: 'inbox' as PageType },
    { label: 'الإشعارات', page: 'notifications' as PageType },
  ]

  return (
    <footer className="bg-gradient-to-b from-gray-900 to-gray-950 text-gray-400 pt-16 pb-8">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-2 lg:grid-cols-5 gap-8 lg:gap-12 mb-12">
          {/* Brand Section */}
          <div className="lg:col-span-2">
            <div className="flex items-center gap-2 mb-4 cursor-pointer" onClick={() => navigate('home')}>
              <div className="w-10 h-10 bg-gradient-to-br from-amber-400 to-orange-500 rounded-xl flex items-center justify-center">
                <span className="text-white font-bold text-xl">ض</span>
              </div>
              <h3 className="text-2xl font-bold text-white">ضيف</h3>
            </div>
            <p className="text-gray-400 mb-6 leading-relaxed max-w-md">
              منصتك الموثوقة للسياحة والضيافة في سوريا. نربط الضيوف بالمضيفين بطريقة آمنة وموثوقة، 
              ونسهل استكشاف جمال سوريا بكل أمان وراحة.
            </p>
            
            {/* Stats */}
            <div className="flex gap-6 mb-6">
              <div className="text-center">
                <div className="text-2xl font-bold text-amber-400">+500</div>
                <div className="text-xs text-gray-500">إقامة</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-amber-400">+50</div>
                <div className="text-xs text-gray-500">وجهة</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-amber-400">+10K</div>
                <div className="text-xs text-gray-500">ضيف</div>
              </div>
            </div>
            
            {/* Social Links */}
            <div className="flex gap-3">
              {[
                { name: 'Facebook', icon: <svg className="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 24 24"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>, url: 'https://facebook.com' },
                { name: 'Instagram', icon: <svg className="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/></svg>, url: 'https://instagram.com' },
                { name: 'Twitter', icon: <svg className="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 24 24"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>, url: 'https://twitter.com' },
                { name: 'WhatsApp', icon: <svg className="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 24 24"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>, url: 'https://wa.me/963111234567' },
              ].map((social) => (
                <a 
                  key={social.name}
                  href={social.url} 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  className="w-10 h-10 bg-gray-800 rounded-xl flex items-center justify-center hover:bg-amber-500 hover:scale-110 transition-all duration-300"
                  title={social.name}
                >
                  {social.icon}
                </a>
              ))}
            </div>
          </div>
          
          {/* Quick Links */}
          <div>
            <h4 className="text-white font-semibold mb-4 flex items-center gap-2">
              <Compass className="w-4 h-4 text-amber-400" />
              روابط سريعة
            </h4>
            <ul className="space-y-3">
              {quickLinks.map((link) => (
                <li key={link.page}>
                  <button 
                    onClick={() => navigate(link.page)} 
                    className="hover:text-amber-400 hover:translate-x-1 transition-all duration-200 text-right bg-transparent cursor-pointer flex items-center gap-2"
                  >
                    <ArrowLeft className="w-3 h-3 opacity-0 group-hover:opacity-100" />
                    {link.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>
          
          {/* For Hosts */}
          <div>
            <h4 className="text-white font-semibold mb-4 flex items-center gap-2">
              <Building2 className="w-4 h-4 text-amber-400" />
              للمضيفين
            </h4>
            <ul className="space-y-3">
              {hostLinks.map((link) => (
                <li key={link.page}>
                  <button 
                    onClick={() => navigate(link.page)} 
                    className="hover:text-amber-400 transition-colors text-right bg-transparent cursor-pointer"
                  >
                    {link.label}
                  </button>
                </li>
              ))}
              <li>
                <button 
                  onClick={() => navigate('host-dashboard')} 
                  className="text-amber-400 hover:text-amber-300 transition-colors text-right bg-transparent cursor-pointer font-medium"
                >
                  انضم كمضيف ←
                </button>
              </li>
            </ul>
          </div>
          
          {/* Contact */}
          <div>
            <h4 className="text-white font-semibold mb-4 flex items-center gap-2">
              <Phone className="w-4 h-4 text-amber-400" />
              تواصل معنا
            </h4>
            <ul className="space-y-4">
              <li className="flex items-center gap-3">
                <div className="w-8 h-8 bg-gray-800 rounded-lg flex items-center justify-center">
                  <Phone className="w-4 h-4 text-amber-400" />
                </div>
                <a href="tel:+963111234567" dir="ltr" className="hover:text-amber-400 transition-colors">
                  +963 11 123 4567
                </a>
              </li>
              <li className="flex items-center gap-3">
                <div className="w-8 h-8 bg-gray-800 rounded-lg flex items-center justify-center">
                  <MessageCircle className="w-4 h-4 text-amber-400" />
                </div>
                <a href="mailto:info@dayf.sy" className="hover:text-amber-400 transition-colors">
                  info@dayf.sy
                </a>
              </li>
              <li className="flex items-start gap-3">
                <div className="w-8 h-8 bg-gray-800 rounded-lg flex items-center justify-center mt-0.5">
                  <MapPin className="w-4 h-4 text-amber-400" />
                </div>
                <span className="leading-relaxed">دمشق، سوريا<br />شارع الثورة</span>
              </li>
            </ul>
          </div>
        </div>
        
        {/* Trust Badges */}
        <div className="border-t border-gray-800 pt-8 mb-8">
          <div className="flex flex-wrap justify-center gap-6 text-sm text-gray-500">
            <div className="flex items-center gap-2">
              <Shield className="w-5 h-5 text-emerald-500" />
              <span>حجز آمن 100%</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5 text-emerald-500" />
              <span>مضيفون موثقون</span>
            </div>
            <div className="flex items-center gap-2">
              <Star className="w-5 h-5 text-amber-400" />
              <span>تقييمات حقيقية</span>
            </div>
            <div className="flex items-center gap-2">
              <MessageCircle className="w-5 h-5 text-sky-500" />
              <span>دعم على مدار الساعة</span>
            </div>
          </div>
        </div>
        
        {/* Copyright */}
        <div className="border-t border-gray-800 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-sm text-gray-500">
              © {new Date().getFullYear()} ضيف. جميع الحقوق محفوظة. صنع بـ ❤️ في سوريا
            </p>
            <div className="flex flex-wrap justify-center gap-6 text-sm">
              <a href="#" className="hover:text-amber-400 transition-colors">سياسة الخصوصية</a>
              <a href="#" className="hover:text-amber-400 transition-colors">شروط الاستخدام</a>
              <a href="#" className="hover:text-amber-400 transition-colors">سياسة الإلغاء</a>
              <a href="#" className="hover:text-amber-400 transition-colors">الأسئلة الشائعة</a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  )
}

// ==================== Inbox View (Messages) ====================

interface ConversationData {
  id: string
  type: string
  status: string
  lastMessage: string | null
  lastMessageAt: string | null
  hasUnread: boolean
  guest: {
    id: string
    name: string | null
    nameAr: string | null
    avatar: string | null
  }
  host: {
    id: string
    name: string | null
    nameAr: string | null
    avatar: string | null
  }
  booking: {
    id: string
    accommodation: {
      id: string
      titleAr: string
      coverImage: string | null
    }
  } | null
  messages: Array<{
    id: string
    content: string
    createdAt: string
    isFromGuest: boolean
    isRead: boolean
  }>
}

function InboxView() {
  const { navigate, pageParams } = useNavigation()
  const [conversations, setConversations] = useState<ConversationData[]>([])
  const [loading, setLoading] = useState(true)
  const [activeTab, setActiveTab] = useState<'all' | 'guest' | 'host'>('all')

  useEffect(() => {
    const fetchConversations = async () => {
      try {
        const params = new URLSearchParams()
        params.set('userId', 'demo-user')
        params.set('type', activeTab)
        
        const response = await fetch(`/api/conversations?${params}`)
        const data = await response.json()
        setConversations(data.conversations || [])
      } catch (error) {
        console.error('Error fetching conversations:', error)
      } finally {
        setLoading(false)
      }
    }

    fetchConversations()
  }, [activeTab])

  const getOtherParty = (conv: ConversationData) => {
    // If user is guest, show host; if user is host, show guest
    const isUserGuest = conv.guest.id === 'demo-user'
    return isUserGuest ? conv.host : conv.guest
  }

  const formatTime = (dateStr: string | null) => {
    if (!dateStr) return ''
    const date = new Date(dateStr)
    const now = new Date()
    const diffDays = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60 * 24))
    
    if (diffDays === 0) {
      return date.toLocaleTimeString('ar-SY', { hour: '2-digit', minute: '2-digit' })
    } else if (diffDays === 1) {
      return 'أمس'
    } else if (diffDays < 7) {
      return date.toLocaleDateString('ar-SY', { weekday: 'long' })
    } else {
      return date.toLocaleDateString('ar-SY', { day: 'numeric', month: 'short' })
    }
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">الرسائل</h1>
            <p className="text-gray-600 mt-1">تواصل مع المضيفين والضيوف</p>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-2 mb-6">
          {[
            { key: 'all', label: 'الكل' },
            { key: 'guest', label: 'كضيف' },
            { key: 'host', label: 'كمضيف' }
          ].map((tab) => (
            <Button
              key={tab.key}
              variant={activeTab === tab.key ? 'default' : 'outline'}
              onClick={() => setActiveTab(tab.key as any)}
              className={activeTab === tab.key ? 'bg-amber-500 hover:bg-amber-600' : ''}
            >
              {tab.label}
            </Button>
          ))}
        </div>

        {/* Conversations List */}
        {loading ? (
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <Card key={i} className="animate-pulse">
                <CardContent className="p-4">
                  <div className="flex gap-4">
                    <div className="w-12 h-12 bg-gray-200 rounded-full" />
                    <div className="flex-1">
                      <div className="h-4 bg-gray-200 rounded w-1/3 mb-2" />
                      <div className="h-3 bg-gray-200 rounded w-2/3" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : conversations.length === 0 ? (
          <Card className="text-center py-12">
            <CardContent>
              <MessageSquare className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-700 mb-2">لا توجد محادثات</h3>
              <p className="text-gray-500 mb-4">ابدأ محادثة جديدة مع مضيف</p>
              <Button onClick={() => navigate('accommodations')} className="bg-amber-500 hover:bg-amber-600">
                استكشف الإقامات
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-2">
            {conversations.map((conv) => {
              const otherParty = getOtherParty(conv)
              const lastMessage = conv.messages[0]
              
              return (
                <Card 
                  key={conv.id} 
                  className={`cursor-pointer hover:shadow-md transition-all ${conv.hasUnread ? 'border-amber-300 bg-amber-50/30' : ''}`}
                  onClick={() => navigate('conversation', { id: conv.id })}
                >
                  <CardContent className="p-4">
                    <div className="flex gap-4">
                      {/* Avatar */}
                      <div className="relative">
                        <div className="w-12 h-12 rounded-full bg-gradient-to-br from-amber-400 to-orange-500 flex items-center justify-center text-white font-bold text-lg">
                          {otherParty.nameAr?.charAt(0) || otherParty.name?.charAt(0) || 'ض'}
                        </div>
                        {conv.hasUnread && (
                          <div className="absolute -top-1 -right-1 w-4 h-4 bg-amber-500 rounded-full border-2 border-white" />
                        )}
                      </div>
                      
                      {/* Content */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between mb-1">
                          <h3 className="font-semibold text-gray-900 truncate">
                            {otherParty.nameAr || otherParty.name || 'مستخدم'}
                          </h3>
                          <span className="text-xs text-gray-500">
                            {formatTime(conv.lastMessageAt)}
                          </span>
                        </div>
                        
                        {conv.booking && (
                          <p className="text-sm text-amber-600 mb-1 truncate">
                            📍 {conv.booking.accommodation.titleAr}
                          </p>
                        )}
                        
                        <p className={`text-sm truncate ${conv.hasUnread ? 'font-medium text-gray-900' : 'text-gray-500'}`}>
                          {lastMessage?.content || conv.lastMessage || 'ابدأ المحادثة...'}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        )}
      </div>
    </div>
  )
}

// ==================== Conversation View ====================

function ConversationView() {
  const { pageParams, navigate } = useNavigation()
  const [conversation, setConversation] = useState<ConversationData | null>(null)
  const [messages, setMessages] = useState<Array<{
    id: string
    content: string
    createdAt: string
    isFromGuest: boolean
    isRead: boolean
    sender: {
      id: string
      name: string | null
      nameAr: string | null
      avatar: string | null
    }
  }>>([])
  const [loading, setLoading] = useState(true)
  const [newMessage, setNewMessage] = useState('')
  const [sending, setSending] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const fetchConversation = async () => {
      if (!pageParams.id) return
      
      try {
        const params = new URLSearchParams()
        params.set('userId', 'demo-user')
        
        const response = await fetch(`/api/conversations/${pageParams.id}?${params}`)
        const data = await response.json()
        
        if (data.conversation) {
          setConversation(data.conversation)
          setMessages(data.messages || [])
        }
      } catch (error) {
        console.error('Error fetching conversation:', error)
      } finally {
        setLoading(false)
      }
    }

    fetchConversation()
  }, [pageParams.id])

  // Auto scroll to bottom
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' })
    }
  }, [messages])

  const handleSendMessage = async () => {
    if (!newMessage.trim() || !conversation) return
    
    setSending(true)
    try {
      const response = await fetch(`/api/conversations/${conversation.id}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          senderId: 'demo-user',
          content: newMessage.trim()
        })
      })
      
      const data = await response.json()
      
      if (data.success) {
        setMessages([...messages, data.message])
        setNewMessage('')
      }
    } catch (error) {
      console.error('Error sending message:', error)
    } finally {
      setSending(false)
    }
  }

  const isUserGuest = conversation?.guest.id === 'demo-user'
  const otherParty = conversation ? (isUserGuest ? conversation.host : conversation.guest) : null

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 pt-8">
        <div className="container mx-auto px-4">
          <div className="animate-pulse space-y-4">
            <div className="h-8 bg-gray-200 rounded w-1/3" />
            <div className="h-96 bg-gray-200 rounded-xl" />
          </div>
        </div>
      </div>
    )
  }

  if (!conversation) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <AlertCircle className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <h2 className="text-xl font-semibold text-gray-700 mb-2">المحادثة غير موجودة</h2>
          <Button onClick={() => navigate('inbox')} className="mt-4">العودة للرسائل</Button>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* Header */}
      <div className="bg-white border-b sticky top-16 z-10">
        <div className="container mx-auto px-4 py-3">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => navigate('inbox')}>
              <ArrowLeft className="w-5 h-5" />
            </Button>
            
            <div className="flex items-center gap-3 flex-1">
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-amber-400 to-orange-500 flex items-center justify-center text-white font-bold">
                {otherParty?.nameAr?.charAt(0) || otherParty?.name?.charAt(0) || 'ض'}
              </div>
              <div>
                <h2 className="font-semibold">{otherParty?.nameAr || otherParty?.name || 'مستخدم'}</h2>
                <p className="text-xs text-gray-500">
                  {isUserGuest ? 'مضيف' : 'ضيف'}
                </p>
              </div>
            </div>

            {conversation.booking && (
              <div 
                className="hidden md:flex items-center gap-2 p-2 bg-gray-50 rounded-lg cursor-pointer hover:bg-gray-100"
                onClick={() => navigate('accommodation-detail', { id: conversation.booking!.accommodation.id })}
              >
                <img 
                  src={conversation.booking.accommodation.coverImage || '/images/default-accommodation.png'} 
                  alt=""
                  className="w-10 h-10 rounded object-cover"
                />
                <span className="text-sm font-medium">{conversation.booking.accommodation.titleAr}</span>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto container mx-auto px-4 py-4">
        <div className="max-w-2xl mx-auto space-y-4">
          {messages.map((message) => {
            const isOwn = (isUserGuest && message.isFromGuest) || (!isUserGuest && !message.isFromGuest)
            
            return (
              <div key={message.id} className={`flex ${isOwn ? 'justify-start' : 'justify-end'}`}>
                <div className={`max-w-[80%] ${isOwn ? 'order-2' : 'order-1'}`}>
                  <div className={`rounded-2xl px-4 py-2 ${
                    isOwn 
                      ? 'bg-amber-500 text-white rounded-tr-none' 
                      : 'bg-white shadow-sm rounded-tl-none'
                  }`}>
                    <p className="text-sm whitespace-pre-wrap">{message.content}</p>
                  </div>
                  <p className={`text-xs text-gray-400 mt-1 ${isOwn ? 'text-left' : 'text-right'}`}>
                    {new Date(message.createdAt).toLocaleTimeString('ar-SY', { hour: '2-digit', minute: '2-digit' })}
                    {isOwn && message.isRead && (
                      <CheckCircle2 className="w-3 h-3 inline mr-1 text-amber-400" />
                    )}
                  </p>
                </div>
              </div>
            )
          })}
          <div ref={messagesEndRef} />
        </div>
      </div>

      {/* Input */}
      <div className="bg-white border-t sticky bottom-0">
        <div className="container mx-auto px-4 py-3">
          <div className="max-w-2xl mx-auto flex gap-2">
            <input
              type="text"
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && !e.shiftKey && handleSendMessage()}
              placeholder="اكتب رسالتك..."
              className="flex-1 border rounded-full px-4 py-2 focus:outline-none focus:border-amber-400"
              dir="rtl"
            />
            <Button 
              onClick={handleSendMessage}
              disabled={!newMessage.trim() || sending}
              className="rounded-full w-10 h-10 p-0 bg-amber-500 hover:bg-amber-600"
            >
              {sending ? (
                <Loader2 className="w-5 h-5 animate-spin" />
              ) : (
                <Send className="w-5 h-5" />
              )}
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}

// ==================== Notifications View ====================

function NotificationsView() {
  const { navigate } = useNavigation()
  const [notifications, setNotifications] = useState<Array<{
    id: string
    type: string
    titleAr: string
    bodyAr: string | null
    data: string | null
    isRead: boolean
    createdAt: string
  }>>([])
  const [loading, setLoading] = useState(true)
  const [unreadCount, setUnreadCount] = useState(0)

  useEffect(() => {
    const fetchNotifications = async () => {
      try {
        const params = new URLSearchParams()
        params.set('userId', 'demo-user')
        
        const response = await fetch(`/api/notifications?${params}`)
        const data = await response.json()
        setNotifications(data.notifications || [])
        setUnreadCount(data.unreadCount || 0)
      } catch (error) {
        console.error('Error fetching notifications:', error)
      } finally {
        setLoading(false)
      }
    }

    fetchNotifications()
  }, [])

  const markAllAsRead = async () => {
    try {
      await fetch('/api/notifications', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: 'demo-user',
          markAllAsRead: true
        })
      })
      
      setNotifications(notifications.map(n => ({ ...n, isRead: true })))
      setUnreadCount(0)
    } catch (error) {
      console.error('Error marking notifications as read:', error)
    }
  }

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'booking': return <Calendar className="w-5 h-5 text-amber-500" />
      case 'message': return <MessageCircle className="w-5 h-5 text-blue-500" />
      case 'review': return <Star className="w-5 h-5 text-yellow-500" />
      case 'system': return <Bell className="w-5 h-5 text-gray-500" />
      default: return <Bell className="w-5 h-5 text-gray-400" />
    }
  }

  const formatTime = (dateStr: string) => {
    const date = new Date(dateStr)
    const now = new Date()
    const diffMins = Math.floor((now.getTime() - date.getTime()) / (1000 * 60))
    
    if (diffMins < 60) return `منذ ${diffMins} دقيقة`
    if (diffMins < 1440) return `منذ ${Math.floor(diffMins / 60)} ساعة`
    return date.toLocaleDateString('ar-SY', { day: 'numeric', month: 'short' })
  }

  const handleNotificationClick = (notification: typeof notifications[0]) => {
    if (notification.data) {
      try {
        const data = JSON.parse(notification.data)
        if (data.conversationId) {
          navigate('conversation', { id: data.conversationId })
        } else if (data.bookingId) {
          navigate('booking-detail', { id: data.bookingId })
        }
      } catch (e) {
        // Invalid JSON
      }
    }
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">الإشعارات</h1>
            {unreadCount > 0 && (
              <p className="text-gray-600 mt-1">{unreadCount} إشعار غير مقروء</p>
            )}
          </div>
          {unreadCount > 0 && (
            <Button variant="outline" onClick={markAllAsRead}>
              تحديد الكل كمقروء
            </Button>
          )}
        </div>

        {/* Notifications List */}
        {loading ? (
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <Card key={i} className="animate-pulse">
                <CardContent className="p-4">
                  <div className="flex gap-4">
                    <div className="w-10 h-10 bg-gray-200 rounded-full" />
                    <div className="flex-1">
                      <div className="h-4 bg-gray-200 rounded w-1/3 mb-2" />
                      <div className="h-3 bg-gray-200 rounded w-2/3" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : notifications.length === 0 ? (
          <Card className="text-center py-12">
            <CardContent>
              <Bell className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-700 mb-2">لا توجد إشعارات</h3>
              <p className="text-gray-500">ستظهر الإشعارات هنا عند وصولها</p>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-2">
            {notifications.map((notification) => (
              <Card 
                key={notification.id}
                className={`cursor-pointer hover:shadow-md transition-all ${
                  !notification.isRead ? 'bg-amber-50/50 border-amber-200' : ''
                }`}
                onClick={() => handleNotificationClick(notification)}
              >
                <CardContent className="p-4">
                  <div className="flex gap-4">
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                      notification.isRead ? 'bg-gray-100' : 'bg-amber-100'
                    }`}>
                      {getNotificationIcon(notification.type)}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-1">
                        <h3 className={`font-medium ${!notification.isRead ? 'text-gray-900' : 'text-gray-700'}`}>
                          {notification.titleAr}
                        </h3>
                        <span className="text-xs text-gray-500">
                          {formatTime(notification.createdAt)}
                        </span>
                      </div>
                      {notification.bodyAr && (
                        <p className="text-sm text-gray-600">{notification.bodyAr}</p>
                      )}
                    </div>
                    {!notification.isRead && (
                      <div className="w-2 h-2 bg-amber-500 rounded-full mt-2" />
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}

// ==================== My Bookings View ====================

interface BookingData {
  id: string
  confirmationCode: string
  status: string
  checkIn: string
  checkOut: string
  nightsCount: number
  guestsCount: number
  totalAmount: number
  currency: string
  createdAt: string
  accommodation: {
    id: string
    titleAr: string
    city: { nameAr: string } | null
    host: { id: string; name: string | null; nameAr: string | null; phone: string }
  }
  payments: Array<{
    id: string
    amount: number
    status: string
    method: string
  }>
}

function MyBookingsView() {
  const { navigate } = useNavigation()
  const [bookings, setBookings] = useState<BookingData[]>([])
  const [loading, setLoading] = useState(true)
  const [activeTab, setActiveTab] = useState<'upcoming' | 'past' | 'all'>('upcoming')

  useEffect(() => {
    const fetchBookings = async () => {
      try {
        const params = new URLSearchParams()
        if (activeTab === 'upcoming') params.set('upcoming', 'true')
        if (activeTab === 'past') params.set('past', 'true')
        params.set('userId', 'demo-user') // In real app, get from auth
        
        const response = await fetch(`/api/bookings?${params}`)
        const data = await response.json()
        setBookings(data.bookings || [])
      } catch (error) {
        console.error('Error fetching bookings:', error)
      } finally {
        setLoading(false)
      }
    }

    fetchBookings()
  }, [activeTab])

  const statusColors: Record<string, string> = {
    PENDING: 'bg-yellow-100 text-yellow-700',
    CONFIRMED: 'bg-blue-100 text-blue-700',
    PAYMENT_PENDING: 'bg-orange-100 text-orange-700',
    PAID: 'bg-green-100 text-green-700',
    CHECKED_IN: 'bg-purple-100 text-purple-700',
    CHECKED_OUT: 'bg-gray-100 text-gray-700',
    CANCELLED: 'bg-red-100 text-red-700',
    REFUNDED: 'bg-pink-100 text-pink-700'
  }

  const statusLabels: Record<string, string> = {
    PENDING: 'قيد الانتظار',
    CONFIRMED: 'مؤكد',
    PAYMENT_PENDING: 'بانتظار الدفع',
    PAID: 'مدفوع',
    CHECKED_IN: 'وصل',
    CHECKED_OUT: 'غادر',
    CANCELLED: 'ملغي',
    REFUNDED: 'مسترد'
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">حجوزاتي</h1>
            <p className="text-gray-600 mt-1">إدارة جميع حجوزاتك في مكان واحد</p>
          </div>
          <Button onClick={() => navigate('accommodations')} className="bg-amber-500 hover:bg-amber-600">
            حجز جديد
          </Button>
        </div>

        {/* Tabs */}
        <div className="flex gap-2 mb-6">
          {[
            { key: 'upcoming', label: 'القادمة' },
            { key: 'past', label: 'السابقة' },
            { key: 'all', label: 'الكل' }
          ].map((tab) => (
            <Button
              key={tab.key}
              variant={activeTab === tab.key ? 'default' : 'outline'}
              onClick={() => setActiveTab(tab.key as any)}
              className={activeTab === tab.key ? 'bg-amber-500 hover:bg-amber-600' : ''}
            >
              {tab.label}
            </Button>
          ))}
        </div>

        {/* Bookings List */}
        {loading ? (
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <Card key={i} className="animate-pulse">
                <CardContent className="p-6">
                  <div className="h-4 bg-gray-200 rounded w-1/4 mb-4" />
                  <div className="h-4 bg-gray-200 rounded w-1/2" />
                </CardContent>
              </Card>
            ))}
          </div>
        ) : bookings.length === 0 ? (
          <Card className="text-center py-12">
            <CardContent>
              <Calendar className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-700 mb-2">لا توجد حجوزات</h3>
              <p className="text-gray-500 mb-4">لم تقم بأي حجوزات بعد</p>
              <Button onClick={() => navigate('accommodations')} className="bg-amber-500 hover:bg-amber-600">
                استكشف الإقامات
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-4">
            {bookings.map((booking) => (
              <Card 
                key={booking.id} 
                className="hover:shadow-md transition-shadow cursor-pointer"
                onClick={() => navigate('booking-detail', { id: booking.id })}
              >
                <CardContent className="p-6">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-3">
                        <Badge className={statusColors[booking.status]}>
                          {statusLabels[booking.status] || booking.status}
                        </Badge>
                        <span className="text-sm text-gray-500">
                          #{booking.confirmationCode.slice(0, 8).toUpperCase()}
                        </span>
                      </div>

                      <h3 className="text-lg font-semibold text-gray-900 mb-2">
                        {booking.accommodation.titleAr}
                      </h3>

                      <div className="flex flex-wrap gap-4 text-sm text-gray-600">
                        <div className="flex items-center gap-1">
                          <MapPin className="w-4 h-4" />
                          <span>{booking.accommodation.city?.nameAr || 'سوريا'}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Calendar className="w-4 h-4" />
                          <span>
                            {new Date(booking.checkIn).toLocaleDateString('ar-SY')} -
                            {new Date(booking.checkOut).toLocaleDateString('ar-SY')}
                          </span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Users className="w-4 h-4" />
                          <span>{booking.guestsCount} ضيف</span>
                        </div>
                      </div>
                    </div>

                    <div className="text-left">
                      <p className="text-2xl font-bold text-amber-600">
                        {booking.totalAmount.toLocaleString()}
                      </p>
                      <p className="text-sm text-gray-500">{booking.currency}</p>
                    </div>
                  </div>

                  <div className="flex gap-2 mt-4 pt-4 border-t">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={(e) => {
                        e.stopPropagation()
                        navigate('accommodation-detail', { id: booking.accommodation.id })
                      }}
                    >
                      عرض الإقامة
                    </Button>
                    {booking.status === 'PENDING' && (
                      <Button 
                        variant="destructive" 
                        size="sm"
                        onClick={(e) => {
                          e.stopPropagation()
                          navigate('booking-detail', { id: booking.id })
                        }}
                      >
                        إلغاء الحجز
                      </Button>
                    )}
                    {booking.status === 'CONFIRMED' && (
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={(e) => {
                          e.stopPropagation()
                          navigate('conversation', { id: booking.accommodation.host.id })
                        }}
                      >
                        تواصل مع المضيف
                      </Button>
                    )}
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      className="mr-auto text-gray-500"
                      onClick={(e) => {
                        e.stopPropagation()
                        navigate('booking-detail', { id: booking.id })
                      }}
                    >
                      التفاصيل
                      <ArrowLeft className="w-4 h-4 mr-1" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}

// ==================== Booking Detail View ====================

interface BookingDetailData {
  id: string
  confirmationCode: string
  status: string
  checkIn: string
  checkOut: string
  nightsCount: number
  guestsCount: number
  totalAmount: number
  currency: string
  specialRequests: string | null
  createdAt: string
  confirmedAt: string | null
  cancelledAt: string | null
  cancelledBy: string | null
  cancellationReason: string | null
  accommodation: {
    id: string
    titleAr: string
    addressAr: string | null
    type: string
    coverImage: string | null
    city: { nameAr: string } | null
    host: {
      id: string
      name: string | null
      nameAr: string | null
      phone: string
      avatar: string | null
    }
    images: Array<{ url: string }>
  }
  room: { id: string; nameAr: string } | null
  guest: {
    id: string
    name: string | null
    nameAr: string | null
    phone: string
    email: string | null
    avatar: string | null
  }
  payments: Array<{
    id: string
    amount: number
    status: string
    method: string
    createdAt: string
  }>
  review: {
    id: string
    rating: number
    commentAr: string | null
    createdAt: string
  } | null
}

function BookingDetailView() {
  const { navigate, pageParams } = useNavigation()
  const { user } = useAuth()
  const [booking, setBooking] = useState<BookingDetailData | null>(null)
  const [loading, setLoading] = useState(true)
  const [showCancelDialog, setShowCancelDialog] = useState(false)
  const [cancelling, setCancelling] = useState(false)
  const [cancelReason, setCancelReason] = useState('')

  useEffect(() => {
    const fetchBooking = async () => {
      if (!pageParams.id) {
        navigate('my-bookings')
        return
      }

      try {
        const response = await fetch(`/api/bookings/${pageParams.id}`)
        if (response.ok) {
          const data = await response.json()
          setBooking(data.booking)
        } else {
          navigate('my-bookings')
        }
      } catch (error) {
        console.error('Error fetching booking:', error)
      } finally {
        setLoading(false)
      }
    }

    fetchBooking()
  }, [pageParams.id])

  const handleCancelBooking = async () => {
    if (!booking) return
    setCancelling(true)

    try {
      const response = await fetch(`/api/bookings/${booking.id}?cancelledBy=guest&reason=${encodeURIComponent(cancelReason)}`, {
        method: 'DELETE'
      })

      if (response.ok) {
        setBooking({ ...booking, status: 'CANCELLED', cancelledAt: new Date().toISOString(), cancelledBy: 'guest' })
        setShowCancelDialog(false)
      }
    } catch (error) {
      console.error('Error cancelling booking:', error)
    } finally {
      setCancelling(false)
    }
  }

  const statusColors: Record<string, string> = {
    PENDING: 'bg-yellow-100 text-yellow-700 border-yellow-200',
    CONFIRMED: 'bg-blue-100 text-blue-700 border-blue-200',
    PAYMENT_PENDING: 'bg-orange-100 text-orange-700 border-orange-200',
    PAID: 'bg-green-100 text-green-700 border-green-200',
    CHECKED_IN: 'bg-purple-100 text-purple-700 border-purple-200',
    CHECKED_OUT: 'bg-gray-100 text-gray-700 border-gray-200',
    CANCELLED: 'bg-red-100 text-red-700 border-red-200',
    REFUNDED: 'bg-pink-100 text-pink-700 border-pink-200'
  }

  const statusLabels: Record<string, string> = {
    PENDING: 'قيد الانتظار',
    CONFIRMED: 'مؤكد',
    PAYMENT_PENDING: 'بانتظار الدفع',
    PAID: 'مدفوع',
    CHECKED_IN: 'وصل',
    CHECKED_OUT: 'غادر',
    CANCELLED: 'ملغي',
    REFUNDED: 'مسترد'
  }

  const statusDescriptions: Record<string, string> = {
    PENDING: 'في انتظار موافقة المضيف على حجزك',
    CONFIRMED: 'تم تأكيد حجزك من قبل المضيف',
    PAYMENT_PENDING: 'يرجى إتمام عملية الدفع لتأكيد الحجز',
    PAID: 'تم استلام الدفع، الحجز مؤكد بالكامل',
    CHECKED_IN: 'تم تسجيل الوصول',
    CHECKED_OUT: 'تم تسجيل المغادرة، شكراً لاختيارك ضيف',
    CANCELLED: 'تم إلغاء هذا الحجز',
    REFUNDED: 'تم إرجاع المبلغ'
  }

  const canCancel = booking && ['PENDING', 'CONFIRMED', 'PAYMENT_PENDING'].includes(booking.status)
  const canPay = booking && booking.status === 'PAYMENT_PENDING'
  const canReview = booking && booking.status === 'CHECKED_OUT' && !booking.review
  const isPast = booking && new Date(booking.checkOut) < new Date()

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <div className="container mx-auto px-4 py-8">
          <div className="animate-pulse space-y-6">
            <div className="h-8 bg-gray-200 rounded w-1/3" />
            <div className="h-64 bg-gray-200 rounded-xl" />
            <div className="h-48 bg-gray-200 rounded-xl" />
          </div>
        </div>
      </div>
    )
  }

  if (!booking) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Card className="text-center py-12">
          <CardContent>
            <AlertCircle className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-gray-700 mb-2">الحجز غير موجود</h3>
            <p className="text-gray-500 mb-6">لم نتمكن من العثور على هذا الحجز</p>
            <Button onClick={() => navigate('my-bookings')} className="bg-amber-500 hover:bg-amber-600">
              العودة لحجوزاتي
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center gap-4 mb-6">
          <Button variant="ghost" size="icon" onClick={() => navigate('my-bookings')}>
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div className="flex-1">
            <h1 className="text-2xl font-bold text-gray-900">تفاصيل الحجز</h1>
            <p className="text-gray-500">#{booking.confirmationCode}</p>
          </div>
          <Badge className={`${statusColors[booking.status]} px-4 py-2 text-sm font-medium border`}>
            {statusLabels[booking.status]}
          </Badge>
        </div>

        {/* Status Timeline */}
        <Card className="mb-6 border-0 shadow-sm">
          <CardContent className="p-6">
            <div className="flex items-center gap-2 mb-4">
              <Clock className="w-5 h-5 text-amber-500" />
              <h3 className="font-semibold text-gray-900">حالة الحجز</h3>
            </div>
            <p className="text-gray-600 mb-4">{statusDescriptions[booking.status]}</p>
            
            {/* Timeline */}
            <div className="flex items-center justify-between relative">
              <div className="absolute top-4 left-0 right-0 h-1 bg-gray-200 -z-10" />
              {['PENDING', 'CONFIRMED', 'PAID', 'CHECKED_IN', 'CHECKED_OUT'].map((step, index) => {
                const statusOrder = ['PENDING', 'CONFIRMED', 'PAYMENT_PENDING', 'PAID', 'CHECKED_IN', 'CHECKED_OUT']
                const currentIndex = statusOrder.indexOf(booking.status)
                const stepIndex = statusOrder.indexOf(step === 'PAID' ? 'PAID' : step)
                const isCompleted = stepIndex <= currentIndex || (step === 'PAID' && statusOrder.indexOf('PAYMENT_PENDING') <= currentIndex)
                const isCurrent = booking.status === step || (step === 'PAID' && booking.status === 'PAYMENT_PENDING')
                
                return (
                  <div key={step} className="flex flex-col items-center gap-2">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                      isCompleted ? 'bg-green-500 text-white' : isCurrent ? 'bg-amber-500 text-white' : 'bg-gray-200 text-gray-400'
                    }`}>
                      {isCompleted ? <CheckCircle2 className="w-5 h-5" /> : index + 1}
                    </div>
                    <span className={`text-xs ${isCompleted || isCurrent ? 'text-gray-900 font-medium' : 'text-gray-400'}`}>
                      {step === 'PENDING' ? 'طلب' : step === 'CONFIRMED' ? 'تأكيد' : step === 'PAID' ? 'دفع' : step === 'CHECKED_IN' ? 'وصول' : 'مغادرة'}
                    </span>
                  </div>
                )
              })}
            </div>
          </CardContent>
        </Card>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Accommodation Info */}
            <Card className="border-0 shadow-sm">
              <CardContent className="p-6">
                <div className="flex gap-4">
                  <div className="w-32 h-24 rounded-lg overflow-hidden flex-shrink-0 bg-gray-100">
                    {booking.accommodation.coverImage ? (
                      <img src={booking.accommodation.coverImage} alt="" className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center">
                        <Building2 className="w-8 h-8 text-gray-300" />
                      </div>
                    )}
                  </div>
                  <div className="flex-1">
                    <h3 className="text-lg font-semibold text-gray-900 mb-1">{booking.accommodation.titleAr}</h3>
                    <div className="flex items-center gap-2 text-gray-500 text-sm mb-2">
                      <MapPin className="w-4 h-4" />
                      <span>{booking.accommodation.city?.nameAr || 'سوريا'}</span>
                      {booking.accommodation.addressAr && (
                        <>
                          <span>•</span>
                          <span>{booking.accommodation.addressAr}</span>
                        </>
                      )}
                    </div>
                    <Badge variant="outline" className="text-xs">
                      {booking.accommodation.type === 'HOTEL' ? 'فندق' : 
                       booking.accommodation.type === 'APARTMENT' ? 'شقة' :
                       booking.accommodation.type === 'VILLA' ? 'فيلا' : 'إقامة'}
                    </Badge>
                    <Button 
                      variant="link" 
                      className="p-0 h-auto text-amber-600 mt-2"
                      onClick={() => navigate('accommodation-detail', { id: booking.accommodation.id })}
                    >
                      عرض الإقامة
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Dates & Guests */}
            <Card className="border-0 shadow-sm">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg">تفاصيل الإقامة</CardTitle>
              </CardHeader>
              <CardContent className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="text-center p-4 bg-gray-50 rounded-xl">
                  <Calendar className="w-6 h-6 text-amber-500 mx-auto mb-2" />
                  <p className="text-xs text-gray-500 mb-1">تاريخ الوصول</p>
                  <p className="font-semibold text-gray-900">
                    {new Date(booking.checkIn).toLocaleDateString('ar-SY', { weekday: 'short', day: 'numeric', month: 'short' })}
                  </p>
                </div>
                <div className="text-center p-4 bg-gray-50 rounded-xl">
                  <Calendar className="w-6 h-6 text-amber-500 mx-auto mb-2" />
                  <p className="text-xs text-gray-500 mb-1">تاريخ المغادرة</p>
                  <p className="font-semibold text-gray-900">
                    {new Date(booking.checkOut).toLocaleDateString('ar-SY', { weekday: 'short', day: 'numeric', month: 'short' })}
                  </p>
                </div>
                <div className="text-center p-4 bg-gray-50 rounded-xl">
                  <Moon className="w-6 h-6 text-amber-500 mx-auto mb-2" />
                  <p className="text-xs text-gray-500 mb-1">عدد الليالي</p>
                  <p className="font-semibold text-gray-900">{booking.nightsCount} ليلة</p>
                </div>
                <div className="text-center p-4 bg-gray-50 rounded-xl">
                  <Users className="w-6 h-6 text-amber-500 mx-auto mb-2" />
                  <p className="text-xs text-gray-500 mb-1">عدد الضيوف</p>
                  <p className="font-semibold text-gray-900">{booking.guestsCount} ضيف</p>
                </div>
              </CardContent>
            </Card>

            {/* Special Requests */}
            {booking.specialRequests && (
              <Card className="border-0 shadow-sm">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">طلبات خاصة</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600">{booking.specialRequests}</p>
                </CardContent>
              </Card>
            )}

            {/* Payments */}
            <Card className="border-0 shadow-sm">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg">المدفوعات</CardTitle>
              </CardHeader>
              <CardContent>
                {booking.payments.length === 0 ? (
                  <div className="text-center py-6 text-gray-500">
                    <Wallet className="w-10 h-10 mx-auto mb-2 text-gray-300" />
                    <p>لم يتم تسجيل أي مدفوعات بعد</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {booking.payments.map((payment) => (
                      <div key={payment.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div className="flex items-center gap-3">
                          <CreditCard className="w-5 h-5 text-gray-400" />
                          <div>
                            <p className="font-medium text-gray-900">
                              {payment.method === 'SYRIATEL_CASH' ? 'سيرياتيل كاش' :
                               payment.method === 'MTN_CASH' ? 'MTN كاش' :
                               payment.method === 'BANK_TRANSFER' ? 'تحويل بنكي' : 'نقدي'}
                            </p>
                            <p className="text-xs text-gray-500">
                              {new Date(payment.createdAt).toLocaleDateString('ar-SY')}
                            </p>
                          </div>
                        </div>
                        <div className="text-left">
                          <p className="font-semibold text-gray-900">{payment.amount.toLocaleString()} {booking.currency}</p>
                          <Badge variant="outline" className={`text-xs ${
                            payment.status === 'COMPLETED' ? 'border-green-200 text-green-700' :
                            payment.status === 'PENDING' ? 'border-yellow-200 text-yellow-700' :
                            'border-red-200 text-red-700'
                          }`}>
                            {payment.status === 'COMPLETED' ? 'مكتمل' :
                             payment.status === 'PENDING' ? 'قيد الانتظار' : 'فشل'}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Review */}
            {booking.review ? (
              <Card className="border-0 shadow-sm">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">تقييمك</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center gap-2 mb-2">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <Star key={star} className={`w-5 h-5 ${star <= booking.review!.rating ? 'fill-amber-400 text-amber-400' : 'text-gray-300'}`} />
                    ))}
                  </div>
                  {booking.review.commentAr && (
                    <p className="text-gray-600">{booking.review.commentAr}</p>
                  )}
                  <p className="text-xs text-gray-400 mt-2">
                    {new Date(booking.review.createdAt).toLocaleDateString('ar-SY')}
                  </p>
                </CardContent>
              </Card>
            ) : canReview ? (
              <Card className="border-0 shadow-sm border-amber-200 bg-amber-50/50">
                <CardContent className="p-6 text-center">
                  <Star className="w-10 h-10 text-amber-400 mx-auto mb-3" />
                  <h3 className="font-semibold text-gray-900 mb-2">شاركنا تقييمك</h3>
                  <p className="text-gray-600 text-sm mb-4">ساعد الآخرين باضافة تقييمك لهذه الإقامة</p>
                  <Button className="bg-amber-500 hover:bg-amber-600">
                    <PenSquare className="w-4 h-4 ml-2" />
                    أضف تقييم
                  </Button>
                </CardContent>
              </Card>
            ) : null}

            {/* Cancellation Info */}
            {booking.status === 'CANCELLED' && (
              <Card className="border-0 shadow-sm border-red-200 bg-red-50/50">
                <CardContent className="p-6">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-10 h-10 bg-red-100 rounded-full flex items-center justify-center">
                      <AlertCircle className="w-5 h-5 text-red-500" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-red-700">تم إلغاء الحجز</h3>
                      <p className="text-sm text-red-600">
                        {booking.cancelledBy === 'guest' ? 'تم الإلغاء من قبلك' : 'تم الإلغاء من قبل المضيف'}
                      </p>
                    </div>
                  </div>
                  {booking.cancellationReason && (
                    <p className="text-sm text-red-600 bg-red-100/50 p-3 rounded-lg">
                      السبب: {booking.cancellationReason}
                    </p>
                  )}
                </CardContent>
              </Card>
            )}
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Price Summary */}
            <Card className="border-0 shadow-sm sticky top-24">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg">ملخص السعر</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex justify-between text-gray-600">
                  <span>السعر الأساسي ({booking.nightsCount} ليالي)</span>
                  <span>{booking.totalAmount.toLocaleString()} {booking.currency}</span>
                </div>
                <div className="flex justify-between text-gray-600">
                  <span>رسوم الخدمة</span>
                  <span>مشمولة</span>
                </div>
                <div className="border-t pt-3 flex justify-between font-semibold text-gray-900 text-lg">
                  <span>المجموع</span>
                  <span className="text-amber-600">{booking.totalAmount.toLocaleString()} {booking.currency}</span>
                </div>
              </CardContent>
            </Card>

            {/* Host Info */}
            <Card className="border-0 shadow-sm">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg">معلومات المضيف</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-12 h-12 bg-amber-100 rounded-full flex items-center justify-center">
                    {booking.accommodation.host.avatar ? (
                      <img src={booking.accommodation.host.avatar} alt="" className="w-full h-full rounded-full object-cover" />
                    ) : (
                      <User className="w-6 h-6 text-amber-600" />
                    )}
                  </div>
                  <div>
                    <p className="font-semibold text-gray-900">{booking.accommodation.host.nameAr || booking.accommodation.host.name}</p>
                    <p className="text-sm text-gray-500">المضيف</p>
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button 
                    variant="outline" 
                    className="flex-1"
                    onClick={() => navigate('conversation', { id: booking.accommodation.host.id })}
                  >
                    <MessageCircle className="w-4 h-4 ml-2" />
                    تواصل
                  </Button>
                  <Button variant="outline" size="icon">
                    <Phone className="w-4 h-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Actions */}
            <div className="space-y-3">
              {canPay && (
                <Button 
                  className="w-full bg-amber-500 hover:bg-amber-600 h-12"
                  onClick={() => navigate('payment', { bookingId: booking.id })}
                >
                  <CreditCard className="w-5 h-5 ml-2" />
                  إتمام الدفع
                </Button>
              )}
              
              {canCancel && (
                <Button 
                  variant="outline" 
                  className="w-full text-red-600 hover:text-red-700 hover:bg-red-50"
                  onClick={() => setShowCancelDialog(true)}
                >
                  إلغاء الحجز
                </Button>
              )}

              <Button 
                variant="outline" 
                className="w-full"
                onClick={() => navigate('payment-history', { bookingId: booking.id })}
              >
                <Wallet className="w-4 h-4 ml-2" />
                سجل المدفوعات
              </Button>
            </div>

            {/* Help */}
            <Card className="border-0 shadow-sm bg-gray-50">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <HelpCircle className="w-5 h-5 text-gray-400" />
                  <div>
                    <p className="text-sm font-medium text-gray-700">تحتاج مساعدة؟</p>
                    <p className="text-xs text-gray-500">تواصل مع فريق الدعم</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Cancel Dialog */}
        {showCancelDialog && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
            <Card className="w-full max-w-md">
              <CardHeader>
                <CardTitle>إلغاء الحجز</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-gray-600">هل أنت متأكد من إلغاء هذا الحجز؟</p>
                <div>
                  <label className="text-sm font-medium text-gray-700 mb-1 block">سبب الإلغاء (اختياري)</label>
                  <Input
                    value={cancelReason}
                    onChange={(e) => setCancelReason(e.target.value)}
                    placeholder="أدخل سبب الإلغاء..."
                  />
                </div>
                <div className="flex gap-3">
                  <Button 
                    variant="outline" 
                    className="flex-1"
                    onClick={() => setShowCancelDialog(false)}
                    disabled={cancelling}
                  >
                    تراجع
                  </Button>
                  <Button 
                    variant="destructive" 
                    className="flex-1"
                    onClick={handleCancelBooking}
                    disabled={cancelling}
                  >
                    {cancelling ? <Loader2 className="w-4 h-4 animate-spin" /> : 'تأكيد الإلغاء'}
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  )
}

// ==================== Host Bookings View ====================

function HostBookingsView() {
  const { navigate } = useNavigation()
  const [bookings, setBookings] = useState<BookingData[]>([])
  const [loading, setLoading] = useState(true)
  const [activeTab, setActiveTab] = useState<'pending' | 'confirmed' | 'all'>('pending')

  useEffect(() => {
    const fetchBookings = async () => {
      try {
        const params = new URLSearchParams()
        if (activeTab === 'pending') params.set('status', 'PENDING')
        if (activeTab === 'confirmed') params.set('status', 'CONFIRMED')
        params.set('hostId', 'demo-host') // In real app, get from auth
        
        const response = await fetch(`/api/bookings?${params}`)
        const data = await response.json()
        setBookings(data.bookings || [])
      } catch (error) {
        console.error('Error fetching bookings:', error)
      } finally {
        setLoading(false)
      }
    }

    fetchBookings()
  }, [activeTab])

  const handleStatusChange = async (bookingId: string, newStatus: string) => {
    try {
      const response = await fetch(`/api/bookings/${bookingId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: newStatus })
      })
      
      if (response.ok) {
        setBookings(bookings.map(b => 
          b.id === bookingId ? { ...b, status: newStatus } : b
        ))
      }
    } catch (error) {
      console.error('Error updating booking:', error)
    }
  }

  const statusColors: Record<string, string> = {
    PENDING: 'bg-yellow-100 text-yellow-700',
    CONFIRMED: 'bg-blue-100 text-blue-700',
    PAYMENT_PENDING: 'bg-orange-100 text-orange-700',
    PAID: 'bg-green-100 text-green-700',
    CANCELLED: 'bg-red-100 text-red-700'
  }

  const statusLabels: Record<string, string> = {
    PENDING: 'قيد الانتظار',
    CONFIRMED: 'مؤكد',
    PAYMENT_PENDING: 'بانتظار الدفع',
    PAID: 'مدفوع',
    CANCELLED: 'ملغي'
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">إدارة الحجوزات</h1>
            <p className="text-gray-600 mt-1">إدارة حجوزات إقاماتك</p>
          </div>
          <Button onClick={() => navigate('host-dashboard')} variant="outline">
            <ArrowLeft className="w-4 h-4 ml-2" />
            لوحة التحكم
          </Button>
        </div>

        {/* Tabs */}
        <div className="flex gap-2 mb-6">
          {[
            { key: 'pending', label: 'قيد الانتظار' },
            { key: 'confirmed', label: 'مؤكد' },
            { key: 'all', label: 'الكل' }
          ].map((tab) => (
            <Button
              key={tab.key}
              variant={activeTab === tab.key ? 'default' : 'outline'}
              onClick={() => setActiveTab(tab.key as any)}
              className={activeTab === tab.key ? 'bg-amber-500 hover:bg-amber-600' : ''}
            >
              {tab.label}
            </Button>
          ))}
        </div>

        {/* Bookings List */}
        {loading ? (
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <Card key={i} className="animate-pulse">
                <CardContent className="p-6">
                  <div className="h-4 bg-gray-200 rounded w-1/4 mb-4" />
                  <div className="h-4 bg-gray-200 rounded w-1/2" />
                </CardContent>
              </Card>
            ))}
          </div>
        ) : bookings.length === 0 ? (
          <Card className="text-center py-12">
            <CardContent>
              <Calendar className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-700 mb-2">لا توجد حجوزات</h3>
              <p className="text-gray-500">لا توجد حجوزات في هذه الفئة</p>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-4">
            {bookings.map((booking) => (
              <Card key={booking.id}>
                <CardContent className="p-6">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-3">
                        <Badge className={statusColors[booking.status]}>
                          {statusLabels[booking.status] || booking.status}
                        </Badge>
                        <span className="text-sm text-gray-500">
                          #{booking.confirmationCode.slice(0, 8).toUpperCase()}
                        </span>
                      </div>
                      
                      <h3 className="text-lg font-semibold text-gray-900 mb-2">
                        {booking.accommodation.titleAr}
                      </h3>
                      
                      <div className="flex flex-wrap gap-4 text-sm text-gray-600 mb-4">
                        <div className="flex items-center gap-1">
                          <Calendar className="w-4 h-4" />
                          <span>
                            {new Date(booking.checkIn).toLocaleDateString('ar-SY')} - 
                            {new Date(booking.checkOut).toLocaleDateString('ar-SY')}
                          </span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Moon className="w-4 h-4" />
                          <span>{booking.nightsCount} ليالي</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Users className="w-4 h-4" />
                          <span>{booking.guestsCount} ضيف</span>
                        </div>
                      </div>

                      {/* Guest Info */}
                      <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                        <div className="w-10 h-10 rounded-full bg-gradient-to-br from-amber-400 to-orange-500 flex items-center justify-center text-white font-bold">
                          ض
                        </div>
                        <div>
                          <p className="font-medium">ضيف</p>
                          <p className="text-sm text-gray-500">+963999999999</p>
                        </div>
                      </div>
                    </div>
                    
                    <div className="text-left">
                      <p className="text-2xl font-bold text-amber-600">
                        {booking.totalAmount.toLocaleString()}
                      </p>
                      <p className="text-sm text-gray-500">{booking.currency}</p>
                    </div>
                  </div>
                  
                  {/* Actions */}
                  {booking.status === 'PENDING' && (
                    <div className="flex gap-2 mt-4 pt-4 border-t">
                      <Button 
                        className="flex-1 bg-green-500 hover:bg-green-600"
                        onClick={() => handleStatusChange(booking.id, 'CONFIRMED')}
                      >
                        <CheckCircle2 className="w-4 h-4 ml-2" />
                        تأكيد
                      </Button>
                      <Button 
                        variant="destructive"
                        className="flex-1"
                        onClick={() => handleStatusChange(booking.id, 'CANCELLED')}
                      >
                        <X className="w-4 h-4 ml-2" />
                        رفض
                      </Button>
                    </div>
                  )}
                  
                  {booking.status === 'CONFIRMED' && (
                    <div className="flex gap-2 mt-4 pt-4 border-t">
                      <Button 
                        variant="outline"
                        onClick={() => handleStatusChange(booking.id, 'PAID')}
                      >
                        تم الدفع
                      </Button>
                      <Button variant="outline">
                        <MessageCircle className="w-4 h-4 ml-2" />
                        تواصل مع الضيف
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}

// ==================== Auth Context ====================

interface AuthUser {
  id: string
  phone: string
  name: string | null
  nameAr: string | null
  email: string | null
  avatar: string | null
  role: string
  isVerified: boolean
  city?: string | null
}

interface AuthContextType {
  user: AuthUser | null
  token: string | null
  isLoading: boolean
  isAuthenticated: boolean
  login: (phone: string) => Promise<{ success: boolean; error?: string; isNewUser?: boolean }>
  verifyOTP: (phone: string, code: string, name?: string, role?: string) => Promise<{ success: boolean; error?: string }>
  register: (phone: string, name: string, role?: string) => Promise<{ success: boolean; error?: string }>
  logout: () => Promise<void>
  setUser: (user: AuthUser | null) => void
  refetchUser: () => Promise<void>
}

const AuthContext = createContext<AuthContextType | null>(null)

function useAuth() {
  const context = useContext(AuthContext)
  if (!context) {
    throw new Error('useAuth must be used within AuthProvider')
  }
  return context
}

// Token storage utilities
const TOKEN_KEY = 'dayf_auth_token'
const USER_KEY = 'dayf_auth_user'

function saveToken(token: string) {
  if (typeof window !== 'undefined') {
    localStorage.setItem(TOKEN_KEY, token)
  }
}

function getToken(): string | null {
  if (typeof window !== 'undefined') {
    return localStorage.getItem(TOKEN_KEY)
  }
  return null
}

function removeToken() {
  if (typeof window !== 'undefined') {
    localStorage.removeItem(TOKEN_KEY)
    localStorage.removeItem(USER_KEY)
  }
}

function saveUserToStorage(user: AuthUser) {
  if (typeof window !== 'undefined') {
    localStorage.setItem(USER_KEY, JSON.stringify(user))
  }
}

function getUserFromStorage(): AuthUser | null {
  if (typeof window !== 'undefined') {
    const stored = localStorage.getItem(USER_KEY)
    if (stored) {
      try {
        return JSON.parse(stored)
      } catch {
        return null
      }
    }
  }
  return null
}

// ==================== Login View ====================

function LoginView() {
  const { navigate } = useNavigation()
  const { login } = useAuth()
  const [phone, setPhone] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    setLoading(true)

    try {
      const result = await login(phone)
      if (result.success) {
        navigate('verify-otp', { phone })
      } else {
        setError(result.error || 'حدث خطأ')
      }
    } catch (err) {
      setError('حدث خطأ أثناء تسجيل الدخول')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-amber-50 to-white flex items-center justify-center px-4">
      <Card className="w-full max-w-md border-0 shadow-xl">
        <CardHeader className="text-center pb-2">
          <div className="w-16 h-16 bg-gradient-to-br from-amber-400 to-orange-500 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <span className="text-3xl font-bold text-white">ض</span>
          </div>
          <CardTitle className="text-2xl">تسجيل الدخول</CardTitle>
          <p className="text-gray-500 mt-2">أدخل رقم هاتفك للمتابعة</p>
        </CardHeader>
        <CardContent className="pt-4">
          <form onSubmit={handleLogin} className="space-y-4">
            {error && (
              <div className="p-3 bg-red-50 border border-red-200 rounded-lg text-red-600 text-sm text-center">
                {error}
              </div>
            )}
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">رقم الهاتف</label>
              <div className="relative">
                <Input
                  type="tel"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="+963 999 123 456"
                  className="text-left pr-20"
                  dir="ltr"
                  required
                />
                <span className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 text-sm">
                  🇸🇾
                </span>
              </div>
            </div>

            <Button 
              type="submit"
              className="w-full h-12 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white rounded-xl text-lg font-semibold"
              disabled={loading || !phone}
            >
              {loading ? (
                <><Loader2 className="w-5 h-5 animate-spin ml-2" /> جاري الإرسال...</>
              ) : (
                'إرسال رمز التحقق'
              )}
            </Button>
          </form>

          <div className="mt-6 text-center">
            <p className="text-gray-500">
              ليس لديك حساب؟{' '}
              <button 
                onClick={() => navigate('register')}
                className="text-amber-600 hover:text-amber-700 font-medium"
              >
                إنشاء حساب جديد
              </button>
            </p>
          </div>

          <div className="mt-6 pt-6 border-t">
            <Button 
              variant="outline"
              className="w-full"
              onClick={() => navigate('home')}
            >
              <ArrowLeft className="w-4 h-4 ml-2" />
              العودة للرئيسية
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

// ==================== Register View ====================

function RegisterView() {
  const { navigate } = useNavigation()
  const { register } = useAuth()
  const [phone, setPhone] = useState('')
  const [name, setName] = useState('')
  const [role, setRole] = useState<'GUEST' | 'HOST'>('GUEST')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    setLoading(true)

    try {
      const result = await register(phone, name)
      if (result.success) {
        navigate('verify-otp', { phone, name, role })
      } else {
        setError(result.error || 'حدث خطأ')
      }
    } catch (err) {
      setError('حدث خطأ أثناء إنشاء الحساب')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-amber-50 to-white flex items-center justify-center px-4 py-8">
      <Card className="w-full max-w-md border-0 shadow-xl">
        <CardHeader className="text-center pb-2">
          <div className="w-16 h-16 bg-gradient-to-br from-amber-400 to-orange-500 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <span className="text-3xl font-bold text-white">ض</span>
          </div>
          <CardTitle className="text-2xl">إنشاء حساب جديد</CardTitle>
          <p className="text-gray-500 mt-2">انضم إلى مجتمع ضيف السياحي</p>
        </CardHeader>
        <CardContent className="pt-4">
          <form onSubmit={handleRegister} className="space-y-4">
            {error && (
              <div className="p-3 bg-red-50 border border-red-200 rounded-lg text-red-600 text-sm text-center">
                {error}
              </div>
            )}

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">الاسم الكامل</label>
              <Input
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="أحمد محمد"
                className="text-right"
                required
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">رقم الهاتف</label>
              <div className="relative">
                <Input
                  type="tel"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="+963 999 123 456"
                  className="text-left pr-20"
                  dir="ltr"
                  required
                />
                <span className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 text-sm">
                  🇸🇾
                </span>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">نوع الحساب</label>
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => setRole('GUEST')}
                  className={`p-4 rounded-xl border-2 transition-all ${
                    role === 'GUEST' 
                      ? 'border-amber-500 bg-amber-50' 
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <Users className="w-6 h-6 mx-auto mb-2 text-amber-500" />
                  <span className="font-medium">ضيف</span>
                  <p className="text-xs text-gray-500 mt-1">للبحث عن إقامات</p>
                </button>
                <button
                  type="button"
                  onClick={() => setRole('HOST')}
                  className={`p-4 rounded-xl border-2 transition-all ${
                    role === 'HOST' 
                      ? 'border-amber-500 bg-amber-50' 
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <Building2 className="w-6 h-6 mx-auto mb-2 text-amber-500" />
                  <span className="font-medium">مضيف</span>
                  <p className="text-xs text-gray-500 mt-1">لعرض إقاماتك</p>
                </button>
              </div>
            </div>

            <Button 
              type="submit"
              className="w-full h-12 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white rounded-xl text-lg font-semibold"
              disabled={loading || !phone || !name}
            >
              {loading ? (
                <><Loader2 className="w-5 h-5 animate-spin ml-2" /> جاري إنشاء الحساب...</>
              ) : (
                'إنشاء حساب'
              )}
            </Button>
          </form>

          <div className="mt-6 text-center">
            <p className="text-gray-500">
              لديك حساب بالفعل؟{' '}
              <button 
                onClick={() => navigate('login')}
                className="text-amber-600 hover:text-amber-700 font-medium"
              >
                تسجيل الدخول
              </button>
            </p>
          </div>

          <div className="mt-6 pt-6 border-t">
            <Button 
              variant="outline"
              className="w-full"
              onClick={() => navigate('home')}
            >
              <ArrowLeft className="w-4 h-4 ml-2" />
              العودة للرئيسية
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

// ==================== OTP Verify View ====================

function OTPVerifyView() {
  const { navigate, pageParams } = useNavigation()
  const { verifyOTP } = useAuth()
  const [code, setCode] = useState(['', '', '', '', '', ''])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [resendCooldown, setResendCooldown] = useState(60)
  const inputRefs = useRef<(HTMLInputElement | null)[]>([])

  const phone = pageParams.phone || ''

  // Cooldown timer
  useEffect(() => {
    if (resendCooldown > 0) {
      const timer = setTimeout(() => setResendCooldown(c => c - 1), 1000)
      return () => clearTimeout(timer)
    }
  }, [resendCooldown])

  const handleCodeChange = (index: number, value: string) => {
    if (value.length > 1) {
      // Handle paste
      const digits = value.slice(0, 6).split('')
      const newCode = [...code]
      digits.forEach((digit, i) => {
        if (i < 6 && /^\d$/.test(digit)) {
          newCode[i] = digit
        }
      })
      setCode(newCode)
      // Focus last filled or next empty
      const nextIndex = Math.min(digits.length, 5)
      inputRefs.current[nextIndex]?.focus()
    } else if (/^\d*$/.test(value)) {
      const newCode = [...code]
      newCode[index] = value
      setCode(newCode)
      
      // Auto focus next
      if (value && index < 5) {
        inputRefs.current[index + 1]?.focus()
      }
    }
  }

  const handleKeyDown = (index: number, e: React.KeyboardEvent) => {
    if (e.key === 'Backspace' && !code[index] && index > 0) {
      inputRefs.current[index - 1]?.focus()
    }
  }

  const handleVerify = async () => {
    const fullCode = code.join('')
    if (fullCode.length !== 6) {
      setError('الرجاء إدخال الرمز كاملاً')
      return
    }

    setError('')
    setLoading(true)

    try {
      // Pass name and role from pageParams for new user registration
      const result = await verifyOTP(phone, fullCode, pageParams.name, pageParams.role)
      if (result.success) {
        navigate('home')
      } else {
        setError(result.error || 'رمز التحقق غير صحيح')
      }
    } catch (err) {
      setError('حدث خطأ أثناء التحقق')
    } finally {
      setLoading(false)
    }
  }

  const handleResend = async () => {
    if (resendCooldown > 0) return

    try {
      const res = await fetch('/api/auth/send-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phone, purpose: pageParams.name ? 'register' : 'login' })
      })

      if (res.ok) {
        setResendCooldown(60)
        setCode(['', '', '', '', '', ''])
        inputRefs.current[0]?.focus()
      }
    } catch (err) {
      console.error('Failed to resend OTP:', err)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-amber-50 to-white flex items-center justify-center px-4">
      <Card className="w-full max-w-md border-0 shadow-xl">
        <CardHeader className="text-center pb-2">
          <div className="w-16 h-16 bg-gradient-to-br from-amber-400 to-orange-500 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <MessageCircle className="w-8 h-8 text-white" />
          </div>
          <CardTitle className="text-2xl">التحقق من الرقم</CardTitle>
          <p className="text-gray-500 mt-2">
            أدخل الرمز المرسل إلى
            <br />
            <span className="font-medium text-gray-700" dir="ltr">{phone}</span>
          </p>
        </CardHeader>
        <CardContent className="pt-4">
          {error && (
            <div className="p-3 bg-red-50 border border-red-200 rounded-lg text-red-600 text-sm text-center mb-4">
              {error}
            </div>
          )}

          {/* OTP Input */}
          <div className="flex justify-center gap-2 mb-6" dir="ltr">
            {code.map((digit, index) => (
              <input
                key={index}
                ref={el => { inputRefs.current[index] = el }}
                type="text"
                inputMode="numeric"
                maxLength={6}
                value={digit}
                onChange={(e) => handleCodeChange(index, e.target.value)}
                onKeyDown={(e) => handleKeyDown(index, e)}
                className="w-12 h-14 text-center text-2xl font-bold border-2 rounded-xl focus:border-amber-500 focus:outline-none transition-colors"
              />
            ))}
          </div>

          <Button 
            onClick={handleVerify}
            className="w-full h-12 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white rounded-xl text-lg font-semibold"
            disabled={loading || code.some(c => !c)}
          >
            {loading ? (
              <><Loader2 className="w-5 h-5 animate-spin ml-2" /> جاري التحقق...</>
            ) : (
              'تأكيد'
            )}
          </Button>

          <div className="mt-6 text-center">
            <p className="text-gray-500 mb-2">لم تستلم الرمز؟</p>
            <button 
              onClick={handleResend}
              disabled={resendCooldown > 0}
              className={`font-medium ${resendCooldown > 0 ? 'text-gray-400' : 'text-amber-600 hover:text-amber-700'}`}
            >
              {resendCooldown > 0 ? `إعادة الإرسال (${resendCooldown}s)` : 'إعادة الإرسال'}
            </button>
          </div>

          <div className="mt-6 pt-6 border-t">
            <Button 
              variant="outline"
              className="w-full"
              onClick={() => navigate('login')}
            >
              <ArrowLeft className="w-4 h-4 ml-2" />
              تغيير رقم الهاتف
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

// ==================== Payment View ====================

interface PaymentMethodInfo {
  id: string
  name: string
  nameAr: string
  icon: string
  color: string
  description: string
  descriptionAr: string
  processingTime: string
  processingTimeAr: string
  fees: number // percentage
}

const paymentMethods: PaymentMethodInfo[] = [
  {
    id: 'SYRIATEL_CASH',
    name: 'Syriatel Cash',
    nameAr: 'سيرياتيل كاش',
    icon: '📱',
    color: 'from-red-500 to-red-600',
    description: 'Pay via Syriatel mobile wallet',
    descriptionAr: 'الدفع عبر محفظة سيرياتيل',
    processingTime: 'Instant',
    processingTimeAr: 'فوري',
    fees: 0
  },
  {
    id: 'MTN_CASH',
    name: 'MTN Cash',
    nameAr: 'MTN كاش',
    icon: '📱',
    color: 'from-yellow-500 to-orange-500',
    description: 'Pay via MTN mobile wallet',
    descriptionAr: 'الدفع عبر محفظة MTN',
    processingTime: 'Instant',
    processingTimeAr: 'فوري',
    fees: 0
  },
  {
    id: 'BANK_TRANSFER',
    name: 'Bank Transfer',
    nameAr: 'تحويل بنكي',
    icon: '🏦',
    color: 'from-blue-500 to-blue-600',
    description: 'Direct bank transfer',
    descriptionAr: 'تحويل بنكي مباشر',
    processingTime: '1-2 business days',
    processingTimeAr: '1-2 أيام عمل',
    fees: 0
  },
  {
    id: 'CASH',
    name: 'Cash on Arrival',
    nameAr: 'نقدي عند الوصول',
    icon: '💵',
    color: 'from-green-500 to-emerald-600',
    description: 'Pay in cash when you arrive',
    descriptionAr: 'الدفع نقداً عند الوصول',
    processingTime: 'On arrival',
    processingTimeAr: 'عند الوصول',
    fees: 0
  }
]

function PaymentView() {
  const { navigate, pageParams } = useNavigation()
  const { user, isAuthenticated, isLoading: authLoading } = useAuth()
  const [selectedMethod, setSelectedMethod] = useState<string | null>(null)
  const [phoneNumber, setPhoneNumber] = useState('')
  const [accountNumber, setAccountNumber] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [step, setStep] = useState<'method' | 'details' | 'confirm' | 'success'>('method')

  // Booking details from params
  const bookingId = pageParams.bookingId || ''
  const amount = parseFloat(pageParams.amount || '0')
  const accommodationTitle = pageParams.accommodationTitle || 'إقامة'
  const isGuarantee = pageParams.isGuarantee === 'true'

  // Redirect if not authenticated
  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      navigate('login')
    }
  }, [authLoading, isAuthenticated, navigate])

  if (authLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-amber-500" />
      </div>
    )
  }

  if (!isAuthenticated) return null

  const handleMethodSelect = (methodId: string) => {
    setSelectedMethod(methodId)
    setStep('details')
  }

  const handleSubmitPayment = async () => {
    if (!selectedMethod || !bookingId) return

    setError('')
    setLoading(true)

    try {
      const res = await fetch('/api/payments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          bookingId,
          userId: user?.id,
          amount,
          method: selectedMethod,
          isGuarantee,
          paymentDetails: {
            phoneNumber: selectedMethod.includes('CASH') ? phoneNumber : undefined,
            accountNumber: selectedMethod === 'BANK_TRANSFER' ? accountNumber : undefined
          }
        })
      })

      const data = await res.json()

      if (res.ok) {
        setStep('success')
      } else {
        setError(data.error || 'حدث خطأ في الدفع')
      }
    } catch (err) {
      setError('حدث خطأ في الاتصال')
    } finally {
      setLoading(false)
    }
  }

  const selectedMethodInfo = paymentMethods.find(m => m.id === selectedMethod)

  const renderStep = () => {
    switch (step) {
      case 'method':
        return (
          <div className="space-y-4">
            <div className="text-center mb-6">
              <h2 className="text-2xl font-bold text-gray-900 mb-2">اختر طريقة الدفع</h2>
              <p className="text-gray-500">اختر الطريقة المناسبة لك</p>
            </div>

            <div className="grid gap-3">
              {paymentMethods.map((method) => (
                <button
                  key={method.id}
                  onClick={() => handleMethodSelect(method.id)}
                  className="w-full p-4 border-2 border-gray-200 rounded-xl hover:border-amber-400 transition-all text-right flex items-center gap-4 group"
                >
                  <div className={`w-14 h-14 bg-gradient-to-br ${method.color} rounded-xl flex items-center justify-center text-2xl shadow-lg group-hover:scale-105 transition-transform`}>
                    {method.icon}
                  </div>
                  <div className="flex-1">
                    <h3 className="font-bold text-gray-900 text-lg">{method.nameAr}</h3>
                    <p className="text-sm text-gray-500">{method.descriptionAr}</p>
                    <div className="flex items-center gap-2 mt-1">
                      <Clock className="w-3 h-3 text-gray-400" />
                      <span className="text-xs text-gray-400">{method.processingTimeAr}</span>
                      {method.fees > 0 && (
                        <span className="text-xs text-amber-600">+{method.fees}% رسوم</span>
                      )}
                    </div>
                  </div>
                  <ChevronLeft className="w-5 h-5 text-gray-400 group-hover:text-amber-500 transition-colors" />
                </button>
              ))}
            </div>
          </div>
        )

      case 'details':
        return (
          <div className="space-y-6">
            <button
              onClick={() => setStep('method')}
              className="flex items-center gap-2 text-gray-600 hover:text-gray-900"
            >
              <ArrowLeft className="w-4 h-4" />
              العودة لاختيار الطريقة
            </button>

            <div className="text-center">
              <div className={`w-20 h-20 bg-gradient-to-br ${selectedMethodInfo?.color} rounded-2xl flex items-center justify-center text-4xl mx-auto mb-4 shadow-xl`}>
                {selectedMethodInfo?.icon}
              </div>
              <h2 className="text-2xl font-bold text-gray-900 mb-2">{selectedMethodInfo?.nameAr}</h2>
              <p className="text-gray-500">{selectedMethodInfo?.descriptionAr}</p>
            </div>

            {selectedMethod?.includes('CASH') && selectedMethod !== 'CASH' && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  رقم المحفظة
                </label>
                <Input
                  type="tel"
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(e.target.value)}
                  placeholder="09XXXXXXXX"
                  className="text-left"
                  dir="ltr"
                />
              </div>
            )}

            {selectedMethod === 'BANK_TRANSFER' && (
              <div className="space-y-4">
                <div className="p-4 bg-blue-50 rounded-xl border border-blue-200">
                  <h4 className="font-bold text-blue-800 mb-2">معلومات الحساب البنكي</h4>
                  <div className="text-sm text-blue-700 space-y-1">
                    <p><strong>البنك:</strong> بنك سوريا الدولي الإسلامي</p>
                    <p><strong>رقم الحساب:</strong> XXXX-XXXX-XXXX-1234</p>
                    <p><strong>اسم المستفيد:</strong> منصة ضيف</p>
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    رقم الإيصال / المرجع
                  </label>
                  <Input
                    value={accountNumber}
                    onChange={(e) => setAccountNumber(e.target.value)}
                    placeholder="أدخل رقم الإيصال بعد التحويل"
                  />
                </div>
              </div>
            )}

            {selectedMethod === 'CASH' && (
              <div className="p-4 bg-green-50 rounded-xl border border-green-200">
                <h4 className="font-bold text-green-800 mb-2">الدفع عند الوصول</h4>
                <p className="text-sm text-green-700">
                  سيتم استلام المبلغ نقداً عند وصولك لمكان الإقامة. يرجى تجهيز المبلغ مقدماً.
                </p>
              </div>
            )}

            <Button
              onClick={() => setStep('confirm')}
              className="w-full h-12 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white rounded-xl text-lg font-semibold"
              disabled={selectedMethod === 'BANK_TRANSFER' && !accountNumber}
            >
              متابعة
            </Button>
          </div>
        )

      case 'confirm':
        return (
          <div className="space-y-6">
            <button
              onClick={() => setStep('details')}
              className="flex items-center gap-2 text-gray-600 hover:text-gray-900"
            >
              <ArrowLeft className="w-4 h-4" />
              العودة
            </button>

            <div className="text-center">
              <h2 className="text-2xl font-bold text-gray-900 mb-2">تأكيد الدفع</h2>
              <p className="text-gray-500">راجع تفاصيل الدفع قبل التأكيد</p>
            </div>

            <Card className="border-0 shadow-md">
              <CardContent className="p-6 space-y-4">
                <div className="flex justify-between items-center pb-3 border-b">
                  <span className="text-gray-600">الإقامة</span>
                  <span className="font-medium">{accommodationTitle}</span>
                </div>
                <div className="flex justify-between items-center pb-3 border-b">
                  <span className="text-gray-600">طريقة الدفع</span>
                  <span className="font-medium">{selectedMethodInfo?.nameAr}</span>
                </div>
                {isGuarantee && (
                  <div className="flex justify-between items-center pb-3 border-b">
                    <span className="text-gray-600">نوع الدفع</span>
                    <Badge className="bg-amber-100 text-amber-700">ضمان حجز</Badge>
                  </div>
                )}
                <div className="flex justify-between items-center pt-2">
                  <span className="text-gray-900 font-bold">المبلغ الإجمالي</span>
                  <span className="text-2xl font-bold text-amber-600">{amount.toLocaleString()} ل.س</span>
                </div>
              </CardContent>
            </Card>

            {error && (
              <div className="p-3 bg-red-50 border border-red-200 rounded-lg text-red-600 text-sm text-center">
                {error}
              </div>
            )}

            <Button
              onClick={handleSubmitPayment}
              className="w-full h-14 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 text-white rounded-xl text-lg font-semibold"
              disabled={loading}
            >
              {loading ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin ml-2" />
                  جاري المعالجة...
                </>
              ) : (
                <>
                  <Shield className="w-5 h-5 ml-2" />
                  تأكيد الدفع
                </>
              )}
            </Button>

            <p className="text-xs text-gray-500 text-center">
              <Shield className="w-3 h-3 inline ml-1" />
              مدفوعاتك محمية بنظام ضمان ضيف
            </p>
          </div>
        )

      case 'success':
        return (
          <div className="text-center py-8">
            <div className="w-24 h-24 bg-gradient-to-br from-emerald-400 to-teal-500 rounded-full flex items-center justify-center mx-auto mb-6 shadow-xl">
              <CheckCircle2 className="w-12 h-12 text-white" />
            </div>
            <h2 className="text-2xl font-bold text-gray-900 mb-2">تم الدفع بنجاح!</h2>
            <p className="text-gray-500 mb-6">
              {isGuarantee
                ? 'تم استلام مبلغ الضمان وسيتم إطلاقه للمضيف بعد انتهاء إقامتك'
                : 'تم تأكيد حجزك بنجاح'
              }
            </p>

            <Card className="border-0 shadow-md max-w-sm mx-auto mb-6">
              <CardContent className="p-4">
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">رقم العملية</span>
                  <span className="font-mono font-bold">{bookingId.slice(0, 8).toUpperCase()}</span>
                </div>
              </CardContent>
            </Card>

            <div className="flex flex-col sm:flex-row gap-3 justify-center">
              <Button
                variant="outline"
                onClick={() => navigate('my-bookings')}
              >
                <Calendar className="w-4 h-4 ml-2" />
                حجوزاتي
              </Button>
              <Button
                onClick={() => navigate('home')}
                className="bg-amber-500 hover:bg-amber-600 text-white"
              >
                العودة للرئيسية
              </Button>
            </div>
          </div>
        )
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-amber-50 to-white">
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-lg mx-auto">
          {/* Payment Summary Card */}
          <Card className="border-0 shadow-lg mb-6">
            <CardContent className="p-6">
              <div className="flex items-center gap-4 mb-4">
                <div className="w-16 h-16 bg-gradient-to-br from-amber-400 to-orange-500 rounded-xl flex items-center justify-center">
                  <Shield className="w-8 h-8 text-white" />
                </div>
                <div>
                  <h3 className="font-bold text-gray-900">{accommodationTitle}</h3>
                  <p className="text-sm text-gray-500">
                    {isGuarantee ? 'مبلغ الضمان' : 'قيمة الحجز'}
                  </p>
                </div>
              </div>
              <div className="flex items-center justify-between pt-4 border-t">
                <span className="text-gray-600">المبلغ المستحق</span>
                <span className="text-3xl font-bold text-amber-600">{amount.toLocaleString()} <span className="text-sm font-normal">ل.س</span></span>
              </div>
            </CardContent>
          </Card>

          {/* Payment Steps */}
          <Card className="border-0 shadow-lg">
            <CardContent className="p-6">
              {/* Progress Steps */}
              <div className="flex items-center justify-center gap-2 mb-8">
                {['method', 'details', 'confirm', 'success'].map((s, i) => (
                  <div
                    key={s}
                    className={`h-2 rounded-full transition-all ${
                      ['method', 'details', 'confirm', 'success'].indexOf(step) >= i
                        ? 'w-8 bg-amber-500'
                        : 'w-2 bg-gray-200'
                    }`}
                  />
                ))}
              </div>

              {renderStep()}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

// ==================== Payment History View ====================

function PaymentHistoryView() {
  const { navigate } = useNavigation()
  const { user, isAuthenticated, isLoading: authLoading } = useAuth()
  const [payments, setPayments] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [activeTab, setActiveTab] = useState<'all' | 'pending' | 'completed'>('all')

  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      navigate('login')
    }
  }, [authLoading, isAuthenticated, navigate])

  useEffect(() => {
    if (isAuthenticated && user) {
      fetchPayments()
    }
  }, [isAuthenticated, user, activeTab])

  const fetchPayments = async () => {
    setLoading(true)
    try {
      const res = await fetch(`/api/payments?userId=${user?.id}&status=${activeTab === 'all' ? '' : activeTab.toUpperCase()}`)
      const data = await res.json()
      setPayments(data.payments || [])
    } catch (err) {
      console.error('Error fetching payments:', err)
    } finally {
      setLoading(false)
    }
  }

  const getStatusBadge = (status: string) => {
    const styles: Record<string, string> = {
      PENDING: 'bg-amber-100 text-amber-700',
      PROCESSING: 'bg-blue-100 text-blue-700',
      COMPLETED: 'bg-emerald-100 text-emerald-700',
      FAILED: 'bg-red-100 text-red-700',
      CANCELLED: 'bg-gray-100 text-gray-700',
      REFUNDED: 'bg-purple-100 text-purple-700'
    }
    const labels: Record<string, string> = {
      PENDING: 'قيد الانتظار',
      PROCESSING: 'قيد المعالجة',
      COMPLETED: 'مكتمل',
      FAILED: 'فشل',
      CANCELLED: 'ملغي',
      REFUNDED: 'مسترد'
    }
    return (
      <Badge className={styles[status] || styles.PENDING}>
        {labels[status] || status}
      </Badge>
    )
  }

  const formatDate = (dateStr: string) => {
    return new Date(dateStr).toLocaleDateString('ar-SY', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    })
  }

  if (authLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-amber-500" />
      </div>
    )
  }

  if (!isAuthenticated) return null

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-emerald-600 to-teal-600 text-white py-12">
        <div className="container mx-auto px-4">
          <h1 className="text-3xl font-bold mb-2">سجل المدفوعات</h1>
          <p className="text-white/80">تتبع جميع معاملاتك المالية</p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        {/* Tabs */}
        <div className="flex gap-2 mb-6">
          {[
            { key: 'all', label: 'الكل' },
            { key: 'pending', label: 'قيد الانتظار' },
            { key: 'completed', label: 'مكتملة' }
          ].map((tab) => (
            <Button
              key={tab.key}
              variant={activeTab === tab.key ? 'default' : 'outline'}
              onClick={() => setActiveTab(tab.key as typeof activeTab)}
              className={activeTab === tab.key ? 'bg-emerald-500 hover:bg-emerald-600' : ''}
            >
              {tab.label}
            </Button>
          ))}
        </div>

        {/* Payments List */}
        {loading ? (
          <div className="flex justify-center py-12">
            <Loader2 className="w-8 h-8 animate-spin text-emerald-500" />
          </div>
        ) : payments.length === 0 ? (
          <EmptyState
            icon={CreditCard}
            title="لا توجد مدفوعات"
            description="لم تقم بأي مدفوعات بعد"
            action={() => navigate('accommodations')}
            actionLabel="تصفح الإقامات"
          />
        ) : (
          <div className="space-y-4">
            {payments.map((payment) => (
              <Card key={payment.id} className="border-0 shadow-sm hover:shadow-md transition-shadow">
                <CardContent className="p-4">
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex items-start gap-4">
                      <div className={`w-12 h-12 rounded-xl flex items-center justify-center text-xl ${
                        payment.method === 'CASH' ? 'bg-green-100' :
                        payment.method?.includes('CASH') ? 'bg-yellow-100' :
                        payment.method === 'BANK_TRANSFER' ? 'bg-blue-100' :
                        'bg-gray-100'
                      }`}>
                        {payment.method === 'CASH' ? '💵' :
                         payment.method?.includes('SYRIATEL') ? '📱' :
                         payment.method?.includes('MTN') ? '📱' :
                         payment.method === 'BANK_TRANSFER' ? '🏦' : '💳'}
                      </div>
                      <div>
                        <h3 className="font-semibold text-gray-900">
                          {payment.booking?.accommodation?.titleAr || 'حجز'}
                        </h3>
                        <p className="text-sm text-gray-500">{formatDate(payment.createdAt)}</p>
                        <p className="text-xs text-gray-400 mt-1">
                          العملية: {payment.id.slice(0, 8).toUpperCase()}
                        </p>
                      </div>
                    </div>
                    <div className="text-left">
                      <p className="font-bold text-lg text-gray-900">
                        {payment.amount?.toLocaleString()} ل.س
                      </p>
                      {getStatusBadge(payment.status)}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}

// ==================== Payouts View (Host) ====================

function PayoutsView() {
  const { navigate } = useNavigation()
  const { user, isAuthenticated, isLoading: authLoading } = useAuth()
  const [payouts, setPayouts] = useState<any[]>([])
  const [stats, setStats] = useState({
    totalAmount: 0,
    pendingAmount: 0,
    completedAmount: 0
  })
  const [loading, setLoading] = useState(true)
  const [showRequestModal, setShowRequestModal] = useState(false)
  const [requestAmount, setRequestAmount] = useState('')
  const [requestMethod, setRequestMethod] = useState('bank')
  const [requesting, setRequesting] = useState(false)

  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      navigate('login')
    }
  }, [authLoading, isAuthenticated, navigate])

  useEffect(() => {
    if (isAuthenticated && user) {
      fetchPayouts()
    }
  }, [isAuthenticated, user])

  const fetchPayouts = async () => {
    setLoading(true)
    try {
      const res = await fetch(`/api/payouts?hostId=${user?.id}`)
      const data = await res.json()
      setPayouts(data.payouts || [])
      setStats(data.stats || stats)
    } catch (err) {
      console.error('Error fetching payouts:', err)
    } finally {
      setLoading(false)
    }
  }

  const handleRequestPayout = async () => {
    if (!requestAmount || parseFloat(requestAmount) <= 0) return

    setRequesting(true)
    try {
      const res = await fetch('/api/payouts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          hostId: user?.id,
          amount: parseFloat(requestAmount),
          method: requestMethod
        })
      })

      const data = await res.json()

      if (res.ok) {
        setShowRequestModal(false)
        setRequestAmount('')
        fetchPayouts()
      } else {
        alert(data.error || 'حدث خطأ')
      }
    } catch (err) {
      console.error('Error requesting payout:', err)
    } finally {
      setRequesting(false)
    }
  }

  const getStatusBadge = (status: string) => {
    const styles: Record<string, string> = {
      pending: 'bg-amber-100 text-amber-700',
      processing: 'bg-blue-100 text-blue-700',
      completed: 'bg-emerald-100 text-emerald-700',
      failed: 'bg-red-100 text-red-700'
    }
    const labels: Record<string, string> = {
      pending: 'قيد الانتظار',
      processing: 'قيد المعالجة',
      completed: 'مكتمل',
      failed: 'فشل'
    }
    return (
      <Badge className={styles[status] || styles.pending}>
        {labels[status] || status}
      </Badge>
    )
  }

  const formatDate = (dateStr: string) => {
    return new Date(dateStr).toLocaleDateString('ar-SY', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    })
  }

  if (authLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-amber-500" />
      </div>
    )
  }

  if (!isAuthenticated) return null

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-violet-600 to-purple-600 text-white py-12">
        <div className="container mx-auto px-4">
          <h1 className="text-3xl font-bold mb-2">المدفوعات</h1>
          <p className="text-white/80">إدارة أرباحك وسحب الأموال</p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        {/* Stats Cards */}
        <div className="grid md:grid-cols-3 gap-4 mb-8">
          <Card className="border-0 shadow-md">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-violet-100 rounded-xl flex items-center justify-center">
                  <Wallet className="w-6 h-6 text-violet-600" />
                </div>
                <div>
                  <p className="text-sm text-gray-500">إجمالي الأرباح</p>
                  <p className="text-2xl font-bold text-gray-900">{stats.totalAmount.toLocaleString()} ل.س</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-md">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-amber-100 rounded-xl flex items-center justify-center">
                  <Clock className="w-6 h-6 text-amber-600" />
                </div>
                <div>
                  <p className="text-sm text-gray-500">قيد الانتظار</p>
                  <p className="text-2xl font-bold text-amber-600">{stats.pendingAmount.toLocaleString()} ل.س</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-md">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-emerald-100 rounded-xl flex items-center justify-center">
                  <CheckCircle2 className="w-6 h-6 text-emerald-600" />
                </div>
                <div>
                  <p className="text-sm text-gray-500">تم سحبها</p>
                  <p className="text-2xl font-bold text-emerald-600">{stats.completedAmount.toLocaleString()} ل.س</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Request Payout Button */}
        <div className="mb-6">
          <Button
            onClick={() => setShowRequestModal(true)}
            className="bg-gradient-to-r from-violet-500 to-purple-500 hover:from-violet-600 hover:to-purple-600 text-white"
          >
            <Wallet className="w-4 h-4 ml-2" />
            طلب سحب جديد
          </Button>
        </div>

        {/* Payouts List */}
        {loading ? (
          <div className="flex justify-center py-12">
            <Loader2 className="w-8 h-8 animate-spin text-violet-500" />
          </div>
        ) : payouts.length === 0 ? (
          <EmptyState
            icon={Wallet}
            title="لا توجد مدفوعات"
            description="لم تقم بأي طلبات سحب بعد"
          />
        ) : (
          <div className="space-y-4">
            {payouts.map((payout) => (
              <Card key={payout.id} className="border-0 shadow-sm">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-semibold text-gray-900">
                        طلب سحب #{payout.id.slice(0, 8).toUpperCase()}
                      </h3>
                      <p className="text-sm text-gray-500">{formatDate(payout.createdAt)}</p>
                      <p className="text-xs text-gray-400 mt-1">
                        الطريقة: {payout.method === 'bank' ? 'تحويل بنكي' : payout.method}
                      </p>
                    </div>
                    <div className="text-left">
                      <p className="font-bold text-lg">{payout.amount.toLocaleString()} ل.س</p>
                      {getStatusBadge(payout.status)}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* Request Payout Modal */}
        {showRequestModal && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
            <Card className="w-full max-w-md border-0 shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  طلب سحب جديد
                  <Button variant="ghost" size="icon" onClick={() => setShowRequestModal(false)}>
                    <X className="w-4 h-4" />
                  </Button>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    المبلغ المتاح: {(stats.totalAmount - stats.completedAmount - stats.pendingAmount).toLocaleString()} ل.س
                  </label>
                  <Input
                    type="number"
                    value={requestAmount}
                    onChange={(e) => setRequestAmount(e.target.value)}
                    placeholder="أدخل المبلغ"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    طريقة السحب
                  </label>
                  <select
                    value={requestMethod}
                    onChange={(e) => setRequestMethod(e.target.value)}
                    className="w-full p-3 border rounded-xl"
                  >
                    <option value="bank">تحويل بنكي</option>
                    <option value="syriatel">سيرياتيل كاش</option>
                    <option value="mtn">MTN كاش</option>
                  </select>
                </div>

                <Button
                  onClick={handleRequestPayout}
                  className="w-full bg-violet-500 hover:bg-violet-600 text-white"
                  disabled={requesting || !requestAmount}
                >
                  {requesting ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin ml-2" />
                      جاري الإرسال...
                    </>
                  ) : (
                    'تقديم الطلب'
                  )}
                </Button>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  )
}

// ==================== Admin Dashboard View ====================

interface AdminStats {
  users: { total: number; hosts: number; guests: number; recent: number }
  accommodations: { total: number; pending: number; active: number }
  bookings: { total: number; pending: number; confirmed: number; completed: number; recent: number }
  revenue: { total: number; pending: number }
  reviews: number
  conversations: number
  topCities: { id: string; name: string; count: number }[]
  accommodationTypes: { type: string; count: number }[]
}

function AdminDashboardView() {
  const { navigate } = useNavigation()
  const { user, isAuthenticated, isLoading: authLoading } = useAuth()
  const [stats, setStats] = useState<AdminStats | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (!authLoading && (!isAuthenticated || user?.role !== 'ADMIN')) {
      navigate('home')
    }
  }, [authLoading, isAuthenticated, user, navigate])

  useEffect(() => {
    if (isAuthenticated && user?.role === 'ADMIN') {
      fetchStats()
    }
  }, [isAuthenticated, user])

  const fetchStats = async () => {
    setLoading(true)
    try {
      const res = await fetch('/api/admin/stats')
      const data = await res.json()
      setStats(data)
    } catch (err) {
      console.error('Error fetching stats:', err)
    } finally {
      setLoading(false)
    }
  }

  if (authLoading || loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-amber-500" />
      </div>
    )
  }

  if (!isAuthenticated || user?.role !== 'ADMIN') return null

  const quickActions = [
    { icon: Users, label: 'إدارة المستخدمين', page: 'admin-users' as PageType, color: 'bg-blue-500' },
    { icon: Building2, label: 'إدارة الإقامات', page: 'admin-accommodations' as PageType, color: 'bg-emerald-500' },
    { icon: Calendar, label: 'إدارة الحجوزات', page: 'admin-bookings' as PageType, color: 'bg-violet-500' },
    { icon: Shield, label: 'التقارير', page: 'admin' as PageType, color: 'bg-amber-500' },
  ]

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-slate-800 to-slate-900 text-white py-8">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold mb-1">لوحة تحكم المشرف</h1>
              <p className="text-gray-300">مرحباً بك، {user?.nameAr || user?.name}</p>
            </div>
            <Badge className="bg-red-500 text-white px-4 py-2">
              مشرف
            </Badge>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        {/* Quick Actions */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          {quickActions.map((action, i) => (
            <button
              key={i}
              onClick={() => navigate(action.page)}
              className="bg-white rounded-xl p-6 shadow-sm hover:shadow-md transition-all text-center group"
            >
              <div className={`w-14 h-14 ${action.color} rounded-xl flex items-center justify-center mx-auto mb-3 group-hover:scale-110 transition-transform`}>
                <action.icon className="w-7 h-7 text-white" />
              </div>
              <span className="font-medium text-gray-900">{action.label}</span>
            </button>
          ))}
        </div>

        {/* Stats Grid */}
        {stats && (
          <>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
              <Card className="border-0 shadow-sm">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-500">المستخدمين</p>
                      <p className="text-3xl font-bold text-gray-900">{stats.users.total}</p>
                      <p className="text-xs text-emerald-600 mt-1">+{stats.users.recent} هذا الأسبوع</p>
                    </div>
                    <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
                      <Users className="w-6 h-6 text-blue-600" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-sm">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-500">الإقامات</p>
                      <p className="text-3xl font-bold text-gray-900">{stats.accommodations.total}</p>
                      <p className="text-xs text-amber-600 mt-1">{stats.accommodations.pending} بانتظار الموافقة</p>
                    </div>
                    <div className="w-12 h-12 bg-emerald-100 rounded-xl flex items-center justify-center">
                      <Building2 className="w-6 h-6 text-emerald-600" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-sm">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-500">الحجوزات</p>
                      <p className="text-3xl font-bold text-gray-900">{stats.bookings.total}</p>
                      <p className="text-xs text-violet-600 mt-1">+{stats.bookings.recent} هذا الأسبوع</p>
                    </div>
                    <div className="w-12 h-12 bg-violet-100 rounded-xl flex items-center justify-center">
                      <Calendar className="w-6 h-6 text-violet-600" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-sm">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-500">الإيرادات</p>
                      <p className="text-3xl font-bold text-gray-900">{stats.revenue.total?.toLocaleString()}</p>
                      <p className="text-xs text-gray-500 mt-1">ل.س</p>
                    </div>
                    <div className="w-12 h-12 bg-amber-100 rounded-xl flex items-center justify-center">
                      <Wallet className="w-6 h-6 text-amber-600" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Charts Row */}
            <div className="grid md:grid-cols-2 gap-6 mb-8">
              {/* Top Cities */}
              <Card className="border-0 shadow-sm">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">أكثر المدن طلباً</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {stats.topCities.map((city, i) => (
                      <div key={city.id} className="flex items-center gap-3">
                        <span className="w-6 h-6 bg-amber-100 rounded-full flex items-center justify-center text-sm font-bold text-amber-600">
                          {i + 1}
                        </span>
                        <div className="flex-1">
                          <div className="flex justify-between mb-1">
                            <span className="font-medium">{city.name}</span>
                            <span className="text-sm text-gray-500">{city.count} إقامة</span>
                          </div>
                          <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                            <div
                              className="h-full bg-amber-500 rounded-full"
                              style={{ width: `${(city.count / Math.max(...stats.topCities.map(c => c.count))) * 100}%` }}
                            />
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Accommodation Types */}
              <Card className="border-0 shadow-sm">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">أنواع الإقامات</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-4">
                    {stats.accommodationTypes.map((type) => {
                      const typeLabels: Record<string, string> = {
                        HOTEL: 'فندق',
                        APARTMENT: 'شقة',
                        VILLA: 'فيلا',
                        CHALET: 'شاليه',
                        CAMP: 'مخيم',
                        GUESTHOUSE: 'نزل',
                        HOSTEL: 'سكن شباب',
                        RESORT: 'منتجع'
                      }
                      return (
                        <div key={type.type} className="bg-gray-50 rounded-xl p-4 text-center">
                          <p className="text-2xl font-bold text-gray-900">{type.count}</p>
                          <p className="text-sm text-gray-500">{typeLabels[type.type] || type.type}</p>
                        </div>
                      )
                    })}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Additional Stats */}
            <div className="grid md:grid-cols-3 gap-4">
              <Card className="border-0 shadow-sm">
                <CardContent className="p-6 text-center">
                  <Star className="w-8 h-8 text-amber-500 mx-auto mb-2" />
                  <p className="text-3xl font-bold text-gray-900">{stats.reviews}</p>
                  <p className="text-sm text-gray-500">تقييم</p>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-sm">
                <CardContent className="p-6 text-center">
                  <MessageCircle className="w-8 h-8 text-blue-500 mx-auto mb-2" />
                  <p className="text-3xl font-bold text-gray-900">{stats.conversations}</p>
                  <p className="text-sm text-gray-500">محادثة</p>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-sm">
                <CardContent className="p-6 text-center">
                  <Users className="w-8 h-8 text-emerald-500 mx-auto mb-2" />
                  <p className="text-3xl font-bold text-gray-900">{stats.users.hosts}</p>
                  <p className="text-sm text-gray-500">مضيف</p>
                </CardContent>
              </Card>
            </div>
          </>
        )}
      </div>
    </div>
  )
}

// ==================== Admin Users View ====================

function AdminUsersView() {
  const { navigate } = useNavigation()
  const { user, isAuthenticated, isLoading: authLoading } = useAuth()
  const [users, setUsers] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [roleFilter, setRoleFilter] = useState('all')
  const [searchQuery, setSearchQuery] = useState('')
  const [selectedUser, setSelectedUser] = useState<any>(null)
  const [showUserModal, setShowUserModal] = useState(false)

  useEffect(() => {
    if (!authLoading && (!isAuthenticated || user?.role !== 'ADMIN')) {
      navigate('home')
    }
  }, [authLoading, isAuthenticated, user, navigate])

  useEffect(() => {
    if (isAuthenticated && user?.role === 'ADMIN') {
      fetchUsers()
    }
  }, [isAuthenticated, user, roleFilter])

  const fetchUsers = async () => {
    setLoading(true)
    try {
      const res = await fetch(`/api/admin/users?role=${roleFilter}&search=${searchQuery}`)
      const data = await res.json()
      setUsers(data.users || [])
    } catch (err) {
      console.error('Error fetching users:', err)
    } finally {
      setLoading(false)
    }
  }

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    fetchUsers()
  }

  const handleUserAction = async (userId: string, action: 'suspend' | 'activate' | 'make-host') => {
    try {
      const body: any = {}
      if (action === 'suspend') {
        body.status = 'SUSPENDED'
      } else if (action === 'activate') {
        body.status = 'ACTIVE'
      } else if (action === 'make-host') {
        body.role = 'HOST'
      }

      const res = await fetch(`/api/admin/users/${userId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
      })

      if (res.ok) {
        fetchUsers()
        setShowUserModal(false)
      }
    } catch (err) {
      console.error('Error updating user:', err)
    }
  }

  const getRoleBadge = (role: string) => {
    const styles: Record<string, string> = {
      GUEST: 'bg-blue-100 text-blue-700',
      HOST: 'bg-emerald-100 text-emerald-700',
      ADMIN: 'bg-red-100 text-red-700'
    }
    const labels: Record<string, string> = {
      GUEST: 'ضيف',
      HOST: 'مضيف',
      ADMIN: 'مشرف'
    }
    return <Badge className={styles[role] || styles.GUEST}>{labels[role] || role}</Badge>
  }

  const getStatusBadge = (status: string) => {
    const styles: Record<string, string> = {
      ACTIVE: 'bg-emerald-100 text-emerald-700',
      INACTIVE: 'bg-gray-100 text-gray-700',
      SUSPENDED: 'bg-red-100 text-red-700',
      PENDING_VERIFICATION: 'bg-amber-100 text-amber-700'
    }
    const labels: Record<string, string> = {
      ACTIVE: 'نشط',
      INACTIVE: 'غير نشط',
      SUSPENDED: 'موقوف',
      PENDING_VERIFICATION: 'بانتظار التحقق'
    }
    return <Badge className={styles[status] || styles.INACTIVE}>{labels[status] || status}</Badge>
  }

  if (authLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-amber-500" />
      </div>
    )
  }

  if (!isAuthenticated || user?.role !== 'ADMIN') return null

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-600 to-blue-700 text-white py-8">
        <div className="container mx-auto px-4">
          <div className="flex items-center gap-4">
            <Button variant="ghost" className="text-white hover:bg-white/10" onClick={() => navigate('admin')}>
              <ArrowLeft className="w-4 h-4 ml-2" />
              العودة
            </Button>
            <div>
              <h1 className="text-3xl font-bold">إدارة المستخدمين</h1>
              <p className="text-blue-200">إدارة جميع مستخدمي المنصة</p>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        {/* Filters */}
        <div className="flex flex-col md:flex-row gap-4 mb-6">
          <form onSubmit={handleSearch} className="flex-1">
            <div className="relative">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
              <Input
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="بحث عن مستخدم..."
                className="pr-10"
              />
            </div>
          </form>
          <div className="flex gap-2">
            {['all', 'GUEST', 'HOST', 'ADMIN'].map((role) => (
              <Button
                key={role}
                variant={roleFilter === role ? 'default' : 'outline'}
                onClick={() => setRoleFilter(role)}
                className={roleFilter === role ? 'bg-blue-500 hover:bg-blue-600' : ''}
              >
                {role === 'all' ? 'الكل' : role === 'GUEST' ? 'ضيوف' : role === 'HOST' ? 'مضيفين' : 'مشرفين'}
              </Button>
            ))}
          </div>
        </div>

        {/* Users Table */}
        {loading ? (
          <div className="flex justify-center py-12">
            <Loader2 className="w-8 h-8 animate-spin text-blue-500" />
          </div>
        ) : (
          <Card className="border-0 shadow-sm overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50 border-b">
                  <tr>
                    <th className="text-right p-4 font-medium text-gray-600">المستخدم</th>
                    <th className="text-right p-4 font-medium text-gray-600">الدور</th>
                    <th className="text-right p-4 font-medium text-gray-600">الحالة</th>
                    <th className="text-right p-4 font-medium text-gray-600">النشاط</th>
                    <th className="text-right p-4 font-medium text-gray-600">تاريخ التسجيل</th>
                    <th className="text-right p-4 font-medium text-gray-600">إجراءات</th>
                  </tr>
                </thead>
                <tbody className="divide-y">
                  {users.map((u) => (
                    <tr key={u.id} className="hover:bg-gray-50">
                      <td className="p-4">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-gradient-to-br from-amber-400 to-orange-500 rounded-full flex items-center justify-center text-white font-bold">
                            {u.nameAr?.charAt(0) || u.name?.charAt(0) || 'ض'}
                          </div>
                          <div>
                            <p className="font-medium">{u.nameAr || u.name || 'مستخدم'}</p>
                            <p className="text-sm text-gray-500" dir="ltr">{u.phone}</p>
                          </div>
                        </div>
                      </td>
                      <td className="p-4">{getRoleBadge(u.role)}</td>
                      <td className="p-4">{getStatusBadge(u.status)}</td>
                      <td className="p-4">
                        <div className="flex gap-2 text-sm text-gray-500">
                          <span>{u._count?.accommodations || 0} إقامة</span>
                          <span>•</span>
                          <span>{u._count?.bookingsAsGuest || 0} حجز</span>
                        </div>
                      </td>
                      <td className="p-4 text-sm text-gray-500">
                        {new Date(u.createdAt).toLocaleDateString('ar-SY')}
                      </td>
                      <td className="p-4">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => { setSelectedUser(u); setShowUserModal(true) }}
                        >
                          التفاصيل
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>
        )}

        {/* User Details Modal */}
        {showUserModal && selectedUser && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
            <Card className="w-full max-w-lg border-0 shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  تفاصيل المستخدم
                  <Button variant="ghost" size="icon" onClick={() => setShowUserModal(false)}>
                    <X className="w-4 h-4" />
                  </Button>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 bg-gradient-to-br from-amber-400 to-orange-500 rounded-full flex items-center justify-center text-white text-2xl font-bold">
                    {selectedUser.nameAr?.charAt(0) || selectedUser.name?.charAt(0) || 'ض'}
                  </div>
                  <div>
                    <h3 className="font-bold text-lg">{selectedUser.nameAr || selectedUser.name}</h3>
                    <p className="text-gray-500" dir="ltr">{selectedUser.phone}</p>
                    <div className="flex gap-2 mt-1">
                      {getRoleBadge(selectedUser.role)}
                      {getStatusBadge(selectedUser.status)}
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4 py-4 border-y">
                  <div>
                    <p className="text-sm text-gray-500">الإقامات</p>
                    <p className="font-bold">{selectedUser._count?.accommodations || 0}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">الحجوزات</p>
                    <p className="font-bold">{selectedUser._count?.bookingsAsGuest || 0}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">التقييمات</p>
                    <p className="font-bold">{selectedUser._count?.reviews || 0}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">تاريخ التسجيل</p>
                    <p className="font-bold">{new Date(selectedUser.createdAt).toLocaleDateString('ar-SY')}</p>
                  </div>
                </div>

                <div className="flex gap-2">
                  {selectedUser.status !== 'SUSPENDED' && (
                    <Button
                      variant="destructive"
                      className="flex-1"
                      onClick={() => handleUserAction(selectedUser.id, 'suspend')}
                    >
                      إيقاف
                    </Button>
                  )}
                  {selectedUser.status === 'SUSPENDED' && (
                    <Button
                      variant="outline"
                      className="flex-1 border-emerald-500 text-emerald-600 hover:bg-emerald-50"
                      onClick={() => handleUserAction(selectedUser.id, 'activate')}
                    >
                      تفعيل
                    </Button>
                  )}
                  {selectedUser.role === 'GUEST' && (
                    <Button
                      variant="outline"
                      className="flex-1"
                      onClick={() => handleUserAction(selectedUser.id, 'make-host')}
                    >
                      ترقية لمضيف
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  )
}

// ==================== Admin Accommodations View ====================

function AdminAccommodationsView() {
  const { navigate } = useNavigation()
  const { user, isAuthenticated, isLoading: authLoading } = useAuth()
  const [accommodations, setAccommodations] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [statusFilter, setStatusFilter] = useState('PENDING_APPROVAL')

  useEffect(() => {
    if (!authLoading && (!isAuthenticated || user?.role !== 'ADMIN')) {
      navigate('home')
    }
  }, [authLoading, isAuthenticated, user, navigate])

  useEffect(() => {
    if (isAuthenticated && user?.role === 'ADMIN') {
      fetchAccommodations()
    }
  }, [isAuthenticated, user, statusFilter])

  const fetchAccommodations = async () => {
    setLoading(true)
    try {
      const res = await fetch(`/api/admin/accommodations?status=${statusFilter}`)
      const data = await res.json()
      setAccommodations(data.accommodations || [])
    } catch (err) {
      console.error('Error fetching accommodations:', err)
    } finally {
      setLoading(false)
    }
  }

  const handleApprove = async (id: string) => {
    try {
      await fetch(`/api/admin/accommodations/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: 'ACTIVE' })
      })
      fetchAccommodations()
    } catch (err) {
      console.error('Error approving accommodation:', err)
    }
  }

  const handleReject = async (id: string, reason: string) => {
    try {
      await fetch(`/api/admin/accommodations/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: 'SUSPENDED', rejectionReason: reason })
      })
      fetchAccommodations()
    } catch (err) {
      console.error('Error rejecting accommodation:', err)
    }
  }

  const getStatusBadge = (status: string) => {
    const styles: Record<string, string> = {
      DRAFT: 'bg-gray-100 text-gray-700',
      PENDING_APPROVAL: 'bg-amber-100 text-amber-700',
      ACTIVE: 'bg-emerald-100 text-emerald-700',
      INACTIVE: 'bg-blue-100 text-blue-700',
      SUSPENDED: 'bg-red-100 text-red-700'
    }
    const labels: Record<string, string> = {
      DRAFT: 'مسودة',
      PENDING_APPROVAL: 'بانتظار الموافقة',
      ACTIVE: 'نشط',
      INACTIVE: 'غير نشط',
      SUSPENDED: 'موقوف'
    }
    return <Badge className={styles[status] || styles.DRAFT}>{labels[status] || status}</Badge>
  }

  if (authLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-amber-500" />
      </div>
    )
  }

  if (!isAuthenticated || user?.role !== 'ADMIN') return null

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-emerald-600 to-emerald-700 text-white py-8">
        <div className="container mx-auto px-4">
          <div className="flex items-center gap-4">
            <Button variant="ghost" className="text-white hover:bg-white/10" onClick={() => navigate('admin')}>
              <ArrowLeft className="w-4 h-4 ml-2" />
              العودة
            </Button>
            <div>
              <h1 className="text-3xl font-bold">إدارة الإقامات</h1>
              <p className="text-emerald-200">المراجعة والموافقة على الإقامات</p>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        {/* Filters */}
        <div className="flex gap-2 mb-6 overflow-x-auto pb-2">
          {[
            { value: 'PENDING_APPROVAL', label: 'بانتظار الموافقة' },
            { value: 'ACTIVE', label: 'نشط' },
            { value: 'SUSPENDED', label: 'موقوف' },
            { value: 'all', label: 'الكل' }
          ].map((filter) => (
            <Button
              key={filter.value}
              variant={statusFilter === filter.value ? 'default' : 'outline'}
              onClick={() => setStatusFilter(filter.value)}
              className={statusFilter === filter.value ? 'bg-emerald-500 hover:bg-emerald-600' : ''}
            >
              {filter.label}
            </Button>
          ))}
        </div>

        {/* Accommodations List */}
        {loading ? (
          <div className="flex justify-center py-12">
            <Loader2 className="w-8 h-8 animate-spin text-emerald-500" />
          </div>
        ) : accommodations.length === 0 ? (
          <EmptyState
            icon={Building2}
            title="لا توجد إقامات"
            description="لا توجد إقامات بهذه الحالة"
          />
        ) : (
          <div className="space-y-4">
            {accommodations.map((acc) => (
              <Card key={acc.id} className="border-0 shadow-sm overflow-hidden">
                <CardContent className="p-4">
                  <div className="flex gap-4">
                    {/* Image */}
                    <div className="w-32 h-24 bg-gray-100 rounded-lg overflow-hidden shrink-0">
                      {acc.coverImage ? (
                        <img src={acc.coverImage} alt="" className="w-full h-full object-cover" />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center text-gray-400">
                          <Building2 className="w-8 h-8" />
                        </div>
                      )}
                    </div>

                    {/* Details */}
                    <div className="flex-1">
                      <div className="flex items-start justify-between">
                        <div>
                          <h3 className="font-bold text-gray-900">{acc.titleAr}</h3>
                          <p className="text-sm text-gray-500 flex items-center gap-1 mt-1">
                            <MapPin className="w-3 h-3" />
                            {acc.city?.nameAr || 'غير محدد'}
                          </p>
                        </div>
                        {getStatusBadge(acc.status)}
                      </div>

                      <div className="flex items-center gap-4 mt-3 text-sm text-gray-500">
                        <span className="flex items-center gap-1">
                          <User className="w-3 h-3" />
                          {acc.host?.nameAr || acc.host?.name || 'مضيف'}
                        </span>
                        <span className="flex items-center gap-1">
                          <Star className="w-3 h-3 text-amber-500" />
                          {acc.rating?.toFixed(1) || '0.0'}
                        </span>
                        <span>{acc._count?.bookings || 0} حجز</span>
                        <span>{acc._count?.reviews || 0} تقييم</span>
                      </div>

                      <div className="flex items-center gap-2 mt-3">
                        <span className="font-bold text-amber-600">{acc.basePrice?.toLocaleString()} ل.س/ليلة</span>
                      </div>
                    </div>

                    {/* Actions */}
                    {acc.status === 'PENDING_APPROVAL' && (
                      <div className="flex flex-col gap-2">
                        <Button
                          className="bg-emerald-500 hover:bg-emerald-600 text-white"
                          onClick={() => handleApprove(acc.id)}
                        >
                          <CheckCircle2 className="w-4 h-4 ml-1" />
                          موافقة
                        </Button>
                        <Button
                          variant="destructive"
                          onClick={() => handleReject(acc.id, 'لا يستوفي الشروط')}
                        >
                          <X className="w-4 h-4 ml-1" />
                          رفض
                        </Button>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}

// ==================== Admin Bookings View ====================

function AdminBookingsView() {
  const { navigate } = useNavigation()
  const { user, isAuthenticated, isLoading: authLoading } = useAuth()
  const [bookings, setBookings] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [statusFilter, setStatusFilter] = useState('all')

  useEffect(() => {
    if (!authLoading && (!isAuthenticated || user?.role !== 'ADMIN')) {
      navigate('home')
    }
  }, [authLoading, isAuthenticated, user, navigate])

  useEffect(() => {
    if (isAuthenticated && user?.role === 'ADMIN') {
      fetchBookings()
    }
  }, [isAuthenticated, user, statusFilter])

  const fetchBookings = async () => {
    setLoading(true)
    try {
      const res = await fetch(`/api/bookings?status=${statusFilter === 'all' ? '' : statusFilter}&limit=50`)
      const data = await res.json()
      setBookings(data.bookings || [])
    } catch (err) {
      console.error('Error fetching bookings:', err)
    } finally {
      setLoading(false)
    }
  }

  const getStatusBadge = (status: string) => {
    const styles: Record<string, string> = {
      PENDING: 'bg-amber-100 text-amber-700',
      CONFIRMED: 'bg-emerald-100 text-emerald-700',
      CHECKED_IN: 'bg-blue-100 text-blue-700',
      CHECKED_OUT: 'bg-gray-100 text-gray-700',
      CANCELLED: 'bg-red-100 text-red-700'
    }
    const labels: Record<string, string> = {
      PENDING: 'قيد الانتظار',
      CONFIRMED: 'مؤكد',
      CHECKED_IN: 'واصل',
      CHECKED_OUT: 'غادر',
      CANCELLED: 'ملغي'
    }
    return <Badge className={styles[status] || styles.PENDING}>{labels[status] || status}</Badge>
  }

  const formatDate = (dateStr: string) => {
    return new Date(dateStr).toLocaleDateString('ar-SY', {
      month: 'short',
      day: 'numeric'
    })
  }

  if (authLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-amber-500" />
      </div>
    )
  }

  if (!isAuthenticated || user?.role !== 'ADMIN') return null

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-violet-600 to-violet-700 text-white py-8">
        <div className="container mx-auto px-4">
          <div className="flex items-center gap-4">
            <Button variant="ghost" className="text-white hover:bg-white/10" onClick={() => navigate('admin')}>
              <ArrowLeft className="w-4 h-4 ml-2" />
              العودة
            </Button>
            <div>
              <h1 className="text-3xl font-bold">إدارة الحجوزات</h1>
              <p className="text-violet-200">متابعة جميع الحجوزات</p>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        {/* Filters */}
        <div className="flex gap-2 mb-6 overflow-x-auto pb-2">
          {[
            { value: 'all', label: 'الكل' },
            { value: 'PENDING', label: 'قيد الانتظار' },
            { value: 'CONFIRMED', label: 'مؤكد' },
            { value: 'CHECKED_IN', label: 'واصل' },
            { value: 'CANCELLED', label: 'ملغي' }
          ].map((filter) => (
            <Button
              key={filter.value}
              variant={statusFilter === filter.value ? 'default' : 'outline'}
              onClick={() => setStatusFilter(filter.value)}
              className={statusFilter === filter.value ? 'bg-violet-500 hover:bg-violet-600' : ''}
            >
              {filter.label}
            </Button>
          ))}
        </div>

        {/* Bookings List */}
        {loading ? (
          <div className="flex justify-center py-12">
            <Loader2 className="w-8 h-8 animate-spin text-violet-500" />
          </div>
        ) : bookings.length === 0 ? (
          <EmptyState
            icon={Calendar}
            title="لا توجد حجوزات"
            description="لا توجد حجوزات بهذه الحالة"
          />
        ) : (
          <Card className="border-0 shadow-sm overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50 border-b">
                  <tr>
                    <th className="text-right p-4 font-medium text-gray-600">رقم الحجز</th>
                    <th className="text-right p-4 font-medium text-gray-600">الإقامة</th>
                    <th className="text-right p-4 font-medium text-gray-600">الضيف</th>
                    <th className="text-right p-4 font-medium text-gray-600">التواريخ</th>
                    <th className="text-right p-4 font-medium text-gray-600">المبلغ</th>
                    <th className="text-right p-4 font-medium text-gray-600">الحالة</th>
                  </tr>
                </thead>
                <tbody className="divide-y">
                  {bookings.map((booking) => (
                    <tr key={booking.id} className="hover:bg-gray-50">
                      <td className="p-4 font-mono text-sm">{booking.confirmationCode}</td>
                      <td className="p-4">
                        <p className="font-medium">{booking.accommodation?.titleAr || 'إقامة'}</p>
                      </td>
                      <td className="p-4">
                        <p>{booking.guestName || booking.guest?.nameAr || 'ضيف'}</p>
                        <p className="text-sm text-gray-500" dir="ltr">{booking.guestPhone}</p>
                      </td>
                      <td className="p-4 text-sm">
                        <p>{formatDate(booking.checkIn)} - {formatDate(booking.checkOut)}</p>
                        <p className="text-gray-500">{booking.nightsCount} ليالي</p>
                      </td>
                      <td className="p-4 font-medium">{booking.totalAmount?.toLocaleString()} ل.س</td>
                      <td className="p-4">{getStatusBadge(booking.status)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>
        )}
      </div>
    </div>
  )
}

// ==================== Profile View ====================

function ProfileView() {
  const { navigate } = useNavigation()
  const { user: authUser, isAuthenticated, isLoading: authLoading, logout, setUser } = useAuth()
  const [activeTab, setActiveTab] = useState<'info' | 'bookings' | 'reviews' | 'settings'>('info')
  const [editMode, setEditMode] = useState(false)
  const [saving, setSaving] = useState(false)

  // Redirect if not authenticated
  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      navigate('login')
    }
  }, [authLoading, isAuthenticated, navigate])

  // User data from auth
  const user = {
    name: authUser?.name || 'ضيف',
    nameAr: authUser?.nameAr || authUser?.name || 'ضيف',
    email: authUser?.email || '',
    phone: authUser?.phone || '',
    avatar: authUser?.avatar,
    role: authUser?.role?.toLowerCase() || 'guest',
    verified: authUser?.isVerified || false,
    city: authUser?.city || 'سوريا',
  }

  const [editForm, setEditForm] = useState(() => ({
    name: authUser?.name || '',
    email: authUser?.email || '',
    phone: authUser?.phone || '',
    city: authUser?.city || '',
  }))

  const handleSave = async () => {
    setSaving(true)
    // TODO: Call API to update user profile
    await new Promise(resolve => setTimeout(resolve, 1000))

    // Update auth context
    if (authUser) {
      setUser({
        ...authUser,
        name: editForm.name,
        nameAr: editForm.name,
        email: editForm.email,
        city: editForm.city,
      })
    }
    setSaving(false)
    setEditMode(false)
  }

  // Mock bookings data
  const recentBookings = [
    { id: '1', accommodation: 'شقة فندقية في المزة', date: '2024-12-20', status: 'confirmed' },
    { id: '2', accommodation: 'شاليه في اللاذقية', date: '2024-11-15', status: 'completed' },
    { id: '3', accommodation: 'غرفة في فندق الشام', date: '2024-10-05', status: 'completed' },
  ]

  // Mock reviews
  const reviews = [
    { id: '1', accommodation: 'شقة فندقية في المزة', rating: 5, comment: 'تجربة رائعة ومضيف متعاون', date: '2024-12-22' },
    { id: '2', accommodation: 'شاليه في اللاذقية', rating: 4, comment: 'مكان جميل وإطلالة رائعة', date: '2024-11-18' },
    { id: '3', accommodation: 'غرفة في فندق الشام', rating: 5, comment: 'نظافة ممتازة وخدمة رائعة', date: '2024-10-08' },
  ]

  // Show loading state
  if (authLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-8 h-8 animate-spin text-amber-500 mx-auto mb-4" />
          <p className="text-gray-500">جاري التحميل...</p>
        </div>
      </div>
    )
  }

  // Not authenticated
  if (!isAuthenticated) {
    return null
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Cover Section */}
      <div className="bg-gradient-to-r from-gray-800 to-gray-900 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center gap-6">
            {/* Avatar */}
            <div className="relative">
              {user.avatar ? (
                <img src={user.avatar} alt={user.name} className="w-28 h-28 rounded-full object-cover shadow-xl" />
              ) : (
                <div className="w-28 h-28 rounded-full bg-gradient-to-br from-amber-400 to-orange-500 flex items-center justify-center text-white text-4xl font-bold shadow-xl">
                  {user.nameAr?.charAt(0) || user.name?.charAt(0) || 'ض'}
                </div>
              )}
              {user.verified && (
                <div className="absolute -bottom-1 -right-1 w-8 h-8 bg-emerald-500 rounded-full flex items-center justify-center border-4 border-gray-900">
                  <CheckCircle2 className="w-4 h-4 text-white" />
                </div>
              )}
            </div>

            {/* Info */}
            <div className="text-center md:text-right flex-1">
              <h1 className="text-3xl font-bold mb-2">{user.nameAr || user.name}</h1>
              <div className="flex flex-wrap items-center justify-center md:justify-start gap-4 text-gray-300 mb-3">
                <div className="flex items-center gap-1">
                  <MapPin className="w-4 h-4" />
                  <span>{user.city}</span>
                </div>
                <div className="flex items-center gap-1">
                  <Phone className="w-4 h-4" />
                  <span dir="ltr">{user.phone}</span>
                </div>
              </div>
              <Badge className="bg-amber-500/20 text-amber-300 border-amber-500/30">
                {user.role === 'host' ? '🏠 مضيف' : '👤 ضيف'}
              </Badge>
            </div>

            {/* Actions */}
            <div className="flex gap-3">
              <Button
                variant="outline"
                className="border-white/30 text-white hover:bg-white/10"
                onClick={() => setEditMode(true)}
              >
                <Edit className="w-4 h-4 ml-2" />
                تعديل الملف
              </Button>
              <Button
                variant="ghost"
                className="text-red-300 hover:bg-red-500/20 hover:text-red-200"
                onClick={logout}
              >
                <LogOut className="w-4 h-4 ml-2" />
                خروج
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        {/* Tabs */}
        <div className="flex gap-2 mb-6 overflow-x-auto pb-2">
          {[
            { key: 'info', label: 'المعلومات الشخصية', icon: User },
            { key: 'bookings', label: 'حجوزاتي', icon: Calendar },
            { key: 'reviews', label: 'تقييماتي', icon: Star },
            { key: 'settings', label: 'الإعدادات', icon: Settings },
          ].map((tab) => (
            <Button
              key={tab.key}
              variant={activeTab === tab.key ? 'default' : 'outline'}
              onClick={() => setActiveTab(tab.key as typeof activeTab)}
              className={`whitespace-nowrap ${activeTab === tab.key ? 'bg-amber-500 hover:bg-amber-600' : ''}`}
            >
              <tab.icon className="w-4 h-4 ml-2" />
              {tab.label}
            </Button>
          ))}
        </div>

        {/* Content */}
        {activeTab === 'info' && (
          <Card className="border-0 shadow-sm">
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="text-lg">المعلومات الشخصية</CardTitle>
              {!editMode ? (
                <Button variant="outline" onClick={() => setEditMode(true)}>
                  <Edit className="w-4 h-4 ml-2" />
                  تعديل
                </Button>
              ) : (
                <div className="flex gap-2">
                  <Button variant="outline" onClick={() => setEditMode(false)}>
                    إلغاء
                  </Button>
                  <Button 
                    className="bg-amber-500 hover:bg-amber-600"
                    onClick={handleSave}
                    disabled={saving}
                  >
                    {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : 'حفظ'}
                  </Button>
                </div>
              )}
            </CardHeader>
            <CardContent>
              {editMode ? (
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">الاسم الكامل</label>
                    <Input
                      value={editForm.name}
                      onChange={(e) => setEditForm({ ...editForm, name: e.target.value })}
                      className="text-right"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">البريد الإلكتروني</label>
                    <Input
                      type="email"
                      value={editForm.email}
                      onChange={(e) => setEditForm({ ...editForm, email: e.target.value })}
                      dir="ltr"
                      className="text-left"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">رقم الهاتف</label>
                    <Input
                      type="tel"
                      value={editForm.phone}
                      onChange={(e) => setEditForm({ ...editForm, phone: e.target.value })}
                      dir="ltr"
                      className="text-left"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">المدينة</label>
                    <Input
                      value={editForm.city}
                      onChange={(e) => setEditForm({ ...editForm, city: e.target.value })}
                    />
                  </div>
                  <div className="md:col-span-2">
                    <label className="block text-sm font-medium text-gray-700 mb-2">نبذة عني</label>
                    <textarea
                      value={editForm.bio}
                      onChange={(e) => setEditForm({ ...editForm, bio: e.target.value })}
                      rows={4}
                      className="w-full border rounded-lg p-3 text-right focus:outline-none focus:border-amber-400"
                    />
                  </div>
                </div>
              ) : (
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-xl">
                      <User className="w-5 h-5 text-amber-500" />
                      <div>
                        <p className="text-sm text-gray-500">الاسم الكامل</p>
                        <p className="font-medium">{user.name}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-xl">
                      <MessageCircle className="w-5 h-5 text-amber-500" />
                      <div>
                        <p className="text-sm text-gray-500">البريد الإلكتروني</p>
                        <p className="font-medium" dir="ltr">{user.email}</p>
                      </div>
                    </div>
                  </div>
                  <div className="space-y-4">
                    <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-xl">
                      <Phone className="w-5 h-5 text-amber-500" />
                      <div>
                        <p className="text-sm text-gray-500">رقم الهاتف</p>
                        <p className="font-medium" dir="ltr">{user.phone}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-xl">
                      <MapPin className="w-5 h-5 text-amber-500" />
                      <div>
                        <p className="text-sm text-gray-500">المدينة</p>
                        <p className="font-medium">{user.city}</p>
                      </div>
                    </div>
                  </div>
                  {user.bio && (
                    <div className="md:col-span-2 p-4 bg-gray-50 rounded-xl">
                      <p className="text-sm text-gray-500 mb-2">نبذة عني</p>
                      <p className="text-gray-700">{user.bio}</p>
                    </div>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        )}

        {activeTab === 'bookings' && (
          <div className="space-y-4">
            <Card className="border-0 shadow-sm">
              <CardHeader>
                <CardTitle className="text-lg">سجل الحجوزات</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {recentBookings.map((booking) => (
                    <div key={booking.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-xl">
                      <div>
                        <h4 className="font-medium">{booking.accommodation}</h4>
                        <p className="text-sm text-gray-500">
                          {new Date(booking.date).toLocaleDateString('ar-SY')}
                        </p>
                      </div>
                      <Badge className={
                        booking.status === 'confirmed' ? 'bg-green-100 text-green-700' :
                        booking.status === 'completed' ? 'bg-gray-100 text-gray-700' :
                        'bg-yellow-100 text-yellow-700'
                      }>
                        {booking.status === 'confirmed' ? 'مؤكد' : 
                         booking.status === 'completed' ? 'مكتمل' : 'قيد الانتظار'}
                      </Badge>
                    </div>
                  ))}
                </div>
                <Button 
                  variant="outline" 
                  className="w-full mt-4"
                  onClick={() => navigate('my-bookings')}
                >
                  عرض كل الحجوزات
                  <ArrowLeft className="w-4 h-4 mr-2" />
                </Button>
              </CardContent>
            </Card>
          </div>
        )}

        {activeTab === 'reviews' && (
          <div className="space-y-4">
            <Card className="border-0 shadow-sm">
              <CardHeader>
                <CardTitle className="text-lg">تقييماتي</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {reviews.map((review) => (
                    <div key={review.id} className="p-4 bg-gray-50 rounded-xl">
                      <div className="flex items-start justify-between mb-2">
                        <h4 className="font-medium">{review.accommodation}</h4>
                        <div className="flex items-center gap-1">
                          {[...Array(5)].map((_, i) => (
                            <Star
                              key={i}
                              className={`w-4 h-4 ${i < review.rating ? 'text-amber-400 fill-amber-400' : 'text-gray-300'}`}
                            />
                          ))}
                        </div>
                      </div>
                      <p className="text-gray-600 text-sm mb-2">{review.comment}</p>
                      <p className="text-xs text-gray-400">
                        {new Date(review.date).toLocaleDateString('ar-SY')}
                      </p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {activeTab === 'settings' && (
          <div className="space-y-4">
            {/* Notifications Settings */}
            <Card className="border-0 shadow-sm">
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Bell className="w-5 h-5 text-amber-500" />
                  إعدادات الإشعارات
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {[
                  { label: 'إشعارات الحجوزات', desc: 'استلام إشعارات عند تحديث حالة الحجز' },
                  { label: 'إشعارات الرسائل', desc: 'استلام إشعارات عند وصول رسائل جديدة' },
                  { label: 'إشعارات التقييمات', desc: 'استلام إشعارات عند تلقي تقييم جديد' },
                  { label: 'النشرة البريدية', desc: 'استلام عروض ونصائح سياحية' },
                ].map((item, idx) => (
                  <div key={idx} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div>
                      <p className="font-medium">{item.label}</p>
                      <p className="text-sm text-gray-500">{item.desc}</p>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input type="checkbox" defaultChecked={idx < 3} className="sr-only peer" />
                      <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:right-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-amber-500"></div>
                    </label>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Privacy Settings */}
            <Card className="border-0 shadow-sm">
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Shield className="w-5 h-5 text-amber-500" />
                  الخصوصية والأمان
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Button variant="outline" className="w-full justify-start" onClick={() => toast.info('هذه الميزة قيد التطوير', { description: 'ستتوفر قريباً' })}>
                  <Key className="w-4 h-4 ml-2" />
                  تغيير كلمة المرور
                </Button>
                <Button variant="outline" className="w-full justify-start" onClick={() => toast.info('هذه الميزة قيد التطوير', { description: 'ستتوفر قريباً' })}>
                  <Shield className="w-4 h-4 ml-2" />
                  التحقق بخطوتين
                </Button>
                <Button variant="outline" className="w-full justify-start text-red-600 hover:text-red-700 hover:bg-red-50" onClick={() => toast.error('هل أنت متأكد؟', { description: 'لا يمكن التراجع عن هذا الإجراء' })}>
                  <Trash2 className="w-4 h-4 ml-2" />
                  حذف الحساب
                </Button>
              </CardContent>
            </Card>

            {/* Become Host */}
            {user.role !== 'host' && (
              <Card className="border-0 shadow-sm bg-gradient-to-r from-amber-50 to-orange-50">
                <CardContent className="p-6">
                  <div className="flex items-center gap-4">
                    <div className="w-14 h-14 bg-gradient-to-br from-amber-400 to-orange-500 rounded-2xl flex items-center justify-center">
                      <Building2 className="w-7 h-7 text-white" />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-bold text-lg">كن مضيفاً!</h3>
                      <p className="text-gray-600">شارك مكانك مع الضيوف واكسب الدخل</p>
                    </div>
                    <Button 
                      className="bg-amber-500 hover:bg-amber-600"
                      onClick={() => navigate('host-dashboard')}
                    >
                      ابدأ الآن
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        )}
      </div>
    </div>
  )
}

// Key icon for settings
function Key({ className }: { className?: string }) {
  return (
    <svg className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11 17H9v2H7v2H4a1 1 0 01-1-1v-2.586a1 1 0 01.293-.707l5.964-5.964A6 6 0 1121 9z" />
    </svg>
  )
}

// ==================== Main Page Component ====================

function HomeView() {
  const [cities, setCities] = useState<City[]>([])
  const [citiesLoading, setCitiesLoading] = useState(true)
  const [accommodations, setAccommodations] = useState<Accommodation[]>([])
  const [accommodationsLoading, setAccommodationsLoading] = useState(true)
  const { navigate } = useNavigation()

  const [stats, setStats] = useState({
    totalAccommodations: 500,
    totalCities: 50
  })

  useEffect(() => {
    const fetchData = async () => {
      fetch('/api/cities')
        .then(async (response) => {
          if (!response.ok) throw new Error('فشل في جلب البيانات')
          const data = await response.json()
          setCities(data.cities || [])
          setStats(prev => ({ ...prev, totalCities: data.cities?.length || 0 }))
        })
        .catch((err) => console.error('Error fetching cities:', err))
        .finally(() => setCitiesLoading(false))

      fetch('/api/accommodations?limit=4')
        .then(async (response) => {
          if (!response.ok) throw new Error('فشل في جلب البيانات')
          const data = await response.json()
          setAccommodations(data.accommodations || [])
          setStats(prev => ({ ...prev, totalAccommodations: data.pagination?.total || data.accommodations?.length || 0 }))
        })
        .catch((err) => console.error('Error fetching accommodations:', err))
        .finally(() => setAccommodationsLoading(false))
    }

    fetchData()
  }, [])

  return (
    <main>
      <HeroSection 
        totalAccommodations={stats.totalAccommodations}
        totalCities={stats.totalCities}
        onSearch={() => navigate('accommodations')}
      />
      <ServicesSection onNavigate={navigate} />
      <PopularDestinations cities={cities} loading={citiesLoading} error={null} onNavigate={navigate} />
      <FeaturedAccommodations accommodations={accommodations} loading={accommodationsLoading} error={null} onNavigate={navigate} />
      <HowItWorks />
      <TrustSection />
      <CTASection onNavigate={navigate} />
      <HostCTA onNavigate={navigate} />
    </main>
  )
}

// ==================== App Component ====================

export default function Home() {
  const [currentPage, setCurrentPage] = useState<PageType>('home')
  const [pageParams, setPageParams] = useState<Record<string, string>>({})

  // Auth state
  const [user, setUser] = useState<AuthUser | null>(null)
  const [token, setToken] = useState<string | null>(null)
  const [authLoading, setAuthLoading] = useState(true)

  // Load user session on mount
  useEffect(() => {
    const loadSession = async () => {
      const storedToken = getToken()
      const storedUser = getUserFromStorage()

      if (storedToken && storedUser) {
        setToken(storedToken)
        setUser(storedUser)

        // Verify session is still valid
        try {
          const res = await fetch('/api/auth/me', {
            headers: { 'Authorization': `Bearer ${storedToken}` }
          })
          if (res.ok) {
            const data = await res.json()
            setUser(data.user)
            saveUserToStorage(data.user)
          } else {
            // Session expired
            removeToken()
            setUser(null)
            setToken(null)
          }
        } catch {
          // Keep using stored user on network error
        }
      }
      setAuthLoading(false)
    }

    loadSession()
  }, [])

  const navigate = (page: PageType, params?: Record<string, string>) => {
    setCurrentPage(page)
    setPageParams(params || {})
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  const contextValue: NavigationContextType = {
    currentPage,
    setCurrentPage,
    pageParams,
    setPageParams,
    navigate
  }

  // ==================== Transport View ====================
  function TransportView() {
    const { navigate, pageParams } = useNavigation()
    const [transports, setTransports] = useState<Array<{
      id: string
      titleAr: string
      type: string
      brand: string | null
      model: string | null
      year: number | null
      seats: number
      hasDriver: boolean
      basePrice: number
      coverImage: string | null
      images: string[]
      rating: number
      city: { nameAr: string } | null
    }>>([])
    const [loading, setLoading] = useState(true)
    const [activeType, setActiveType] = useState<string>('all')

    useEffect(() => {
      const fetchTransports = async () => {
        try {
          const params = new URLSearchParams()
          if (pageParams.cityId) params.set('cityId', pageParams.cityId)
          if (activeType !== 'all') params.set('type', activeType)
          
          const response = await fetch(`/api/transports?${params}`)
          const data = await response.json()
          setTransports(data.transports || [])
        } catch (error) {
          console.error('Error fetching transports:', error)
        } finally {
          setLoading(false)
        }
      }
      fetchTransports()
    }, [pageParams.cityId, activeType])

    const typeLabels: Record<string, string> = {
      CAR: 'سيارة',
      CAR_WITH_DRIVER: 'سيارة مع سائق',
      BUS: 'باص',
      MINIVAN: 'حافلة صغيرة',
      BOAT: 'قارب',
      HELICOPTER: 'هليكوبتر'
    }

    const typeIcons: Record<string, string> = {
      CAR: '🚗',
      CAR_WITH_DRIVER: '🚕',
      BUS: '🚌',
      MINIVAN: '🚐',
      BOAT: '🚤',
      HELICOPTER: '🚁'
    }

    return (
      <div className="min-h-screen bg-gray-50">
        <div className="container mx-auto px-4 py-8">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-gray-900 mb-2">النقل والمواصلات</h1>
            <p className="text-gray-600">سيارات مع أو بدون سائق، باصات، وخدمات نقل آمنة في سوريا</p>
          </div>

          {/* Filters */}
          <div className="flex flex-wrap gap-2 mb-6">
            <Button
              variant={activeType === 'all' ? 'default' : 'outline'}
              onClick={() => setActiveType('all')}
              className={activeType === 'all' ? 'bg-emerald-500 hover:bg-emerald-600' : ''}
            >
              الكل
            </Button>
            {Object.entries(typeLabels).map(([key, label]) => (
              <Button
                key={key}
                variant={activeType === key ? 'default' : 'outline'}
                onClick={() => setActiveType(key)}
                className={activeType === key ? 'bg-emerald-500 hover:bg-emerald-600' : ''}
              >
                {typeIcons[key]} {label}
              </Button>
            ))}
          </div>

          {/* Results */}
          {loading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[1, 2, 3, 4, 5, 6].map((i) => (
                <SkeletonCard key={i} className="h-64" />
              ))}
            </div>
          ) : transports.length === 0 ? (
            <Card className="text-center py-16">
              <CardContent>
                <Car className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-gray-700 mb-2">لا توجد مركبات</h3>
                <p className="text-gray-500">لم يتم العثور على مركبات مطابقة للبحث</p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {transports.map((transport) => (
                <Card 
                  key={transport.id} 
                  className="group overflow-hidden border-0 shadow-md hover:shadow-xl transition-all duration-300 cursor-pointer bg-white"
                  onClick={() => navigate('transport-detail', { id: transport.id })}
                >
                  <div className="relative h-48 bg-gray-100">
                    {transport.coverImage ? (
                      <img 
                        src={transport.coverImage} 
                        alt={transport.titleAr}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center">
                        <Car className="w-16 h-16 text-gray-300" />
                      </div>
                    )}
                    <Badge className="absolute top-3 right-3 bg-emerald-500">
                      {typeIcons[transport.type]} {typeLabels[transport.type]}
                    </Badge>
                    {transport.hasDriver && (
                      <Badge className="absolute top-3 left-3 bg-blue-500">
                        مع سائق
                      </Badge>
                    )}
                  </div>
                  <CardContent className="p-4">
                    <h3 className="font-bold text-lg text-gray-900 mb-1">{transport.titleAr}</h3>
                    {transport.brand && transport.model && (
                      <p className="text-sm text-gray-500 mb-2">
                        {transport.brand} {transport.model} {transport.year && `- ${transport.year}`}
                      </p>
                    )}
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-1 text-sm text-gray-500">
                        <Users className="w-4 h-4" />
                        <span>{transport.seats} مقعد</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Star className="w-4 h-4 text-amber-400 fill-amber-400" />
                        <span className="text-sm font-medium">{transport.rating.toFixed(1)}</span>
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <div>
                        <span className="text-xl font-bold text-emerald-600">
                          {transport.basePrice.toLocaleString()}
                        </span>
                        <span className="text-sm text-gray-500 mr-1">ل.س</span>
                      </div>
                      {transport.city && (
                        <div className="flex items-center gap-1 text-sm text-gray-500">
                          <MapPin className="w-4 h-4" />
                          <span>{transport.city.nameAr}</span>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      </div>
    )
  }

  // ==================== Transport Detail View ====================
  function TransportDetailView() {
    const { navigate, pageParams } = useNavigation()
    const [transport, setTransport] = useState<any>(null)
    const [loading, setLoading] = useState(true)

    useEffect(() => {
      const fetchTransport = async () => {
        if (!pageParams.id) return
        try {
          const response = await fetch(`/api/transports/${pageParams.id}`)
          const data = await response.json()
          setTransport(data.transport)
        } catch (error) {
          console.error('Error fetching transport:', error)
        } finally {
          setLoading(false)
        }
      }
      fetchTransport()
    }, [pageParams.id])

    if (loading) {
      return (
        <div className="min-h-screen bg-gray-50 flex items-center justify-center">
          <Loader2 className="w-8 h-8 animate-spin text-emerald-500" />
        </div>
      )
    }

    if (!transport) {
      return (
        <div className="min-h-screen bg-gray-50 flex items-center justify-center">
          <Card className="text-center p-8">
            <Car className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <h2 className="text-xl font-semibold">المركبة غير موجودة</h2>
            <Button onClick={() => navigate('transport')} className="mt-4">العودة للقائمة</Button>
          </Card>
        </div>
      )
    }

    return (
      <div className="min-h-screen bg-gray-50">
        <div className="container mx-auto px-4 py-8">
          <Button onClick={() => navigate('transport')} variant="ghost" className="mb-4">
            <ArrowLeft className="w-4 h-4 ml-2" />
            العودة
          </Button>
          
          {/* Transport details will be shown here */}
          <Card>
            <CardContent className="p-6">
              <h1 className="text-2xl font-bold mb-4">{transport.titleAr}</h1>
              <p className="text-gray-600">تفاصيل المركبة...</p>
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  // ==================== Tours View ====================
  function ToursView() {
    const { navigate, pageParams } = useNavigation()
    const [tours, setTours] = useState<Array<{
      id: string
      titleAr: string
      type: string
      duration: number
      maxGroupSize: number
      basePrice: number
      coverImage: string | null
      images: string[]
      rating: number
      city: { nameAr: string } | null
    }>>([])
    const [loading, setLoading] = useState(true)
    const [activeType, setActiveType] = useState<string>('all')

    useEffect(() => {
      const fetchTours = async () => {
        try {
          const params = new URLSearchParams()
          if (pageParams.cityId) params.set('cityId', pageParams.cityId)
          if (activeType !== 'all') params.set('type', activeType)
          
          const response = await fetch(`/api/tours?${params}`)
          const data = await response.json()
          setTours(data.tours || [])
        } catch (error) {
          console.error('Error fetching tours:', error)
        } finally {
          setLoading(false)
        }
      }
      fetchTours()
    }, [pageParams.cityId, activeType])

    const typeLabels: Record<string, string> = {
      CITY_TOUR: 'جولة مدينة',
      HISTORICAL: 'سياحة تاريخية',
      RELIGIOUS: 'سياحة دينية',
      ADVENTURE: 'سياحة مغامرة',
      MEDICAL: 'سياحة علاجية',
      WAR_TOURISM: 'سياحة الحرب',
      NATURE: 'سياحة طبيعية',
      FOOD: 'سياحة الطعام',
      SHOPPING: 'سياحة تسوق',
      CUSTOM: 'جولة مخصصة'
    }

    return (
      <div className="min-h-screen bg-gray-50">
        <div className="container mx-auto px-4 py-8">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-gray-900 mb-2">الجولات السياحية</h1>
            <p className="text-gray-600">اكتشف سوريا مع جولات سياحية متنوعة ومعالم تاريخية</p>
          </div>

          {/* Filters */}
          <div className="flex flex-wrap gap-2 mb-6">
            <Button
              variant={activeType === 'all' ? 'default' : 'outline'}
              onClick={() => setActiveType('all')}
              className={activeType === 'all' ? 'bg-sky-500 hover:bg-sky-600' : ''}
            >
              الكل
            </Button>
            {Object.entries(typeLabels).slice(0, 6).map(([key, label]) => (
              <Button
                key={key}
                variant={activeType === key ? 'default' : 'outline'}
                onClick={() => setActiveType(key)}
                className={activeType === key ? 'bg-sky-500 hover:bg-sky-600' : ''}
              >
                {label}
              </Button>
            ))}
          </div>

          {/* Results */}
          {loading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[1, 2, 3, 4, 5, 6].map((i) => (
                <SkeletonCard key={i} className="h-64" />
              ))}
            </div>
          ) : tours.length === 0 ? (
            <Card className="text-center py-16">
              <CardContent>
                <Compass className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-gray-700 mb-2">لا توجد جولات</h3>
                <p className="text-gray-500">لم يتم العثور على جولات مطابقة</p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {tours.map((tour) => (
                <Card 
                  key={tour.id} 
                  className="group overflow-hidden border-0 shadow-md hover:shadow-xl transition-all duration-300 cursor-pointer bg-white"
                  onClick={() => navigate('tour-detail', { id: tour.id })}
                >
                  <div className="relative h-48 bg-gray-100">
                    {tour.coverImage ? (
                      <img 
                        src={tour.coverImage} 
                        alt={tour.titleAr}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-sky-100 to-blue-100">
                        <Compass className="w-16 h-16 text-sky-300" />
                      </div>
                    )}
                    <Badge className="absolute top-3 right-3 bg-sky-500">
                      {typeLabels[tour.type] || tour.type}
                    </Badge>
                  </div>
                  <CardContent className="p-4">
                    <h3 className="font-bold text-lg text-gray-900 mb-2">{tour.titleAr}</h3>
                    <div className="flex items-center gap-4 text-sm text-gray-500 mb-3">
                      <div className="flex items-center gap-1">
                        <Clock className="w-4 h-4" />
                        <span>{tour.duration} ساعات</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Users className="w-4 h-4" />
                        <span>حتى {tour.maxGroupSize} أشخاص</span>
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <div>
                        <span className="text-xl font-bold text-sky-600">
                          {tour.basePrice.toLocaleString()}
                        </span>
                        <span className="text-sm text-gray-500 mr-1">ل.س / شخص</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Star className="w-4 h-4 text-amber-400 fill-amber-400" />
                        <span className="text-sm font-medium">{tour.rating.toFixed(1)}</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      </div>
    )
  }

  // ==================== Tour Detail View ====================
  function TourDetailView() {
    const { navigate, pageParams } = useNavigation()
    const [tour, setTour] = useState<any>(null)
    const [loading, setLoading] = useState(true)

    useEffect(() => {
      const fetchTour = async () => {
        if (!pageParams.id) return
        try {
          const response = await fetch(`/api/tours/${pageParams.id}`)
          const data = await response.json()
          setTour(data.tour)
        } catch (error) {
          console.error('Error fetching tour:', error)
        } finally {
          setLoading(false)
        }
      }
      fetchTour()
    }, [pageParams.id])

    if (loading) {
      return (
        <div className="min-h-screen bg-gray-50 flex items-center justify-center">
          <Loader2 className="w-8 h-8 animate-spin text-sky-500" />
        </div>
      )
    }

    if (!tour) {
      return (
        <div className="min-h-screen bg-gray-50 flex items-center justify-center">
          <Card className="text-center p-8">
            <Compass className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <h2 className="text-xl font-semibold">الجولة غير موجودة</h2>
            <Button onClick={() => navigate('tours')} className="mt-4">العودة للقائمة</Button>
          </Card>
        </div>
      )
    }

    return (
      <div className="min-h-screen bg-gray-50">
        <div className="container mx-auto px-4 py-8">
          <Button onClick={() => navigate('tours')} variant="ghost" className="mb-4">
            <ArrowLeft className="w-4 h-4 ml-2" />
            العودة
          </Button>
          
          <Card>
            <CardContent className="p-6">
              <h1 className="text-2xl font-bold mb-4">{tour.titleAr}</h1>
              <p className="text-gray-600">تفاصيل الجولة...</p>
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  // ==================== Business View ====================
  function BusinessView() {
    const { navigate, pageParams } = useNavigation()
    const [listings, setListings] = useState<Array<{
      id: string
      titleAr: string
      type: string
      sector: string | null
      price: number | null
      investmentMin: number | null
      investmentMax: number | null
      expectedReturn: number | null
      coverImage: string | null
      images: string[]
      city: { nameAr: string } | null
    }>>([])
    const [loading, setLoading] = useState(true)
    const [activeType, setActiveType] = useState<string>('all')

    useEffect(() => {
      const fetchListings = async () => {
        try {
          const params = new URLSearchParams()
          if (pageParams.cityId) params.set('cityId', pageParams.cityId)
          if (activeType !== 'all') params.set('type', activeType)
          
          const response = await fetch(`/api/business?${params}`)
          const data = await response.json()
          setListings(data.listings || [])
        } catch (error) {
          console.error('Error fetching business listings:', error)
        } finally {
          setLoading(false)
        }
      }
      fetchListings()
    }, [pageParams.cityId, activeType])

    const typeLabels: Record<string, string> = {
      INVESTMENT_OPPORTUNITY: 'فرصة استثمارية',
      COMMERCIAL_PROPERTY: 'عقار تجاري',
      BUSINESS_SERVICE: 'خدمة أعمال',
      PARTNERSHIP: 'شراكة تجارية',
      FRANCHISE: 'امتياز تجاري'
    }

    return (
      <div className="min-h-screen bg-gray-50">
        <div className="container mx-auto px-4 py-8">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-gray-900 mb-2">الأعمال والاستثمار</h1>
            <p className="text-gray-600">فرص استثمارية، خدمات للأعمال، وشراكات تجارية في سوريا</p>
          </div>

          {/* Filters */}
          <div className="flex flex-wrap gap-2 mb-6">
            <Button
              variant={activeType === 'all' ? 'default' : 'outline'}
              onClick={() => setActiveType('all')}
              className={activeType === 'all' ? 'bg-violet-500 hover:bg-violet-600' : ''}
            >
              الكل
            </Button>
            {Object.entries(typeLabels).map(([key, label]) => (
              <Button
                key={key}
                variant={activeType === key ? 'default' : 'outline'}
                onClick={() => setActiveType(key)}
                className={activeType === key ? 'bg-violet-500 hover:bg-violet-600' : ''}
              >
                {label}
              </Button>
            ))}
          </div>

          {/* Results */}
          {loading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[1, 2, 3, 4, 5, 6].map((i) => (
                <SkeletonCard key={i} className="h-64" />
              ))}
            </div>
          ) : listings.length === 0 ? (
            <Card className="text-center py-16">
              <CardContent>
                <Building2 className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-gray-700 mb-2">لا توجد فرص</h3>
                <p className="text-gray-500">لم يتم العثور على فرص أعمال مطابقة</p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {listings.map((listing) => (
                <Card 
                  key={listing.id} 
                  className="group overflow-hidden border-0 shadow-md hover:shadow-xl transition-all duration-300 cursor-pointer bg-white"
                  onClick={() => navigate('business-detail', { id: listing.id })}
                >
                  <div className="relative h-48 bg-gray-100">
                    {listing.coverImage ? (
                      <img 
                        src={listing.coverImage} 
                        alt={listing.titleAr}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-violet-100 to-purple-100">
                        <Building2 className="w-16 h-16 text-violet-300" />
                      </div>
                    )}
                    <Badge className="absolute top-3 right-3 bg-violet-500">
                      {typeLabels[listing.type] || listing.type}
                    </Badge>
                  </div>
                  <CardContent className="p-4">
                    <h3 className="font-bold text-lg text-gray-900 mb-1">{listing.titleAr}</h3>
                    {listing.sector && (
                      <p className="text-sm text-gray-500 mb-3">قطاع: {listing.sector}</p>
                    )}
                    
                    {listing.type === 'INVESTMENT_OPPORTUNITY' && listing.investmentMin && (
                      <div className="mb-3">
                        <p className="text-sm text-gray-500">الحد الأدنى للاستثمار</p>
                        <p className="font-bold text-violet-600">{listing.investmentMin.toLocaleString()} ل.س</p>
                        {listing.expectedReturn && (
                          <p className="text-sm text-green-600">عائد متوقع: {listing.expectedReturn}%</p>
                        )}
                      </div>
                    )}
                    
                    {listing.price && (
                      <div className="flex items-center justify-between">
                        <div>
                          <span className="text-xl font-bold text-violet-600">
                            {listing.price.toLocaleString()}
                          </span>
                          <span className="text-sm text-gray-500 mr-1">ل.س</span>
                        </div>
                        {listing.city && (
                          <div className="flex items-center gap-1 text-sm text-gray-500">
                            <MapPin className="w-4 h-4" />
                            <span>{listing.city.nameAr}</span>
                          </div>
                        )}
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      </div>
    )
  }

  // ==================== Business Detail View ====================
  function BusinessDetailView() {
    const { navigate, pageParams } = useNavigation()
    const [listing, setListing] = useState<any>(null)
    const [loading, setLoading] = useState(true)

    useEffect(() => {
      const fetchListing = async () => {
        if (!pageParams.id) return
        try {
          const response = await fetch(`/api/business/${pageParams.id}`)
          const data = await response.json()
          setListing(data.listing)
        } catch (error) {
          console.error('Error fetching business listing:', error)
        } finally {
          setLoading(false)
        }
      }
      fetchListing()
    }, [pageParams.id])

    if (loading) {
      return (
        <div className="min-h-screen bg-gray-50 flex items-center justify-center">
          <Loader2 className="w-8 h-8 animate-spin text-violet-500" />
        </div>
      )
    }

    if (!listing) {
      return (
        <div className="min-h-screen bg-gray-50 flex items-center justify-center">
          <Card className="text-center p-8">
            <Building2 className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <h2 className="text-xl font-semibold">الفرصة غير موجودة</h2>
            <Button onClick={() => navigate('business')} className="mt-4">العودة للقائمة</Button>
          </Card>
        </div>
      )
    }

    return (
      <div className="min-h-screen bg-gray-50">
        <div className="container mx-auto px-4 py-8">
          <Button onClick={() => navigate('business')} variant="ghost" className="mb-4">
            <ArrowLeft className="w-4 h-4 ml-2" />
            العودة
          </Button>
          
          <Card>
            <CardContent className="p-6">
              <h1 className="text-2xl font-bold mb-4">{listing.titleAr}</h1>
              <p className="text-gray-600">تفاصيل فرصة الأعمال...</p>
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  const renderPage = () => {
    switch (currentPage) {
      case 'community':
        return <CommunityView />
      case 'community-post':
        return <CommunityPostView />
      case 'accommodations':
        return <AccommodationsView />
      case 'accommodation-detail':
        return <AccommodationDetailView />
      case 'search':
        return <SearchView />
      case 'host-reviews':
        return <HostReviewsView />
      case 'how-it-works':
        return <HowItWorksView />
      case 'host-dashboard':
        return <HostDashboardView />
      case 'add-accommodation':
        return <AddAccommodationView />
      case 'my-bookings':
        return <MyBookingsView />
      case 'booking-detail':
        return <BookingDetailView />
      case 'host-bookings':
        return <HostBookingsView />
      case 'profile':
        return <ProfileView />
      case 'inbox':
        return <InboxView />
      case 'conversation':
        return <ConversationView />
      case 'notifications':
        return <NotificationsView />
      case 'login':
        return <LoginView />
      case 'register':
        return <RegisterView />
      case 'verify-otp':
        return <OTPVerifyView />
      case 'payment':
        return <PaymentView />
      case 'payment-history':
        return <PaymentHistoryView />
      case 'payouts':
        return <PayoutsView />
      case 'admin':
        return <AdminDashboardView />
      case 'admin-users':
        return <AdminUsersView />
      case 'admin-accommodations':
        return <AdminAccommodationsView />
      case 'admin-bookings':
        return <AdminBookingsView />
      case 'transport':
        return <TransportView />
      case 'transport-detail':
        return <TransportDetailView />
      case 'tours':
        return <ToursView />
      case 'tour-detail':
        return <TourDetailView />
      case 'business':
        return <BusinessView />
      case 'business-detail':
        return <BusinessDetailView />
      case 'home':
      default:
        return <HomeView />
    }
  }

  // Auth functions
  const login = async (phone: string) => {
    try {
      const res = await fetch('/api/auth/send-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phone, purpose: 'login' })
      })
      const data = await res.json()
      return { success: res.ok, error: data.error, isNewUser: data.isNewUser }
    } catch {
      return { success: false, error: 'حدث خطأ في الاتصال' }
    }
  }

  const verifyOTP = async (phone: string, code: string, name?: string, role?: string) => {
    try {
      const res = await fetch('/api/auth/verify-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phone, code, name, role })
      })
      const data = await res.json()

      if (res.ok && data.user && data.token) {
        setUser(data.user)
        setToken(data.token)
        saveToken(data.token)
        saveUserToStorage(data.user)
        return { success: true }
      }
      return { success: false, error: data.error || 'فشل التحقق' }
    } catch {
      return { success: false, error: 'حدث خطأ في الاتصال' }
    }
  }

  const register = async (phone: string, name: string, role?: string) => {
    try {
      const res = await fetch('/api/auth/send-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phone, purpose: 'register', name, role })
      })
      const data = await res.json()
      return { success: res.ok, error: data.error }
    } catch {
      return { success: false, error: 'حدث خطأ في الاتصال' }
    }
  }

  const logout = async () => {
    try {
      if (token) {
        await fetch('/api/auth/logout', {
          method: 'POST',
          headers: { 'Authorization': `Bearer ${token}` }
        })
      }
    } catch {}
    removeToken()
    setUser(null)
    setToken(null)
    navigate('home')
  }

  const refetchUser = async () => {
    if (!token) return
    try {
      const res = await fetch('/api/auth/me', {
        headers: { 'Authorization': `Bearer ${token}` }
      })
      if (res.ok) {
        const data = await res.json()
        setUser(data.user)
        saveUserToStorage(data.user)
      }
    } catch {}
  }

  // Auth context value
  const authValue: AuthContextType = {
    user,
    token,
    isLoading: authLoading,
    isAuthenticated: !!user,
    login,
    verifyOTP,
    register,
    logout,
    setUser,
    refetchUser
  }

  return (
    <AuthContext.Provider value={authValue}>
      <NavigationContext.Provider value={contextValue}>
        <div className="min-h-screen flex flex-col">
          {/* Hide header/footer on auth pages */}
          {!['login', 'register', 'verify-otp'].includes(currentPage) && <Header />}
          <div className={`flex-1 ${!['login', 'register', 'verify-otp'].includes(currentPage) ? 'pt-16' : ''}`}>
            {renderPage()}
          </div>
          {!['login', 'register', 'verify-otp'].includes(currentPage) && <Footer />}
          <TourismAgent />
        </div>
      </NavigationContext.Provider>
    </AuthContext.Provider>
  )
}
