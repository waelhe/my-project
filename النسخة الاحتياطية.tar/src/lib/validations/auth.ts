/**
 * Zod Validation Schemas for Authentication
 * منطقة: ضيف - منصة السياحة والضيافة السورية
 */

import { z } from 'zod';

// Syrian phone number regex
// Accepts: +9639XXXXXXXX, 09XXXXXXXX, 9XXXXXXXX
const syrianPhoneRegex = /^(\+963|0)?9\d{8}$/;

// OTP code regex (6 digits)
const otpCodeRegex = /^\d{6}$/;

/**
 * Send OTP validation schema
 * التحقق من صحة طلب إرسال رمز التحقق
 */
export const sendOTPSchema = z.object({
  phone: z
    .string('رقم الهاتف مطلوب')
    .trim()
    .transform(val => val.replace(/\s/g, '')) // Remove spaces
    .refine(
      val => syrianPhoneRegex.test(val),
      { message: 'رقم الهاتف غير صالح. يجب أن يكون رقم سوري صحيح' }
    ),
  purpose: z
    .enum(['login', 'verify', 'reset'], { message: 'الغرض غير صالح' })
    .optional()
    .default('login')
});

export type SendOTPInput = z.infer<typeof sendOTPSchema>;

/**
 * Verify OTP validation schema
 * التحقق من صحة طلب التحقق من الرمز
 */
export const verifyOTPSchema = z.object({
  phone: z
    .string('رقم الهاتف مطلوب')
    .trim()
    .transform(val => val.replace(/\s/g, ''))
    .refine(
      val => syrianPhoneRegex.test(val),
      { message: 'رقم الهاتف غير صالح. يجب أن يكون رقم سوري صحيح' }
    ),
  code: z
    .string('رمز التحقق مطلوب')
    .trim()
    .refine(
      val => otpCodeRegex.test(val),
      { message: 'رمز التحقق يجب أن يكون 6 أرقام' }
    ),
  name: z
    .string()
    .trim()
    .min(2, { message: 'الاسم يجب أن يكون حرفين على الأقل' })
    .max(100, { message: 'الاسم طويل جداً' })
    .optional(),
  role: z
    .enum(['GUEST', 'HOST'], { message: 'الدور غير صالح' })
    .optional()
    .default('GUEST'),
  // Remember me option - for persistent sessions
  rememberMe: z
    .boolean()
    .optional()
    .default(false)
});

export type VerifyOTPInput = z.infer<typeof verifyOTPSchema>;

/**
 * User profile update validation
 * التحقق من صحة تحديث الملف الشخصي
 */
export const updateProfileSchema = z.object({
  name: z
    .string()
    .trim()
    .min(2, { message: 'الاسم يجب أن يكون حرفين على الأقل' })
    .max(100, { message: 'الاسم طويل جداً' })
    .optional(),
  nameAr: z
    .string()
    .trim()
    .min(2, { message: 'الاسم بالعربية يجب أن يكون حرفين على الأقل' })
    .max(100, { message: 'الاسم طويل جداً' })
    .optional(),
  email: z
    .string()
    .trim()
    .email({ message: 'البريد الإلكتروني غير صالح' })
    .optional()
    .or(z.literal('')), // Allow empty string to clear email
  language: z
    .enum(['ar', 'en'], { message: 'اللغة غير صالحة' })
    .optional(),
  city: z
    .string()
    .trim()
    .max(100, { message: 'اسم المدينة طويل جداً' })
    .optional()
});

export type UpdateProfileInput = z.infer<typeof updateProfileSchema>;

/**
 * Normalize phone number to +963 format
 * يوحّد رقم الهاتف إلى صيغة +963
 */
export function normalizePhone(phone: string): string {
  const cleaned = phone.replace(/\s/g, '');
  if (cleaned.startsWith('+963')) return cleaned;
  if (cleaned.startsWith('0')) return `+963${cleaned.slice(1)}`;
  return `+963${cleaned}`;
}
