/**
 * Zod Validation Schemas - Index
 * منطقة: ضيف - منصة السياحة والضيافة السورية
 */

export * from './auth';
export * from './accommodation';

import { NextResponse } from 'next/server';
import { ZodError } from 'zod';

/**
 * Format Zod validation errors in Arabic
 * ينسّق أخطاء التحقق بالعربية
 */
export function formatZodErrors(error: ZodError): Record<string, string[]> {
  const errors: Record<string, string[]> = {};

  for (const issue of error.issues) {
    const path = issue.path.join('.') || 'general';
    if (!errors[path]) {
      errors[path] = [];
    }
    errors[path].push(issue.message);
  }

  return errors;
}

/**
 * Create error response from Zod error
 * ينشئ استجابة خطأ من خطأ Zod
 */
export function zodErrorResponse(error: ZodError): NextResponse {
  const errors = formatZodErrors(error);
  
  // Get first error message for main error
  const firstError = error.issues[0]?.message || 'بيانات غير صالحة';

  return NextResponse.json(
    {
      error: firstError,
      details: errors
    },
    { status: 400 }
  );
}

/**
 * Validation result type
 */
export type ValidationResult<T> = 
  | { success: true; data: T }
  | { success: false; response: NextResponse };

/**
 * Safe parse with Arabic error response
 * تحليل آمن مع استجابة خطأ عربية
 */
export function safeParse<T>(
  schema: { safeParse: (data: unknown) => { success: boolean; data?: T; error?: ZodError } },
  data: unknown
): ValidationResult<T> {
  const result = schema.safeParse(data);

  if (result.success) {
    return { success: true, data: result.data as T };
  }

  return { success: false, response: zodErrorResponse(result.error!) };
}
