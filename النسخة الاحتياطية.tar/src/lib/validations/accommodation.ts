/**
 * Zod Validation Schemas for Accommodations
 * منطقة: ضيف - منصة السياحة والضيافة السورية
 */

import { z } from 'zod';

// Valid accommodation types
const accommodationTypes = [
  'HOTEL',
  'APARTMENT',
  'VILLA',
  'CHALET',
  'CAMP',
  'GUESTHOUSE',
  'HOSTEL',
  'RESORT'
] as const;

// Valid amenities
const validAmenities = [
  'wifi', 'ac', 'heating', 'parking', 'pool', 'gym', 'kitchen',
  'washing_machine', 'dryer', 'tv', 'balcony', 'garden', 'bbq',
  'fireplace', 'elevator', 'security', 'doorman', 'caretaker',
  'iron', 'hair_dryer', 'desk', 'safe', 'minibar', 'jacuzzi',
  'sauna', 'sea_view', 'mountain_view', 'city_view', 'breakfast',
  'airport_shuttle', 'pet_friendly', 'smoking_area', 'prayer_room'
] as const;

// Time format (HH:MM)
const timeRegex = /^([01]\d|2[0-3]):([0-5]\d)$/;

/**
 * Create accommodation validation schema
 * التحقق من صحة إنشاء إقامة جديدة
 */
export const createAccommodationSchema = z.object({
  // Title (required, both languages)
  titleAr: z
    .string('العنوان بالعربية مطلوب')
    .trim()
    .min(5, { message: 'العنوان بالعربية يجب أن يكون 5 أحرف على الأقل' })
    .max(100, { message: 'العنوان بالعربية طويل جداً' }),
  
  titleEn: z
    .string()
    .trim()
    .min(5, { message: 'English title must be at least 5 characters' })
    .max(100, { message: 'English title is too long' })
    .optional()
    .or(z.literal('')),

  // Description
  descriptionAr: z
    .string()
    .trim()
    .min(20, { message: 'الوصف يجب أن يكون 20 حرفاً على الأقل' })
    .max(2000, { message: 'الوصف طويل جداً' })
    .optional()
    .or(z.literal('')),
  
  descriptionEn: z
    .string()
    .trim()
    .min(20, { message: 'Description must be at least 20 characters' })
    .max(2000, { message: 'Description is too long' })
    .optional()
    .or(z.literal('')),

  // Type (required)
  type: z
    .enum(accommodationTypes, { message: 'نوع الإقامة غير صالح' }),

  // Location
  addressAr: z
    .string()
    .trim()
    .min(5, { message: 'العنوان يجب أن يكون 5 أحرف على الأقل' })
    .max(200, { message: 'العنوان طويل جداً' })
    .optional()
    .or(z.literal('')),
  
  addressEn: z
    .string()
    .trim()
    .max(200, { message: 'Address is too long' })
    .optional()
    .or(z.literal('')),
  
  cityId: z
    .string('المدينة مطلوبة')
    .cuid({ message: 'معرف المدينة غير صالح' }),
  
  latitude: z
    .number()
    .min(-90, { message: 'خط العرض غير صالح' })
    .max(90, { message: 'خط العرض غير صالح' })
    .optional(),
  
  longitude: z
    .number()
    .min(-180, { message: 'خط الطول غير صالح' })
    .max(180, { message: 'خط الطول غير صالح' })
    .optional(),

  // Room details
  bedrooms: z
    .number()
    .int({ message: 'عدد غرف النوم يجب أن يكون رقماً صحيحاً' })
    .min(0, { message: 'عدد غرف النوم لا يمكن أن يكون سالباً' })
    .max(50, { message: 'عدد غرف النوم كبير جداً' })
    .optional()
    .default(1),
  
  bathrooms: z
    .number()
    .int({ message: 'عدد الحمامات يجب أن يكون رقماً صحيحاً' })
    .min(0, { message: 'عدد الحمامات لا يمكن أن يكون سالباً' })
    .max(50, { message: 'عدد الحمامات كبير جداً' })
    .optional()
    .default(1),
  
  maxGuests: z
    .number()
    .int({ message: 'عدد الضيوف يجب أن يكون رقماً صحيحاً' })
    .min(1, { message: 'يجب استيعاب ضيف واحد على الأقل' })
    .max(100, { message: 'عدد الضيوف كبير جداً' })
    .optional()
    .default(2),
  
  beds: z
    .number()
    .int({ message: 'عدد الأسرة يجب أن يكون رقماً صحيحاً' })
    .min(0, { message: 'عدد الأسرة لا يمكن أن يكون سالباً' })
    .max(100, { message: 'عدد الأسرة كبير جداً' })
    .optional()
    .default(1),
  
  size: z
    .number()
    .positive({ message: 'المساحة يجب أن تكون رقماً موجباً' })
    .max(10000, { message: 'المساحة كبيرة جداً' })
    .optional(),

  // Pricing (required)
  basePrice: z
    .number('السعر الأساسي مطلوب')
    .positive({ message: 'السعر الأساسي يجب أن يكون رقماً موجباً' })
    .max(100000000, { message: 'السعر كبير جداً' }),
  
  weekendPrice: z
    .number()
    .positive({ message: 'سعر نهاية الأسبوع يجب أن يكون رقماً موجباً' })
    .max(100000000, { message: 'السعر كبير جداً' })
    .optional(),
  
  cleaningFee: z
    .number()
    .min(0, { message: 'رسوم التنظيف لا يمكن أن تكون سالبة' })
    .max(10000000, { message: 'رسوم التنظيف كبيرة جداً' })
    .optional(),
  
  securityDeposit: z
    .number()
    .min(0, { message: 'التأمين لا يمكن أن يكون سالباً' })
    .max(100000000, { message: 'التأمين كبير جداً' })
    .optional(),

  // Amenities
  amenities: z
    .array(z.enum(validAmenities, { message: 'وسيلة راحة غير صالحة' }))
    .max(50, { message: 'عدد وسائل الراحة كبير جداً' })
    .optional()
    .default([]),

  // Check-in/out times
  checkInTime: z
    .string()
    .regex(timeRegex, { message: 'وقت تسجيل الوصول يجب أن يكون بالصيغة HH:MM' })
    .optional()
    .default('14:00'),
  
  checkOutTime: z
    .string()
    .regex(timeRegex, { message: 'وقت تسجيل المغادرة يجب أن يكون بالصيغة HH:MM' })
    .optional()
    .default('12:00'),

  // Stay duration
  minNights: z
    .number()
    .int()
    .min(1, { message: 'الحد الأدنى للإقامة ليلة واحدة' })
    .max(365, { message: 'الحد الأدنى للإقامة كبير جداً' })
    .optional()
    .default(1),
  
  maxNights: z
    .number()
    .int()
    .min(1, { message: 'الحد الأقصى للإقامة ليلة واحدة على الأقل' })
    .max(365, { message: 'الحد الأقصى للإقامة كبير جداً' })
    .optional(),

  // House rules
  houseRules: z
    .array(z.string().trim().max(200, { message: 'كل قاعدة يجب ألا تتجاوز 200 حرف' }))
    .max(20, { message: 'عدد القواعد كبير جداً' })
    .optional()
    .default([]),

  // Permissions
  smokingAllowed: z.boolean().optional().default(false),
  petsAllowed: z.boolean().optional().default(false),
  partiesAllowed: z.boolean().optional().default(false),

  // Media
  images: z
    .array(
      z.string().url({ message: 'رابط الصورة غير صالح' })
    )
    .max(20, { message: 'عدد الصور كبير جداً' })
    .optional()
    .default([]),
  
  coverImage: z
    .string()
    .url({ message: 'رابط صورة الغلاف غير صالح' })
    .optional()
    .or(z.literal(''))
});

export type CreateAccommodationInput = z.infer<typeof createAccommodationSchema>;

/**
 * Update accommodation validation schema
 * التحقق من صحة تحديث الإقامة
 */
export const updateAccommodationSchema = createAccommodationSchema.partial();

export type UpdateAccommodationInput = z.infer<typeof updateAccommodationSchema>;

/**
 * Accommodation search/filter validation
 * التحقق من صحة البحث والتصفية
 */
export const accommodationFilterSchema = z.object({
  cityId: z.string().cuid({ message: 'معرف المدينة غير صالح' }).optional(),
  type: z.enum(accommodationTypes, { message: 'نوع الإقامة غير صالح' }).optional(),
  minPrice: z
    .number()
    .positive({ message: 'الحد الأدنى للسعر يجب أن يكون موجباً' })
    .optional(),
  maxPrice: z
    .number()
    .positive({ message: 'الحد الأقصى للسعر يجب أن يكون موجباً' })
    .optional(),
  guests: z
    .number()
    .int()
    .positive({ message: 'عدد الضيوف يجب أن يكون رقماً موجباً' })
    .max(100, { message: 'عدد الضيوف كبير جداً' })
    .optional(),
  bedrooms: z
    .number()
    .int()
    .min(0, { message: 'عدد غرف النوم لا يمكن أن يكون سالباً' })
    .optional(),
  limit: z
    .number()
    .int()
    .min(1, { message: 'الحد الأدنى للنتائج 1' })
    .max(100, { message: 'الحد الأقصى للنتائج 100' })
    .optional()
    .default(12),
  offset: z
    .number()
    .int()
    .min(0, { message: 'الإزاحة لا يمكن أن تكون سالبة' })
    .optional()
    .default(0),
  amenities: z
    .array(z.enum(validAmenities))
    .optional()
});

export type AccommodationFilterInput = z.infer<typeof accommodationFilterSchema>;

/**
 * Sanitize string input to prevent XSS
 * ينظّح النص لمنع هجمات XSS
 */
export function sanitizeString(input: string): string {
  return input
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#x27;')
    .replace(/\//g, '&#x2F;');
}

/**
 * Validate and sanitize accommodation data
 * يتحقق وينظّح بيانات الإقامة
 */
export function sanitizeAccommodationData(data: CreateAccommodationInput): CreateAccommodationInput {
  return {
    ...data,
    titleAr: data.titleAr ? sanitizeString(data.titleAr) : data.titleAr,
    titleEn: data.titleEn ? sanitizeString(data.titleEn) : data.titleEn,
    descriptionAr: data.descriptionAr ? sanitizeString(data.descriptionAr) : data.descriptionAr,
    descriptionEn: data.descriptionEn ? sanitizeString(data.descriptionEn) : data.descriptionEn,
    addressAr: data.addressAr ? sanitizeString(data.addressAr) : data.addressAr,
    addressEn: data.addressEn ? sanitizeString(data.addressEn) : data.addressEn,
    houseRules: data.houseRules?.map(rule => sanitizeString(rule))
  };
}
