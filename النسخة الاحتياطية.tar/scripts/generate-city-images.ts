import ZAI from 'z-ai-web-dev-sdk';
import fs from 'fs';
import path from 'path';

const outputDir = '/home/z/my-project/public/images/cities';

const cities = [
  { name: 'damascus', prompt: 'Damascus old city with Umayyad Mosque and traditional markets, golden sunset, aerial view, Middle Eastern architecture, historic, beautiful, cinematic, high quality' },
  { name: 'aleppo', prompt: 'Aleppo city with citadel, ancient fortress on hill, Middle Eastern architecture, golden hour, historic, cinematic view, high quality' },
  { name: 'latakia', prompt: 'Latakia Mediterranean beach resort, crystal blue sea, palm trees, sandy beach, summer resort, scenic view, high quality' },
  { name: 'tartus', prompt: 'Tartus Mediterranean coast, Arwad island in distance, blue sea, marina, coastal city view, scenic, high quality' },
  { name: 'palmyra', prompt: 'Palmyra ancient ruins, Roman columns and temples in desert, golden sunset, archaeological site, historic, cinematic, high quality' },
  { name: 'maaloula', prompt: 'Maaloula cliff-side village, ancient monasteries carved in rock, mountain village, blue sky, historic, scenic, high quality' },
  { name: 'safita', prompt: 'Safita mountain town, medieval tower, green hills, scenic mountain view, historic, peaceful, high quality' },
  { name: 'homs', prompt: 'Krak des Chevaliers castle, medieval crusader fortress on hill, dramatic sky, historic monument, cinematic view, high quality' },
  { name: 'hama', prompt: 'Hama water wheels on Orontes river, ancient wooden norias, historic city, riverside, golden hour, scenic, high quality' }
];

async function generateImages() {
  if (!fs.existsSync(outputDir)) {
    fs.mkdirSync(outputDir, { recursive: true });
  }

  const zai = await ZAI.create();

  for (const city of cities) {
    const outputPath = path.join(outputDir, `${city.name}.png`);
    
    // Skip if already exists
    if (fs.existsSync(outputPath)) {
      console.log(`⏭️ Skipping ${city.name} - already exists`);
      continue;
    }

    try {
      console.log(`🎨 Generating image for ${city.name}...`);
      
      const response = await zai.images.generations.create({
        prompt: city.prompt,
        size: '1344x768'
      });

      const imageBase64 = response.data[0].base64;
      const buffer = Buffer.from(imageBase64, 'base64');
      fs.writeFileSync(outputPath, buffer);

      console.log(`✅ Generated: ${city.name}.png`);
    } catch (error) {
      console.error(`❌ Failed to generate ${city.name}:`, error);
    }
  }

  console.log('\n🎉 Image generation completed!');
}

generateImages();
