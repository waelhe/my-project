# نسخة احتياطية - مشروع ضيف
# Backup - Dayf Project

تاريخ النسخة الاحتياطية: $(date)

## هيكل الملفات

```
backup/
├── app/
│   ├── page.tsx              # الصفحة الرئيسية
│   ├── layout.tsx            # التخطيط الرئيسي
│   ├── globals.css           # الأنماط العامة
│   └── api/                  # واجهات API
│       ├── accommodations/
│       ├── auth/
│       ├── badges/
│       ├── chat/
│       ├── cities/
│       ├── community/
│       ├── host-reviews/
│       ├── seed/
│       └── tourism-agent/
│
├── modules/                   # وحدات Modular Monolith
│   ├── ai/                   # وحدة الذكاء الاصطناعي
│   │   ├── api/
│   │   │   ├── chat/
│   │   │   ├── vision/
│   │   │   ├── asr/
│   │   │   └── tts/
│   │   ├── components/
│   │   │   └── TourismAgent.tsx
│   │   ├── lib/
│   │   │   └── prompts.ts
│   │   └── index.ts
│   │
│   ├── tourism/              # وحدة السياحة
│   │   ├── lib/
│   │   │   └── knowledge.ts
│   │   └── index.ts
│   │
│   ├── booking/              # وحدة الحجوزات
│   │   ├── lib/
│   │   │   └── types.ts
│   │   └── index.ts
│   │
│   └── community/            # وحدة المجتمع
│       ├── lib/
│       │   └── types.ts
│       └── index.ts
│
├── lib/                      # المكتبات المساعدة
│   ├── db.ts
│   ├── utils.ts
│   ├── session.ts
│   ├── rate-limiter.ts
│   ├── auth-middleware.ts
│   ├── tourism-agent-prompt.ts
│   ├── syrian-knowledge.ts
│   └── validations/
│
├── components/               # المكونات
│   ├── tourism/
│   ├── chat/
│   ├── auth/
│   └── ui/                   # shadcn/ui components
│
├── hooks/                    # React hooks
│
├── prisma/                   # قاعدة البيانات
│   └── schema.prisma
│
├── package.json
├── tsconfig.json
├── next.config.ts
└── tailwind.config.ts
```

## الوحدات (Modules)

### 1. AI Module - وحدة الذكاء الاصطناعي
- **chat**: محادثة مع الذكاء الاصطناعي
- **vision**: تحليل الصور
- **asr**: تحويل الصوت إلى نص
- **tts**: تحويل النص إلى كلام
- **TourismAgent**: مكون الوكيل السياحي

### 2. Tourism Module - وحدة السياحة
- 8 مدن سورية
- المعالم السياحية
- أنواع السياحة
- النصائح العامة

### 3. Booking Module - وحدة الحجوزات
- أنواع الإقامة (8 أنواع)
- حالات الحجز
- طرق الدفع

### 4. Community Module - وحدة المجتمع
- أنواع المنشورات
- التعليقات
- التصنيفات

## للاستعادة

```bash
# نسخ الملفات من النسخة الاحتياطية
cp -r backup/modules/* src/modules/
cp -r backup/app/* src/app/
cp -r backup/lib/* src/lib/
cp -r backup/components/* src/components/
```

---
تم إنشاء هذه النسخة الاحتياطية بواسطة Z.ai Code
