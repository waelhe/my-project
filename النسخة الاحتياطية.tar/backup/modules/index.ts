// ═══════════════════════════════════════════════════════════════════════════
// Modules - Main Index
// الوحدات - التصدير الرئيسي
// ═══════════════════════════════════════════════════════════════════════════

/**
 * بنية Modular Monolith
 * Modular Monolith Architecture
 * 
 * كل وحدة مستقلة مع:
 * - API routes خاصة بها
 * - Components خاصة بها
 * - Lib/Types خاصة بها
 * - Index file للتصدير
 */

// ═══════════════════════════════════════════════════════════════════════════
// AI Module - وحدة الذكاء الاصطناعي
// ═══════════════════════════════════════════════════════════════════════════
export { 
  TourismAgent, 
  AI_MODULE_INFO,
  SYRIAN_TOURISM_SYSTEM_PROMPT,
  IMAGE_ANALYSIS_PROMPT,
  syrianCities as aiCities,
  tourismTypes as aiTourismTypes,
  generalTips as aiTips
} from './ai';

// ═══════════════════════════════════════════════════════════════════════════
// Tourism Module - وحدة السياحة
// ═══════════════════════════════════════════════════════════════════════════
export {
  TOURISM_MODULE_INFO,
  syrianCities,
  tourismTypes,
  generalTips,
  seasonalEvents
} from './tourism';

// ═══════════════════════════════════════════════════════════════════════════
// Booking Module - وحدة الحجوزات
// ═══════════════════════════════════════════════════════════════════════════
export {
  BOOKING_MODULE_INFO,
  AccommodationType,
  BookingStatus,
  PaymentMethod,
  ACCOMMODATION_TYPE_LABELS,
  BOOKING_STATUS_LABELS
} from './booking';

// ═══════════════════════════════════════════════════════════════════════════
// Community Module - وحدة المجتمع
// ═══════════════════════════════════════════════════════════════════════════
export {
  COMMUNITY_MODULE_INFO,
  PostType,
  POST_TYPE_LABELS
} from './community';

// ═══════════════════════════════════════════════════════════════════════════
// System Information
// ═══════════════════════════════════════════════════════════════════════════

/**
 * معلومات النظام الكامل
 * Full System Information
 */
export const SYSTEM_INFO = {
  name: 'ضيف - منصة السياحة السورية',
  nameEn: 'Dayf - Syrian Tourism Platform',
  version: '2.0.0',
  architecture: 'Modular Monolith',
  
  modules: [
    {
      name: 'AI',
      nameAr: 'الذكاء الاصطناعي',
      description: 'AI-powered tourism assistant',
      features: ['Chat', 'Vision', 'ASR', 'TTS']
    },
    {
      name: 'Tourism',
      nameAr: 'السياحة',
      description: 'Tourism knowledge and destinations',
      features: ['Cities', 'Attractions', 'Tips', 'Events']
    },
    {
      name: 'Booking',
      nameAr: 'الحجوزات',
      description: 'Accommodation and reservation system',
      features: ['Accommodations', 'Reservations', 'Availability']
    },
    {
      name: 'Community',
      nameAr: 'المجتمع',
      description: 'Community posts and discussions',
      features: ['Posts', 'Comments', 'Categories']
    }
  ],

  capabilities: [
    '🤖 مرشد سياحي ذكي بالذكاء الاصطناعي',
    '📸 تحليل صور المعالم السياحية',
    '🎤 تحويل الصوت إلى نص والعكس',
    '🏛️ 8 مدن سورية مع معالمها',
    '🏨 نظام حجوزات متكامل',
    '👥 مجتمع تفاعلي للسياح'
  ]
};
