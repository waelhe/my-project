// ═══════════════════════════════════════════════════════════════════════════
// AI Module - Tourism Agent Component
// وحدة الذكاء الاصطناعي - مكون الوكيل السياحي
// ═══════════════════════════════════════════════════════════════════════════

'use client';

import { useState, useRef, useEffect } from 'react';
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  X, 
  Send, 
  Loader2, 
  Bot,
  User,
  Camera,
  Sparkles,
  Plane,
  Hotel,
  Utensils,
  Compass,
  RefreshCw,
  Mic,
  Volume2
} from "lucide-react";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

// ═══════════════════════════════════════════════════════════════════════════
// Types
// ═══════════════════════════════════════════════════════════════════════════

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  image?: string;
  audio?: string;
  suggestions?: string[];
  timestamp: Date;
}

// ═══════════════════════════════════════════════════════════════════════════
// Quick Questions
// ═══════════════════════════════════════════════════════════════════════════

const QUICK_QUESTIONS = [
  { icon: Compass, text: "ما أفضل الأماكن في دمشق؟", type: "explore" },
  { icon: Hotel, text: "فنادق تراثية في حلب", type: "stay" },
  { icon: Utensils, text: "أفضل المطاعم السورية", type: "food" },
  { icon: Plane, text: "خطة 5 أيام في سوريا", type: "plan" },
];

// ═══════════════════════════════════════════════════════════════════════════
// Tourism Agent Component
// ═══════════════════════════════════════════════════════════════════════════

export function TourismAgent() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [isRecording, setIsRecording] = useState(false);
  const [isPlaying, setIsPlaying] = useState<string | null>(null);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const sessionId = useRef(`session-${Date.now()}`);

  // Auto scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Welcome message
  useEffect(() => {
    if (isOpen && messages.length === 0) {
      setMessages([{
        id: 'welcome',
        role: 'assistant',
        content: `مرحباً بك في ضيف! 🇸🇾

أنا مرشدك السياحي الذكي لسوريا. أساعدك في:

🏛️ **اكتشاف المعالم التاريخية والأثرية**
🏨 **إيجاد أفضل أماكن الإقامة**
🍽️ **توصيات المطاعم والمأكولات**
🗺️ **تخطيط رحلاتك السياحية**
📸 **التعرف على الأماكن من الصور**
🎤 **الاستماع للردود صوتياً**

كيف يمكنني مساعدتك اليوم؟`,
        timestamp: new Date()
      }]);
    }
  }, [isOpen, messages.length]);

  // Toggle chat handler
  const handleToggleChat = () => {
    setIsOpen(prev => !prev);
  };

  // Send message
  const sendMessage = async (messageText?: string, imageBase64?: string) => {
    const text = messageText || input.trim();
    if ((!text && !imageBase64) || loading) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: text,
      image: imageBase64 || undefined,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setSelectedImage(null);
    setLoading(true);

    try {
      const endpoint = imageBase64 ? '/api/vision' : '/api/chat';
      const body = imageBase64 
        ? { image: imageBase64, message: text, sessionId: sessionId.current }
        : { message: text, sessionId: sessionId.current };

      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
      });

      const data = await res.json();

      if (data.success) {
        const aiMessage: Message = {
          id: (Date.now() + 1).toString(),
          role: 'assistant',
          content: data.response || data.analysis,
          suggestions: data.suggestions,
          timestamp: new Date()
        };
        setMessages(prev => [...prev, aiMessage]);
      } else {
        throw new Error(data.error || 'حدث خطأ');
      }
    } catch {
      toast.error('حدث خطأ، يرجى المحاولة مرة أخرى');
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: 'عذراً، حدث خطأ في معالجة طلبك. يرجى المحاولة مرة أخرى. 🙏',
        timestamp: new Date()
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setLoading(false);
    }
  };

  // Handle image selection
  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const base64 = event.target?.result as string;
        setSelectedImage(base64);
      };
      reader.readAsDataURL(file);
    }
  };

  // Handle key press
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      if (selectedImage) {
        sendMessage(input, selectedImage);
      } else {
        sendMessage();
      }
    }
  };

  // Clear conversation
  const clearConversation = async () => {
    sessionId.current = `session-${Date.now()}`;
    setMessages([{
      id: 'welcome',
      role: 'assistant',
      content: 'تم مسح المحادثة. كيف يمكنني مساعدتك؟ 🌟',
      timestamp: new Date()
    }]);
    
    // Clear on server
    await fetch(`/api/chat?sessionId=${sessionId.current}`, { method: 'DELETE' });
  };

  // Text to Speech
  const speakText = async (text: string, messageId: string) => {
    if (isPlaying === messageId) {
      setIsPlaying(null);
      return;
    }

    setIsPlaying(messageId);
    
    try {
      const res = await fetch('/api/tts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: text.substring(0, 500) })
      });

      const data = await res.json();
      
      if (data.success && data.audio) {
        const audio = new Audio(`data:audio/mp3;base64,${data.audio}`);
        audio.onended = () => setIsPlaying(null);
        await audio.play();
      }
    } catch {
      toast.error('حدث خطأ في تحويل النص إلى كلام');
      setIsPlaying(null);
    }
  };

  // Speech to Text
  const startRecording = async () => {
    if (isRecording) {
      setIsRecording(false);
      return;
    }

    setIsRecording(true);
    
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      const chunks: BlobPart[] = [];

      mediaRecorder.ondataavailable = (e) => chunks.push(e.data);
      
      mediaRecorder.onstop = async () => {
        const blob = new Blob(chunks, { type: 'audio/webm' });
        const reader = new FileReader();
        reader.onload = async (event) => {
          const base64 = (event.target?.result as string)?.split(',')[1];
          
          try {
            const res = await fetch('/api/asr', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ audio: base64 })
            });

            const data = await res.json();
            if (data.success && data.text) {
              setInput(data.text);
            }
          } catch {
            toast.error('حدث خطأ في التعرف على الكلام');
          }
        };
        reader.readAsDataURL(blob);
        stream.getTracks().forEach(track => track.stop());
      };

      mediaRecorder.start();
      
      // Stop after 10 seconds
      setTimeout(() => {
        if (mediaRecorder.state === 'recording') {
          mediaRecorder.stop();
          setIsRecording(false);
        }
      }, 10000);

    } catch {
      toast.error('يرجى السماح بالوصول للميكروفون');
      setIsRecording(false);
    }
  };

  // Render formatted content safely
  const renderFormattedContent = (content: string) => {
    const parts = content.split(/(\*\*[^*]+\*\*)/g);
    
    return parts.map((part, index) => {
      if (part.startsWith('**') && part.endsWith('**')) {
        const boldText = part.slice(2, -2);
        return <strong key={index}>{boldText}</strong>;
      }
      return part.split('\n').map((line, lineIndex, arr) => (
        <span key={`${index}-${lineIndex}`}>
          {line}
          {lineIndex < arr.length - 1 && <br />}
        </span>
      ));
    });
  };

  return (
    <>
      {/* Floating Button */}
      <div className="fixed bottom-6 left-6 z-[99999]">
        <button
          onClick={handleToggleChat}
          className={cn(
            "w-16 h-16 rounded-full border-[3px] border-white shadow-[0_10px_40px_rgba(0,0,0,0.3)]",
            "cursor-pointer flex items-center justify-center",
            "transition-all duration-300 ease-in-out",
            "hover:scale-110",
            "focus:outline-none focus:ring-4 focus:ring-amber-300 focus:ring-offset-2",
            isOpen 
              ? "bg-gray-700 rotate-180" 
              : "bg-gradient-to-br from-amber-500 to-orange-600"
          )}
          type="button"
          aria-label={isOpen ? "إغلاق محادثة المرشد السياحي" : "فتح محادثة المرشد السياحي"}
          aria-expanded={isOpen}
          aria-controls="tourism-chat-window"
        >
          {isOpen ? (
            <X className="w-6 h-6 text-white" />
          ) : (
            <div className="flex flex-col items-center">
              <Sparkles className="w-5 h-5 text-white" />
              <span className="text-[10px] text-white mt-0.5">ضيف</span>
            </div>
          )}
        </button>
        
        {/* Ping animation */}
        {!isOpen && (
          <span 
            className="absolute inset-0 rounded-full bg-amber-400 animate-ping opacity-30 pointer-events-none"
            style={{ animation: 'ping 1s cubic-bezier(0, 0, 0.2, 1) infinite' }}
          />
        )}
      </div>

      {/* Chat Window */}
      {isOpen && (
        <div id="tourism-chat-window" className="fixed bottom-28 left-6 z-[9999] w-[420px] max-w-[calc(100vw-48px)]">
          <Card className="shadow-2xl border-amber-200 overflow-hidden">
            {/* Header */}
            <CardHeader className="bg-gradient-to-l from-amber-500 via-orange-500 to-red-500 text-white p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center backdrop-blur-sm">
                    <span className="text-2xl">🇸🇾</span>
                  </div>
                  <div>
                    <CardTitle className="text-lg">ضيف - المرشد السياحي</CardTitle>
                    <div className="flex items-center gap-1 text-sm text-white/80">
                      <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
                      متصل بالذكاء الاصطناعي
                    </div>
                  </div>
                </div>
                <button
                  onClick={clearConversation}
                  className="bg-transparent border-none text-white/80 cursor-pointer p-2 rounded
                             hover:bg-white/20 hover:text-white transition-colors
                             focus:outline-none focus:ring-2 focus:ring-white/50 focus:ring-offset-2"
                  aria-label="مسح المحادثة وبدء محادثة جديدة"
                  title="مسح المحادثة"
                >
                  <RefreshCw className="w-4 h-4" />
                </button>
              </div>
            </CardHeader>
            
            <CardContent className="p-0">
              {/* Messages */}
              <div className="h-[400px] overflow-y-auto p-4 space-y-4 bg-gradient-to-b from-amber-50/50 to-white">
                {messages.map((message) => (
                  <div
                    key={message.id}
                    className={cn(
                      "flex gap-2",
                      message.role === 'user' ? "flex-row-reverse" : "flex-row"
                    )}
                  >
                    {/* Avatar */}
                    <div className={cn(
                      "w-9 h-9 rounded-full flex items-center justify-center shrink-0",
                      message.role === 'user' 
                        ? "bg-amber-100 text-amber-600" 
                        : "bg-gradient-to-br from-amber-400 to-orange-500 text-white"
                    )}>
                      {message.role === 'user' ? (
                        <User className="w-4 h-4" />
                      ) : (
                        <Bot className="w-4 h-4" />
                      )}
                    </div>

                    {/* Message Content */}
                    <div className={cn(
                      "max-w-[80%] rounded-2xl p-3",
                      message.role === 'user'
                        ? "bg-amber-500 text-white rounded-tr-none"
                        : "bg-white border shadow-sm rounded-tl-none"
                    )}>
                      {message.image && (
                        <img 
                          src={message.image} 
                          alt="صورة مرفقة من المستخدم"
                          className="max-w-[200px] rounded-lg mb-2 object-cover"
                        />
                      )}
                      <p className="text-sm leading-relaxed">
                        {renderFormattedContent(message.content)}
                      </p>
                      
                      {/* TTS Button for AI messages */}
                      {message.role === 'assistant' && message.id !== 'welcome' && (
                        <button
                          onClick={() => speakText(message.content, message.id)}
                          className="mt-2 p-1 rounded hover:bg-amber-100 transition-colors"
                          aria-label="استماع للرد"
                        >
                          <Volume2 className={cn(
                            "w-4 h-4",
                            isPlaying === message.id ? "text-amber-600 animate-pulse" : "text-gray-400"
                          )} />
                        </button>
                      )}
                    </div>
                  </div>
                ))}
                
                {loading && (
                  <div className="flex gap-2">
                    <div className="w-9 h-9 rounded-full bg-gradient-to-br from-amber-400 to-orange-500 text-white flex items-center justify-center">
                      <Bot className="w-4 h-4" />
                    </div>
                    <div className="bg-white border shadow-sm rounded-2xl rounded-tl-none p-4">
                      <div className="flex items-center gap-2">
                        <Loader2 className="w-4 h-4 animate-spin text-amber-500" />
                        <span className="text-sm text-gray-500">جاري التفكير...</span>
                      </div>
                    </div>
                  </div>
                )}
                
                <div ref={messagesEndRef} />
              </div>

              {/* Quick Questions */}
              {messages.length <= 1 && (
                <div className="px-4 py-3 border-t bg-gray-50">
                  <p className="text-xs text-gray-500 mb-2">أسئلة سريعة:</p>
                  <div className="grid grid-cols-2 gap-2">
                    {QUICK_QUESTIONS.map((q, i) => (
                      <button
                        key={i}
                        onClick={() => sendMessage(q.text)}
                        className="flex items-center gap-2 text-xs bg-white border border-gray-200 
                                   text-gray-700 px-3 py-2 rounded-lg cursor-pointer text-right
                                   hover:bg-amber-50 hover:border-amber-300 hover:text-amber-700
                                   focus:outline-none focus:ring-2 focus:ring-amber-400 focus:ring-offset-1
                                   transition-colors"
                        aria-label={`سؤال سريع: ${q.text}`}
                      >
                        <q.icon className="w-3.5 h-3.5 shrink-0" />
                        <span className="overflow-hidden text-ellipsis whitespace-nowrap">{q.text}</span>
                      </button>
                    ))}
                  </div>
                </div>
              )}
              
              {/* Image Preview */}
              {selectedImage && (
                <div className="px-4 py-2 border-t bg-gray-50">
                  <div className="flex items-center gap-2">
                    <img src={selectedImage} alt="صورة محددة للإرسال" className="w-16 h-16 rounded-lg object-cover" />
                    <div className="flex-1">
                      <p className="text-xs text-gray-500">صورة مرفقة</p>
                      <button 
                        onClick={() => setSelectedImage(null)}
                        className="bg-transparent border-none text-red-500 cursor-pointer text-xs 
                                   py-1 px-0 flex items-center gap-1 hover:text-red-600 
                                   focus:outline-none focus:ring-2 focus:ring-red-400 focus:ring-offset-1 rounded
                                   transition-colors"
                        aria-label="إزالة الصورة المرفقة"
                      >
                        <X className="w-3 h-3" /> إزالة
                      </button>
                    </div>
                  </div>
                </div>
              )}
              
              {/* Input Area */}
              <div className="p-4 border-t bg-white">
                <div className="flex gap-2">
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    onChange={handleImageSelect}
                    className="hidden"
                  />
                  
                  {/* Image upload button */}
                  <button
                    onClick={() => fileInputRef.current?.click()}
                    className="w-10 h-10 border border-gray-200 rounded-lg bg-white cursor-pointer 
                               flex items-center justify-center shrink-0
                               hover:border-amber-300 hover:bg-amber-50 
                               focus:outline-none focus:ring-2 focus:ring-amber-400 focus:ring-offset-1
                               transition-colors"
                    aria-label="إرفاق صورة للتعرف على المكان"
                    title="إرفاق صورة"
                    type="button"
                  >
                    <Camera className="w-4 h-4 text-gray-500" />
                  </button>

                  {/* Voice input button */}
                  <button
                    onClick={startRecording}
                    className={cn(
                      "w-10 h-10 border rounded-lg flex items-center justify-center shrink-0",
                      "transition-colors",
                      isRecording 
                        ? "border-red-300 bg-red-50 animate-pulse" 
                        : "border-gray-200 bg-white hover:border-amber-300 hover:bg-amber-50"
                    )}
                    aria-label={isRecording ? "إيقاف التسجيل" : "تسجيل صوتي"}
                    title={isRecording ? "إيقاف" : "تسجيل"}
                    type="button"
                  >
                    <Mic className={cn(
                      "w-4 h-4",
                      isRecording ? "text-red-500" : "text-gray-500"
                    )} />
                  </button>

                  <Input
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyDown={handleKeyDown}
                    placeholder="اسأل عن أي شيء في سوريا..."
                    className="flex-1 text-right"
                    dir="rtl"
                    disabled={loading}
                  />
                  
                  <button
                    onClick={() => selectedImage ? sendMessage(input, selectedImage) : sendMessage()}
                    disabled={(!input.trim() && !selectedImage) || loading}
                    className={cn(
                      "w-10 h-10 border-none rounded-lg",
                      "bg-gradient-to-r from-amber-500 to-orange-600",
                      "flex items-center justify-center shrink-0",
                      "transition-opacity",
                      "focus:outline-none focus:ring-2 focus:ring-amber-400 focus:ring-offset-2",
                      (!input.trim() && !selectedImage) || loading 
                        ? "opacity-50 cursor-not-allowed" 
                        : "cursor-pointer hover:opacity-90"
                    )}
                    type="button"
                    aria-label="إرسال الرسالة"
                  >
                    <Send className="w-4 h-4 text-white" />
                  </button>
                </div>
                
                <p className="text-[10px] text-gray-400 mt-2 text-center">
                  powered by ضيف AI • يمكنك إرسال صور أو تسجيل صوتي
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </>
  );
}
