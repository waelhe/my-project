// ═══════════════════════════════════════════════════════════════════════════
// AI Module - Vision API
// وحدة الذكاء الاصطناعي - واجهة الرؤية
// ═══════════════════════════════════════════════════════════════════════════

import { NextRequest, NextResponse } from 'next/server';
import ZAI from 'z-ai-web-dev-sdk';
import { IMAGE_ANALYSIS_PROMPT, SYRIAN_TOURISM_SYSTEM_PROMPT } from '../../lib/prompts';
import { tourismAgentLimiter, getClientIP, createRateLimitHeaders } from '@/lib/rate-limiter';

// Initialize ZAI instance
let zaiInstance: Awaited<ReturnType<typeof ZAI.create>> | null = null;

async function getZAI() {
  if (!zaiInstance) {
    zaiInstance = await ZAI.create();
  }
  return zaiInstance;
}

/**
 * POST - Analyze image with Vision AI
 * تحليل الصورة باستخدام الذكاء الاصطناعي البصري
 */
export async function POST(request: NextRequest) {
  try {
    // Rate limiting check
    const clientIP = getClientIP(request);
    const rateLimitResult = await tourismAgentLimiter.check(clientIP);
    
    if (!rateLimitResult.success) {
      return NextResponse.json(
        { 
          error: 'طلبات كثيرة جداً. يرجى الانتظار قبل المحاولة مجدداً',
          retryAfter: rateLimitResult.retryAfter 
        },
        { 
          status: 429,
          headers: createRateLimitHeaders(rateLimitResult)
        }
      );
    }

    const body = await request.json();
    const { image, message } = body;

    if (!image) {
      return NextResponse.json(
        { error: 'الصورة مطلوبة' },
        { status: 400 }
      );
    }

    const zai = await getZAI();

    // Build vision messages
    const visionMessages = [
      {
        role: 'user',
        content: [
          { type: 'text', text: IMAGE_ANALYSIS_PROMPT },
          { type: 'image_url', image_url: { url: image } }
        ]
      }
    ];

    // Get vision analysis
    const visionResponse = await zai.chat.completions.createVision({
      model: 'gpt-4o',
      messages: visionMessages as any,
      thinking: { type: 'disabled' }
    });

    const imageAnalysis = visionResponse.choices[0]?.message?.content || '';

    // If user has additional question, get follow-up response
    let finalResponse = imageAnalysis;
    
    if (message) {
      const followUpMessages = [
        { role: 'assistant', content: SYRIAN_TOURISM_SYSTEM_PROMPT },
        {
          role: 'user',
          content: `${message}\n\n[تحليل الصورة: ${imageAnalysis}]`
        }
      ];

      const followUpResponse = await zai.chat.completions.create({
        messages: followUpMessages as any,
        thinking: { type: 'disabled' }
      });

      finalResponse = followUpResponse.choices[0]?.message?.content || imageAnalysis;
    }

    return NextResponse.json({
      success: true,
      analysis: imageAnalysis,
      response: finalResponse,
      timestamp: new Date().toISOString()
    }, {
      headers: createRateLimitHeaders(rateLimitResult)
    });

  } catch (error) {
    console.error('Vision API error:', error);
    return NextResponse.json(
      { 
        success: false,
        error: 'حدث خطأ في تحليل الصورة. يرجى المحاولة مرة أخرى.',
        details: error instanceof Error ? error.message : 'Unknown error'
      },
      { status: 500 }
    );
  }
}

/**
 * GET - Vision API info
 */
export async function GET() {
  return NextResponse.json({
    success: true,
    message: 'AI Vision API - ضيف',
    capabilities: [
      'تحليل صور المعالم السياحية',
      'التعرف على الأماكن السورية',
      'اقتراح أماكن مشابهة',
      'تقديم معلومات تاريخية وثقافية'
    ]
  });
}
