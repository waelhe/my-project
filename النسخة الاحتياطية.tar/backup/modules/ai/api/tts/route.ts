// ═══════════════════════════════════════════════════════════════════════════
// AI Module - TTS (Text to Speech) API
// وحدة الذكاء الاصطناعي - واجهة تحويل النص إلى كلام
// ═══════════════════════════════════════════════════════════════════════════

import { NextRequest, NextResponse } from 'next/server';
import ZAI from 'z-ai-web-dev-sdk';
import { tourismAgentLimiter, getClientIP, createRateLimitHeaders } from '@/lib/rate-limiter';

// Initialize ZAI instance
let zaiInstance: Awaited<ReturnType<typeof ZAI.create>> | null = null;

async function getZAI() {
  if (!zaiInstance) {
    zaiInstance = await ZAI.create();
  }
  return zaiInstance;
}

/**
 * POST - Convert text to speech
 * تحويل النص إلى كلام
 */
export async function POST(request: NextRequest) {
  try {
    // Rate limiting check
    const clientIP = getClientIP(request);
    const rateLimitResult = await tourismAgentLimiter.check(clientIP);
    
    if (!rateLimitResult.success) {
      return NextResponse.json(
        { 
          error: 'طلبات كثيرة جداً. يرجى الانتظار قبل المحاولة مجدداً',
          retryAfter: rateLimitResult.retryAfter 
        },
        { 
          status: 429,
          headers: createRateLimitHeaders(rateLimitResult)
        }
      );
    }

    const body = await request.json();
    const { 
      text, 
      voice = 'alloy',
      speed = 1.0,
      language = 'ar'
    } = body;

    if (!text) {
      return NextResponse.json(
        { error: 'النص مطلوب' },
        { status: 400 }
      );
    }

    // Limit text length
    if (text.length > 4000) {
      return NextResponse.json(
        { error: 'النص طويل جداً. الحد الأقصى 4000 حرف.' },
        { status: 400 }
      );
    }

    const zai = await getZAI();

    // Convert text to speech
    const ttsResult = await zai.tts.synthesize({
      text: text,
      voice: voice,
      speed: speed,
      response_format: 'mp3'
    });

    return NextResponse.json({
      success: true,
      audio: ttsResult.audio, // Base64 encoded audio
      format: 'mp3',
      voice: voice,
      language: language,
      timestamp: new Date().toISOString()
    }, {
      headers: createRateLimitHeaders(rateLimitResult)
    });

  } catch (error) {
    console.error('TTS API error:', error);
    return NextResponse.json(
      { 
        success: false,
        error: 'حدث خطأ في تحويل النص إلى كلام. يرجى المحاولة مرة أخرى.',
        details: error instanceof Error ? error.message : 'Unknown error'
      },
      { status: 500 }
    );
  }
}

/**
 * GET - TTS API info and available voices
 */
export async function GET() {
  return NextResponse.json({
    success: true,
    message: 'AI TTS API - ضيف',
    capabilities: [
      'تحويل النص إلى كلام',
      'دعم اللغة العربية',
      'أصوات متعددة',
      'سرعة قابلة للتعديل'
    ],
    voices: [
      { id: 'alloy', name: 'Alloy', description: 'صوت متوازن' },
      { id: 'echo', name: 'Echo', description: 'صوت رجالي واضح' },
      { id: 'fable', name: 'Fable', description: 'صوت راوي' },
      { id: 'onyx', name: 'Onyx', description: 'صوت رجالي عميق' },
      { id: 'nova', name: 'Nova', description: 'صوت نسائي' },
      { id: 'shimmer', name: 'Shimmer', description: 'صوت نسائي ناعم' }
    ],
    formats: ['mp3', 'opus', 'aac', 'flac', 'wav', 'pcm']
  });
}
