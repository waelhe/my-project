// ═══════════════════════════════════════════════════════════════════════════
// AI Module - ASR (Automatic Speech Recognition) API
// وحدة الذكاء الاصطناعي - واجهة التعرف على الكلام
// ═══════════════════════════════════════════════════════════════════════════

import { NextRequest, NextResponse } from 'next/server';
import ZAI from 'z-ai-web-dev-sdk';
import { tourismAgentLimiter, getClientIP, createRateLimitHeaders } from '@/lib/rate-limiter';

// Initialize ZAI instance
let zaiInstance: Awaited<ReturnType<typeof ZAI.create>> | null = null;

async function getZAI() {
  if (!zaiInstance) {
    zaiInstance = await ZAI.create();
  }
  return zaiInstance;
}

/**
 * POST - Transcribe audio to text
 * تحويل الصوت إلى نص
 */
export async function POST(request: NextRequest) {
  try {
    // Rate limiting check
    const clientIP = getClientIP(request);
    const rateLimitResult = await tourismAgentLimiter.check(clientIP);
    
    if (!rateLimitResult.success) {
      return NextResponse.json(
        { 
          error: 'طلبات كثيرة جداً. يرجى الانتظار قبل المحاولة مجدداً',
          retryAfter: rateLimitResult.retryAfter 
        },
        { 
          status: 429,
          headers: createRateLimitHeaders(rateLimitResult)
        }
      );
    }

    const body = await request.json();
    const { audio, language = 'ar' } = body;

    if (!audio) {
      return NextResponse.json(
        { error: 'الملف الصوتي مطلوب' },
        { status: 400 }
      );
    }

    const zai = await getZAI();

    // Transcribe audio using ASR
    const transcription = await zai.asr.transcribe({
      audio: audio,
      language: language
    });

    return NextResponse.json({
      success: true,
      text: transcription.text,
      language: transcription.language || language,
      duration: transcription.duration,
      timestamp: new Date().toISOString()
    }, {
      headers: createRateLimitHeaders(rateLimitResult)
    });

  } catch (error) {
    console.error('ASR API error:', error);
    return NextResponse.json(
      { 
        success: false,
        error: 'حدث خطأ في تحويل الصوت إلى نص. يرجى المحاولة مرة أخرى.',
        details: error instanceof Error ? error.message : 'Unknown error'
      },
      { status: 500 }
    );
  }
}

/**
 * GET - ASR API info
 */
export async function GET() {
  return NextResponse.json({
    success: true,
    message: 'AI ASR API - ضيف',
    capabilities: [
      'تحويل الصوت إلى نص',
      'دعم اللغة العربية',
      'دعم اللغة الإنجليزية',
      'مناسب للهجات السورية'
    ],
    supportedFormats: ['mp3', 'wav', 'm4a', 'ogg', 'webm']
  });
}
