// ═══════════════════════════════════════════════════════════════════════════
// AI Module - Index
// وحدة الذكاء الاصطناعي - التصدير الرئيسي
// ═══════════════════════════════════════════════════════════════════════════

// Components
export { TourismAgent } from './components/TourismAgent';

// Prompts and Knowledge
export {
  SYRIAN_TOURISM_SYSTEM_PROMPT,
  IMAGE_ANALYSIS_PROMPT,
  PERSONALIZED_RECOMMENDATION_PROMPT,
  buildTourismPrompt,
  syrianCities,
  tourismTypes,
  generalTips,
  type CityKey,
  type SyrianCity,
  type TourismType
} from './lib/prompts';

// Module Info
export const AI_MODULE_INFO = {
  name: 'AI Module',
  nameAr: 'وحدة الذكاء الاصطناعي',
  version: '1.0.0',
  description: 'AI-powered tourism assistant with chat, vision, ASR, and TTS capabilities',
  apis: [
    { path: '/api/chat', method: 'POST', description: 'محادثة مع الذكاء الاصطناعي' },
    { path: '/api/vision', method: 'POST', description: 'تحليل الصور' },
    { path: '/api/asr', method: 'POST', description: 'تحويل الصوت إلى نص' },
    { path: '/api/tts', method: 'POST', description: 'تحويل النص إلى كلام' }
  ]
};
