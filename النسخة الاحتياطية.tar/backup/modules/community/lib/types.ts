// ═══════════════════════════════════════════════════════════════════════════
// Community Module - Types
// وحدة المجتمع - الأنواع
// ═══════════════════════════════════════════════════════════════════════════

/**
 * أنواع المنشورات
 * Post Types
 */
export enum PostType {
  DISCUSSION = 'DISCUSSION',
  QUESTION = 'QUESTION',
  STORY = 'STORY',
  ANNOUNCEMENT = 'ANNOUNCEMENT',
  GUIDE = 'GUIDE'
}

/**
 * تسميات أنواع المنشورات بالعربية
 * Post Type Labels
 */
export const POST_TYPE_LABELS: Record<PostType, { label: string; color: string }> = {
  [PostType.DISCUSSION]: { label: 'نقاش', color: 'bg-sky-100 text-sky-700' },
  [PostType.QUESTION]: { label: 'سؤال', color: 'bg-amber-100 text-amber-700' },
  [PostType.STORY]: { label: 'تجربة', color: 'bg-rose-100 text-rose-700' },
  [PostType.ANNOUNCEMENT]: { label: 'إعلان', color: 'bg-violet-100 text-violet-700' },
  [PostType.GUIDE]: { label: 'دليل', color: 'bg-emerald-100 text-emerald-700' }
};

/**
 * معلومات المنشور
 * Post Information
 */
export interface PostInfo {
  id: string;
  titleAr: string;
  titleEn?: string;
  contentAr: string;
  contentEn?: string;
  type: PostType;
  authorId: string;
  categoryId?: string;
  tags: string[];
  images: string[];
  viewCount: number;
  likeCount: number;
  commentCount: number;
  isPinned: boolean;
  isFeatured: boolean;
  createdAt: Date;
  updatedAt: Date;
}

/**
 * معلومات التعليق
 * Comment Information
 */
export interface CommentInfo {
  id: string;
  postId: string;
  authorId: string;
  contentAr: string;
  parentId?: string;
  likeCount: number;
  isAccepted: boolean;
  createdAt: Date;
  updatedAt: Date;
}

/**
 * معلومات التصنيف
 * Category Information
 */
export interface CategoryInfo {
  id: string;
  nameAr: string;
  nameEn?: string;
  descriptionAr?: string;
  icon?: string;
  color?: string;
  isPopular: boolean;
  postCount: number;
}

/**
 * إحصائيات المجتمع
 * Community Stats
 */
export interface CommunityStats {
  totalPosts: number;
  totalComments: number;
  totalMembers: number;
  activeToday: number;
  topContributors: Array<{
    id: string;
    name: string;
    posts: number;
    likes: number;
  }>;
}
