// ═══════════════════════════════════════════════════════════════════════════
// Community Module - Index
// وحدة المجتمع - التصدير الرئيسي
// ═══════════════════════════════════════════════════════════════════════════

// Types
export {
  PostType,
  POST_TYPE_LABELS,
  type PostInfo,
  type CommentInfo,
  type CategoryInfo,
  type CommunityStats
} from './lib/types';

// Module Info
export const COMMUNITY_MODULE_INFO = {
  name: 'Community Module',
  nameAr: 'وحدة المجتمع',
  version: '1.0.0',
  description: 'Community platform with posts, comments, and categories',
  apis: [
    { path: '/api/community/posts', method: 'GET', description: 'قائمة المنشورات' },
    { path: '/api/community/comments', method: 'GET', description: 'قائمة التعليقات' },
    { path: '/api/community/categories', method: 'GET', description: 'قائمة التصنيفات' }
  ],
  features: [
    '5 أنواع منشورات',
    'نظام تعليقات متسلسل',
    'تصنيفات متعددة',
    'إحصائيات المجتمع'
  ]
};
