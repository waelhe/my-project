// ═══════════════════════════════════════════════════════════════════════════
// Tourism Module - Knowledge Base
// وحدة السياحة - قاعدة المعرفة
// ═══════════════════════════════════════════════════════════════════════════

/**
 * المدن السورية
 * Syrian Cities Data
 */
export const syrianCities = {
  damascus: {
    id: 'damascus',
    nameAr: "دمشق",
    nameEn: "Damascus",
    governorate: "دمشق",
    description: "أقدم عاصمة مأهولة في العالم، مدينة التاريخ والحضارات",
    isPopular: true,
    population: 2100000,
    coordinates: { lat: 33.5138, lng: 36.2765 },
    attractions: [
      {
        name: "الجامع الأموي",
        description: "من أعرق المساجد في العالم الإسلامي، بني على كنيسة يوحنا المعمدان",
        type: "ديني",
        workingHours: "8:00 - 20:00",
        entryFee: "مجاني",
        tips: ["ارتدِ ملابس محتشمة", "يمكن زيارة ضريح يوحنا المعمدان", "أفضل وقت الصباح الباكر"]
      },
      {
        name: "سوق الحميدية",
        description: "أشهر أسواق دمشق التقليدية، يمتد لأكثر من 600 متر",
        type: "تسوق",
        workingHours: "9:00 - 22:00",
        tips: ["تفاوض على الأسعار", "جرب البوظة الدمشقية", "اشترِ الحلويات والبهارات"]
      },
      {
        name: "بيت نظام",
        description: "نموذج رائع للبيت الدمشقي التقليدي، تحول لمتحف",
        type: "تراثي",
        workingHours: "9:00 - 16:00",
        entryFee: "500 ل.س",
        tips: ["جولات مرشدة متاحة", "تصوير رائع في الباحة الداخلية"]
      },
      {
        name: "باب توما",
        description: "من أقدم أحياء دمشق المسيحية، مليء بالكنائس والمطاعم",
        type: "تراثي",
        workingHours: "مفتوح دائماً",
        tips: ["جرب المطاعم التراثية", "زيارة كنيسة حنانيا", "أجواء مسائية رائعة"]
      }
    ],
    restaurants: [
      { name: "بيت اليمان", type: "تراثي", priceRange: "$$", speciality: "المزة السورية" },
      { name: "النوفرة", type: "تقليدي", priceRange: "$", speciality: "الفتة والشاورما" },
      { name: "دار السلام", type: "راقي", priceRange: "$$$", speciality: "المأكولات الشامية" }
    ],
    hotels: [
      { name: "فندق شيراتون", stars: 5, area: "المزة", priceFrom: 150 },
      { name: "فندق فور سيزونز", stars: 5, area: "المزرعة", priceFrom: 200 },
      { name: "بيت الوالي", type: "تراثي", area: "القلعة", priceFrom: 80 }
    ],
    weather: { 
      summer: "حار جاف 30-40°", 
      winter: "بارد ممطر 5-15°", 
      bestTime: "مارس-مايو، سبتمبر-نوفمبر" 
    }
  },

  aleppo: {
    id: 'aleppo',
    nameAr: "حلب",
    nameEn: "Aleppo",
    governorate: "حلب",
    description: "مدينة التراث والثقافة، عاصمة المطبخ السوري",
    isPopular: true,
    population: 2100000,
    coordinates: { lat: 36.2021, lng: 37.1343 },
    attractions: [
      {
        name: "قلعة حلب",
        description: "من أروع القلاع في العالم، شاهدة على حضارات متعددة",
        type: "أثري",
        workingHours: "9:00 - 17:00",
        entryFee: "1000 ل.س",
        tips: ["أحذية مريحة للصعود", "إطلالة بانورامية رائعة", "جولة تحتاج ساعتين"]
      },
      {
        name: "الأسواق القديمة",
        description: "شبكة من الأسواق المغطاة، كل سوق لحرفة معينة",
        type: "تراثي",
        workingHours: "9:00 - 19:00",
        tips: ["سوق الصابون", "سوق النحاس", "سوق الحرير"]
      },
      {
        name: "فندق بارون",
        description: "فندق تاريخي من 1909، نزل فيه لورنس العرب وأغاثا كريستي",
        type: "تراثي",
        workingHours: "24 ساعة",
        tips: ["اشرب الشاي في الصالة التاريخية", "تصوير الأثاث العتيق"]
      }
    ],
    restaurants: [
      { name: "ساندويشات أبو شاكر", type: "شعبي", priceRange: "$", speciality: "الشاورما" },
      { name: "مطعم الكورنيش", type: "تراثي", priceRange: "$$", speciality: "الكبة الحلبية" }
    ],
    famousDishes: ["الكبة الحلبية", "الشاورما الحلبية", "المعمول", "الجبس الحلبي"],
    weather: { summer: "حار جاف 30-38°", winter: "بارد 2-12°", bestTime: "أبريل-يونيو، سبتمبر-أكتوبر" }
  },

  lattakia: {
    id: 'lattakia',
    nameAr: "اللاذقية",
    nameEn: "Lattakia",
    governorate: "اللاذقية",
    description: "عروس الساحل السوري، بوابة البحر المتوسط",
    isPopular: true,
    population: 900000,
    coordinates: { lat: 35.5369, lng: 35.7953 },
    attractions: [
      {
        name: "شاطئ السيادر",
        description: "أجمل شواطئ اللاذقية، مياه صافية ورمال ذهبية",
        type: "شاطئ",
        workingHours: "6:00 - 20:00",
        entryFee: "500-2000 ل.س حسب الموسم",
        tips: ["أفضل وقت الصباح الباكر", "كراسي ومظلات متاحة", "مطاعم قريبة"]
      },
      {
        name: "قلعة صلاح الدين",
        description: "قلعة الأكراد التاريخية، معقل صلاح الدين الأيوبي",
        type: "أثري",
        workingHours: "9:00 - 17:00",
        tips: ["صعود شديد الانحدار", "إطلالة رائعة", "جولة ساعتين"]
      },
      {
        name: "جزيرة أرواد",
        description: "الجزيرة السورية الوحيدة المأهولة، رحلات بالقوارب",
        type: "طبيعي",
        workingHours: "8:00 - 18:00",
        tips: ["قوارب من طرطوس", "مطاعم سمك طازج", "آثار فينيقية"]
      }
    ],
    beaches: ["السيادر", "الشاطئ الأزرق", "رواد", "عائلي"],
    weather: { summer: "دافئ رطب 25-32°", winter: "معتدل 10-18°", bestTime: "يونيو-سبتمبر" }
  },

  palmyra: {
    id: 'palmyra',
    nameAr: "تدمر",
    nameEn: "Palmyra",
    governorate: "حمص",
    description: "عروس الصحراء، مدينة زنوبيا الملكة",
    isPopular: true,
    population: 50000,
    coordinates: { lat: 34.5573, lng: 38.2848 },
    attractions: [
      {
        name: "المدينة الأثرية",
        description: "مدينة تدمر التاريخية، موقع تراث عالمي",
        type: "أثري",
        workingHours: "7:00 - 18:00",
        entryFee: "1500 ل.س",
        tips: ["أفضل وقت الصباح الباكر أو الغروب", "احمل ماء كثير", "مرشد محلي أنصح به"]
      },
      {
        name: "قوس النصر",
        description: "رمز تدمر، أقيم تخليداً لانتصارات المدينة",
        type: "أثري",
        tips: ["أفضل صور عند الغروب", "يمكن المشي من المدينة الأثرية"]
      },
      {
        name: "وادي السياح",
        description: "منطقة تخييم واستراحات",
        type: "طبيعي",
        tips: ["تخييم تحت النجوم", "أجواء صحراوية", "إفطار بدوي"]
      }
    ],
    weather: { summer: "حار جداً 35-45°", winter: "بارد ليلاً 5-20°", bestTime: "أكتوبر-أبريل" },
    tips: ["احمل ماء كافي", "حماية من الشمس", "مرشد محلي مهم"]
  },

  maaloula: {
    id: 'maaloula',
    nameAr: "معلولا",
    nameEn: "Maaloula",
    governorate: "ريف دمشق",
    description: "القرية التي تتحدث الآرامية، لغة المسيح",
    isPopular: true,
    population: 5000,
    coordinates: { lat: 33.8375, lng: 36.5586 },
    attractions: [
      {
        name: "دير مار تقلا",
        description: "من أقدم الأديرة في العالم، ضريح القديسة تقلا",
        type: "ديني",
        workingHours: "8:00 - 18:00",
        tips: ["احترام مكان العبادة", "يمكن سماع الصلاة بالآرامية"]
      },
      {
        name: "دير سيرجيوس",
        description: "أحد أقدم المعابد المسيحية في العالم",
        type: "ديني",
        workingHours: "8:00 - 18:00"
      }
    ],
    language: "الآرامية (لا تزال محكية)",
    weather: { summer: "معتدل 20-28°", winter: "بارد مع ثلوج -5-10°", bestTime: "مارس-نوفمبر" },
    tips: ["مجتمع محافظ", "احترام التقاليد", "جولة يومية من دمشق"]
  },

  homs: {
    id: 'homs',
    nameAr: "حمص",
    nameEn: "Homs",
    governorate: "حمص",
    description: "مدينة ينابيع المياه الحارة وقلعة الحصن",
    isPopular: true,
    population: 800000,
    coordinates: { lat: 34.7384, lng: 36.7175 },
    attractions: [
      {
        name: "قلعة الحصن",
        description: "كراك دي شوفالييه - أعظم قلاع الصليبيين",
        type: "أثري",
        workingHours: "9:00 - 17:00",
        entryFee: "1000 ل.س",
        tips: ["أحذية مريحة", "جولة 3 ساعات", "إطلالة بانورامية"]
      },
      {
        name: "ينابيع أبوربص",
        description: "ينابيع مياه حارة طبيعية للعلاج والاستجمام",
        type: "طبيعي",
        workingHours: "طوال اليوم",
        tips: ["مناسب للعائلات", "كبائن خاصة", "مطاعم قريبة"]
      }
    ],
    weather: { summer: "حار 28-35°", winter: "بارد 3-12°", bestTime: "أبريل-يونيو، سبتمبر-نوفمبر" }
  },

  tartus: {
    id: 'tartus',
    nameAr: "طرطوس",
    nameEn: "Tartus",
    governorate: "طرطوس",
    description: "المدينة الساحلية الهادئة مع شواطئ خلابة",
    isPopular: true,
    population: 400000,
    coordinates: { lat: 34.8959, lng: 35.8867 },
    attractions: [
      {
        name: "شاطئ طرطوس",
        description: "شاطئ رملي هادئ مناسب للعائلات",
        type: "شاطئ",
        workingHours: "طوال اليوم",
        tips: ["مياه نظيفة", "مطاعم على الشاطئ", "غروب جميل"]
      },
      {
        name: "جزيرة أرواد",
        description: "جزيرة تاريخية مع قلعة وآثار فينيقية",
        type: "أثري",
        workingHours: "8:00 - 18:00",
        tips: ["قوارب من الميناء", "مطاعم سمك", "نزهة بحرية"]
      }
    ],
    weather: { summer: "دافئ 25-32°", winter: "معتدل 8-16°", bestTime: "يونيو-سبتمبر" }
  },

  bosra: {
    id: 'bosra',
    nameAr: "بصرى",
    nameEn: "Bosra",
    governorate: "درعا",
    description: "مدينة المسرح الروماني - موقع تراث عالمي",
    isPopular: false,
    population: 30000,
    coordinates: { lat: 32.5189, lng: 36.4847 },
    attractions: [
      {
        name: "المسرح الروماني",
        description: "من أفضل المسارح الرومانية المحفوظة في العالم",
        type: "أثري",
        workingHours: "9:00 - 17:00",
        entryFee: "1500 ل.س",
        tips: ["جولات مرشدة", "مهرجانات صيفية", "تصوير رائع"]
      }
    ],
    weather: { summer: "حار 28-38°", winter: "بارد 4-12°", bestTime: "أبريل-مايو، سبتمبر-أكتوبر" }
  }
};

/**
 * أنواع السياحة
 * Tourism Types
 */
export const tourismTypes = {
  cultural: {
    id: 'cultural',
    nameAr: 'سياحة ثقافية وتراثية',
    nameEn: 'Cultural Tourism',
    description: 'زيارة المواقع الأثرية والمتاحف والأسواق التراثية',
    icon: 'Landmark',
    cities: ['damascus', 'aleppo', 'palmyra', 'bosra']
  },
  religious: {
    id: 'religious',
    nameAr: 'سياحة دينية',
    nameEn: 'Religious Tourism',
    description: 'زيارة المساجد والكنائس والمقامات الدينية',
    icon: 'Church',
    cities: ['damascus', 'aleppo', 'maaloula']
  },
  beach: {
    id: 'beach',
    nameAr: 'سياحة شاطئية',
    nameEn: 'Beach Tourism',
    description: 'الاستجمام على شواطئ البحر المتوسط',
    icon: 'Waves',
    cities: ['lattakia', 'tartus']
  },
  nature: {
    id: 'nature',
    nameAr: 'سياحة طبيعية',
    nameEn: 'Nature Tourism',
    description: 'الجبال والغابات والينابيع الطبيعية',
    icon: 'Trees',
    cities: ['homs', 'lattakia']
  },
  medical: {
    id: 'medical',
    nameAr: 'سياحة علاجية',
    nameEn: 'Medical Tourism',
    description: 'الينابيع الحارة والعلاج الطبيعي',
    icon: 'Heart',
    cities: ['homs']
  },
  adventure: {
    id: 'adventure',
    nameAr: 'سياحة المغامرات',
    nameEn: 'Adventure Tourism',
    description: 'السفاري والتخييم واستكشاف الصحراء',
    icon: 'Compass',
    cities: ['palmyra']
  }
};

/**
 * نصائح عامة للسياح
 * General Tips for Tourists
 */
export const generalTips = {
  safety: [
    "تجنب المناطق الحدودية بدون مرشد",
    "سافر نهاراً بين المدن",
    "احتفظ بصور جواز سفرك",
    "سجل في سفارتك إن وجدت"
  ],
  culture: [
    "لباس محتشم尤其在 المناطق التقليدية",
    "احترم أوقات الصلاة",
    "التفاوض في الأسواق متوقع",
    "البقشيش 10% معتاد"
  ],
  money: [
    "العملة: الليرة السورية (SYP)",
    "الدولار مقبول في أماكن كثيرة",
    "نقدي في معظم الأماكن",
    "صرافات في المدن الكبرى"
  ],
  transport: [
    "تاكسي أو سيارة مستأجرة أفضل",
    "تطبيقات: أويا، سيرياباص",
    "القطار محدود",
    "الطيران: دمشق، حلب، اللاذقية"
  ]
};

/**
 * فعاليات موسمية
 * Seasonal Events
 */
export const seasonalEvents = [
  { name: "مهرجان دمشق السينمائي", city: "دمشق", month: "نوفمبر", type: "ثقافي" },
  { name: "موسم اللاذقية السياحي", city: "اللاذقية", month: "يونيو-أغسطس", type: "سياحي" },
  { name: "موسم التخييم", city: "تدمر", month: "أكتوبر-أبريل", type: "مغامرة" },
  { name: "مهرجان الزهور", city: "دمشق", month: "أبريل", type: "ثقافي" },
  { name: "موسم السباحة", city: "اللاذقية وطرطوس", month: "يونيو-سبتمبر", type: "سياحي" }
];

// Types
export type CityKey = keyof typeof syrianCities;
export type SyrianCity = typeof syrianCities[CityKey];
export type TourismTypeKey = keyof typeof tourismTypes;
