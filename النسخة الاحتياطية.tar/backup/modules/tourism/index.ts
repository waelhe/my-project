// ═══════════════════════════════════════════════════════════════════════════
// Tourism Module - Index
// وحدة السياحة - التصدير الرئيسي
// ═══════════════════════════════════════════════════════════════════════════

// Knowledge Base
export {
  syrianCities,
  tourismTypes,
  generalTips,
  seasonalEvents,
  type CityKey,
  type SyrianCity,
  type TourismTypeKey
} from './lib/knowledge';

// Module Info
export const TOURISM_MODULE_INFO = {
  name: 'Tourism Module',
  nameAr: 'وحدة السياحة',
  version: '1.0.0',
  description: 'Syrian tourism knowledge base with cities, attractions, and travel information',
  apis: [
    { path: '/api/cities', method: 'GET', description: 'قائمة المدن السورية' },
    { path: '/api/destinations', method: 'GET', description: 'الوجهات السياحية' }
  ],
  features: [
    '8 مدن سورية رئيسية',
    'معالم سياحية متعددة',
    'أنواع السياحة المختلفة',
    'نصائح للسائحين'
  ]
};
