// ═══════════════════════════════════════════════════════════════════════════
// Booking Module - Types
// وحدة الحجوزات - الأنواع
// ═══════════════════════════════════════════════════════════════════════════

/**
 * أنواع أماكن الإقامة
 * Accommodation Types
 */
export enum AccommodationType {
  HOTEL = 'HOTEL',
  APARTMENT = 'APARTMENT',
  VILLA = 'VILLA',
  CHALET = 'CHALET',
  CAMP = 'CAMP',
  GUESTHOUSE = 'GUESTHOUSE',
  HOSTEL = 'HOSTEL',
  RESORT = 'RESORT'
}

/**
 * حالة الحجز
 * Booking Status
 */
export enum BookingStatus {
  PENDING = 'PENDING',
  CONFIRMED = 'CONFIRMED',
  CANCELLED = 'CANCELLED',
  COMPLETED = 'COMPLETED'
}

/**
 * وسائل الدفع
 * Payment Methods
 */
export enum PaymentMethod {
  CASH = 'CASH',
  BANK_TRANSFER = 'BANK_TRANSFER',
  MOBILE_MONEY = 'MOBILE_MONEY',
  CREDIT_CARD = 'CREDIT_CARD'
}

/**
 * تسميات أنواع الإقامة بالعربية
 * Accommodation Type Labels
 */
export const ACCOMMODATION_TYPE_LABELS: Record<AccommodationType, string> = {
  [AccommodationType.HOTEL]: 'فندق',
  [AccommodationType.APARTMENT]: 'شقة',
  [AccommodationType.VILLA]: 'فيلا',
  [AccommodationType.CHALET]: 'شاليه',
  [AccommodationType.CAMP]: 'مخيم',
  [AccommodationType.GUESTHOUSE]: 'نزل',
  [AccommodationType.HOSTEL]: 'سكن شباب',
  [AccommodationType.RESORT]: 'منتجع'
};

/**
 * تسميات حالة الحجز بالعربية
 * Booking Status Labels
 */
export const BOOKING_STATUS_LABELS: Record<BookingStatus, string> = {
  [BookingStatus.PENDING]: 'قيد الانتظار',
  [BookingStatus.CONFIRMED]: 'مؤكد',
  [BookingStatus.CANCELLED]: 'ملغي',
  [BookingStatus.COMPLETED]: 'مكتمل'
};

/**
 * معلومات الحجز
 * Booking Information
 */
export interface BookingInfo {
  id: string;
  accommodationId: string;
  userId: string;
  checkIn: Date;
  checkOut: Date;
  guests: number;
  totalPrice: number;
  status: BookingStatus;
  paymentMethod: PaymentMethod;
  specialRequests?: string;
  createdAt: Date;
  updatedAt: Date;
}

/**
 * تفاصيل الإقامة
 * Accommodation Details
 */
export interface AccommodationDetails {
  id: string;
  titleAr: string;
  titleEn?: string;
  descriptionAr?: string;
  type: AccommodationType;
  addressAr?: string;
  cityId: string;
  basePrice: number;
  maxGuests: number;
  bedrooms: number;
  bathrooms: number;
  amenities: string[];
  images: string[];
  coverImage?: string;
  rating: number;
  reviewCount: number;
  isActive: boolean;
  hostId: string;
}

/**
 * تواريخ متاحة
 * Available Dates
 */
export interface AvailableDates {
  accommodationId: string;
  availableDates: Date[];
  blockedDates: Date[];
  minNights: number;
  maxNights: number;
}
