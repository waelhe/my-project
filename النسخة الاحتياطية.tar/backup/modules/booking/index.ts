// ═══════════════════════════════════════════════════════════════════════════
// Booking Module - Index
// وحدة الحجوزات - التصدير الرئيسي
// ═══════════════════════════════════════════════════════════════════════════

// Types
export {
  AccommodationType,
  BookingStatus,
  PaymentMethod,
  ACCOMMODATION_TYPE_LABELS,
  BOOKING_STATUS_LABELS,
  type BookingInfo,
  type AccommodationDetails,
  type AvailableDates
} from './lib/types';

// Module Info
export const BOOKING_MODULE_INFO = {
  name: 'Booking Module',
  nameAr: 'وحدة الحجوزات',
  version: '1.0.0',
  description: 'Accommodation booking system with reservations management',
  apis: [
    { path: '/api/accommodations', method: 'GET', description: 'قائمة أماكن الإقامة' },
    { path: '/api/reservations', method: 'POST', description: 'إنشاء حجز جديد' }
  ],
  features: [
    '8 أنواع إقامة',
    'نظام حجز متكامل',
    'طرق دفع متعددة',
    'إدارة التوفر'
  ]
};
