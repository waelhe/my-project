import { PrismaClient } from '@prisma/client'

const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined
}

// تعطيل logging في الإنتاج لتحسين الأداء والأمان
// Disable logging in production for better performance and security
export const db =
  globalForPrisma.prisma ??
  new PrismaClient({
    log: process.env.NODE_ENV !== 'production' 
      ? ['query', 'error', 'warn'] 
      : ['error'], // Only errors in production
  })

if (process.env.NODE_ENV !== 'production') globalForPrisma.prisma = db