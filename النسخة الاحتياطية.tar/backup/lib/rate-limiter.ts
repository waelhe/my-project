/**
 * Rate Limiter - Production-ready with database persistence
 * نظام تحديد معدل الطلبات مع دعم قاعدة البيانات
 * 
 * يستخدم لتقييد عدد الطلبات لكل IP خلال فترة زمنية محددة
 */

import { db } from './db';

interface RateLimitEntry {
  count: number;
  resetTime: number;
}

interface RateLimitResult {
  success: boolean;
  limit: number;
  remaining: number;
  resetTime: number;
  retryAfter?: number;
}

// In-memory fallback for development
// تخزين مؤقت للتطوير فقط
const memoryStore = new Map<string, RateLimitEntry>();

// Cleanup interval to prevent memory leaks
setInterval(() => {
  const now = Date.now();
  for (const [key, entry] of memoryStore.entries()) {
    if (now > entry.resetTime) {
      memoryStore.delete(key);
    }
  }
}, 60 * 1000);

/**
 * Check if database is available
 * التحقق من توفر قاعدة البيانات
 */
async function isDatabaseAvailable(): Promise<boolean> {
  try {
    // Check if RateLimitEntry table exists by trying to count
    await db.rateLimitEntry.count({ take: 1 });
    return true;
  } catch {
    return false;
  }
}

/**
 * Rate Limiter Class with Database Persistence
 * فئة تحديد معدل الطلبات مع دعم قاعدة البيانات
 */
export class RateLimiter {
  private windowMs: number;
  private maxRequests: number;
  private prefix: string;
  private useDatabase: boolean | null = null;

  constructor(options: { windowMs: number; maxRequests: number; prefix?: string }) {
    this.windowMs = options.windowMs;
    this.maxRequests = options.maxRequests;
    this.prefix = options.prefix || 'rl';
  }

  /**
   * Check rate limit for a given key
   * التحقق من حد الطلبات لمفتاح معين
   */
  async check(key: string): Promise<RateLimitResult> {
    const fullKey = `${this.prefix}:${key}`;
    const now = Date.now();

    // Try to use database first (production)
    if (this.useDatabase === null) {
      this.useDatabase = await isDatabaseAvailable();
    }

    if (this.useDatabase) {
      return this.checkDatabase(fullKey, now);
    }

    // Fallback to memory (development)
    return this.checkMemory(fullKey, now);
  }

  /**
   * Check using database (production)
   */
  private async checkDatabase(key: string, now: number): Promise<RateLimitResult> {
    const resetAt = new Date(now + this.windowMs);

    try {
      // Get existing entry
      const existing = await db.rateLimitEntry.findUnique({
        where: { key }
      });

      if (!existing || existing.resetAt < new Date(now)) {
        // Create new entry
        await db.rateLimitEntry.upsert({
          where: { key },
          update: { count: 1, resetAt },
          create: { key, count: 1, resetAt }
        });

        return {
          success: true,
          limit: this.maxRequests,
          remaining: this.maxRequests - 1,
          resetTime: now + this.windowMs
        };
      }

      if (existing.count >= this.maxRequests) {
        return {
          success: false,
          limit: this.maxRequests,
          remaining: 0,
          resetTime: existing.resetAt.getTime(),
          retryAfter: Math.ceil((existing.resetAt.getTime() - now) / 1000)
        };
      }

      // Increment count
      await db.rateLimitEntry.update({
        where: { key },
        data: { count: { increment: 1 } }
      });

      return {
        success: true,
        limit: this.maxRequests,
        remaining: this.maxRequests - existing.count - 1,
        resetTime: existing.resetAt.getTime()
      };
    } catch (error) {
      // Fallback to memory on database error
      console.error('Rate limiter database error, falling back to memory:', error);
      return this.checkMemory(key, now);
    }
  }

  /**
   * Check using memory (development fallback)
   */
  private checkMemory(key: string, now: number): RateLimitResult {
    const entry = memoryStore.get(key);

    if (!entry || now > entry.resetTime) {
      const newEntry: RateLimitEntry = {
        count: 1,
        resetTime: now + this.windowMs
      };
      memoryStore.set(key, newEntry);

      return {
        success: true,
        limit: this.maxRequests,
        remaining: this.maxRequests - 1,
        resetTime: newEntry.resetTime
      };
    }

    if (entry.count >= this.maxRequests) {
      return {
        success: false,
        limit: this.maxRequests,
        remaining: 0,
        resetTime: entry.resetTime,
        retryAfter: Math.ceil((entry.resetTime - now) / 1000)
      };
    }

    entry.count++;
    memoryStore.set(key, entry);

    return {
      success: true,
      limit: this.maxRequests,
      remaining: this.maxRequests - entry.count,
      resetTime: entry.resetTime
    };
  }

  /**
   * Reset rate limit for a given key
   */
  async reset(key: string): Promise<void> {
    const fullKey = `${this.prefix}:${key}`;
    
    if (this.useDatabase) {
      try {
        await db.rateLimitEntry.delete({ where: { key: fullKey } });
      } catch {
        // Ignore if not found
      }
    }
    
    memoryStore.delete(fullKey);
  }
}

/**
 * Get client IP from request with unique fallback
 * الحصول على عنوان IP للعميل مع fallback فريد
 */
export function getClientIP(request: Request): string {
  // Check various headers for real IP (behind proxy/CDN)
  const forwarded = request.headers.get('x-forwarded-for');
  if (forwarded) {
    // Take first IP in the chain
    const ip = forwarded.split(',')[0].trim();
    if (ip && ip !== 'unknown') {
      return ip;
    }
  }

  const realIP = request.headers.get('x-real-ip');
  if (realIP && realIP !== 'unknown') {
    return realIP;
  }

  // Use a unique identifier based on available headers
  // This prevents all "unknown" IPs from sharing the same rate limit bucket
  const userAgent = request.headers.get('user-agent') || '';
  const acceptLanguage = request.headers.get('accept-language') || '';
  
  // Create a hash-like identifier for unknown IPs
  // إنشاء معرف شبه فريد للـ IPs غير المعروفة
  const fallbackHash = `unknown-${hashString(userAgent + acceptLanguage).slice(0, 8)}`;
  
  return fallbackHash;
}

/**
 * Simple string hash for creating unique identifiers
 */
function hashString(str: string): string {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash;
  }
  return Math.abs(hash).toString(36);
}

/**
 * Create rate limit headers for response
 */
export function createRateLimitHeaders(result: RateLimitResult): HeadersInit {
  return {
    'X-RateLimit-Limit': result.limit.toString(),
    'X-RateLimit-Remaining': result.remaining.toString(),
    'X-RateLimit-Reset': Math.ceil(result.resetTime / 1000).toString(),
    ...(result.retryAfter && { 'Retry-After': result.retryAfter.toString() })
  };
}

// Pre-configured rate limiters for different endpoints

export const tourismAgentLimiter = new RateLimiter({
  windowMs: 60 * 1000, // 1 minute
  maxRequests: 10,
  prefix: 'tourism-agent'
});

export const chatLimiter = new RateLimiter({
  windowMs: 60 * 1000, // 1 minute
  maxRequests: 10,
  prefix: 'chat'
});

export const otpLimiter = new RateLimiter({
  windowMs: 60 * 1000, // 1 minute
  maxRequests: 3,
  prefix: 'otp'
});
