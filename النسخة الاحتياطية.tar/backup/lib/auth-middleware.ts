/**
 * Auth Middleware - Helper functions for API authentication
 * منطقة: ضيف - منصة السياحة والضيافة السورية
 */

import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import {
  validateSession as validateSessionToken,
  deleteSession as removeSession,
  createSession as newSession,
  setSessionCookie as setCookie,
  clearSessionCookie as clearCookie,
  extractClientInfo,
  getSessionExpiration,
  generateSessionToken,
} from '@/lib/session';

export interface AuthUser {
  id: string;
  phone: string;
  name: string | null;
  role: string;
  status: string;
}

export interface AuthResult {
  success: true;
  user: AuthUser;
  session: {
    id: string;
    token: string;
    expiresAt: Date;
    isPersistent: boolean;
  };
}

export interface AuthError {
  success: false;
  error: string;
  statusCode: number;
}

/**
 * Get authenticated user from request
 * يستخرج المستخدم المصادق عليه من الطلب
 */
export async function getAuthUser(request: NextRequest): Promise<AuthResult | AuthError> {
  try {
    const sessionToken = request.cookies.get('session')?.value;

    if (!sessionToken) {
      return {
        success: false,
        error: 'يرجى تسجيل الدخول أولاً',
        statusCode: 401
      };
    }

    // Find session in database
    const session = await db.session.findUnique({
      where: { token: sessionToken },
      include: {
        user: {
          select: {
            id: true,
            phone: true,
            name: true,
            role: true,
            status: true
          }
        }
      }
    });

    if (!session) {
      return {
        success: false,
        error: 'جلسة غير موجودة، يرجى تسجيل الدخول',
        statusCode: 401
      };
    }

    // Check if session is expired
    if (session.expiresAt < new Date()) {
      // Delete expired session
      await db.session.delete({ where: { id: session.id } });
      
      return {
        success: false,
        error: 'انتهت صلاحية الجلسة، يرجى تسجيل الدخول مجدداً',
        statusCode: 401
      };
    }

    // Check if user is active
    if (session.user.status !== 'ACTIVE') {
      return {
        success: false,
        error: 'الحساب غير مفعل أو معلق',
        statusCode: 403
      };
    }

    // Update last accessed time
    await db.session.update({
      where: { id: session.id },
      data: { lastAccessed: new Date() }
    });

    return {
      success: true,
      user: session.user,
      session: {
        id: session.id,
        token: session.token,
        expiresAt: session.expiresAt,
        isPersistent: session.isPersistent
      }
    };

  } catch (error) {
    console.error('Auth middleware error:', error);
    return {
      success: false,
      error: 'حدث خطأ في التحقق من الهوية',
      statusCode: 500
    };
  }
}

/**
 * Require authentication - returns user or error response
 * يتطلب المصادقة - يعيد المستخدم أو استجابة الخطأ
 */
export async function requireAuth(request: NextRequest): Promise<{ user: AuthUser; session: AuthResult['session'] } | NextResponse> {
  const authResult = await getAuthUser(request);

  if (!authResult.success) {
    return NextResponse.json(
      { error: authResult.error },
      { status: authResult.statusCode }
    );
  }

  return {
    user: authResult.user,
    session: authResult.session
  };
}

/**
 * Require specific role - returns user or error response
 * يتطلب دور محدد - يعيد المستخدم أو استجابة الخطأ
 */
export async function requireRole(
  request: NextRequest, 
  allowedRoles: string[]
): Promise<{ user: AuthUser; session: AuthResult['session'] } | NextResponse> {
  const authResult = await getAuthUser(request);

  if (!authResult.success) {
    return NextResponse.json(
      { error: authResult.error },
      { status: authResult.statusCode }
    );
  }

  if (!allowedRoles.includes(authResult.user.role)) {
    return NextResponse.json(
      { error: 'غير مصرح لك بهذا الإجراء' },
      { status: 403 }
    );
  }

  return {
    user: authResult.user,
    session: authResult.session
  };
}

/**
 * Require Host role - convenience function
 * يتطلب دور المضيف - دالة مساعدة
 */
export async function requireHost(request: NextRequest): Promise<{ user: AuthUser; session: AuthResult['session'] } | NextResponse> {
  return requireRole(request, ['HOST', 'ADMIN', 'SUPER_ADMIN']);
}

/**
 * Require Admin role - convenience function
 * يتطلب دور المدير - دالة مساعدة
 */
export async function requireAdmin(request: NextRequest): Promise<{ user: AuthUser; session: AuthResult['session'] } | NextResponse> {
  return requireRole(request, ['ADMIN', 'SUPER_ADMIN']);
}

/**
 * Create a new session for user
 * ينشئ جلسة جديدة للمستخدم
 */
export async function createSession(
  userId: string,
  request?: NextRequest,
  isPersistent: boolean = false
): Promise<{ token: string; expiresAt: Date }> {
  return newSession(userId, request || {} as NextRequest, isPersistent);
}

/**
 * Delete session (logout)
 * يحذف الجلسة (تسجيل الخروج)
 */
export async function deleteSession(token: string): Promise<void> {
  return removeSession(token);
}

/**
 * Clean up expired sessions (can be run as cron job)
 * ينظف الجلسات المنتهية (يمكن تشغيله كوظيفة مجدولة)
 */
export async function cleanupExpiredSessions(): Promise<number> {
  const result = await db.session.deleteMany({
    where: {
      expiresAt: { lt: new Date() }
    }
  });
  return result.count;
}

/**
 * Set session cookie on response
 * يضبط ملف تعريف الجلسة على الاستجابة
 */
export function setSessionCookie(
  response: NextResponse, 
  token: string, 
  expiresAt: Date
): void {
  setCookie(response, token, expiresAt);
}

/**
 * Clear session cookie on response
 * يحذف ملف تعريف الجلسة من الاستجابة
 */
export function clearSessionCookie(response: NextResponse): void {
  clearCookie(response);
}
