/**
 * Session Management Utilities
 * نظام إدارة الجلسات لمشروع "ضيف"
 */

import { randomUUID } from 'crypto';
import { cookies } from 'next/headers';
import { db } from './db';
import { NextRequest, NextResponse } from 'next/server';

// Session configuration
export const SESSION_CONFIG = {
  // Regular session: 24 hours
  REGULAR_DURATION_HOURS: 24,
  // Persistent session ("Remember me"): 30 days
  PERSISTENT_DURATION_DAYS: 30,
  // Cookie name
  COOKIE_NAME: 'session',
  // Cookie settings
  COOKIE_OPTIONS: {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax' as const,
    path: '/',
  },
};

/**
 * Generate a secure session token
 */
export function generateSessionToken(): string {
  return randomUUID() + '-' + Date.now().toString(36);
}

/**
 * Calculate session expiration date
 */
export function getSessionExpiration(isPersistent: boolean = false): Date {
  if (isPersistent) {
    // 30 days for "remember me"
    return new Date(Date.now() + SESSION_CONFIG.PERSISTENT_DURATION_DAYS * 24 * 60 * 60 * 1000);
  }
  // 24 hours for regular session
  return new Date(Date.now() + SESSION_CONFIG.REGULAR_DURATION_HOURS * 60 * 60 * 1000);
}

/**
 * Extract client info from request
 */
export function extractClientInfo(request: NextRequest) {
  const userAgent = request.headers.get('user-agent') || undefined;
  const ipAddress = request.headers.get('x-forwarded-for')?.split(',')[0]?.trim() || 
                    request.headers.get('x-real-ip') || 
                    undefined;
  
  // Detect device type from user agent
  let deviceInfo = 'unknown';
  if (userAgent) {
    if (/mobile/i.test(userAgent)) {
      deviceInfo = 'mobile';
    } else if (/tablet/i.test(userAgent)) {
      deviceInfo = 'tablet';
    } else {
      deviceInfo = 'desktop';
    }
  }
  
  return { userAgent, ipAddress, deviceInfo };
}

/**
 * Create a new session
 */
export async function createSession(
  userId: string,
  request: NextRequest,
  isPersistent: boolean = false
): Promise<{ token: string; expiresAt: Date }> {
  const token = generateSessionToken();
  const expiresAt = getSessionExpiration(isPersistent);
  const { userAgent, ipAddress, deviceInfo } = extractClientInfo(request);
  
  await db.session.create({
    data: {
      token,
      userId,
      expiresAt,
      isPersistent,
      userAgent,
      ipAddress,
      deviceInfo,
      lastAccessed: new Date(),
    },
  });
  
  return { token, expiresAt };
}

/**
 * Validate a session token
 */
export async function validateSession(token: string): Promise<{
  valid: boolean;
  user?: {
    id: string;
    phone: string;
    name: string | null;
    role: string;
    email: string | null;
    avatar: string | null;
  };
  session?: {
    id: string;
    isPersistent: boolean;
  };
}> {
  if (!token) {
    return { valid: false };
  }
  
  const session = await db.session.findUnique({
    where: { token },
    include: {
      user: {
        select: {
          id: true,
          phone: true,
          name: true,
          role: true,
          email: true,
          avatar: true,
        },
      },
    },
  });
  
  if (!session) {
    return { valid: false };
  }
  
  // Check if session is expired
  if (session.expiresAt < new Date()) {
    // Clean up expired session
    await db.session.delete({ where: { id: session.id } });
    return { valid: false };
  }
  
  // Update last accessed time
  await db.session.update({
    where: { id: session.id },
    data: { lastAccessed: new Date() },
  });
  
  return {
    valid: true,
    user: session.user,
    session: {
      id: session.id,
      isPersistent: session.isPersistent,
    },
  };
}

/**
 * Delete a session (logout)
 */
export async function deleteSession(token: string): Promise<void> {
  if (token) {
    await db.session.deleteMany({ where: { token } }).catch(() => {});
  }
}

/**
 * Delete all sessions for a user (logout from all devices)
 */
export async function deleteAllUserSessions(userId: string): Promise<void> {
  await db.session.deleteMany({ where: { userId } });
}

/**
 * Clean up expired sessions (can be run as a cron job)
 */
export async function cleanupExpiredSessions(): Promise<number> {
  const result = await db.session.deleteMany({
    where: {
      expiresAt: { lt: new Date() },
    },
  });
  return result.count;
}

/**
 * Get session token from request cookies
 */
export function getSessionToken(request: NextRequest): string | undefined {
  return request.cookies.get(SESSION_CONFIG.COOKIE_NAME)?.value;
}

/**
 * Set session cookie in response
 */
export function setSessionCookie(
  response: NextResponse,
  token: string,
  expiresAt: Date
): void {
  const maxAge = Math.floor((expiresAt.getTime() - Date.now()) / 1000);
  
  response.cookies.set(SESSION_CONFIG.COOKIE_NAME, token, {
    ...SESSION_CONFIG.COOKIE_OPTIONS,
    maxAge: maxAge > 0 ? maxAge : 0,
  });
}

/**
 * Clear session cookie in response
 */
export function clearSessionCookie(response: NextResponse): void {
  response.cookies.delete(SESSION_CONFIG.COOKIE_NAME);
}

/**
 * Get current user from session (for server components)
 */
export async function getCurrentUser(): Promise<{
  id: string;
  phone: string;
  name: string | null;
  role: string;
  email: string | null;
  avatar: string | null;
} | null> {
  const cookieStore = await cookies();
  const token = cookieStore.get(SESSION_CONFIG.COOKIE_NAME)?.value;
  
  if (!token) {
    return null;
  }
  
  const { valid, user } = await validateSession(token);
  return valid && user ? user : null;
}

/**
 * Get current session info (for server components)
 */
export async function getCurrentSession(): Promise<{
  isAuthenticated: boolean;
  user?: {
    id: string;
    phone: string;
    name: string | null;
    role: string;
    email: string | null;
    avatar: string | null;
  };
}> {
  const user = await getCurrentUser();
  
  return {
    isAuthenticated: !!user,
    user: user || undefined,
  };
}
