'use client'

import { useState } from 'react'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { InputOTP, InputOTPGroup, InputOTPSlot } from "@/components/ui/input-otp"
import { Phone, ArrowRight, Loader2 } from "lucide-react"
import { toast } from "sonner"

interface AuthModalProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  defaultRole?: 'GUEST' | 'HOST'
}

type Step = 'phone' | 'otp' | 'name'

export function AuthModal({ open, onOpenChange, defaultRole = 'GUEST' }: AuthModalProps) {
  const [step, setStep] = useState<Step>('phone')
  const [phone, setPhone] = useState('')
  const [otp, setOtp] = useState('')
  const [name, setName] = useState('')
  const [loading, setLoading] = useState(false)
  const [role] = useState(defaultRole)

  const handleSendOTP = async () => {
    if (!phone.match(/^(\+963|0)?9\d{8}$/)) {
      toast.error('رقم الهاتف غير صالح')
      return
    }

    setLoading(true)
    try {
      const res = await fetch('/api/auth/send-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phone, purpose: 'login' })
      })

      const data = await res.json()

      if (!res.ok) {
        toast.error(data.error || 'حدث خطأ')
        return
      }

      toast.success('تم إرسال رمز التحقق')
      setStep('otp')
    } catch (error) {
      toast.error('حدث خطأ، يرجى المحاولة لاحقاً')
    } finally {
      setLoading(false)
    }
  }

  const handleVerifyOTP = async () => {
    if (otp.length !== 6) {
      toast.error('يرجى إدخال الرمز كاملاً')
      return
    }

    setLoading(true)
    try {
      const res = await fetch('/api/auth/verify-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phone, code: otp, name, role })
      })

      const data = await res.json()

      if (!res.ok) {
        toast.error(data.error || 'رمز التحقق غير صحيح')
        return
      }

      toast.success('تم تسجيل الدخول بنجاح')
      onOpenChange(false)
      // Refresh the page to update auth state
      window.location.reload()
    } catch (error) {
      toast.error('حدث خطأ، يرجى المحاولة لاحقاً')
    } finally {
      setLoading(false)
    }
  }

  const handleCompleteName = async () => {
    if (!name.trim()) {
      toast.error('يرجى إدخال اسمك')
      return
    }
    await handleVerifyOTP()
  }

  const resetState = () => {
    setStep('phone')
    setPhone('')
    setOtp('')
    setName('')
    setLoading(false)
  }

  const handleOpenChange = (open: boolean) => {
    if (!open) resetState()
    onOpenChange(open)
  }

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold text-center">
            {step === 'phone' && 'تسجيل الدخول'}
            {step === 'otp' && 'تحقق من الرقم'}
            {step === 'name' && 'أكمل ملفك'}
          </DialogTitle>
          <DialogDescription className="text-center">
            {step === 'phone' && 'أدخل رقم هاتفك لتسجيل الدخول أو إنشاء حساب'}
            {step === 'otp' && `أدخل الرمز المرسل إلى ${phone}`}
            {step === 'name' && 'أدخل اسمك لإكمال التسجيل'}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6 pt-4">
          {/* Step 1: Phone Input */}
          {step === 'phone' && (
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="phone">رقم الهاتف</Label>
                <div className="relative">
                  <Phone className="absolute right-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
                  <Input
                    id="phone"
                    type="tel"
                    placeholder="09XXXXXXXX"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="h-12 pr-10 text-lg"
                    dir="ltr"
                  />
                </div>
              </div>
              <Button
                onClick={handleSendOTP}
                disabled={loading || !phone}
                className="w-full h-12 bg-amber-500 hover:bg-amber-600 text-white"
              >
                {loading ? (
                  <Loader2 className="h-5 w-5 animate-spin" />
                ) : (
                  <>
                    إرسال رمز التحقق
                    <ArrowRight className="mr-2 h-5 w-5" />
                  </>
                )}
              </Button>
            </div>
          )}

          {/* Step 2: OTP Input */}
          {step === 'otp' && (
            <div className="space-y-4">
              <div className="flex justify-center">
                <InputOTP
                  maxLength={6}
                  value={otp}
                  onChange={setOtp}
                >
                  <InputOTPGroup className="gap-2">
                    <InputOTPSlot index={0} className="w-12 h-14 text-xl" />
                    <InputOTPSlot index={1} className="w-12 h-14 text-xl" />
                    <InputOTPSlot index={2} className="w-12 h-14 text-xl" />
                    <InputOTPSlot index={3} className="w-12 h-14 text-xl" />
                    <InputOTPSlot index={4} className="w-12 h-14 text-xl" />
                    <InputOTPSlot index={5} className="w-12 h-14 text-xl" />
                  </InputOTPGroup>
                </InputOTP>
              </div>
              
              <div className="text-center">
                <Button
                  variant="link"
                  onClick={handleSendOTP}
                  disabled={loading}
                  className="text-amber-600"
                >
                  إعادة إرسال الرمز
                </Button>
              </div>

              <Button
                onClick={handleVerifyOTP}
                disabled={loading || otp.length !== 6}
                className="w-full h-12 bg-amber-500 hover:bg-amber-600 text-white"
              >
                {loading ? (
                  <Loader2 className="h-5 w-5 animate-spin" />
                ) : (
                  <>
                    تحقق
                    <ArrowRight className="mr-2 h-5 w-5" />
                  </>
                )}
              </Button>

              <Button
                variant="ghost"
                onClick={() => setStep('phone')}
                className="w-full"
              >
                العودة
              </Button>
            </div>
          )}

          {/* Step 3: Name Input (for new users) */}
          {step === 'name' && (
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name">الاسم</Label>
                <Input
                  id="name"
                  type="text"
                  placeholder="أدخل اسمك الكامل"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="h-12 text-lg"
                />
              </div>
              <Button
                onClick={handleCompleteName}
                disabled={loading || !name.trim()}
                className="w-full h-12 bg-amber-500 hover:bg-amber-600 text-white"
              >
                {loading ? (
                  <Loader2 className="h-5 w-5 animate-spin" />
                ) : (
                  <>
                    إكمال التسجيل
                    <ArrowRight className="mr-2 h-5 w-5" />
                  </>
                )}
              </Button>
            </div>
          )}
        </div>

        <div className="text-center text-xs text-gray-500 mt-4">
          بالمتابعة، أنت توافق على{' '}
          <a href="#" className="text-amber-600 hover:underline">شروط الاستخدام</a>
          {' '}و{' '}
          <a href="#" className="text-amber-600 hover:underline">سياسة الخصوصية</a>
        </div>
      </DialogContent>
    </Dialog>
  )
}
