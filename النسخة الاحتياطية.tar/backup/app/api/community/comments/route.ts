import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getClientIP, RateLimiter, createRateLimitHeaders } from '@/lib/rate-limiter';

const commentLimiter = new RateLimiter({
  windowMs: 60 * 1000, // 1 minute
  maxRequests: 10,
  prefix: 'community-comment'
});

/**
 * GET /api/community/comments
 * جلب التعليقات
 */
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const postId = searchParams.get('postId');
    const parentId = searchParams.get('parentId');
    const limit = parseInt(searchParams.get('limit') || '50');
    const offset = parseInt(searchParams.get('offset') || '0');

    if (!postId) {
      return NextResponse.json(
        { error: 'معرف المشاركة مطلوب' },
        { status: 400 }
      );
    }

    const where: any = { 
      postId,
      isHidden: false,
      parentId: parentId || null // null للحصول على التعليقات الرئيسية فقط
    };

    const comments = await db.communityComment.findMany({
      where,
      orderBy: { createdAt: 'asc' },
      take: limit,
      skip: offset,
      include: {
        author: {
          select: {
            id: true,
            name: true,
            nameAr: true,
            avatar: true,
            role: true
          }
        },
        _count: {
          select: { replies: true, likes: true }
        }
      }
    });

    // Format comments
    const formattedComments = comments.map(comment => ({
      id: comment.id,
      contentAr: comment.contentAr,
      contentEn: comment.contentEn,
      isEdited: comment.isEdited,
      likeCount: comment.likeCount,
      createdAt: comment.createdAt,
      author: comment.author,
      _count: comment._count
    }));

    return NextResponse.json({
      success: true,
      comments: formattedComments
    });

  } catch (error) {
    console.error('Get comments error:', error);
    return NextResponse.json(
      { error: 'حدث خطأ في جلب التعليقات' },
      { status: 500 }
    );
  }
}

/**
 * POST /api/community/comments
 * إنشاء تعليق جديد
 */
export async function POST(request: NextRequest) {
  try {
    // Rate limiting
    const clientIP = getClientIP(request);
    const rateLimitResult = await commentLimiter.check(clientIP);
    
    if (!rateLimitResult.success) {
      return NextResponse.json(
        { error: 'طلبات كثيرة جداً، يرجى الانتظار' },
        { 
          status: 429,
          headers: createRateLimitHeaders(rateLimitResult)
        }
      );
    }

    const body = await request.json();
    const { 
      postId, 
      contentAr, 
      contentEn, 
      parentId,
      authorId // سيتم استبداله بالـ user من الجلسة
    } = body;

    if (!contentAr) {
      return NextResponse.json(
        { error: 'محتوى التعليق مطلوب' },
        { status: 400 }
      );
    }

    if (!postId) {
      return NextResponse.json(
        { error: 'معرف المشاركة مطلوب' },
        { status: 400 }
      );
    }

    if (!authorId) {
      return NextResponse.json(
        { error: 'يجب تسجيل الدخول للتعليق' },
        { status: 401 }
      );
    }

    // Create comment
    const comment = await db.communityComment.create({
      data: {
        contentAr,
        contentEn,
        postId,
        authorId,
        parentId
      },
      include: {
        author: {
          select: {
            id: true,
            name: true,
            nameAr: true,
            avatar: true
          }
        }
      }
    });

    // Update post comment count
    await db.communityPost.update({
      where: { id: postId },
      data: { commentCount: { increment: 1 } }
    });

    // Update user reputation
    await db.userReputation.upsert({
      where: { userId: authorId },
      create: {
        userId: authorId,
        communityPoints: 5,
        commentsCount: 1
      },
      update: {
        communityPoints: { increment: 5 },
        commentsCount: { increment: 1 }
      }
    });

    return NextResponse.json({
      success: true,
      comment: {
        id: comment.id,
        contentAr: comment.contentAr,
        contentEn: comment.contentEn,
        createdAt: comment.createdAt,
        author: comment.author
      }
    }, {
      headers: createRateLimitHeaders(rateLimitResult)
    });

  } catch (error) {
    console.error('Create comment error:', error);
    return NextResponse.json(
      { error: 'حدث خطأ في إنشاء التعليق' },
      { status: 500 }
    );
  }
}
