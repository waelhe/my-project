import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

/**
 * GET /api/community/categories
 * جلب أقسام المجتمع
 */
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const includeStats = searchParams.get('includeStats') === 'true';

    // Check if communityCategory model exists
    if (!db.communityCategory) {
      // Return default categories if model doesn't exist
      return NextResponse.json({
        success: true,
        categories: [
          { id: '1', nameAr: 'نصائح السفر', nameEn: 'Travel Tips', descriptionAr: 'نصائح وإرشادات للسفر', icon: 'compass', color: '#3b82f6', isPopular: true, postsCount: 0 },
          { id: '2', nameAr: 'تجارب الضيوف', nameEn: 'Guest Experiences', descriptionAr: 'قصص وتجارب الضيوف', icon: 'heart', color: '#ef4444', isPopular: true, postsCount: 0 },
          { id: '3', nameAr: 'أسئلة وأجوبة', nameEn: 'Q&A', descriptionAr: 'أسئلة واستفسارات', icon: 'help-circle', color: '#f59e0b', isPopular: true, postsCount: 0 },
          { id: '4', nameAr: 'دليل المضيفين', nameEn: 'Host Guide', descriptionAr: 'نصائح للمضيفين', icon: 'home', color: '#10b981', isPopular: false, postsCount: 0 },
        ]
      });
    }

    const categories = await db.communityCategory.findMany({
      where: { isActive: true },
      orderBy: [{ isPopular: 'desc' }, { order: 'asc' }],
      include: includeStats ? {
        _count: {
          select: {
            posts: {
              where: { status: 'PUBLISHED' }
            }
          }
        }
      } : false
    });

    // Format response
    const formattedCategories = categories.map(cat => ({
      id: cat.id,
      nameAr: cat.nameAr,
      nameEn: cat.nameEn,
      descriptionAr: cat.descriptionAr,
      descriptionEn: cat.descriptionEn,
      icon: cat.icon,
      color: cat.color,
      isPopular: cat.isPopular,
      postsCount: includeStats ? cat._count?.posts || 0 : undefined
    }));

    return NextResponse.json({
      success: true,
      categories: formattedCategories
    });

  } catch (error) {
    console.error('Get categories error:', error);
    return NextResponse.json(
      { error: 'حدث خطأ في جلب الأقسام' },
      { status: 500 }
    );
  }
}

/**
 * POST /api/community/categories
 * إنشاء قسم جديد (للمسؤولين)
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { nameAr, nameEn, descriptionAr, descriptionEn, icon, color, order } = body;

    if (!nameAr) {
      return NextResponse.json(
        { error: 'اسم القسم بالعربية مطلوب' },
        { status: 400 }
      );
    }

    if (!db.communityCategory) {
      return NextResponse.json(
        { error: 'النموذج غير متاح حالياً' },
        { status: 503 }
      );
    }

    const category = await db.communityCategory.create({
      data: {
        nameAr,
        nameEn,
        descriptionAr,
        descriptionEn,
        icon,
        color,
        order: order || 0
      }
    });

    return NextResponse.json({
      success: true,
      category
    });

  } catch (error) {
    console.error('Create category error:', error);
    return NextResponse.json(
      { error: 'حدث خطأ في إنشاء القسم' },
      { status: 500 }
    );
  }
}
