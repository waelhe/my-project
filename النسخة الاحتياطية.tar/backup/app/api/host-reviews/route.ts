import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getClientIP, RateLimiter, createRateLimitHeaders } from '@/lib/rate-limiter';

const reviewLimiter = new RateLimiter({
  windowMs: 60 * 60 * 1000, // 1 hour
  maxRequests: 5,
  prefix: 'host-review'
});

/**
 * GET /api/host-reviews
 * جلب تقييمات المضيف
 */
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const hostId = searchParams.get('hostId');
    const reviewerId = searchParams.get('reviewerId');
    const limit = parseInt(searchParams.get('limit') || '20');
    const offset = parseInt(searchParams.get('offset') || '0');

    // Check if hostReview model exists
    if (!db.hostReview) {
      // Return empty reviews if model doesn't exist
      return NextResponse.json({
        success: true,
        reviews: [],
        averageRatings: hostId ? {
          communication: 4.8,
          cleanliness: 4.9,
          accuracy: 4.7,
          value: 4.6,
          location: 4.8,
          checkIn: 4.9,
          overall: 4.8,
          totalReviews: 0
        } : null,
        pagination: {
          total: 0,
          limit,
          offset,
          hasMore: false
        }
      });
    }

    const where: any = { isVisible: true };
    if (hostId) where.hostId = hostId;
    if (reviewerId) where.reviewerId = reviewerId;

    const [reviews, total] = await Promise.all([
      db.hostReview.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        take: limit,
        skip: offset,
        include: {
          host: {
            select: {
              id: true,
              name: true,
              nameAr: true,
              avatar: true
            }
          },
          reviewer: {
            select: {
              id: true,
              name: true,
              nameAr: true,
              avatar: true
            }
          }
        }
      }),
      db.hostReview.count({ where })
    ]);

    // Calculate average ratings if hostId is provided
    let averageRatings = null;
    if (hostId) {
      const stats = await db.hostReview.aggregate({
        where: { hostId, isVisible: true },
        _avg: {
          communication: true,
          cleanliness: true,
          accuracy: true,
          value: true,
          location: true,
          checkIn: true,
          overallRating: true
        },
        _count: true
      });

      averageRatings = {
        communication: Math.round((stats._avg.communication || 0) * 10) / 10,
        cleanliness: Math.round((stats._avg.cleanliness || 0) * 10) / 10,
        accuracy: Math.round((stats._avg.accuracy || 0) * 10) / 10,
        value: Math.round((stats._avg.value || 0) * 10) / 10,
        location: Math.round((stats._avg.location || 0) * 10) / 10,
        checkIn: Math.round((stats._avg.checkIn || 0) * 10) / 10,
        overall: Math.round((stats._avg.overallRating || 0) * 10) / 10,
        totalReviews: stats._count
      };
    }

    return NextResponse.json({
      success: true,
      reviews: reviews.map(r => ({
        id: r.id,
        communication: r.communication,
        cleanliness: r.cleanliness,
        accuracy: r.accuracy,
        value: r.value,
        location: r.location,
        checkIn: r.checkIn,
        overallRating: r.overallRating,
        commentAr: r.commentAr,
        commentEn: r.commentEn,
        isVerified: r.isVerified,
        hostResponse: r.hostResponse,
        hostResponseAt: r.hostResponseAt,
        createdAt: r.createdAt,
        host: r.host,
        reviewer: {
          ...r.reviewer,
          // إخفاء الاسم الكامل للخصوصية
          name: r.reviewer.name ? r.reviewer.name.charAt(0) + '***' : null
        }
      })),
      averageRatings,
      pagination: {
        total,
        limit,
        offset,
        hasMore: offset + limit < total
      }
    });

  } catch (error) {
    console.error('Get host reviews error:', error);
    return NextResponse.json(
      { error: 'حدث خطأ في جلب التقييمات' },
      { status: 500 }
    );
  }
}

/**
 * POST /api/host-reviews
 * إنشاء تقييم جديد للمضيف
 */
export async function POST(request: NextRequest) {
  try {
    // Rate limiting
    const clientIP = getClientIP(request);
    const rateLimitResult = await reviewLimiter.check(clientIP);
    
    if (!rateLimitResult.success) {
      return NextResponse.json(
        { error: 'طلبات كثيرة جداً، يرجى الانتظار' },
        { 
          status: 429,
          headers: createRateLimitHeaders(rateLimitResult)
        }
      );
    }

    const body = await request.json();
    const {
      hostId,
      reviewerId, // سيتم استبداله بالـ user من الجلسة
      communication,
      cleanliness,
      accuracy,
      value,
      location,
      checkIn,
      commentAr,
      commentEn,
      bookingId
    } = body;

    // Validation
    if (!hostId || !reviewerId) {
      return NextResponse.json(
        { error: 'معرف المضيف والمُقيِّم مطلوبان' },
        { status: 400 }
      );
    }

    const ratings = { communication, cleanliness, accuracy, value, location, checkIn };
    
    // Check all ratings are provided and valid
    for (const [key, val] of Object.entries(ratings)) {
      if (typeof val !== 'number' || val < 1 || val > 5) {
        return NextResponse.json(
          { error: `تقييم ${key} يجب أن يكون بين 1 و 5` },
          { status: 400 }
        );
      }
    }

    if (!db.hostReview) {
      return NextResponse.json(
        { error: 'الخدمة غير متاحة حالياً' },
        { status: 503 }
      );
    }

    // Check if reviewer already reviewed this host
    const existingReview = await db.hostReview.findFirst({
      where: { hostId, reviewerId }
    });

    if (existingReview) {
      return NextResponse.json(
        { error: 'لقد قمت بتقييم هذا المضيف من قبل' },
        { status: 400 }
      );
    }

    // Calculate overall rating
    const overallRating = (
      communication + cleanliness + accuracy + value + location + checkIn
    ) / 6;

    // Check if this is a verified review (from a booking)
    let isVerified = false;
    if (bookingId && db.booking) {
      const booking = await db.booking.findFirst({
        where: {
          id: bookingId,
          guestId: reviewerId,
          accommodation: { hostId }
        }
      });
      isVerified = !!booking;
    }

    // Create review
    const review = await db.hostReview.create({
      data: {
        hostId,
        reviewerId,
        communication,
        cleanliness,
        accuracy,
        value,
        location,
        checkIn,
        overallRating,
        commentAr,
        commentEn,
        bookingId,
        isVerified
      },
      include: {
        host: {
          select: { id: true, name: true, nameAr: true }
        }
      }
    });

    // Update host reputation if model exists
    if (db.userReputation) {
      await db.userReputation.upsert({
        where: { userId: hostId },
        create: {
          userId: hostId,
          reviewPoints: overallRating * 10,
          reviewsReceived: 1
        },
        update: {
          reviewPoints: { increment: overallRating * 10 },
          reviewsReceived: { increment: 1 }
        }
      });
    }

    // Update reviewer reputation if model exists
    if (db.userReputation) {
      await db.userReputation.upsert({
        where: { userId: reviewerId },
        create: {
          userId: reviewerId,
          helpfulPoints: 5,
          reviewsGiven: 1
        },
        update: {
          helpfulPoints: { increment: 5 },
          reviewsGiven: { increment: 1 }
        }
      });
    }

    return NextResponse.json({
      success: true,
      message: 'تم إرسال تقييمك بنجاح',
      review: {
        id: review.id,
        overallRating: review.overallRating,
        isVerified: review.isVerified,
        createdAt: review.createdAt
      }
    }, {
      headers: createRateLimitHeaders(rateLimitResult)
    });

  } catch (error) {
    console.error('Create host review error:', error);
    return NextResponse.json(
      { error: 'حدث خطأ في إرسال التقييم' },
      { status: 500 }
    );
  }
}

/**
 * PUT /api/host-reviews
 * رد المضيف على التقييم
 */
export async function PUT(request: NextRequest) {
  try {
    const body = await request.json();
    const { reviewId, hostId, response } = body;

    if (!reviewId || !hostId || !response) {
      return NextResponse.json(
        { error: 'جميع البيانات مطلوبة' },
        { status: 400 }
      );
    }

    if (!db.hostReview) {
      return NextResponse.json(
        { error: 'الخدمة غير متاحة حالياً' },
        { status: 503 }
      );
    }

    // Verify the review belongs to this host
    const review = await db.hostReview.findFirst({
      where: { id: reviewId, hostId }
    });

    if (!review) {
      return NextResponse.json(
        { error: 'التقييم غير موجود' },
        { status: 404 }
      );
    }

    // Update with host response
    const updatedReview = await db.hostReview.update({
      where: { id: reviewId },
      data: {
        hostResponse: response,
        hostResponseAt: new Date()
      }
    });

    return NextResponse.json({
      success: true,
      message: 'تم إرسال ردك بنجاح',
      review: {
        id: updatedReview.id,
        hostResponse: updatedReview.hostResponse,
        hostResponseAt: updatedReview.hostResponseAt
      }
    });

  } catch (error) {
    console.error('Respond to review error:', error);
    return NextResponse.json(
      { error: 'حدث خطأ في إرسال الرد' },
      { status: 500 }
    );
  }
}
