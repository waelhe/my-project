import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

/**
 * GET /api/badges
 * جلب الشارات المتاحة
 */
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const type = searchParams.get('type'); // host, guest, community, special
    const userId = searchParams.get('userId'); // جلب شارات المستخدم

    const where: any = { isActive: true };
    if (type) where.type = type;

    // Get all badges
    const badges = await db.badge.findMany({
      where,
      orderBy: { pointsRequired: 'asc' }
    });

    // If userId provided, include user's earned badges
    let userBadges: string[] = [];
    if (userId) {
      const earnedBadges = await db.userBadge.findMany({
        where: { userId },
        select: { badgeId: true }
      });
      userBadges = earnedBadges.map(b => b.badgeId);
    }

    const formattedBadges = badges.map(badge => ({
      id: badge.id,
      nameAr: badge.nameAr,
      nameEn: badge.nameEn,
      descriptionAr: badge.descriptionAr,
      descriptionEn: badge.descriptionEn,
      icon: badge.icon,
      color: badge.color,
      type: badge.type,
      pointsRequired: badge.pointsRequired,
      earned: userBadges.includes(badge.id)
    }));

    return NextResponse.json({
      success: true,
      badges: formattedBadges
    });

  } catch (error) {
    console.error('Get badges error:', error);
    return NextResponse.json(
      { error: 'حدث خطأ في جلب الشارات' },
      { status: 500 }
    );
  }
}

/**
 * GET /api/badges/user/:userId
 * جلب شارات المستخدم
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { userId } = body;

    if (!userId) {
      return NextResponse.json(
        { error: 'معرف المستخدم مطلوب' },
        { status: 400 }
      );
    }

    const userBadges = await db.userBadge.findMany({
      where: { userId },
      include: {
        badge: true
      },
      orderBy: { earnedAt: 'desc' }
    });

    return NextResponse.json({
      success: true,
      userBadges: userBadges.map(ub => ({
        id: ub.id,
        earnedAt: ub.earnedAt,
        isDisplayed: ub.isDisplayed,
        badge: {
          id: ub.badge.id,
          nameAr: ub.badge.nameAr,
          nameEn: ub.badge.nameEn,
          descriptionAr: ub.badge.descriptionAr,
          icon: ub.badge.icon,
          color: ub.badge.color,
          type: ub.badge.type
        }
      }))
    });

  } catch (error) {
    console.error('Get user badges error:', error);
    return NextResponse.json(
      { error: 'حدث خطأ في جلب شارات المستخدم' },
      { status: 500 }
    );
  }
}
