import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { requireHost } from '@/lib/auth-middleware';
import { 
  createAccommodationSchema, 
  accommodationFilterSchema,
  sanitizeAccommodationData,
  safeParse
} from '@/lib/validations';

/**
 * GET /api/accommodations - List accommodations (Public)
 * الحصول على قائمة الإقامات (عام)
 */
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    
    // Parse and validate query parameters
    const queryParams = {
      cityId: searchParams.get('cityId') || undefined,
      type: searchParams.get('type') || undefined,
      minPrice: searchParams.get('minPrice') ? parseFloat(searchParams.get('minPrice')!) : undefined,
      maxPrice: searchParams.get('maxPrice') ? parseFloat(searchParams.get('maxPrice')!) : undefined,
      guests: searchParams.get('guests') ? parseInt(searchParams.get('guests')!) : undefined,
      limit: parseInt(searchParams.get('limit') || '12'),
      offset: parseInt(searchParams.get('offset') || '0')
    };

    // Validate query parameters
    const parseResult = safeParse(accommodationFilterSchema, queryParams);
    if (!parseResult.success) {
      return parseResult.response;
    }

    const { cityId, type, minPrice, maxPrice, guests, limit, offset } = parseResult.data;

    // Build filter
    const where: Record<string, unknown> = {
      status: 'ACTIVE'
    };

    if (cityId) {
      where.cityId = cityId;
    }

    if (type) {
      where.type = type;
    }

    if (minPrice || maxPrice) {
      where.basePrice = {
        ...(minPrice && { gte: minPrice }),
        ...(maxPrice && { lte: maxPrice })
      };
    }

    if (guests) {
      where.maxGuests = { gte: guests };
    }

    // Fetch accommodations
    const accommodations = await db.accommodation.findMany({
      where,
      take: limit,
      skip: offset,
      orderBy: [
        { rating: 'desc' },
        { createdAt: 'desc' }
      ],
      include: {
        city: true,
        host: {
          select: {
            id: true,
            name: true,
            avatar: true
          }
        }
      }
    });

    // Get total count for pagination
    const total = await db.accommodation.count({ where });

    return NextResponse.json({
      accommodations: accommodations.map(acc => ({
        ...acc,
        amenities: acc.amenities ? JSON.parse(acc.amenities) : [],
        images: acc.images ? JSON.parse(acc.images) : []
      })),
      pagination: {
        total,
        limit,
        offset,
        hasMore: offset + limit < total
      }
    });

  } catch (error) {
    console.error('Get accommodations error:', error);
    return NextResponse.json(
      { error: 'حدث خطأ في جلب البيانات' },
      { status: 500 }
    );
  }
}

/**
 * POST /api/accommodations - Create accommodation (Host only)
 * إنشاء إقامة جديدة (للمضيفين فقط)
 */
export async function POST(request: NextRequest) {
  try {
    // Require host authentication
    const authResult = await requireHost(request);
    
    if (authResult instanceof NextResponse) {
      return authResult; // Return error response
    }

    const { user } = authResult;

    // Parse request body
    let body;
    try {
      body = await request.json();
    } catch {
      return NextResponse.json(
        { error: 'بيانات غير صالحة' },
        { status: 400 }
      );
    }

    // Validate input
    const parseResult = safeParse(createAccommodationSchema, body);
    if (!parseResult.success) {
      return parseResult.response;
    }

    // Sanitize input data
    const validatedData = sanitizeAccommodationData(parseResult.data);

    // Verify city exists
    const city = await db.city.findUnique({
      where: { id: validatedData.cityId }
    });

    if (!city) {
      return NextResponse.json(
        { error: 'المدينة غير موجودة' },
        { status: 400 }
      );
    }

    // Create accommodation
    const accommodation = await db.accommodation.create({
      data: {
        titleAr: validatedData.titleAr,
        titleEn: validatedData.titleEn || null,
        descriptionAr: validatedData.descriptionAr || null,
        descriptionEn: validatedData.descriptionEn || null,
        type: validatedData.type,
        addressAr: validatedData.addressAr || null,
        addressEn: validatedData.addressEn || null,
        cityId: validatedData.cityId,
        latitude: validatedData.latitude || null,
        longitude: validatedData.longitude || null,
        bedrooms: validatedData.bedrooms || 1,
        bathrooms: validatedData.bathrooms || 1,
        maxGuests: validatedData.maxGuests || 2,
        beds: validatedData.beds || 1,
        size: validatedData.size || null,
        basePrice: validatedData.basePrice,
        weekendPrice: validatedData.weekendPrice || null,
        cleaningFee: validatedData.cleaningFee || null,
        securityDeposit: validatedData.securityDeposit || null,
        amenities: validatedData.amenities && validatedData.amenities.length > 0 
          ? JSON.stringify(validatedData.amenities) 
          : null,
        checkInTime: validatedData.checkInTime || '14:00',
        checkOutTime: validatedData.checkOutTime || '12:00',
        minNights: validatedData.minNights || 1,
        maxNights: validatedData.maxNights || null,
        houseRules: validatedData.houseRules && validatedData.houseRules.length > 0 
          ? JSON.stringify(validatedData.houseRules) 
          : null,
        smokingAllowed: validatedData.smokingAllowed || false,
        petsAllowed: validatedData.petsAllowed || false,
        partiesAllowed: validatedData.partiesAllowed || false,
        images: validatedData.images && validatedData.images.length > 0 
          ? JSON.stringify(validatedData.images) 
          : null,
        coverImage: validatedData.coverImage || null,
        hostId: user.id,
        status: 'PENDING_APPROVAL'
      },
      include: {
        city: true
      }
    });

    return NextResponse.json({
      success: true,
      message: 'تم إنشاء الإعلان بنجاح وهو قيد المراجعة',
      accommodation: {
        ...accommodation,
        amenities: accommodation.amenities ? JSON.parse(accommodation.amenities) : [],
        images: accommodation.images ? JSON.parse(accommodation.images) : []
      }
    }, { status: 201 });

  } catch (error) {
    console.error('Create accommodation error:', error);
    return NextResponse.json(
      { error: 'حدث خطأ في إنشاء الإعلان' },
      { status: 500 }
    );
  }
}
