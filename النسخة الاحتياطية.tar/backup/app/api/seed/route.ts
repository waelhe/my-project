import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

// POST /api/seed - Seed initial data
// ⚠️ This endpoint is only available in development mode
export async function POST() {
  // Security: Only allow in development
  if (process.env.NODE_ENV === 'production') {
    return NextResponse.json(
      { error: 'هذا الإجراء غير متاح في بيئة الإنتاج' },
      { status: 403 }
    );
  }

  try {
    // Check if already seeded
    const existingCities = await db.city.count();
    if (existingCities > 0) {
      return NextResponse.json({ 
        message: 'Database already seeded',
        cities: existingCities 
      });
    }

    // Create cities
    const cities = await db.city.createMany({
      data: [
        { nameAr: 'دمشق', nameEn: 'Damascus', governorate: 'دمشق', isPopular: true },
        { nameAr: 'حلب', nameEn: 'Aleppo', governorate: 'حلب', isPopular: true },
        { nameAr: 'اللاذقية', nameEn: 'Lattakia', governorate: 'اللاذقية', isPopular: true },
        { nameAr: 'طرطوس', nameEn: 'Tartus', governorate: 'طرطوس', isPopular: true },
        { nameAr: 'حمص', nameEn: 'Homs', governorate: 'حمص', isPopular: true },
        { nameAr: 'حماة', nameEn: 'Hama', governorate: 'حماة', isPopular: false },
        { nameAr: 'تدمر', nameEn: 'Palmyra', governorate: 'حمص', isPopular: true },
        { nameAr: 'معلولا', nameEn: 'Maaloula', governorate: 'ريف دمشق', isPopular: true },
        { nameAr: 'صافيتا', nameEn: 'Safita', governorate: 'طرطوس', isPopular: false },
        { nameAr: 'السويداء', nameEn: 'Suwayda', governorate: 'السويداء', isPopular: false },
        { nameAr: 'درعا', nameEn: 'Daraa', governorate: 'درعا', isPopular: false },
        { nameAr: 'القامشلي', nameEn: 'Qamishli', governorate: 'الحسكة', isPopular: false },
        { nameAr: 'دير الزور', nameEn: 'Deir ez-Zor', governorate: 'دير الزور', isPopular: false },
        { nameAr: 'إدلب', nameEn: 'Idlib', governorate: 'إدلب', isPopular: false },
        { nameAr: 'الرقة', nameEn: 'Raqqa', governorate: 'الرقة', isPopular: false },
      ]
    });

    // Create a demo host user
    const host = await db.user.create({
      data: {
        phone: '+963999999999',
        name: 'مضيف تجريبي',
        nameAr: 'مضيف تجريبي',
        role: 'HOST',
        status: 'ACTIVE',
        isVerified: true
      }
    });

    // Create community categories
    await db.communityCategory.createMany({
      data: [
        { 
          nameAr: 'نصائح السفر', 
          nameEn: 'Travel Tips', 
          descriptionAr: 'نصائح وإرشادات للسفر في سوريا',
          icon: 'compass',
          color: '#3b82f6',
          order: 1,
          isPopular: true
        },
        { 
          nameAr: 'تجارب الضيوف', 
          nameEn: 'Guest Experiences', 
          descriptionAr: 'قصص وتجارب الضيوف مع المضيفين',
          icon: 'heart',
          color: '#ef4444',
          order: 2,
          isPopular: true
        },
        { 
          nameAr: 'أسئلة وأجوبة', 
          nameEn: 'Q&A', 
          descriptionAr: 'أسئلة واستفسارات حول السياحة في سوريا',
          icon: 'help-circle',
          color: '#f59e0b',
          order: 3,
          isPopular: true
        },
        { 
          nameAr: 'دليل المضيفين', 
          nameEn: 'Host Guide', 
          descriptionAr: 'نصائح للمضيفين وتحسين تجربة الضيوف',
          icon: 'home',
          color: '#10b981',
          order: 4,
          isPopular: false
        },
        { 
          nameAr: 'أخبار وتحديثات', 
          nameEn: 'News & Updates', 
          descriptionAr: 'أخبار المنصة والتحديثات الجديدة',
          icon: 'newspaper',
          color: '#8b5cf6',
          order: 5,
          isPopular: false
        }
      ]
    });

    // Create badges
    await db.badge.createMany({
      data: [
        // Host badges
        { 
          nameAr: 'مضيف جديد', 
          nameEn: 'New Host',
          descriptionAr: 'انضم حديثاً كمضيف',
          icon: '🌟',
          color: '#3b82f6',
          type: 'host',
          pointsRequired: 0
        },
        { 
          nameAr: 'مضيف موثوق', 
          nameEn: 'Trusted Host',
          descriptionAr: 'حصل على 5 تقييمات إيجابية',
          icon: '✓',
          color: '#10b981',
          type: 'host',
          pointsRequired: 50
        },
        { 
          nameAr: 'مضيف مميز', 
          nameEn: 'Super Host',
          descriptionAr: 'تقييم 4.8+ مع 10+ تقييمات',
          icon: '🏆',
          color: '#f59e0b',
          type: 'host',
          pointsRequired: 200
        },
        { 
          nameAr: 'مضيف ذهبي', 
          nameEn: 'Gold Host',
          descriptionAr: 'تقييم 4.9+ مع 50+ تقييمات',
          icon: '👑',
          color: '#eab308',
          type: 'host',
          pointsRequired: 500
        },
        // Guest badges
        { 
          nameAr: 'ضيف جديد', 
          nameEn: 'New Guest',
          descriptionAr: 'انضم حديثاً للمنصة',
          icon: '👋',
          color: '#6b7280',
          type: 'guest',
          pointsRequired: 0
        },
        { 
          nameAr: 'مسافر نشط', 
          nameEn: 'Active Traveler',
          descriptionAr: 'أكمل 3 حجوزات',
          icon: '✈️',
          color: '#3b82f6',
          type: 'guest',
          pointsRequired: 30
        },
        { 
          nameAr: 'مقيّم ممتاز', 
          nameEn: 'Great Reviewer',
          descriptionAr: 'كتب 5 تقييمات مفيدة',
          icon: '⭐',
          color: '#f59e0b',
          type: 'guest',
          pointsRequired: 50
        },
        // Community badges
        { 
          nameAr: 'عضو نشط', 
          nameEn: 'Active Member',
          descriptionAr: 'شارك 10 مشاركات في المجتمع',
          icon: '💬',
          color: '#8b5cf6',
          type: 'community',
          pointsRequired: 100
        },
        { 
          nameAr: 'صاحب خبرة', 
          nameEn: 'Experienced',
          descriptionAr: 'حصل على 50 إعجاب على مشاركاته',
          icon: '🎯',
          color: '#ec4899',
          type: 'community',
          pointsRequired: 200
        },
        // Special badges
        { 
          nameAr: 'من مؤسسي المنصة', 
          nameEn: 'Platform Founder',
          descriptionAr: 'من أوائل المستخدمين',
          icon: '💎',
          color: '#6366f1',
          type: 'special',
          pointsRequired: 0
        }
      ]
    });

    // Get Damascus city
    const damascus = await db.city.findFirst({
      where: { nameEn: 'Damascus' }
    });

    const aleppo = await db.city.findFirst({
      where: { nameEn: 'Aleppo' }
    });

    const lattakia = await db.city.findFirst({
      where: { nameEn: 'Lattakia' }
    });

    // Create sample accommodations
    if (damascus && aleppo && lattakia) {
      await db.accommodation.createMany({
        data: [
          {
            titleAr: 'شقة فاخرة في قلب دمشق',
            titleEn: 'Luxury Apartment in Heart of Damascus',
            descriptionAr: 'شقة مفروشة بالكامل مع إطلالة رائعة على المدينة القديمة',
            descriptionEn: 'Fully furnished apartment with stunning view of the Old City',
            type: 'APARTMENT',
            status: 'ACTIVE',
            addressAr: 'الشعلان، دمشق',
            cityId: damascus.id,
            bedrooms: 2,
            bathrooms: 1,
            maxGuests: 4,
            beds: 2,
            basePrice: 150000,
            amenities: JSON.stringify(['wifi', 'ac', 'parking', 'kitchen', 'tv']),
            hostId: host.id,
            images: JSON.stringify([
              'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?q=80&w=800',
              'https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?q=80&w=800'
            ]),
            coverImage: 'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?q=80&w=800',
            rating: 4.9,
            reviewCount: 128
          },
          {
            titleAr: 'غرفة في فندق تاريخي',
            titleEn: 'Room in Historic Hotel',
            descriptionAr: 'فندق بارون التاريخي - تجربة فريدة في قلب حلب القديمة',
            descriptionEn: 'Historic Baron Hotel - Unique experience in Old Aleppo',
            type: 'HOTEL',
            status: 'ACTIVE',
            addressAr: 'الجميلية، حلب',
            cityId: aleppo.id,
            bedrooms: 1,
            bathrooms: 1,
            maxGuests: 2,
            beds: 1,
            basePrice: 280000,
            amenities: JSON.stringify(['wifi', 'breakfast', 'restaurant', 'room-service']),
            hostId: host.id,
            images: JSON.stringify([
              'https://images.unsplash.com/photo-1566073771259-6a8506099945?q=80&w=800'
            ]),
            coverImage: 'https://images.unsplash.com/photo-1566073771259-6a8506099945?q=80&w=800',
            rating: 4.7,
            reviewCount: 89
          },
          {
            titleAr: 'شاليه على شاطئ اللاذقية',
            titleEn: 'Chalet on Lattakia Beach',
            descriptionAr: 'شاليه مباشر على البحر مع خاصية خروج للشاطئ',
            descriptionEn: 'Beachfront chalet with direct beach access',
            type: 'CHALET',
            status: 'ACTIVE',
            addressAr: 'شاطئ السيادر، اللاذقية',
            cityId: lattakia.id,
            bedrooms: 3,
            bathrooms: 2,
            maxGuests: 6,
            beds: 4,
            basePrice: 200000,
            amenities: JSON.stringify(['wifi', 'ac', 'parking', 'kitchen', 'sea-view', 'bbq']),
            hostId: host.id,
            images: JSON.stringify([
              'https://images.unsplash.com/photo-1587061949409-02df41d5e562?q=80&w=800'
            ]),
            coverImage: 'https://images.unsplash.com/photo-1587061949409-02df41d5e562?q=80&w=800',
            rating: 4.8,
            reviewCount: 156
          },
          {
            titleAr: 'فيلا عصرية في المزة',
            titleEn: 'Modern Villa in Mezzeh',
            descriptionAr: 'فيلا فاخرة مع حديقة ومسبح خاص',
            descriptionEn: 'Luxury villa with garden and private pool',
            type: 'VILLA',
            status: 'ACTIVE',
            addressAr: 'المزة، دمشق',
            cityId: damascus.id,
            bedrooms: 4,
            bathrooms: 3,
            maxGuests: 8,
            beds: 5,
            basePrice: 350000,
            amenities: JSON.stringify(['wifi', 'ac', 'parking', 'kitchen', 'pool', 'garden']),
            hostId: host.id,
            images: JSON.stringify([
              'https://images.unsplash.com/photo-1631049307264-da0ec9d70304?q=80&w=800'
            ]),
            coverImage: 'https://images.unsplash.com/photo-1631049307264-da0ec9d70304?q=80&w=800',
            rating: 4.9,
            reviewCount: 234
          }
        ]
      });
    }

    return NextResponse.json({
      success: true,
      message: 'Database seeded successfully',
      data: {
        cities: cities.count
      }
    });

  } catch (error) {
    console.error('Seed error:', error);
    return NextResponse.json(
      { error: 'حدث خطأ في تهيئة البيانات' },
      { status: 500 }
    );
  }
}
