import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// Simple in-memory cache for cities
// تخزين مؤقت للمدن لتقليل الاستعلامات
let citiesCache: {
  data: any[];
  timestamp: number;
} | null = null;

const CACHE_TTL = 60 * 1000; // 1 minute cache

// GET /api/cities - List cities with caching
export async function GET(request: NextRequest) {
  try {
    // Check cache first
    const now = Date.now();
    if (citiesCache && (now - citiesCache.timestamp) < CACHE_TTL) {
      return NextResponse.json({ cities: citiesCache.data });
    }

    // Fetch from database with optimized query
    const cities = await db.city.findMany({
      orderBy: [
        { isPopular: 'desc' },
        { nameAr: 'asc' }
      ],
      select: {
        id: true,
        nameAr: true,
        nameEn: true,
        governorate: true,
        isPopular: true,
        image: true,
        _count: {
          select: {
            accommodations: {
              where: { status: 'ACTIVE' }
            }
          }
        }
      }
    });

    // Update cache
    citiesCache = {
      data: cities,
      timestamp: now
    };

    return NextResponse.json({ cities });

  } catch (error) {
    console.error('Get cities error:', error);
    return NextResponse.json(
      { error: 'حدث خطأ في جلب البيانات' },
      { status: 500 }
    );
  }
}
