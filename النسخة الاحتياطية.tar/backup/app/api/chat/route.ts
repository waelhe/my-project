import { NextRequest, NextResponse } from 'next/server';
import ZAI from 'z-ai-web-dev-sdk';
import { db } from '@/lib/db';
import { chatLimiter, getClientIP, createRateLimitHeaders } from '@/lib/rate-limiter';

// Initialize ZAI instance (reuse across requests)
let zaiInstance: Awaited<ReturnType<typeof ZAI.create>> | null = null;

async function getZAI() {
  if (!zaiInstance) {
    zaiInstance = await ZAI.create();
  }
  return zaiInstance;
}

/**
 * Get existing messages from a conversation session
 * جلب الرسائل السابقة من جلسة المحادثة
 */
async function getExistingMessages(sessionId: string): Promise<Array<{ role: string; content: string; timestamp?: string }>> {
  try {
    const conversation = await db.aIConversation.findUnique({
      where: { sessionId }
    });
    
    if (conversation?.messages) {
      return JSON.parse(conversation.messages);
    }
  } catch (error) {
    console.error('Failed to get existing messages:', error);
  }
  
  return [];
}

// System prompt for the Dayf travel assistant
const SYSTEM_PROMPT = `أنت مساعد ذكي لمنصة "ضيف" للسياحة والضيافة في سوريا.

مهمتك:
- مساعدة الضيوف في العثور على أفضل أماكن الإقامة
- تقديم توصيات سياحية مخصصة
- الإجابة على الأسئلة حول المدن السورية ومعالمها
- المساعدة في التخطيط للرحلات والجولات
- تقديم معلومات عن الأسعار والتوفر

معلومات عن سوريا:
- دمشق: العاصمة، المدينة القديمة، سوق الحميدية، الجامع الأموي
- حلب: القلعة، الأسواق القديمة، فندق بارون التاريخي
- اللاذقية: الساحل السوري، شواطئ السيادر والشاطئ الأزرق
- تدمر: المدينة الأثرية، قصر الحير، وادي السياح
- معلولا: القرية التي تتحدث الآرامية، الأديرة

قواعد الرد:
1. أجب دائماً باللغة العربية
2. كن ودوداً ومساعداً
3. قدم معلومات دقيقة ومفيدة
4. إذا لم تعرف الإجابة، اطلب من المستخدم التواصل مع خدمة العملاء
5. استخدم الرموز التعبيرية لجعل الردود أكثر ودية`;

export async function POST(request: NextRequest) {
  try {
    // Rate limiting check - التحقق من حد الطلبات
    const clientIP = getClientIP(request);
    const rateLimitResult = await chatLimiter.check(clientIP);
    
    if (!rateLimitResult.success) {
      return NextResponse.json(
        { 
          error: 'طلبات كثيرة جداً. يرجى الانتظار قبل المحاولة مجدداً',
          retryAfter: rateLimitResult.retryAfter 
        },
        { 
          status: 429,
          headers: createRateLimitHeaders(rateLimitResult)
        }
      );
    }

    const body = await request.json();
    const { message, sessionId, context } = body;

    if (!message) {
      return NextResponse.json(
        { error: 'الرسالة مطلوبة' },
        { status: 400 }
      );
    }

    const zai = await getZAI();

    // Build conversation context
    const messages: Array<{ role: 'assistant' | 'user'; content: string }> = [
      { role: 'assistant', content: SYSTEM_PROMPT }
    ];

    // Add context about accommodations if provided
    if (context?.accommodations) {
      const accContext = `أماكن الإقامة المتاحة حالياً:\n${context.accommodations.map((acc: any) => 
        `- ${acc.titleAr} في ${acc.city?.nameAr || 'سوريا'} - السعر: ${acc.basePrice?.toLocaleString()} ل.س`
      ).join('\n')}`;
      messages.push({ role: 'assistant', content: accContext });
    }

    // Add user message
    messages.push({ role: 'user', content: message });

    // Get AI completion
    const completion = await zai.chat.completions.create({
      messages,
      thinking: { type: 'disabled' }
    });

    const aiResponse = completion.choices[0]?.message?.content;

    if (!aiResponse) {
      throw new Error('لم يتم تلقي رد من الذكاء الاصطناعي');
    }

    // Store conversation in database for persistence
    // حفظ المحادثة في قاعدة البيانات
    if (sessionId) {
      try {
        await db.aIConversation.upsert({
          where: { sessionId },
          create: {
            sessionId,
            messages: JSON.stringify([
              { role: 'user', content: message },
              { role: 'assistant', content: aiResponse }
            ])
          },
          update: {
            messages: JSON.stringify([
              ...(await getExistingMessages(sessionId)),
              { role: 'user', content: message, timestamp: new Date().toISOString() },
              { role: 'assistant', content: aiResponse, timestamp: new Date().toISOString() }
            ])
          }
        });
      } catch (dbError) {
        console.error('Failed to save conversation:', dbError);
        // Don't fail the request if saving fails
      }
    }

    return NextResponse.json({
      success: true,
      response: aiResponse,
      timestamp: new Date().toISOString()
    }, {
      headers: createRateLimitHeaders(rateLimitResult)
    });

  } catch (error) {
    console.error('Chat API error:', error);
    return NextResponse.json(
      { 
        success: false,
        error: 'حدث خطأ في معالجة طلبك. يرجى المحاولة مرة أخرى.',
        details: error instanceof Error ? error.message : 'Unknown error'
      },
      { status: 500 }
    );
  }
}

// GET endpoint to get accommodation context for AI
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const cityId = searchParams.get('cityId');
    const type = searchParams.get('type');

    const where: any = { status: 'ACTIVE' };
    if (cityId) where.cityId = cityId;
    if (type) where.type = type;

    const accommodations = await db.accommodation.findMany({
      where,
      take: 10,
      include: {
        city: true
      }
    });

    return NextResponse.json({
      accommodations: accommodations.map(acc => ({
        id: acc.id,
        titleAr: acc.titleAr,
        type: acc.type,
        basePrice: acc.basePrice,
        city: acc.city,
        rating: acc.rating
      }))
    });

  } catch (error) {
    console.error('Get accommodations context error:', error);
    return NextResponse.json(
      { error: 'حدث خطأ في جلب البيانات' },
      { status: 500 }
    );
  }
}
