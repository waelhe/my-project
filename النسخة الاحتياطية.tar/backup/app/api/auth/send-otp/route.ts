import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { 
  sendOTPSchema, 
  normalizePhone, 
  safeParse 
} from '@/lib/validations';
import { randomInt } from 'crypto';

// Rate limiting configuration
const RATE_LIMIT_WINDOW_MS = 60 * 1000; // 1 minute
const MAX_ATTEMPTS_PER_WINDOW = 3;

/**
 * Generate cryptographically secure 6-digit OTP
 * يولّد رمز تحقق آمن تشفيرياً من 6 أرقام
 */
function generateOTP(): string {
  return randomInt(100000, 1000000).toString();
}

/**
 * POST /api/auth/send-otp - Send OTP code
 * إرسال رمز التحقق
 */
export async function POST(request: NextRequest) {
  try {
    // Parse request body
    let body;
    try {
      body = await request.json();
    } catch {
      return NextResponse.json(
        { error: 'بيانات غير صالحة' },
        { status: 400 }
      );
    }

    // Validate input
    const parseResult = safeParse(sendOTPSchema, body);
    if (!parseResult.success) {
      return parseResult.response;
    }

    const { phone, purpose } = parseResult.data;

    // Normalize phone number
    const normalizedPhone = normalizePhone(phone);

    // Rate limiting: Check for recent OTP requests
    const recentOTPs = await db.oTPCode.findMany({
      where: {
        phone: normalizedPhone,
        createdAt: {
          gte: new Date(Date.now() - RATE_LIMIT_WINDOW_MS)
        }
      }
    });

    if (recentOTPs.length >= MAX_ATTEMPTS_PER_WINDOW) {
      return NextResponse.json(
        { error: 'طلبات كثيرة جداً. يرجى الانتظار دقيقة قبل المحاولة مجدداً' },
        { status: 429 }
      );
    }

    // Check for very recent OTP (minimum 30 seconds between requests)
    const veryRecentOTP = await db.oTPCode.findFirst({
      where: {
        phone: normalizedPhone,
        createdAt: {
          gte: new Date(Date.now() - 30 * 1000) // 30 seconds
        }
      },
      orderBy: { createdAt: 'desc' }
    });

    if (veryRecentOTP) {
      const secondsRemaining = Math.ceil(
        (veryRecentOTP.createdAt.getTime() + 30000 - Date.now()) / 1000
      );
      return NextResponse.json(
        { 
          error: `يرجى الانتظار ${secondsRemaining} ثانية قبل طلب رمز جديد`,
          retryAfter: secondsRemaining
        },
        { status: 429 }
      );
    }

    // Generate new OTP
    const otpCode = generateOTP();
    const expiresAt = new Date(Date.now() + 5 * 60 * 1000); // 5 minutes

    // Invalidate old unused OTPs for this phone
    await db.oTPCode.updateMany({
      where: {
        phone: normalizedPhone,
        used: false
      },
      data: {
        used: true
      }
    });

    // Create new OTP
    await db.oTPCode.create({
      data: {
        phone: normalizedPhone,
        code: otpCode,
        purpose,
        expiresAt
      }
    });

    // In production, send SMS via WhatsApp/SMS provider
    // For development, return the code in response
    const isDevelopment = process.env.NODE_ENV === 'development';

    return NextResponse.json({
      success: true,
      message: 'تم إرسال رمز التحقق بنجاح',
      phone: normalizedPhone,
      ...(isDevelopment && { otp: otpCode }) // Only in development
    });

  } catch {
    return NextResponse.json(
      { error: 'حدث خطأ، يرجى المحاولة لاحقاً' },
      { status: 500 }
    );
  }
}
