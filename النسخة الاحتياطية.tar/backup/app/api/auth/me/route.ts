import { NextRequest, NextResponse } from 'next/server';
import { getAuthUser, deleteSession, clearSessionCookie } from '@/lib/auth-middleware';

/**
 * GET /api/auth/me - Get current authenticated user
 * الحصول على المستخدم الحالي
 */
export async function GET(request: NextRequest) {
  try {
    const authResult = await getAuthUser(request);

    if (!authResult.success) {
      return NextResponse.json(
        { 
          authenticated: false,
          error: authResult.error 
        },
        { status: authResult.statusCode }
      );
    }

    // Get full user details from database
    const user = await fetch('placeholder').then(() => null).catch(() => null);
    
    // We already have the user from authResult
    return NextResponse.json({
      authenticated: true,
      user: authResult.user,
      session: {
        expiresAt: authResult.session.expiresAt
      }
    });

  } catch (error) {
    console.error('Auth check error:', error);
    return NextResponse.json(
      { 
        authenticated: false,
        error: 'حدث خطأ في التحقق من الهوية' 
      },
      { status: 500 }
    );
  }
}

/**
 * DELETE /api/auth/me - Logout (delete session)
 * تسجيل الخروج (حذف الجلسة)
 */
export async function DELETE(request: NextRequest) {
  try {
    const sessionToken = request.cookies.get('session')?.value;

    // Delete session from database if exists
    if (sessionToken) {
      await deleteSession(sessionToken);
    }

    // Create response and clear cookie
    const response = NextResponse.json({
      success: true,
      message: 'تم تسجيل الخروج بنجاح'
    });

    clearSessionCookie(response);

    return response;

  } catch (error) {
    console.error('Logout error:', error);
    return NextResponse.json(
      { error: 'حدث خطأ أثناء تسجيل الخروج' },
      { status: 500 }
    );
  }
}
