import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { 
  verifyOTPSchema, 
  normalizePhone, 
  safeParse 
} from '@/lib/validations';
import { createSession, setSessionCookie } from '@/lib/auth-middleware';

// Maximum OTP attempts before temporary lock
const MAX_OTP_ATTEMPTS = 5;
const LOCK_DURATION_MS = 15 * 60 * 1000; // 15 minutes

/**
 * POST /api/auth/verify-otp - Verify OTP and authenticate user
 * التحقق من الرمز وتسجيل الدخول
 */
export async function POST(request: NextRequest) {
  try {
    // Parse request body
    let body;
    try {
      body = await request.json();
    } catch {
      return NextResponse.json(
        { error: 'بيانات غير صالحة' },
        { status: 400 }
      );
    }

    // Validate input
    const parseResult = safeParse(verifyOTPSchema, body);
    if (!parseResult.success) {
      return parseResult.response;
    }

    const { phone, code, name, role } = parseResult.data;

    // Normalize phone number
    const normalizedPhone = normalizePhone(phone);

    // Check for too many failed attempts (brute force protection)
    // محسّن: نعد المحاولات الفاشلة فقط (used=true AND isSuccess=false)
    const failedAttemptsCount = await db.oTPCode.count({
      where: {
        phone: normalizedPhone,
        used: true,
        isSuccess: false, // فقط المحاولات الفاشلة
        createdAt: {
          gte: new Date(Date.now() - LOCK_DURATION_MS)
        }
      }
    });

    if (failedAttemptsCount >= MAX_OTP_ATTEMPTS) {
      return NextResponse.json(
        { error: 'تم تجاوز عدد المحاولات المسموحة. يرجى المحاولة بعد 15 دقيقة' },
        { status: 429 }
      );
    }

    // Find valid OTP
    const otpRecord = await db.oTPCode.findFirst({
      where: {
        phone: normalizedPhone,
        code,
        used: false,
        expiresAt: {
          gt: new Date()
        }
      },
      orderBy: {
        createdAt: 'desc'
      }
    });

    if (!otpRecord) {
      // Record failed attempt by creating a failed OTP entry
      // تسجيل محاولة فاشلة
      await db.oTPCode.create({
        data: {
          phone: normalizedPhone,
          code: 'FAILED',
          purpose: 'login',
          expiresAt: new Date(),
          used: true,
          isSuccess: false,
          failedAttempts: 1
        }
      });
      
      return NextResponse.json(
        { error: 'رمز التحقق غير صالح أو منتهي الصلاحية' },
        { status: 400 }
      );
    }

    // Mark OTP as used and successful
    await db.oTPCode.update({
      where: { id: otpRecord.id },
      data: { 
        used: true,
        isSuccess: true 
      }
    });

    // Find or create user
    let user = await db.user.findUnique({
      where: { phone: normalizedPhone }
    });

    const isNewUser = !user;

    if (!user) {
      // Create new user
      user = await db.user.create({
        data: {
          phone: normalizedPhone,
          name: name || null,
          role: role as 'GUEST' | 'HOST',
          status: 'ACTIVE',
          isVerified: true,
          lastLoginAt: new Date()
        }
      });
    } else {
      // Update last login and verify
      user = await db.user.update({
        where: { id: user.id },
        data: {
          lastLoginAt: new Date(),
          isVerified: true,
          status: 'ACTIVE',
          // Update name if provided and not already set
          ...(name && !user.name ? { name } : {})
        }
      });
    }

    // Create session
    const { token, expiresAt } = await createSession(user.id, request);

    // Prepare response
    const response = NextResponse.json({
      success: true,
      message: isNewUser ? 'تم إنشاء الحساب وتسجيل الدخول بنجاح' : 'تم تسجيل الدخول بنجاح',
      isNewUser,
      user: {
        id: user.id,
        phone: user.phone,
        name: user.name,
        role: user.role
      }
    });

    // Set session cookie
    setSessionCookie(response, token, expiresAt);

    return response;

  } catch (error) {
    console.error('Verify OTP error:', error);
    return NextResponse.json(
      { error: 'حدث خطأ، يرجى المحاولة لاحقاً' },
      { status: 500 }
    );
  }
}
