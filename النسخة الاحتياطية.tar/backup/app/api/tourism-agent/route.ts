import { NextRequest, NextResponse } from 'next/server';
import ZAI from 'z-ai-web-dev-sdk';
import { SYRIAN_TOURISM_SYSTEM_PROMPT, IMAGE_ANALYSIS_PROMPT, syrianCities, generalTips, tourismTypes } from '@/lib/tourism-agent-prompt';
import { tourismAgentLimiter, getClientIP, createRateLimitHeaders } from '@/lib/rate-limiter';
import { db } from '@/lib/db';

// Initialize ZAI instance
let zaiInstance: Awaited<ReturnType<typeof ZAI.create>> | null = null;

async function getZAI() {
  if (!zaiInstance) {
    zaiInstance = await ZAI.create();
  }
  return zaiInstance;
}

// Conversation message type
type ConversationMessage = { role: 'assistant' | 'user'; content: string };

/**
 * Get conversation from database
 * الحصول على المحادثة من قاعدة البيانات
 */
async function getConversation(sessionId: string): Promise<ConversationMessage[]> {
  try {
    const conversation = await db.aIConversation.findUnique({
      where: { sessionId }
    });
    
    if (conversation) {
      return JSON.parse(conversation.messages);
    }
  } catch (error) {
    console.error('Error getting conversation:', error);
  }
  
  return [];
}

/**
 * Save conversation to database
 * حفظ المحادثة في قاعدة البيانات
 */
async function saveConversation(sessionId: string, messages: ConversationMessage[]): Promise<void> {
  try {
    // Keep only last 20 messages to prevent database bloat
    const trimmedMessages = messages.slice(-20);
    
    await db.aIConversation.upsert({
      where: { sessionId },
      update: { 
        messages: JSON.stringify(trimmedMessages),
        updatedAt: new Date()
      },
      create: { 
        sessionId, 
        messages: JSON.stringify(trimmedMessages)
      }
    });
  } catch (error) {
    console.error('Error saving conversation:', error);
  }
}

/**
 * Delete conversation from database
 * حذف المحادثة من قاعدة البيانات
 */
async function deleteConversation(sessionId: string): Promise<void> {
  try {
    await db.aIConversation.delete({
      where: { sessionId }
    });
  } catch {
    // Ignore if not found
  }
}

export async function POST(request: NextRequest) {
  try {
    // Rate limiting check - التحقق من حد الطلبات
    const clientIP = getClientIP(request);
    const rateLimitResult = await tourismAgentLimiter.check(clientIP);
    
    if (!rateLimitResult.success) {
      return NextResponse.json(
        { 
          error: 'طلبات كثيرة جداً. يرجى الانتظار قبل المحاولة مجدداً',
          retryAfter: rateLimitResult.retryAfter 
        },
        { 
          status: 429,
          headers: createRateLimitHeaders(rateLimitResult)
        }
      );
    }

    const body = await request.json();
    const { 
      message, 
      sessionId, 
      image,
      location,
    } = body;

    if (!message && !image) {
      return NextResponse.json(
        { error: 'الرسالة أو الصورة مطلوبة' },
        { status: 400 }
      );
    }

    const zai = await getZAI();

    // Get conversation history from database
    let history = await getConversation(sessionId);

    // Build context
    let contextualInfo = '';
    
    // Add location context
    if (location?.lat && location?.lng) {
      const nearbyCity = findNearestCity(location.lat, location.lng);
      if (nearbyCity) {
        contextualInfo += `\n[السائح في منطقة: ${nearbyCity}]`;
      }
    }

    // Build messages array
    const messages: Array<{ role: 'assistant' | 'user'; content: string | any[] }> = [
      { role: 'assistant', content: SYRIAN_TOURISM_SYSTEM_PROMPT }
    ];

    // Add conversation history
    for (const msg of history) {
      messages.push({ ...msg } as any);
    }

    // Handle image input with Vision
    if (image) {
      try {
        const visionMessages = [
          {
            role: 'user',
            content: [
              { type: 'text', text: IMAGE_ANALYSIS_PROMPT },
              { type: 'image_url', image_url: { url: image } }
            ]
          }
        ];

        const visionResponse = await zai.chat.completions.createVision({
          model: 'gpt-4o',
          messages: visionMessages as any,
          thinking: { type: 'disabled' }
        });

        const imageAnalysis = visionResponse.choices[0]?.message?.content || '';

        // Use the image analysis in the main conversation
        messages.push({
          role: 'user',
          content: message 
            ? `${message}\n\n[تحليل الصورة: ${imageAnalysis}]${contextualInfo}`
            : `[تحليل الصورة: ${imageAnalysis}]${contextualInfo}`
        } as any);
      } catch (visionError) {
        // Fallback if vision fails
        messages.push({
          role: 'user',
          content: message + contextualInfo
        } as any);
      }
    } else {
      // Text-only message
      messages.push({
        role: 'user',
        content: message + contextualInfo
      } as any);
    }

    // Get AI response
    const response = await zai.chat.completions.create({
      messages: messages as any,
      thinking: { type: 'disabled' }
    });

    const aiResponse = response.choices[0]?.message?.content;

    // Update conversation history
    history.push({ role: 'user', content: message || '[صورة]' });
    history.push({ role: 'assistant', content: aiResponse || '' });
    
    // Save to database (persists across restarts)
    await saveConversation(sessionId, history);

    // Extract suggested actions
    const suggestions = extractSuggestions(aiResponse || '');

    return NextResponse.json({
      success: true,
      response: aiResponse,
      suggestions,
      timestamp: new Date().toISOString()
    }, {
      headers: createRateLimitHeaders(rateLimitResult)
    });

  } catch (error) {
    console.error('Tourism Agent error:', error);
    return NextResponse.json(
      { 
        success: false,
        error: 'حدث خطأ في معالجة طلبك. يرجى المحاولة مرة أخرى.',
        details: error instanceof Error ? error.message : 'Unknown error'
      },
      { status: 500 }
    );
  }
}

// GET endpoint for quick info
export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const city = searchParams.get('city');
  const type = searchParams.get('type');

  try {
    if (city && city.toLowerCase() in syrianCities) {
      const cityData = syrianCities[city.toLowerCase() as keyof typeof syrianCities];
      return NextResponse.json({
        success: true,
        data: cityData
      });
    }

    if (type && type in tourismTypes) {
      return NextResponse.json({
        success: true,
        data: tourismTypes[type as keyof typeof tourismTypes]
      });
    }

    // Return general info
    return NextResponse.json({
      success: true,
      cities: Object.keys(syrianCities),
      tourismTypes: Object.keys(tourismTypes),
      generalTips
    });

  } catch (error) {
    return NextResponse.json(
      { success: false, error: 'حدث خطأ' },
      { status: 500 }
    );
  }
}

// DELETE to clear conversation
export async function DELETE(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const sessionId = searchParams.get('sessionId');
  
  if (sessionId) {
    await deleteConversation(sessionId);
  }
  
  return NextResponse.json({ success: true, message: 'تم مسح المحادثة' });
}

// Helper: Find nearest city
function findNearestCity(lat: number, lng: number): string | null {
  const cities = {
    damascus: { lat: 33.5138, lng: 36.2765, name: 'دمشق' },
    aleppo: { lat: 36.2021, lng: 37.1343, name: 'حلب' },
    lattakia: { lat: 35.5369, lng: 35.7953, name: 'اللاذقية' },
    homs: { lat: 34.7384, lng: 36.7175, name: 'حمص' },
    tartus: { lat: 34.8959, lng: 35.8867, name: 'طرطوس' }
  };

  let nearest: string | null = null;
  let minDistance = Infinity;

  for (const city of Object.values(cities)) {
    const distance = Math.sqrt(
      Math.pow(lat - city.lat, 2) + Math.pow(lng - city.lng, 2)
    );
    if (distance < minDistance) {
      minDistance = distance;
      nearest = city.name;
    }
  }

  return minDistance < 1 ? nearest : null;
}

// Helper: Extract suggested actions from response
function extractSuggestions(response: string): string[] {
  const suggestions: string[] = [];
  const patterns = [/حجز ([^،.\n]+)/gi, /زيارة ([^،.\n]+)/gi, /تجربة ([^،.\n]+)/gi];

  for (const pattern of patterns) {
    const matches = response.matchAll(pattern);
    for (const match of matches) {
      if (match[1] && !suggestions.includes(match[1])) {
        suggestions.push(match[1].trim());
      }
    }
  }

  return suggestions.slice(0, 5);
}
