'use client'

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { 
  Search, 
  MapPin, 
  Star, 
  Heart, 
  Shield, 
  MessageCircle, 
  Phone,
  Home as HomeIcon,
  Car,
  Compass,
  Building2,
  Users,
  CheckCircle2,
  ArrowLeft,
  Menu,
  X,
  Loader2,
  AlertCircle,
  ChevronLeft,
  ChevronRight,
  Sparkles,
  MessageSquare,
  ThumbsUp,
  Eye,
  Clock,
  Award,
  TrendingUp,
  Bookmark,
  Share2,
  MoreHorizontal,
  Send,
  Smile,
  PenSquare,
  Filter,
  SortAsc,
  Plus,
  User,
  Settings,
  LogOut,
  Bell,
  HelpCircle,
  Megaphone,
  BookOpen,
  Lightbulb,
  Calendar,
  Image as ImageIcon,
  Trash2,
  Edit
} from "lucide-react"
import { useState, useEffect, createContext, useContext } from "react"
import { TourismAgent } from "@/components/tourism/TourismAgent"

// ==================== Navigation Context ====================

type PageType = 'home' | 'community' | 'community-post' | 'accommodations' | 'host-reviews' | 'profile' | 'search'

interface NavigationContextType {
  currentPage: PageType
  setCurrentPage: (page: PageType) => void
  pageParams: Record<string, string>
  setPageParams: (params: Record<string, string>) => void
  navigate: (page: PageType, params?: Record<string, string>) => void
}

const NavigationContext = createContext<NavigationContextType | null>(null)

function useNavigation() {
  const context = useContext(NavigationContext)
  if (!context) {
    throw new Error('useNavigation must be used within NavigationProvider')
  }
  return context
}

// ==================== Types ====================

interface City {
  id: string
  nameAr: string
  nameEn: string
  governorate: string
  isPopular: boolean
  image: string | null
  _count: {
    accommodations: number
  }
}

interface Accommodation {
  id: string
  titleAr: string
  titleEn: string | null
  type: string
  addressAr: string | null
  basePrice: number
  rating: number
  reviewCount: number
  coverImage: string | null
  images: string[]
  city: {
    nameAr: string
    nameEn: string
  } | null
}

interface CommunityPost {
  id: string
  titleAr: string
  titleEn: string | null
  contentAr: string
  type: string
  viewCount: number
  likeCount: number
  commentCount: number
  isPinned: boolean
  isFeatured: boolean
  tags: string[]
  createdAt: string
  author: {
    id: string
    name: string | null
    nameAr: string | null
    avatar: string | null
    role: string
  }
  category: {
    id: string
    nameAr: string
    nameEn: string | null
    icon: string | null
    color: string | null
  } | null
  _count: {
    comments: number
    likes: number
  }
}

interface CommunityCategory {
  id: string
  nameAr: string
  nameEn: string | null
  descriptionAr: string | null
  icon: string | null
  color: string | null
  isPopular: boolean
  postsCount?: number
}

interface HostReview {
  id: string
  communication: number
  cleanliness: number
  accuracy: number
  value: number
  location: number
  checkIn: number
  overallRating: number
  commentAr: string | null
  isVerified: boolean
  hostResponse: string | null
  hostResponseAt: string | null
  createdAt: string
  reviewer: {
    id: string
    name: string | null
    nameAr: string | null
    avatar: string | null
  }
  host: {
    id: string
    name: string | null
    nameAr: string | null
    avatar: string | null
  }
}

// ==================== Home View Components ====================

function HeroSection({ totalAccommodations, totalCities, onSearch }: { totalAccommodations: number; totalCities: number; onSearch: () => void }) {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedType, setSelectedType] = useState("all")
  const [currentSlide, setCurrentSlide] = useState(0)
  const [isTransitioning, setIsTransitioning] = useState(false)

  const destinations = [
    { name: "دمشق", description: "أقدم عاصمة مأهولة في العالم - الجامع الأموي والأسواق التاريخية", image: "/images/cities/damascus.png" },
    { name: "حلب", description: "قلعة حلب - من أعظم القلاع في العالم", image: "/images/cities/aleppo.png" },
    { name: "اللاذقية", description: "سحر البحر المتوسط - شواطئ خلابة ومنتجعات سياحية", image: "/images/cities/latakia.png" },
    { name: "تدمر", description: "عروس الصحراء - آثار رومانية تراث عالمي", image: "/images/cities/palmyra.png" },
    { name: "معلولا", description: "دير مار تقلا - مدينة الكهوف والتاريخ", image: "/images/cities/maaloula.png" },
    { name: "حمص", description: "قلعة الحصن - كراك دي شوفالييه العظيمة", image: "/images/cities/homs.png" },
  ]

  const searchTypes = [
    { id: "all", label: "الكل" },
    { id: "hotel", label: "فنادق" },
    { id: "apartment", label: "شقق" },
    { id: "chalet", label: "شاليهات" },
    { id: "tour", label: "جولات" },
  ]

  useEffect(() => {
    const interval = setInterval(() => {
      setIsTransitioning(true)
      setTimeout(() => {
        setCurrentSlide((prev) => (prev + 1) % destinations.length)
        setIsTransitioning(false)
      }, 500)
    }, 5000)
    return () => clearInterval(interval)
  }, [destinations.length])

  const goToSlide = (index: number) => {
    setIsTransitioning(true)
    setTimeout(() => {
      setCurrentSlide(index)
      setIsTransitioning(false)
    }, 500)
  }

  return (
    <section className="relative min-h-[60vh] md:min-h-[75vh] flex items-center justify-center overflow-hidden">
      {destinations.map((dest, index) => (
        <div
          key={index}
          className={`absolute inset-0 bg-cover bg-center transition-all duration-1000 ease-in-out ${
            index === currentSlide ? 'opacity-100 scale-100' : 'opacity-0 scale-105'
          }`}
          style={{ backgroundImage: `url('${dest.image}')` }}
        />
      ))}
      
      <div className="absolute inset-0 bg-gradient-to-b from-black/50 via-black/30 to-black/80" />
      
      <div className="relative z-10 w-full max-w-7xl mx-auto px-4 sm:px-6 text-center pt-8 sm:pt-12">
        <div className="mb-4 sm:mb-6 flex justify-center">
          <div className="bg-white/20 backdrop-blur-md rounded-full px-4 sm:px-6 py-2 sm:py-3 flex items-center gap-2">
            <Sparkles className="w-4 h-4 sm:w-5 sm:h-5 text-amber-400" />
            <span className="text-white text-sm sm:text-base font-medium">منصة ضيف السياحية</span>
          </div>
        </div>
        
        <h2 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-4 sm:mb-6 leading-tight px-2">
          اكتشف جمال <span className="bg-gradient-to-r from-amber-300 to-orange-300 bg-clip-text text-transparent">سوريا</span>
        </h2>
        
        <div className={`mb-4 sm:mb-6 transition-all duration-1000 ${isTransitioning ? 'opacity-0 translate-y-2' : 'opacity-100 translate-y-0'}`}>
          <div className="flex items-center justify-center gap-2 mb-2">
            <MapPin className="w-5 h-5 sm:w-6 sm:h-6 text-amber-300" />
            <span className="text-xl sm:text-2xl md:text-3xl font-bold text-white">{destinations[currentSlide].name}</span>
          </div>
          <p className="text-white/90 text-sm sm:text-base md:text-lg max-w-2xl mx-auto px-4 font-medium leading-relaxed drop-shadow-md">
            {destinations[currentSlide].description}
          </p>
        </div>
        
        <div className="w-full max-w-4xl mx-auto bg-white/95 backdrop-blur-sm rounded-2xl shadow-2xl p-4 sm:p-6 md:p-8 mb-6 sm:mb-8 border border-amber-100">
          <div className="text-center mb-4 sm:mb-6">
            <p className="text-base sm:text-lg md:text-xl text-gray-800 font-semibold leading-relaxed">
              احجز إقامتك وجولاتك بكل أمان مع أفضل المضيفين المحليين
            </p>
            <div className="flex items-center justify-center gap-4 mt-3">
              <div className="flex items-center gap-1.5">
                <Shield className="w-4 h-4 text-emerald-500" />
                <span className="text-sm text-gray-700">حجز آمن</span>
              </div>
              <div className="w-1 h-1 rounded-full bg-emerald-300" />
              <div className="flex items-center gap-1.5">
                <Users className="w-4 h-4 text-emerald-500" />
                <span className="text-sm text-gray-700">مضيفون موثوقون</span>
              </div>
            </div>
          </div>
          
          <div className="flex flex-wrap gap-2 mb-4 sm:mb-6 justify-center">
            {searchTypes.map((type) => (
              <Button
                key={type.id}
                variant={selectedType === type.id ? "default" : "outline"}
                onClick={() => setSelectedType(type.id)}
                className={`rounded-full px-4 sm:px-6 text-sm sm:text-base ${selectedType === type.id ? "bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white border-0" : "border-emerald-200 text-gray-700 hover:bg-emerald-50"}`}
              >
                {type.label}
              </Button>
            ))}
          </div>
          
          <div className="flex flex-col sm:flex-row gap-3 sm:gap-4">
            <div className="flex-1 relative">
              <Search className="absolute right-3 sm:right-4 top-1/2 -translate-y-1/2 text-emerald-500 w-4 h-4 sm:w-5 sm:h-5" />
              <Input
                type="text"
                placeholder="ابحث عن وجهتك..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="h-12 sm:h-14 pr-10 sm:pr-12 text-base sm:text-lg border-emerald-200 rounded-xl focus:border-emerald-500 focus:ring-emerald-500"
              />
            </div>
            <Button size="lg" onClick={onSearch} className="h-12 sm:h-14 px-6 sm:px-8 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white rounded-xl shadow-lg shadow-amber-500/25">
              <Search className="w-4 h-4 sm:w-5 sm:h-5 ml-2" />
              بحث
            </Button>
          </div>
          
          <div className="flex flex-wrap justify-center gap-4 sm:gap-8 mt-4 sm:mt-6 pt-4 sm:pt-6 border-t border-emerald-100">
            <div className="text-center">
              <div className="text-xl sm:text-2xl font-bold text-emerald-600">+{totalAccommodations}</div>
              <div className="text-xs sm:text-sm text-gray-600">مكان إقامة</div>
            </div>
            <div className="text-center">
              <div className="text-xl sm:text-2xl font-bold text-teal-600">+{totalCities}</div>
              <div className="text-xs sm:text-sm text-gray-600">وجهة سياحية</div>
            </div>
            <div className="text-center">
              <div className="text-xl sm:text-2xl font-bold text-amber-500">+10,000</div>
              <div className="text-xs sm:text-sm text-gray-600">ضيف سعيد</div>
            </div>
          </div>
        </div>
      </div>
      
      <button onClick={() => goToSlide((currentSlide - 1 + destinations.length) % destinations.length)} className="absolute right-4 sm:right-8 top-1/2 -translate-y-1/2 z-20 w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-white/10 backdrop-blur-md hover:bg-white/20 flex items-center justify-center transition-all duration-300 group">
        <ChevronRight className="w-5 h-5 sm:w-6 sm:h-6 text-white group-hover:scale-110 transition-transform" />
      </button>
      <button onClick={() => goToSlide((currentSlide + 1) % destinations.length)} className="absolute left-4 sm:left-8 top-1/2 -translate-y-1/2 z-20 w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-white/10 backdrop-blur-md hover:bg-white/20 flex items-center justify-center transition-all duration-300 group">
        <ChevronLeft className="w-5 h-5 sm:w-6 sm:h-6 text-white group-hover:scale-110 transition-transform" />
      </button>
      
      <div className="absolute bottom-6 sm:bottom-8 left-1/2 -translate-x-1/2 z-20 flex items-center gap-2">
        {destinations.map((_, index) => (
          <button key={index} onClick={() => goToSlide(index)} className={`h-2 rounded-full transition-all duration-300 ${index === currentSlide ? 'w-6 bg-white' : 'w-2 bg-white/50 hover:bg-white/70'}`} />
        ))}
      </div>
    </section>
  )
}

function ServicesSection({ onNavigate }: { onNavigate: (page: PageType) => void }) {
  const services = [
    { icon: HomeIcon, title: "السكن", description: "فنادق، شقق مفروشة، شاليهات، ومخيمات في جميع أنحاء سوريا", color: "bg-amber-500", page: 'accommodations' as PageType },
    { icon: Car, title: "النقل", description: "سيارات مع أو بدون سائق، باصات، وخدمات نقل آمنة", color: "bg-emerald-500", page: 'home' as PageType },
    { icon: Compass, title: "السياحة", description: "جولات سياحية، معالم تاريخية، سياحة علاجية وسياحة حرب", color: "bg-sky-500", page: 'home' as PageType },
    { icon: Building2, title: "الأعمال", description: "فرص استثمارية، خدمات للأعمال، وشراكات تجارية", color: "bg-violet-500", page: 'home' as PageType }
  ]

  return (
    <section className="py-20 bg-gradient-to-b from-gray-50 to-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <Badge className="mb-4 bg-amber-100 text-amber-700 hover:bg-amber-100">خدماتنا</Badge>
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">كل ما تحتاجه لرحلتك في مكان واحد</h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">نقدم لك مجموعة متكاملة من الخدمات لتجعل رحلتك إلى سوريا تجربة لا تُنسى</p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {services.map((service, index) => (
            <Card key={index} className="group hover:shadow-xl transition-all duration-300 border-0 bg-white cursor-pointer overflow-hidden" onClick={() => onNavigate(service.page)}>
              <CardContent className="p-6">
                <div className={`w-14 h-14 ${service.color} rounded-2xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                  <service.icon className="w-7 h-7 text-white" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">{service.title}</h3>
                <p className="text-gray-500 text-sm mb-4">{service.description}</p>
                <Button variant="ghost" className="text-amber-600 hover:text-amber-700 p-0 group/btn">
                  اكتشف المزيد
                  <ArrowLeft className="w-4 h-4 mr-2 group-hover/btn:-translate-x-1 transition-transform" />
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}

function PopularDestinations({ cities, loading, error }: { cities: City[]; loading: boolean; error: string | null }) {
  const defaultCityImages: Record<string, string> = {
    "دمشق": "/images/cities/damascus.png",
    "حلب": "/images/cities/aleppo.png",
    "اللاذقية": "/images/cities/latakia.png",
    "طرطوس": "/images/cities/tartus.png",
    "تدمر": "/images/cities/palmyra.png",
    "معلولا": "/images/cities/maaloula.png",
  }
  const defaultImage = "/images/cities/damascus.png"

  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <Badge className="mb-4 bg-sky-100 text-sky-700 hover:bg-sky-100">وجهات مميزة</Badge>
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">اكتشف أجمل الأماكن في سوريا</h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">من المدن التاريخية إلى السواحل الخلابة، سوريا تنتظرك</p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {loading ? (
            [1, 2, 3, 4, 5, 6].map((i) => <div key={i} className="h-64 bg-gray-100 rounded-xl animate-pulse overflow-hidden"><div className="h-full bg-gradient-to-b from-gray-200 to-gray-100" /></div>)
          ) : (
            cities.slice(0, 6).map((city) => (
              <Card key={city.id} className="group overflow-hidden border-0 shadow-lg hover:shadow-2xl transition-all duration-300 cursor-pointer">
                <div className="relative h-64 overflow-hidden bg-gray-200">
                  <img src={city.image || defaultCityImages[city.nameAr] || defaultImage} alt={`صورة لمدينة ${city.nameAr}`} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" loading="lazy" onError={(e) => { e.currentTarget.src = defaultImage }} />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent" />
                  <div className="absolute bottom-0 right-0 left-0 p-6">
                    <h3 className="text-2xl font-bold text-white mb-1">{city.nameAr}</h3>
                    <p className="text-white/80 text-sm mb-2">{city.governorate}</p>
                    <div className="flex items-center text-white/70 text-sm">
                      <HomeIcon className="w-4 h-4 ml-1" />
                      <span>{city._count.accommodations} مكان إقامة</span>
                    </div>
                  </div>
                </div>
              </Card>
            ))
          )}
        </div>
      </div>
    </section>
  )
}

function FeaturedAccommodations({ accommodations, loading, error }: { accommodations: Accommodation[]; loading: boolean; error: string | null }) {
  const typeLabels: Record<string, string> = { HOTEL: "فندق", APARTMENT: "شقة", VILLA: "فيلا", CHALET: "شاليه", CAMP: "مخيم", GUESTHOUSE: "نزل", HOSTEL: "سكن شباب", RESORT: "منتجع" }
  const defaultImage = "/images/default-accommodation.png"

  if (loading) {
    return (
      <section className="py-20 bg-gradient-to-b from-white to-gray-50">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[1, 2, 3, 4].map((i) => <div key={i} className="bg-gray-100 rounded-xl animate-pulse"><div className="h-48 bg-gray-200 rounded-t-xl" /><div className="p-4 space-y-2"><div className="h-4 bg-gray-200 rounded w-3/4" /><div className="h-4 bg-gray-200 rounded w-1/2" /></div></div>)}
          </div>
        </div>
      </section>
    )
  }

  return (
    <section className="py-20 bg-gradient-to-b from-white to-gray-50">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-end mb-12">
          <div>
            <Badge className="mb-4 bg-amber-100 text-amber-700 hover:bg-amber-100">أماكن مميزة</Badge>
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900">أماكن الإقامة الأكثر طلباً</h2>
          </div>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {accommodations.slice(0, 4).map((acc) => {
            const displayImage = acc.coverImage || (acc.images && acc.images[0]) || defaultImage
            const location = acc.city ? `${acc.city.nameAr}${acc.addressAr ? '، ' + acc.addressAr : ''}` : acc.addressAr || 'سوريا'
            
            return (
              <Card key={acc.id} className="group overflow-hidden border-0 shadow-md hover:shadow-xl transition-all duration-300 cursor-pointer bg-white">
                <div className="relative h-48 overflow-hidden">
                  <img src={displayImage} alt={`صورة ${acc.titleAr}`} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" loading="lazy" />
                  {acc.rating >= 4.8 && <Badge className="absolute top-3 right-3 bg-amber-500 text-white">مميز</Badge>}
                  <Button variant="ghost" size="icon" className="absolute top-3 left-3 bg-white/80 hover:bg-white rounded-full h-8 w-8">
                    <Heart className="w-4 h-4 text-gray-600" />
                  </Button>
                </div>
                <CardContent className="p-4">
                  <div className="flex items-center text-sm text-gray-500 mb-2"><MapPin className="w-3 h-3 ml-1" />{location}</div>
                  <h3 className="font-semibold text-gray-900 mb-2 line-clamp-1">{acc.titleAr}</h3>
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center">
                      <Star className="w-4 h-4 text-amber-400 fill-amber-400 ml-1" />
                      <span className="font-medium text-sm">{acc.rating.toFixed(1)}</span>
                      <span className="text-gray-400 text-sm mr-1">({acc.reviewCount})</span>
                    </div>
                    <Badge variant="secondary" className="text-xs">{typeLabels[acc.type] || acc.type}</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="font-bold text-lg text-gray-900">{acc.basePrice.toLocaleString()}</span>
                      <span className="text-gray-500 text-sm mr-1">ل.س / ليلة</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </div>
      </div>
    </section>
  )
}

function HowItWorks() {
  const steps = [
    { number: "01", title: "ابحث واختر", description: "تصفح مئات الخيارات وابحث عن المكان المناسب لرحلتك", icon: Search },
    { number: "02", title: "احجز بسهولة", description: "أكمل الحجز بخطوات بسيطة مع خيارات دفع متعددة", icon: CheckCircle2 },
    { number: "03", title: "استمتع برحلتك", description: "تواصل مع المضيف واستمتع بإقامتك مع ضمان ضيف", icon: Heart }
  ]

  return (
    <section className="py-20 bg-gradient-to-br from-amber-50 to-orange-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <Badge className="mb-4 bg-amber-100 text-amber-700 hover:bg-amber-100">كيف يعمل</Badge>
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">احجز رحلتك في 3 خطوات بسيطة</h2>
        </div>
        
        <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
          {steps.map((step, index) => (
            <div key={index} className="text-center relative">
              <div className="w-20 h-20 bg-white rounded-2xl shadow-lg flex items-center justify-center mx-auto mb-6 relative">
                <step.icon className="w-8 h-8 text-amber-500" />
                <div className="absolute -top-2 -right-2 w-8 h-8 bg-amber-500 text-white rounded-full flex items-center justify-center text-sm font-bold">{step.number}</div>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">{step.title}</h3>
              <p className="text-gray-600">{step.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

function TrustSection() {
  const features = [
    { icon: Shield, title: "ضمان الحجز", description: "نظام ضمان يحمي حقوق الضيف والمضيف على حد سواء" },
    { icon: Users, title: "مضيفون موثوقون", description: "جميع المضيفين مُتحقق منهم لضمان تجربة آمنة" },
    { icon: MessageCircle, title: "دعم على مدار الساعة", description: "فريق دعم متخصص جاهز لمساعدتك في أي وقت" },
    { icon: Phone, title: "تواصل آمن", description: "تواصل مع المضيفين دون الحاجة لكشف معلوماتك الشخصية" }
  ]

  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <Badge className="mb-4 bg-emerald-100 text-emerald-700 hover:bg-emerald-100">لماذا ضيف؟</Badge>
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">رحلتك بأمان مع ضيف</h2>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <div key={index} className="text-center p-6 rounded-2xl bg-gray-50 hover:bg-gray-100 transition-colors">
              <div className="w-16 h-16 bg-emerald-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <feature.icon className="w-8 h-8 text-emerald-600" />
              </div>
              <h3 className="text-lg font-bold text-gray-900 mb-2">{feature.title}</h3>
              <p className="text-gray-600 text-sm">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

function CTASection() {
  return (
    <section className="py-20 bg-gradient-to-r from-amber-500 to-orange-500">
      <div className="container mx-auto px-4 text-center">
        <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">هل أنت مستعد لاستكشاف سوريا؟</h2>
        <p className="text-white/90 text-lg mb-8 max-w-2xl mx-auto">انضم إلى آلاف الضيوف الذين اكتشفوا جمال سوريا معنا</p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button size="lg" className="bg-white text-amber-600 hover:bg-gray-100 rounded-full px-8">ابدأ البحث الآن</Button>
          <Button size="lg" variant="outline" className="border-white text-white hover:bg-white/10 rounded-full px-8">كيف تعمل المنصة؟</Button>
        </div>
      </div>
    </section>
  )
}

function HostCTA() {
  return (
    <section className="py-20 bg-gray-900">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div>
            <Badge className="mb-4 bg-amber-500/20 text-amber-400 hover:bg-amber-500/20">كن مضيفاً</Badge>
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">شارك مكانك مع ضيوف من جميع أنحاء العالم</h2>
            <p className="text-gray-400 text-lg mb-8">سواء كان لديك فندق، شقة، شاليه، أو حتى مخيم، انضم إلى منصة ضيف وابدأ بتقديم خدمتك للضيوف</p>
            <ul className="space-y-4 mb-8">
              {["إدارة سهلة للحجوزات عبر واتساب", "نظام ضمان يحمي حقوقك", "دعم فني متواصل", "تحصيل آمن للمدفوعات"].map((item, i) => (
                <li key={i} className="flex items-center text-gray-300">
                  <CheckCircle2 className="w-5 h-5 text-amber-500 ml-3" />
                  {item}
                </li>
              ))}
            </ul>
            <Button size="lg" className="bg-amber-500 hover:bg-amber-600 text-white rounded-full px-8">سجل كمضيف الآن</Button>
          </div>
          <div className="relative">
            <div className="bg-gradient-to-br from-amber-500/20 to-orange-500/20 rounded-3xl p-8 backdrop-blur-sm border border-amber-500/20">
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-gray-800 rounded-2xl p-6 text-center"><div className="text-3xl font-bold text-amber-400 mb-2">0%</div><div className="text-gray-400 text-sm">عمولة للأشهر الـ 3 الأولى</div></div>
                <div className="bg-gray-800 rounded-2xl p-6 text-center"><div className="text-3xl font-bold text-emerald-400 mb-2">24/7</div><div className="text-gray-400 text-sm">دعم فني مستمر</div></div>
                <div className="bg-gray-800 rounded-2xl p-6 text-center"><div className="text-3xl font-bold text-sky-400 mb-2">+500</div><div className="text-gray-400 text-sm">مضيف نشط</div></div>
                <div className="bg-gray-800 rounded-2xl p-6 text-center"><div className="text-3xl font-bold text-violet-400 mb-2">8%</div><div className="text-gray-400 text-sm">عمولة بعد الترويج</div></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

// ==================== Community View ====================

function CommunityView() {
  const [posts, setPosts] = useState<CommunityPost[]>([])
  const [categories, setCategories] = useState<CommunityCategory[]>([])
  const [loading, setLoading] = useState(true)
  const [activeCategory, setActiveCategory] = useState<string | null>(null)
  const [activeTab, setActiveTab] = useState("latest")
  const { navigate } = useNavigation()

  useEffect(() => {
    const fetchCommunityData = async () => {
      try {
        const [postsRes, categoriesRes] = await Promise.all([
          fetch('/api/community/posts?limit=12&sort=latest'),
          fetch('/api/community/categories?includeStats=true')
        ])

        if (postsRes.ok) {
          const data = await postsRes.json()
          setPosts(data.posts || [])
        }

        if (categoriesRes.ok) {
          const data = await categoriesRes.json()
          setCategories(data.categories || [])
        }
      } catch (error) {
        console.error('Error fetching community data:', error)
      } finally {
        setLoading(false)
      }
    }

    fetchCommunityData()
  }, [])

  const typeLabels: Record<string, { label: string; icon: any; color: string }> = {
    DISCUSSION: { label: 'نقاش', icon: MessageSquare, color: 'bg-sky-100 text-sky-700' },
    QUESTION: { label: 'سؤال', icon: MessageCircle, color: 'bg-amber-100 text-amber-700' },
    STORY: { label: 'تجربة', icon: Heart, color: 'bg-rose-100 text-rose-700' },
    ANNOUNCEMENT: { label: 'إعلان', icon: Megaphone, color: 'bg-violet-100 text-violet-700' },
    GUIDE: { label: 'دليل', icon: BookOpen, color: 'bg-emerald-100 text-emerald-700' }
  }

  const formatTimeAgo = (dateString: string) => {
    const date = new Date(dateString)
    const now = new Date()
    const diff = now.getTime() - date.getTime()
    const minutes = Math.floor(diff / 60000)
    const hours = Math.floor(diff / 3600000)
    const days = Math.floor(diff / 86400000)
    
    if (minutes < 60) return `منذ ${minutes} دقيقة`
    if (hours < 24) return `منذ ${hours} ساعة`
    if (days < 7) return `منذ ${days} يوم`
    return date.toLocaleDateString('ar-SY')
  }

  const filteredPosts = activeCategory ? posts.filter(p => p.category?.id === activeCategory) : posts

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Community Header */}
      <div className="bg-gradient-to-r from-violet-600 to-purple-600 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div>
              <h1 className="text-3xl md:text-4xl font-bold mb-2">مجتمع ضيف</h1>
              <p className="text-white/80 text-lg">شارك تجاربك واستفد من خبرات الآخرين</p>
            </div>
            <Button size="lg" className="bg-white text-violet-600 hover:bg-gray-100 rounded-full">
              <Plus className="w-4 h-4 ml-2" />
              مشاركة جديدة
            </Button>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Sidebar - Categories */}
          <aside className="lg:w-64 shrink-0">
            <Card className="sticky top-24 border-0 shadow-md">
              <CardContent className="p-4">
                <h3 className="font-bold text-gray-900 mb-4 flex items-center gap-2">
                  <Bookmark className="w-4 h-4" />
                  الأقسام
                </h3>
                <div className="space-y-1">
                  <button
                    onClick={() => setActiveCategory(null)}
                    className={`w-full text-right px-3 py-2 rounded-lg transition-colors ${
                      activeCategory === null ? 'bg-violet-100 text-violet-700' : 'hover:bg-gray-100 text-gray-700'
                    }`}
                  >
                    جميع المواضيع
                  </button>
                  {categories.map((cat) => (
                    <button
                      key={cat.id}
                      onClick={() => setActiveCategory(cat.id)}
                      className={`w-full text-right px-3 py-2 rounded-lg transition-colors flex items-center justify-between ${
                        activeCategory === cat.id ? 'bg-violet-100 text-violet-700' : 'hover:bg-gray-100 text-gray-700'
                      }`}
                    >
                      <span>{cat.nameAr}</span>
                      {cat.postsCount !== undefined && (
                        <span className="text-xs bg-gray-200 px-2 py-0.5 rounded-full">{cat.postsCount}</span>
                      )}
                    </button>
                  ))}
                </div>
              </CardContent>
            </Card>
          </aside>

          {/* Main Content */}
          <main className="flex-1">
            {/* Tabs */}
            <Tabs value={activeTab} onValueChange={setActiveTab} className="mb-6">
              <TabsList className="bg-white border shadow-sm">
                <TabsTrigger value="latest" className="gap-2">
                  <Clock className="w-4 h-4" />
                  الأحدث
                </TabsTrigger>
                <TabsTrigger value="popular" className="gap-2">
                  <TrendingUp className="w-4 h-4" />
                  الأكثر تفاعلاً
                </TabsTrigger>
                <TabsTrigger value="featured" className="gap-2">
                  <Star className="w-4 h-4" />
                  المميزة
                </TabsTrigger>
              </TabsList>
            </Tabs>

            {/* Posts Grid */}
            {loading ? (
              <div className="space-y-4">
                {[1, 2, 3, 4].map((i) => (
                  <Card key={i} className="border-0 shadow-md">
                    <CardContent className="p-5">
                      <div className="h-4 bg-gray-200 rounded w-3/4 mb-3 animate-pulse" />
                      <div className="h-3 bg-gray-100 rounded w-full mb-2 animate-pulse" />
                      <div className="h-3 bg-gray-100 rounded w-2/3 animate-pulse" />
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : filteredPosts.length > 0 ? (
              <div className="space-y-4">
                {filteredPosts.map((post) => {
                  const typeInfo = typeLabels[post.type] || typeLabels.DISCUSSION
                  return (
                    <Card 
                      key={post.id} 
                      className={`group border-0 shadow-md hover:shadow-xl transition-all duration-300 cursor-pointer ${
                        post.isPinned ? 'ring-2 ring-amber-400 bg-amber-50/30' : ''
                      }`}
                      onClick={() => navigate('community-post', { id: post.id })}
                    >
                      <CardContent className="p-5">
                        <div className="flex items-start gap-4">
                          {/* Author Avatar */}
                          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-amber-400 to-orange-500 flex items-center justify-center text-white font-bold shrink-0">
                            {post.author.name?.charAt(0) || post.author.nameAr?.charAt(0) || 'ض'}
                          </div>
                          
                          <div className="flex-1 min-w-0">
                            {/* Header */}
                            <div className="flex items-center justify-between mb-2">
                              <div className="flex items-center gap-2">
                                <p className="font-medium text-gray-900">{post.author.nameAr || post.author.name || 'ضيف'}</p>
                                <span className="text-gray-400">•</span>
                                <p className="text-sm text-gray-500">{formatTimeAgo(post.createdAt)}</p>
                                {post.isPinned && (
                                  <Badge className="bg-amber-100 text-amber-700 text-xs">
                                    <Bookmark className="w-3 h-3 ml-1" />
                                    مثبت
                                  </Badge>
                                )}
                              </div>
                              <Badge className={typeInfo.color}>
                                <typeInfo.icon className="w-3 h-3 ml-1" />
                                {typeInfo.label}
                              </Badge>
                            </div>

                            {/* Content */}
                            <h3 className="font-bold text-lg text-gray-900 mb-2 group-hover:text-violet-600 transition-colors">
                              {post.titleAr}
                            </h3>
                            <p className="text-gray-600 line-clamp-2 mb-3">{post.contentAr}</p>

                            {/* Category & Tags */}
                            <div className="flex items-center gap-2 mb-3">
                              {post.category && (
                                <span 
                                  className="text-xs px-2 py-1 rounded-full"
                                  style={{ backgroundColor: post.category.color || '#f3f4f6', color: '#374151' }}
                                >
                                  {post.category.nameAr}
                                </span>
                              )}
                              {post.tags.slice(0, 3).map((tag, i) => (
                                <span key={i} className="text-xs text-gray-500 bg-gray-100 px-2 py-1 rounded-full">
                                  #{tag}
                                </span>
                              ))}
                            </div>

                            {/* Footer Stats */}
                            <div className="flex items-center justify-between pt-3 border-t border-gray-100">
                              <div className="flex items-center gap-4 text-sm text-gray-500">
                                <span className="flex items-center gap-1"><Eye className="w-4 h-4" />{post.viewCount}</span>
                                <span className="flex items-center gap-1"><ThumbsUp className="w-4 h-4" />{post.likeCount}</span>
                                <span className="flex items-center gap-1"><MessageSquare className="w-4 h-4" />{post._count.comments}</span>
                              </div>
                              <Button variant="ghost" size="sm" className="text-violet-600 hover:text-violet-700">
                                اقرأ المزيد
                                <ArrowLeft className="w-4 h-4 mr-1" />
                              </Button>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  )
                })}
              </div>
            ) : (
              <div className="text-center py-12">
                <MessageSquare className="w-12 h-12 text-gray-300 mx-auto mb-4" />
                <p className="text-gray-500">لا توجد مشاركات في هذا القسم</p>
              </div>
            )}
          </main>
        </div>
      </div>
    </div>
  )
}

// ==================== Community Post View ====================

function CommunityPostView() {
  const { pageParams, navigate } = useNavigation()
  const [post, setPost] = useState<CommunityPost | null>(null)
  const [loading, setLoading] = useState(true)
  const [comment, setComment] = useState("")

  useEffect(() => {
    const fetchPost = async () => {
      if (!pageParams.id) return
      
      try {
        const response = await fetch(`/api/community/posts/${pageParams.id}`)
        if (response.ok) {
          const data = await response.json()
          setPost(data.post)
        }
      } catch (error) {
        console.error('Error fetching post:', error)
      } finally {
        setLoading(false)
      }
    }

    fetchPost()
  }, [pageParams.id])

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto">
            <div className="h-8 bg-gray-200 rounded w-1/2 mb-4 animate-pulse" />
            <div className="h-4 bg-gray-100 rounded w-full mb-2 animate-pulse" />
            <div className="h-4 bg-gray-100 rounded w-2/3 animate-pulse" />
          </div>
        </div>
      </div>
    )
  }

  if (!post) {
    return (
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="container mx-auto px-4">
          <div className="text-center">
            <AlertCircle className="w-12 h-12 text-gray-300 mx-auto mb-4" />
            <p className="text-gray-500">المشاركة غير موجودة</p>
            <Button variant="outline" className="mt-4" onClick={() => navigate('community')}>
              العودة للمجتمع
            </Button>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto">
          <Button variant="ghost" className="mb-4" onClick={() => navigate('community')}>
            <ArrowLeft className="w-4 h-4 ml-2" />
            العودة للمجتمع
          </Button>

          <Card className="border-0 shadow-lg">
            <CardContent className="p-6">
              {/* Post Header */}
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-amber-400 to-orange-500 flex items-center justify-center text-white text-lg font-bold">
                  {post.author.name?.charAt(0) || 'ض'}
                </div>
                <div>
                  <p className="font-bold text-gray-900">{post.author.nameAr || post.author.name || 'ضيف'}</p>
                  <p className="text-sm text-gray-500">{new Date(post.createdAt).toLocaleDateString('ar-SY', { year: 'numeric', month: 'long', day: 'numeric' })}</p>
                </div>
              </div>

              {/* Post Title */}
              <h1 className="text-2xl font-bold text-gray-900 mb-4">{post.titleAr}</h1>

              {/* Post Content */}
              <div className="prose prose-lg max-w-none mb-6">
                <p className="text-gray-700 whitespace-pre-wrap">{post.contentAr}</p>
              </div>

              {/* Tags */}
              <div className="flex flex-wrap gap-2 mb-6">
                {post.tags.map((tag, i) => (
                  <span key={i} className="text-sm text-gray-600 bg-gray-100 px-3 py-1 rounded-full">#{tag}</span>
                ))}
              </div>

              {/* Stats */}
              <div className="flex items-center gap-6 py-4 border-t border-b border-gray-100 mb-6">
                <button className="flex items-center gap-2 text-gray-600 hover:text-violet-600 transition-colors">
                  <ThumbsUp className="w-5 h-5" />
                  <span>{post.likeCount} إعجاب</span>
                </button>
                <span className="flex items-center gap-2 text-gray-600">
                  <MessageSquare className="w-5 h-5" />
                  <span>{post._count.comments} تعليق</span>
                </span>
                <span className="flex items-center gap-2 text-gray-600">
                  <Eye className="w-5 h-5" />
                  <span>{post.viewCount} مشاهدة</span>
                </span>
              </div>

              {/* Comment Input */}
              <div className="mb-6">
                <div className="flex gap-3">
                  <div className="w-10 h-10 rounded-full bg-gray-200 flex items-center justify-center shrink-0">
                    <User className="w-5 h-5 text-gray-500" />
                  </div>
                  <div className="flex-1">
                    <Input
                      placeholder="أضف تعليقاً..."
                      value={comment}
                      onChange={(e) => setComment(e.target.value)}
                      className="mb-2"
                    />
                    {comment && (
                      <Button className="bg-violet-600 hover:bg-violet-700">
                        <Send className="w-4 h-4 ml-2" />
                        نشر التعليق
                      </Button>
                    )}
                  </div>
                </div>
              </div>

              {/* Comments Section */}
              <div className="space-y-4">
                <h3 className="font-bold text-gray-900">التعليقات ({post._count.comments})</h3>
                <div className="text-center py-8 text-gray-500">
                  <MessageSquare className="w-8 h-8 mx-auto mb-2 text-gray-300" />
                  <p>لا توجد تعليقات بعد. كن أول من يعلق!</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

// ==================== Host Reviews View ====================

function HostReviewsView() {
  const [reviews, setReviews] = useState<HostReview[]>([])
  const [loading, setLoading] = useState(true)
  const { navigate } = useNavigation()

  useEffect(() => {
    const fetchReviews = async () => {
      try {
        const response = await fetch('/api/host-reviews?limit=20')
        if (response.ok) {
          const data = await response.json()
          setReviews(data.reviews || [])
        }
      } catch (error) {
        console.error('Error fetching reviews:', error)
      } finally {
        setLoading(false)
      }
    }

    fetchReviews()
  }, [])

  const renderStars = (rating: number) => (
    <div className="flex items-center gap-0.5">
      {[1, 2, 3, 4, 5].map((star) => (
        <Star key={star} className={`w-4 h-4 ${star <= rating ? 'text-amber-400 fill-amber-400' : 'text-gray-300'}`} />
      ))}
    </div>
  )

  const formatDate = (dateString: string) => new Date(dateString).toLocaleDateString('ar-SY', { year: 'numeric', month: 'long', day: 'numeric' })

  const avgRating = reviews.length > 0 ? (reviews.reduce((sum, r) => sum + r.overallRating, 0) / reviews.length).toFixed(1) : '0.0'

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-emerald-600 to-teal-600 text-white py-12">
        <div className="container mx-auto px-4">
          <Button variant="ghost" className="text-white mb-4" onClick={() => navigate('home')}>
            <ArrowLeft className="w-4 h-4 ml-2" />
            العودة للرئيسية
          </Button>
          <h1 className="text-3xl md:text-4xl font-bold mb-2">تقييمات المضيفين</h1>
          <p className="text-white/80 text-lg">تقييمات حقيقية من ضيوف حقيقيين</p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        {/* Stats Overview */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <Card className="border-0 shadow-md">
            <CardContent className="p-4 text-center">
              <div className="text-3xl font-bold text-amber-500 mb-1">{avgRating}</div>
              <div className="text-gray-600 text-sm">متوسط التقييم</div>
              <div className="flex justify-center mt-2">{renderStars(Math.round(parseFloat(avgRating)))}</div>
            </CardContent>
          </Card>
          <Card className="border-0 shadow-md">
            <CardContent className="p-4 text-center">
              <div className="text-3xl font-bold text-emerald-500 mb-1">{reviews.length}</div>
              <div className="text-gray-600 text-sm">تقييم إجمالي</div>
            </CardContent>
          </Card>
          <Card className="border-0 shadow-md">
            <CardContent className="p-4 text-center">
              <div className="text-3xl font-bold text-sky-500 mb-1">4.8</div>
              <div className="text-gray-600 text-sm">متوسط النظافة</div>
            </CardContent>
          </Card>
          <Card className="border-0 shadow-md">
            <CardContent className="p-4 text-center">
              <div className="text-3xl font-bold text-violet-500 mb-1">4.9</div>
              <div className="text-gray-600 text-sm">متوسط التواصل</div>
            </CardContent>
          </Card>
        </div>

        {/* Reviews List */}
        {loading ? (
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <Card key={i} className="border-0 shadow-md">
                <CardContent className="p-5">
                  <div className="h-4 bg-gray-200 rounded w-1/2 mb-3 animate-pulse" />
                  <div className="h-3 bg-gray-100 rounded w-full mb-2 animate-pulse" />
                </CardContent>
              </Card>
            ))}
          </div>
        ) : reviews.length > 0 ? (
          <div className="grid md:grid-cols-2 gap-6">
            {reviews.map((review) => (
              <Card key={review.id} className="border-0 shadow-md hover:shadow-xl transition-all duration-300">
                <CardContent className="p-5">
                  {/* Header */}
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-gradient-to-br from-emerald-400 to-teal-500 flex items-center justify-center text-white font-bold">
                        {review.reviewer.name?.charAt(0) || 'ض'}
                      </div>
                      <div>
                        <p className="font-medium text-gray-900">{review.reviewer.name}</p>
                        <p className="text-xs text-gray-500">{formatDate(review.createdAt)}</p>
                      </div>
                    </div>
                    {review.isVerified && (
                      <Badge className="bg-emerald-100 text-emerald-700 text-xs">
                        <CheckCircle2 className="w-3 h-3 ml-1" />
                        حجز موثق
                      </Badge>
                    )}
                  </div>

                  {/* Rating */}
                  <div className="flex items-center gap-2 mb-3">
                    {renderStars(Math.round(review.overallRating))}
                    <span className="font-bold text-gray-900">{review.overallRating.toFixed(1)}</span>
                  </div>

                  {/* Sub-ratings */}
                  <div className="grid grid-cols-3 gap-2 mb-4 text-xs">
                    <div className="text-center p-2 bg-gray-50 rounded">
                      <span className="font-medium text-amber-500">{review.cleanliness}</span>
                      <p className="text-gray-500">نظافة</p>
                    </div>
                    <div className="text-center p-2 bg-gray-50 rounded">
                      <span className="font-medium text-amber-500">{review.communication}</span>
                      <p className="text-gray-500">تواصل</p>
                    </div>
                    <div className="text-center p-2 bg-gray-50 rounded">
                      <span className="font-medium text-amber-500">{review.value}</span>
                      <p className="text-gray-500">قيمة</p>
                    </div>
                  </div>

                  {/* Comment */}
                  {review.commentAr && (
                    <p className="text-gray-600 text-sm line-clamp-3 mb-4">"{review.commentAr}"</p>
                  )}

                  {/* Host Response */}
                  {review.hostResponse && (
                    <div className="bg-gray-50 rounded-lg p-3 mt-3">
                      <p className="text-xs text-gray-500 mb-1">رد المضيف:</p>
                      <p className="text-sm text-gray-700 line-clamp-2">{review.hostResponse}</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <Star className="w-12 h-12 text-gray-300 mx-auto mb-4" />
            <p className="text-gray-500">لا توجد تقييمات حالياً</p>
          </div>
        )}
      </div>
    </div>
  )
}

// ==================== Accommodations View ====================

function AccommodationsView() {
  const [accommodations, setAccommodations] = useState<Accommodation[]>([])
  const [loading, setLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedType, setSelectedType] = useState<string | null>(null)
  const { navigate } = useNavigation()

  const typeLabels: Record<string, string> = {
    HOTEL: "فندق", APARTMENT: "شقة", VILLA: "فيلا", CHALET: "شاليه",
    CAMP: "مخيم", GUESTHOUSE: "نزل", HOSTEL: "سكن شباب", RESORT: "منتجع"
  }
  const defaultImage = "/images/default-accommodation.png"

  useEffect(() => {
    const fetchAccommodations = async () => {
      try {
        const response = await fetch('/api/accommodations?limit=20')
        if (response.ok) {
          const data = await response.json()
          setAccommodations(data.accommodations || [])
        }
      } catch (error) {
        console.error('Error fetching accommodations:', error)
      } finally {
        setLoading(false)
      }
    }

    fetchAccommodations()
  }, [])

  const filteredAccommodations = accommodations.filter(acc => {
    const matchesSearch = !searchQuery || 
      acc.titleAr.toLowerCase().includes(searchQuery.toLowerCase()) ||
      acc.city?.nameAr.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesType = !selectedType || acc.type === selectedType
    return matchesSearch && matchesType
  })

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-amber-500 to-orange-500 text-white py-12">
        <div className="container mx-auto px-4">
          <Button variant="ghost" className="text-white mb-4" onClick={() => navigate('home')}>
            <ArrowLeft className="w-4 h-4 ml-2" />
            العودة للرئيسية
          </Button>
          <h1 className="text-3xl md:text-4xl font-bold mb-2">أماكن الإقامة</h1>
          <p className="text-white/80 text-lg">اكتشف أفضل أماكن الإقامة في سوريا</p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        {/* Filters */}
        <div className="flex flex-col md:flex-row gap-4 mb-8">
          <div className="flex-1 relative">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
            <Input
              placeholder="ابحث عن مكان إقامة..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pr-10"
            />
          </div>
          <div className="flex gap-2 flex-wrap">
            <Button
              variant={selectedType === null ? "default" : "outline"}
              onClick={() => setSelectedType(null)}
              className={selectedType === null ? "bg-amber-500 hover:bg-amber-600" : ""}
            >
              الكل
            </Button>
            {Object.entries(typeLabels).slice(0, 4).map(([type, label]) => (
              <Button
                key={type}
                variant={selectedType === type ? "default" : "outline"}
                onClick={() => setSelectedType(type)}
                className={selectedType === type ? "bg-amber-500 hover:bg-amber-600" : ""}
              >
                {label}
              </Button>
            ))}
          </div>
        </div>

        {/* Results Count */}
        <p className="text-gray-600 mb-4">عرض {filteredAccommodations.length} مكان إقامة</p>

        {/* Accommodations Grid */}
        {loading ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {[1, 2, 3, 4, 5, 6, 7, 8].map((i) => (
              <div key={i} className="bg-gray-100 rounded-xl animate-pulse">
                <div className="h-48 bg-gray-200 rounded-t-xl" />
                <div className="p-4 space-y-2">
                  <div className="h-4 bg-gray-200 rounded w-3/4" />
                  <div className="h-4 bg-gray-200 rounded w-1/2" />
                </div>
              </div>
            ))}
          </div>
        ) : filteredAccommodations.length > 0 ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredAccommodations.map((acc) => {
              const displayImage = acc.coverImage || (acc.images && acc.images[0]) || defaultImage
              const location = acc.city ? `${acc.city.nameAr}` : 'سوريا'
              
              return (
                <Card key={acc.id} className="group overflow-hidden border-0 shadow-md hover:shadow-xl transition-all duration-300 cursor-pointer bg-white">
                  <div className="relative h-48 overflow-hidden">
                    <img src={displayImage} alt={acc.titleAr} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" loading="lazy" />
                    {acc.rating >= 4.8 && <Badge className="absolute top-3 right-3 bg-amber-500 text-white">مميز</Badge>}
                    <Button variant="ghost" size="icon" className="absolute top-3 left-3 bg-white/80 hover:bg-white rounded-full h-8 w-8">
                      <Heart className="w-4 h-4 text-gray-600" />
                    </Button>
                  </div>
                  <CardContent className="p-4">
                    <div className="flex items-center text-sm text-gray-500 mb-2">
                      <MapPin className="w-3 h-3 ml-1" />
                      {location}
                    </div>
                    <h3 className="font-semibold text-gray-900 mb-2 line-clamp-1">{acc.titleAr}</h3>
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center">
                        <Star className="w-4 h-4 text-amber-400 fill-amber-400 ml-1" />
                        <span className="font-medium text-sm">{acc.rating.toFixed(1)}</span>
                        <span className="text-gray-400 text-sm mr-1">({acc.reviewCount})</span>
                      </div>
                      <Badge variant="secondary" className="text-xs">{typeLabels[acc.type] || acc.type}</Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <div>
                        <span className="font-bold text-lg text-gray-900">{acc.basePrice.toLocaleString()}</span>
                        <span className="text-gray-500 text-sm mr-1">ل.س / ليلة</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        ) : (
          <div className="text-center py-12">
            <HomeIcon className="w-12 h-12 text-gray-300 mx-auto mb-4" />
            <p className="text-gray-500">لا توجد أماكن إقامة تطابق بحثك</p>
          </div>
        )}
      </div>
    </div>
  )
}

// ==================== Header Component ====================

function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const { currentPage, navigate } = useNavigation()

  const navItems = [
    { id: 'home' as PageType, label: 'الرئيسية' },
    { id: 'accommodations' as PageType, label: 'الإقامات' },
    { id: 'community' as PageType, label: 'المجتمع' },
    { id: 'host-reviews' as PageType, label: 'التقييمات' },
  ]

  return (
    <header className="fixed top-0 right-0 left-0 z-50 bg-white/80 backdrop-blur-md border-b">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center gap-2 cursor-pointer" onClick={() => navigate('home')}>
            <h1 className="text-2xl font-bold text-amber-600">ضيف</h1>
          </div>
          
          <nav className="hidden md:flex items-center gap-6">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => navigate(item.id)}
                className={`transition-colors bg-transparent cursor-pointer ${
                  currentPage === item.id 
                    ? 'text-amber-600 font-medium' 
                    : 'text-gray-600 hover:text-amber-600'
                }`}
              >
                {item.label}
              </button>
            ))}
          </nav>
          
          <div className="hidden md:flex items-center gap-3">
            <Button variant="ghost" className="text-gray-600 cursor-pointer">تسجيل الدخول</Button>
            <Button className="bg-amber-500 hover:bg-amber-600 text-white rounded-full cursor-pointer">انضم كمضيف</Button>
          </div>
          
          <Button
            variant="ghost"
            size="icon"
            className="md:hidden cursor-pointer"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </Button>
        </div>
        
        {mobileMenuOpen && (
          <div className="md:hidden py-4 border-t">
            <nav className="flex flex-col gap-4">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => { navigate(item.id); setMobileMenuOpen(false) }}
                  className={`text-right py-2 bg-transparent cursor-pointer ${
                    currentPage === item.id ? 'text-amber-600 font-medium' : 'text-gray-600 hover:text-amber-600'
                  }`}
                >
                  {item.label}
                </button>
              ))}
              <div className="flex flex-col gap-2 pt-4 border-t">
                <Button variant="outline" className="w-full justify-center cursor-pointer">تسجيل الدخول</Button>
                <Button className="w-full bg-amber-500 hover:bg-amber-600 text-white cursor-pointer">انضم كمضيف</Button>
              </div>
            </nav>
          </div>
        )}
      </div>
    </header>
  )
}

// ==================== Footer Component ====================

function Footer() {
  const { navigate } = useNavigation()

  return (
    <footer className="bg-gray-900 text-gray-400 pt-16 pb-8">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
          <div>
            <h3 className="text-2xl font-bold text-white mb-4 cursor-pointer" onClick={() => navigate('home')}>ضيف</h3>
            <p className="text-gray-400 mb-6">منصتك الموثوقة للسياحة والضيافة في سوريا. نربط الضيوف بالمضيفين بطريقة آمنة وموثوقة.</p>
            <div className="flex gap-3">
              <a href="https://facebook.com" target="_blank" rel="noopener noreferrer" className="w-10 h-10 bg-gray-800 rounded-full flex items-center justify-center hover:bg-amber-500 transition-colors">
                <svg className="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 24 24"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>
              </a>
              <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" className="w-10 h-10 bg-gray-800 rounded-full flex items-center justify-center hover:bg-amber-500 transition-colors">
                <svg className="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/></svg>
              </a>
            </div>
          </div>
          
          <div>
            <h4 className="text-white font-semibold mb-4">الخدمات</h4>
            <ul className="space-y-3">
              <li><button onClick={() => navigate('accommodations')} className="hover:text-amber-500 transition-colors text-right bg-transparent cursor-pointer">السكن</button></li>
              <li><button onClick={() => navigate('home')} className="hover:text-amber-500 transition-colors text-right bg-transparent cursor-pointer">النقل</button></li>
              <li><button onClick={() => navigate('home')} className="hover:text-amber-500 transition-colors text-right bg-transparent cursor-pointer">الجولات السياحية</button></li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-white font-semibold mb-4">ضيف</h4>
            <ul className="space-y-3">
              <li><button onClick={() => navigate('community')} className="hover:text-amber-500 transition-colors text-right bg-transparent cursor-pointer">المجتمع</button></li>
              <li><button onClick={() => navigate('host-reviews')} className="hover:text-amber-500 transition-colors text-right bg-transparent cursor-pointer">التقييمات</button></li>
              <li><button onClick={() => navigate('home')} className="hover:text-amber-500 transition-colors text-right bg-transparent cursor-pointer">انضم كمضيف</button></li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-white font-semibold mb-4">تواصل معنا</h4>
            <ul className="space-y-3">
              <li className="flex items-center gap-2"><Phone className="w-4 h-4 text-amber-500" /><a href="tel:+963111234567" dir="ltr" className="hover:text-amber-500 transition-colors">+963 11 123 4567</a></li>
              <li className="flex items-center gap-2"><MessageCircle className="w-4 h-4 text-amber-500" /><a href="mailto:info@dayf.sy" className="hover:text-amber-500 transition-colors">info@dayf.sy</a></li>
              <li className="flex items-start gap-2"><MapPin className="w-4 h-4 text-amber-500 mt-1" /><span>دمشق، سوريا</span></li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-800 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-sm">© 2024 ضيف. جميع الحقوق محفوظة.</p>
            <div className="flex gap-6 text-sm">
              <a href="#" className="hover:text-amber-500 transition-colors">سياسة الخصوصية</a>
              <a href="#" className="hover:text-amber-500 transition-colors">شروط الاستخدام</a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  )
}

// ==================== Main Page Component ====================

function HomeView() {
  const [cities, setCities] = useState<City[]>([])
  const [citiesLoading, setCitiesLoading] = useState(true)
  const [accommodations, setAccommodations] = useState<Accommodation[]>([])
  const [accommodationsLoading, setAccommodationsLoading] = useState(true)
  const { navigate } = useNavigation()

  const [stats, setStats] = useState({
    totalAccommodations: 500,
    totalCities: 50
  })

  useEffect(() => {
    const fetchData = async () => {
      fetch('/api/cities')
        .then(async (response) => {
          if (!response.ok) throw new Error('فشل في جلب البيانات')
          const data = await response.json()
          setCities(data.cities || [])
          setStats(prev => ({ ...prev, totalCities: data.cities?.length || 0 }))
        })
        .catch((err) => console.error('Error fetching cities:', err))
        .finally(() => setCitiesLoading(false))

      fetch('/api/accommodations?limit=4')
        .then(async (response) => {
          if (!response.ok) throw new Error('فشل في جلب البيانات')
          const data = await response.json()
          setAccommodations(data.accommodations || [])
          setStats(prev => ({ ...prev, totalAccommodations: data.pagination?.total || data.accommodations?.length || 0 }))
        })
        .catch((err) => console.error('Error fetching accommodations:', err))
        .finally(() => setAccommodationsLoading(false))
    }

    fetchData()
  }, [])

  return (
    <main>
      <HeroSection 
        totalAccommodations={stats.totalAccommodations}
        totalCities={stats.totalCities}
        onSearch={() => navigate('accommodations')}
      />
      <ServicesSection onNavigate={navigate} />
      <PopularDestinations cities={cities} loading={citiesLoading} error={null} />
      <FeaturedAccommodations accommodations={accommodations} loading={accommodationsLoading} error={null} />
      <HowItWorks />
      <TrustSection />
      <CTASection />
      <HostCTA />
    </main>
  )
}

// ==================== App Component ====================

export default function Home() {
  const [currentPage, setCurrentPage] = useState<PageType>('home')
  const [pageParams, setPageParams] = useState<Record<string, string>>({})

  const navigate = (page: PageType, params?: Record<string, string>) => {
    setCurrentPage(page)
    setPageParams(params || {})
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  const contextValue: NavigationContextType = {
    currentPage,
    setCurrentPage,
    pageParams,
    setPageParams,
    navigate
  }

  const renderPage = () => {
    switch (currentPage) {
      case 'community':
        return <CommunityView />
      case 'community-post':
        return <CommunityPostView />
      case 'accommodations':
        return <AccommodationsView />
      case 'host-reviews':
        return <HostReviewsView />
      case 'home':
      default:
        return <HomeView />
    }
  }

  return (
    <NavigationContext.Provider value={contextValue}>
      <div className="min-h-screen flex flex-col">
        <Header />
        <div className="flex-1 pt-16">
          {renderPage()}
        </div>
        <Footer />
        <TourismAgent />
      </div>
    </NavigationContext.Provider>
  )
}
