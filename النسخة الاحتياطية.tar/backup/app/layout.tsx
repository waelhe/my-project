import type { Metadata, Viewport } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import { Noto_Sans_Arabic } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

const notoSansArabic = Noto_Sans_Arabic({
  variable: "--font-arabic",
  subsets: ["arabic"],
  weight: ["300", "400", "500", "600", "700", "800"],
  display: "swap",
  preload: true,
});

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 5,
  userScalable: true,
  themeColor: [
    { media: "(prefers-color-scheme: light)", color: "#ffffff" },
    { media: "(prefers-color-scheme: dark)", color: "#0a0a0a" },
  ],
};

export const metadata: Metadata = {
  title: "ضيف - منصة السياحة والضيافة في سوريا",
  description: "اكتشف سوريا مع ضيف. احجز فنادق، شقق، جولات سياحية، وخدمات نقل آمنة. منصتك الموثوقة للسياحة والاستثمار في سوريا.",
  keywords: ["سياحة سوريا", "فنادق سوريا", "حجز فنادق", "جولات سياحية", "سوريا", "ضيف", "Dayf"],
  authors: [{ name: "ضيف" }],
  icons: {
    icon: "/logo.svg",
  },
  openGraph: {
    title: "ضيف - منصة السياحة والضيافة في سوريا",
    description: "اكتشف سوريا مع ضيف. احجز فنادق، شقق، جولات سياحية",
    type: "website",
    locale: "ar_SY",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ar" dir="rtl" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} ${notoSansArabic.variable} font-[family-name:var(--font-arabic)] antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
