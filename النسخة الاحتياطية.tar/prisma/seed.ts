import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

// Enums as string values
const AccommodationType = {
  HOTEL: 'HOTEL',
  APARTMENT: 'APARTMENT',
  VILLA: 'VILLA',
  CHALET: 'CHALET',
  CAMP: 'CAMP',
  GUESTHOUSE: 'GUESTHOUSE',
  HOSTEL: 'HOSTEL',
  RESORT: 'RESORT',
}

const AccommodationStatus = {
  DRAFT: 'DRAFT',
  PENDING_APPROVAL: 'PENDING_APPROVAL',
  ACTIVE: 'ACTIVE',
  INACTIVE: 'INACTIVE',
  SUSPENDED: 'SUSPENDED',
}

const UserRole = {
  GUEST: 'GUEST',
  HOST: 'HOST',
  ADMIN: 'ADMIN',
  SUPER_ADMIN: 'SUPER_ADMIN',
}

const UserStatus = {
  ACTIVE: 'ACTIVE',
  INACTIVE: 'INACTIVE',
  SUSPENDED: 'SUSPENDED',
  PENDING_VERIFICATION: 'PENDING_VERIFICATION',
}

const BookingStatus = {
  PENDING: 'PENDING',
  CONFIRMED: 'CONFIRMED',
  PAYMENT_PENDING: 'PAYMENT_PENDING',
  PAID: 'PAID',
  CHECKED_IN: 'CHECKED_IN',
  CHECKED_OUT: 'CHECKED_OUT',
  CANCELLED: 'CANCELLED',
  REFUNDED: 'REFUNDED',
  DISPUTED: 'DISPUTED',
}

const PaymentStatus = {
  PENDING: 'PENDING',
  PROCESSING: 'PROCESSING',
  COMPLETED: 'COMPLETED',
  FAILED: 'FAILED',
  REFUNDED: 'REFUNDED',
  DISPUTED: 'DISPUTED',
}

const PaymentMethod = {
  CASH: 'CASH',
  SYRIATEL: 'SYRIATEL',
  MTN: 'MTN',
  BANK_TRANSFER: 'BANK_TRANSFER',
  CREDIT_CARD: 'CREDIT_CARD',
}

const PostType = {
  DISCUSSION: 'DISCUSSION',
  QUESTION: 'QUESTION',
  STORY: 'STORY',
  ANNOUNCEMENT: 'ANNOUNCEMENT',
  GUIDE: 'GUIDE',
}

const PostStatus = {
  DRAFT: 'DRAFT',
  PUBLISHED: 'PUBLISHED',
  HIDDEN: 'HIDDEN',
  DELETED: 'DELETED',
}

// Syrian Cities Data
const citiesData = [
  { nameAr: 'دمشق', nameEn: 'Damascus', governorate: 'دمشق', isPopular: true, image: '/images/cities/damascus.png' },
  { nameAr: 'حلب', nameEn: 'Aleppo', governorate: 'حلب', isPopular: true, image: '/images/cities/aleppo.png' },
  { nameAr: 'حمص', nameEn: 'Homs', governorate: 'حمص', isPopular: true, image: '/images/cities/homs.png' },
  { nameAr: 'اللاذقية', nameEn: 'Latakia', governorate: 'اللاذقية', isPopular: true, image: '/images/cities/latakia.png' },
  { nameAr: 'طرطوس', nameEn: 'Tartus', governorate: 'طرطوس', isPopular: true, image: '/images/cities/tartus.png' },
  { nameAr: 'حماة', nameEn: 'Hama', governorate: 'حماة', isPopular: false, image: '/images/cities/hama.png' },
  { nameAr: 'تدمر', nameEn: 'Palmyra', governorate: 'حمص', isPopular: true, image: '/images/cities/palmyra.png' },
  { nameAr: 'صافيتا', nameEn: 'Safita', governorate: 'طرطوس', isPopular: false, image: '/images/cities/safita.png' },
  { nameAr: 'معلولا', nameEn: 'Maaloula', governorate: 'ريف دمشق', isPopular: false, image: '/images/cities/maaloula.png' },
]

// Users Data
const usersData = [
  // Admin
  { phone: '+963911111111', name: 'Admin', nameAr: 'مدير النظام', role: UserRole.ADMIN, status: UserStatus.ACTIVE, isVerified: true },
  
  // Hosts
  { phone: '+963922222221', name: 'Ahmad Hassan', nameAr: 'أحمد حسن', role: UserRole.HOST, status: UserStatus.ACTIVE, isVerified: true, city: 'دمشق' },
  { phone: '+963922222222', name: 'Fatima Ali', nameAr: 'فاطمة علي', role: UserRole.HOST, status: UserStatus.ACTIVE, isVerified: true, city: 'حلب' },
  { phone: '+963922222223', name: 'Mohammad Khalil', nameAr: 'محمد خليل', role: UserRole.HOST, status: UserStatus.ACTIVE, isVerified: true, city: 'اللاذقية' },
  { phone: '+963922222224', name: 'Layla Mahmoud', nameAr: 'ليلى محمود', role: UserRole.HOST, status: UserStatus.ACTIVE, isVerified: true, city: 'طرطوس' },
  { phone: '+963922222225', name: 'Omar Said', nameAr: 'عمر سعيد', role: UserRole.HOST, status: UserStatus.ACTIVE, isVerified: true, city: 'حمص' },
  
  // Guests
  { phone: '+963933333331', name: 'Sara Ibrahim', nameAr: 'سارة إبراهيم', role: UserRole.GUEST, status: UserStatus.ACTIVE, isVerified: true },
  { phone: '+963933333332', name: 'Youssef Kareem', nameAr: 'يوسف كريم', role: UserRole.GUEST, status: UserStatus.ACTIVE, isVerified: true },
  { phone: '+963933333333', name: 'Nour Al-Din', nameAr: 'نور الدين', role: UserRole.GUEST, status: UserStatus.ACTIVE, isVerified: true },
  { phone: '+963933333334', name: 'Rana Faisal', nameAr: 'رنا فيصل', role: UserRole.GUEST, status: UserStatus.ACTIVE, isVerified: true },
  { phone: '+963933333335', name: 'Khalid Omar', nameAr: 'خالد عمر', role: UserRole.GUEST, status: UserStatus.ACTIVE, isVerified: true },
]

// Accommodations Data
const accommodationsData = [
  // Damascus - Hotels & Apartments
  {
    titleAr: 'فندق الشام الفاخر',
    titleEn: 'Al-Sham Luxury Hotel',
    descriptionAr: 'فندق 5 نجوم في قلب دمشق القديمة، يوفر إطلالات رائعة على الأسواق التاريخية والمسجد الأموي. غرف فاخرة مع جميع وسائل الراحة الحديثة.',
    type: AccommodationType.HOTEL,
    addressAr: 'القصاع، دمشق',
    basePrice: 150000,
    bedrooms: 1,
    bathrooms: 1,
    maxGuests: 2,
    beds: 1,
    size: 45,
    amenities: ['wifi', 'ac', 'tv', 'minibar', 'room_service', 'parking', 'gym', 'spa'],
    rating: 4.8,
    reviewCount: 156,
    latitude: 33.5138,
    longitude: 36.2765,
  },
  {
    titleAr: 'شقة الروضة المفروشة',
    titleEn: 'Al-Rawda Furnished Apartment',
    descriptionAr: 'شقة مفروشة بالكامل في حي الروضة الراقي، قريبة من جميع الخدمات والمطاعم. مثالية للعائلات.',
    type: AccommodationType.APARTMENT,
    addressAr: 'الروضة، دمشق',
    basePrice: 75000,
    bedrooms: 2,
    bathrooms: 1,
    maxGuests: 4,
    beds: 2,
    size: 85,
    amenities: ['wifi', 'ac', 'kitchen', 'washer', 'tv', 'parking'],
    rating: 4.5,
    reviewCount: 89,
    latitude: 33.5238,
    longitude: 36.2865,
  },
  {
    titleAr: 'فندق الأموي',
    titleEn: 'Umayyad Hotel',
    descriptionAr: 'فندق تاريخي عريق على بعد خطوات من المسجد الأموي، يجمع بين التراث والحداثة.',
    type: AccommodationType.HOTEL,
    addressAr: 'باب توما، دمشق',
    basePrice: 120000,
    bedrooms: 1,
    bathrooms: 1,
    maxGuests: 2,
    beds: 1,
    size: 40,
    amenities: ['wifi', 'ac', 'tv', 'breakfast', 'parking'],
    rating: 4.6,
    reviewCount: 234,
    latitude: 33.5138,
    longitude: 36.3065,
  },
  
  // Aleppo
  {
    titleAr: 'فندق حلب الكبير',
    titleEn: 'Aleppo Grand Hotel',
    descriptionAr: 'فندق فاخر في قلب حلب، يقدم تجربة ضيافة استثنائية مع مطعم يقدم أشهر المأكولات الحلبية.',
    type: AccommodationType.HOTEL,
    addressAr: 'الجميلية، حلب',
    basePrice: 130000,
    bedrooms: 1,
    bathrooms: 1,
    maxGuests: 2,
    beds: 1,
    size: 42,
    amenities: ['wifi', 'ac', 'tv', 'restaurant', 'parking', 'gym'],
    rating: 4.7,
    reviewCount: 178,
    latitude: 36.2021,
    longitude: 37.1343,
  },
  {
    titleAr: 'فيلا حلب السياحية',
    titleEn: 'Aleppo Tourist Villa',
    descriptionAr: 'فيلا فسيحة مع حديقة خاصة ومسبح، مثالية للعائلات الكبيرة والمجموعات.',
    type: AccommodationType.VILLA,
    addressAr: 'الشهباء، حلب',
    basePrice: 250000,
    bedrooms: 4,
    bathrooms: 3,
    maxGuests: 10,
    beds: 5,
    size: 350,
    amenities: ['wifi', 'ac', 'pool', 'garden', 'kitchen', 'parking', 'bbq'],
    rating: 4.9,
    reviewCount: 45,
    latitude: 36.2121,
    longitude: 37.1443,
  },
  
  // Latakia
  {
    titleAr: 'منتجع البحر الأبيض',
    titleEn: 'White Sea Resort',
    descriptionAr: 'منتجع ساحلي على شاطئ اللاذقية، غرف بإطلالة بحرية مباشرة وشاطئ خاص.',
    type: AccommodationType.RESORT,
    addressAr: 'شاطئ اللاذقية',
    basePrice: 180000,
    bedrooms: 1,
    bathrooms: 1,
    maxGuests: 3,
    beds: 1,
    size: 50,
    amenities: ['wifi', 'ac', 'pool', 'beach', 'restaurant', 'gym', 'spa'],
    rating: 4.6,
    reviewCount: 312,
    latitude: 35.5378,
    longitude: 35.7937,
  },
  {
    titleAr: 'شاليه الصيف',
    titleEn: 'Summer Chalet',
    descriptionAr: 'شاليه مريح على الساحل السوري، مثالي للعطلات الصيفية مع إطلالة بحرية.',
    type: AccommodationType.CHALET,
    addressAr: 'شاطئ جبلة',
    basePrice: 100000,
    bedrooms: 2,
    bathrooms: 1,
    maxGuests: 5,
    beds: 3,
    size: 70,
    amenities: ['wifi', 'ac', 'kitchen', 'beach_access', 'parking'],
    rating: 4.4,
    reviewCount: 67,
    latitude: 35.5278,
    longitude: 35.7837,
  },
  
  // Tartus
  {
    titleAr: 'نزل الساحل',
    titleEn: 'Coast Inn',
    descriptionAr: 'نزل عائلي دافئ في طرطوس، يتميز بالهدوء والقرب من الشاطئ والمدينة القديمة.',
    type: AccommodationType.GUESTHOUSE,
    addressAr: 'الميناء، طرطوس',
    basePrice: 60000,
    bedrooms: 1,
    bathrooms: 1,
    maxGuests: 2,
    beds: 1,
    size: 35,
    amenities: ['wifi', 'ac', 'tv', 'breakfast'],
    rating: 4.3,
    reviewCount: 98,
    latitude: 34.8959,
    longitude: 35.8867,
  },
  {
    titleAr: 'شقة أرواد',
    titleEn: 'Arwad Apartment',
    descriptionAr: 'شقة مفروشة مع إطلالة على جزيرة أرواد، تجربة سياحية فريدة.',
    type: AccommodationType.APARTMENT,
    addressAr: 'أرواد، طرطوس',
    basePrice: 85000,
    bedrooms: 2,
    bathrooms: 1,
    maxGuests: 4,
    beds: 2,
    size: 75,
    amenities: ['wifi', 'ac', 'kitchen', 'sea_view', 'parking'],
    rating: 4.7,
    reviewCount: 54,
    latitude: 34.8559,
    longitude: 35.8667,
  },
  
  // Homs
  {
    titleAr: 'فندق حمص المركزي',
    titleEn: 'Homs Central Hotel',
    descriptionAr: 'فندق في موقع استراتيجي في وسط حمص، قريب من الأسواق والمطاعم الشهيرة.',
    type: AccommodationType.HOTEL,
    addressAr: 'وسط المدينة، حمص',
    basePrice: 90000,
    bedrooms: 1,
    bathrooms: 1,
    maxGuests: 2,
    beds: 1,
    size: 38,
    amenities: ['wifi', 'ac', 'tv', 'restaurant', 'parking'],
    rating: 4.4,
    reviewCount: 145,
    latitude: 34.7384,
    longitude: 36.7128,
  },
  {
    titleAr: 'شقة الورود',
    titleEn: 'Flowers Apartment',
    descriptionAr: 'شقة عصرية مفروشة في حي هادئ، مناسبة للإقامات الطويلة والقصيرة.',
    type: AccommodationType.APARTMENT,
    addressAr: 'الورشة، حمص',
    basePrice: 55000,
    bedrooms: 2,
    bathrooms: 1,
    maxGuests: 4,
    beds: 2,
    size: 80,
    amenities: ['wifi', 'ac', 'kitchen', 'washer', 'tv', 'parking'],
    rating: 4.5,
    reviewCount: 76,
    latitude: 34.7484,
    longitude: 36.7228,
  },
  
  // Palmyra
  {
    titleAr: 'مخيم تدمر السياحي',
    titleEn: 'Palmyra Tourist Camp',
    descriptionAr: 'تجربة فريدة في قلب الصحراء السورية، بالقرب من آثار تدمر التاريخية. ليالي سحرية تحت النجوم.',
    type: AccommodationType.CAMP,
    addressAr: 'تدمر',
    basePrice: 70000,
    bedrooms: 1,
    bathrooms: 1,
    maxGuests: 2,
    beds: 1,
    size: 25,
    amenities: ['dinner', 'breakfast', 'guided_tours', 'stargazing'],
    rating: 4.8,
    reviewCount: 89,
    latitude: 34.5491,
    longitude: 38.2833,
  },
  {
    titleAr: 'فندق تدمر',
    titleEn: 'Palmyra Hotel',
    descriptionAr: 'فندق سياحي بالقرب من الموقع الأثري، يوفر جولات منظمة وخدمات دليل سياحي.',
    type: AccommodationType.HOTEL,
    addressAr: 'تدمر',
    basePrice: 95000,
    bedrooms: 1,
    bathrooms: 1,
    maxGuests: 3,
    beds: 2,
    size: 40,
    amenities: ['wifi', 'ac', 'restaurant', 'parking', 'guided_tours'],
    rating: 4.5,
    reviewCount: 112,
    latitude: 34.5591,
    longitude: 38.2933,
  },
  
  // Safita
  {
    titleAr: 'برج صافيتا',
    titleEn: 'Safita Tower Lodge',
    descriptionAr: 'إقامة فريدة في برج تاريخي، إطلالات خلابة على الجبال الساحلية.',
    type: AccommodationType.GUESTHOUSE,
    addressAr: 'صافيتا',
    basePrice: 65000,
    bedrooms: 1,
    bathrooms: 1,
    maxGuests: 2,
    beds: 1,
    size: 30,
    amenities: ['wifi', 'breakfast', 'mountain_view', 'hiking'],
    rating: 4.6,
    reviewCount: 34,
    latitude: 34.8556,
    longitude: 36.1169,
  },
  
  // Maaloula
  {
    titleAr: 'نزل معلولا التراثي',
    titleEn: 'Maaloula Heritage Lodge',
    descriptionAr: 'نزل تراثي في قرية معلولا التاريخية، تجربة ثقافية فريدة مع اللغة الآرامية.',
    type: AccommodationType.GUESTHOUSE,
    addressAr: 'معلولا',
    basePrice: 55000,
    bedrooms: 1,
    bathrooms: 1,
    maxGuests: 3,
    beds: 2,
    size: 35,
    amenities: ['wifi', 'breakfast', 'cultural_tours', 'traditional_food'],
    rating: 4.7,
    reviewCount: 56,
    latitude: 33.8794,
    longitude: 36.5728,
  },
]

// Community Categories
const categoriesData = [
  { nameAr: 'نصائح السفر', nameEn: 'Travel Tips', icon: '💡', color: '#f59e0b', order: 1 },
  { nameAr: 'تجارب الضيوف', nameEn: 'Guest Experiences', icon: '⭐', color: '#10b981', order: 2 },
  { nameAr: 'أسئلة وأجوبة', nameEn: 'Q&A', icon: '❓', color: '#3b82f6', order: 3 },
  { nameAr: 'دليل المضيفين', nameEn: 'Host Guide', icon: '🏠', color: '#8b5cf6', order: 4 },
  { nameAr: 'السياحة في سوريا', nameEn: 'Tourism in Syria', icon: '🗺️', color: '#ef4444', order: 5 },
]

// Community Posts
const postsData = [
  {
    titleAr: 'أفضل 10 أماكن للزيارة في دمشق',
    titleEn: 'Top 10 Places to Visit in Damascus',
    contentAr: 'دمشق من أقدم المدن المأهولة في العالم، وتحتضن العديد من المعالم التاريخية والثقافية. إليكم قائمة بأفضل الأماكن للزيارة:\n\n1. المسجد الأموي - تحفة معمارية إسلامية\n2. باب توما - بوابات دمشق القديمة\n3. سوق الحميدية - للتسوق والتراث\n4. قصر العظم - متحف الفنون\n5. حي القنوات - الأزقة التاريخية\n6. مقام السيدة زينب - مزار ديني\n7. جبل قاسيون - إطلالة بانورامية\n8. سوق البزورية - التوابل والحلويات\n9. خان أسعد باشا - العمارة العثمانية\n10. بيت خالد بن الوليد - متحف تاريخي',
    type: PostType.GUIDE,
    tags: ['دمشق', 'سياحة', 'معالم'],
  },
  {
    titleAr: 'تجربتي في منتجع البحر الأبيض',
    titleEn: 'My Experience at White Sea Resort',
    contentAr: 'قضيت عطلة رائعة في منتجع البحر الأبيض في اللاذقية. الخدمة كانت ممتازة، والغرف نظيفة ومريحة. الشاطئ الخاص نظيف جداً والمياه صافية. الأكل لذيذ خاصة المأكولات البحرية. أنصح الجميع بزيارته!',
    type: PostType.STORY,
    tags: ['لاذقية', 'منتجع', 'تجربة'],
  },
  {
    titleAr: 'سؤال: أفضل وقت لزيارة تدمر؟',
    titleEn: 'Question: Best Time to Visit Palmyra?',
    contentAr: 'أخطط لزيارة تدمر قريباً. ما هو أفضل وقت للزيارة؟ وهل هناك جولات منظمة تنصحون بها؟',
    type: PostType.QUESTION,
    tags: ['تدمر', 'سياحة', 'سؤال'],
  },
  {
    titleAr: 'نصائح للمضيفين الجدد',
    titleEn: 'Tips for New Hosts',
    contentAr: 'بعد تجربتي لمدة عام كمضيف، أشارككم بعض النصائح:\n\n1. التقط صوراً عالية الجودة لإقامتك\n2. كن سريعاً في الرد على الاستفسارات\n3. وفر تعليمات واضحة للوصول\n4. اهتم بالنظافة بشكل استثنائي\n5. أضف لمسات شخصية تجعل الضيوف يشعرون بالترحيب\n6. جمع التقييمات وحسّن بناءً عليها',
    type: PostType.GUIDE,
    tags: ['مضيفين', 'نصائح', 'استضافة'],
  },
  {
    titleAr: 'مقاهي دمشق التراثية',
    titleEn: 'Heritage Cafes in Damascus',
    contentAr: 'دمشق مليئة بالمقاهي التراثية الرائعة التي تعكس روح المدينة العريقة:\n\n- مقهى النوفرة: أقدم مقهى دمشقي مع قصاص الحكايات\n- مقهى البندقجي: إطلالة على الأسواق القديمة\n- مقهى مزة: للأراكيلة والشاي\n\nهل لديكم مقاهي أخرى تنصحون بها؟',
    type: PostType.DISCUSSION,
    tags: ['دمشق', 'مقاهي', 'تراث'],
  },
]

// Review Comments
const reviewComments = [
  'مكان رائع ومضيف متعاون جداً، أنصح به بشدة!',
  'الموقع ممتاز قريب من كل الخدمات، النظافة ممتازة.',
  'تجربة جميلة، سنعود بالتأكيد. شكراً للمضيف الكريم.',
  'الشقة نظيفة ومرتبة، الأسعار معقولة مقارنة بالخدمة.',
  'إقامة مريحة وهادئة، مثالية للعائلات.',
  'الإفطار لذيذ والموظفين ودودين.',
  'المسبح نظيف والحديقة جميلة، الأطفال استمتعوا كثيراً.',
  'إطلالة بحرية رائعة، الخدمة ممتازة.',
  'تجربة ثقافية فريدة، تعرفنا على تاريخ المنطقة.',
  'المكان هادئ ومناسب للراحة والاسترخاء.',
]

async function main() {
  console.log('🌱 Starting seed...')

  // Clean existing data
  console.log('🧹 Cleaning existing data...')
  await prisma.message.deleteMany()
  await prisma.conversation.deleteMany()
  await prisma.notification.deleteMany()
  await prisma.review.deleteMany()
  await prisma.payment.deleteMany()
  await prisma.booking.deleteMany()
  await prisma.availability.deleteMany()
  await prisma.room.deleteMany()
  await prisma.favorite.deleteMany()
  await prisma.accommodation.deleteMany()
  await prisma.attraction.deleteMany()
  await prisma.city.deleteMany()
  await prisma.communityLike.deleteMany()
  await prisma.communityComment.deleteMany()
  await prisma.communityPost.deleteMany()
  await prisma.communityCategory.deleteMany()
  await prisma.user.deleteMany()

  // Create Cities
  console.log('🏙️ Creating cities...')
  const cities = await Promise.all(
    citiesData.map((city) =>
      prisma.city.create({
        data: city,
      })
    )
  )
  console.log(`✅ Created ${cities.length} cities`)

  // Create Users
  console.log('👥 Creating users...')
  const users = await Promise.all(
    usersData.map((user) =>
      prisma.user.create({
        data: user,
      })
    )
  )
  console.log(`✅ Created ${users.length} users`)

  // Get hosts and guests
  const hosts = users.filter((u) => u.role === UserRole.HOST)
  const guests = users.filter((u) => u.role === UserRole.GUEST)

  // Image categories for different accommodation types
  const hotelImages = [
    'https://images.unsplash.com/photo-1566073771259-6a8506099945?w=800&q=80',
    'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?w=800&q=80',
    'https://images.unsplash.com/photo-1590490360182-c33d57733427?w=800&q=80',
    'https://images.unsplash.com/photo-1578683010236-d716f9a3f461?w=800&q=80',
    'https://images.unsplash.com/photo-1551882547-ff40c63fe5fa?w=800&q=80',
  ]
  const apartmentImages = [
    'https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?w=800&q=80',
    'https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=800&q=80',
    'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?w=800&q=80',
    'https://images.unsplash.com/photo-1493809842364-78817add7ffb?w=800&q=80',
    'https://images.unsplash.com/photo-1484154218962-a197022b5858?w=800&q=80',
  ]
  const villaImages = [
    'https://images.unsplash.com/photo-1613490493576-7fde63acd811?w=800&q=80',
    'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=800&q=80',
    'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=800&q=80',
    'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=800&q=80',
    'https://images.unsplash.com/photo-1600573472550-8090b5e0745e?w=800&q=80',
  ]
  const resortImages = [
    'https://images.unsplash.com/photo-1571896349842-33c89424de2d?w=800&q=80',
    'https://images.unsplash.com/photo-1520250497591-112f2f40a3f4?w=800&q=80',
    'https://images.unsplash.com/photo-1540541338287-41700207dee6?w=800&q=80',
    'https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?w=800&q=80',
    'https://images.unsplash.com/photo-1584132967334-10e028bd69f7?w=800&q=80',
  ]
  const chaletImages = [
    'https://images.unsplash.com/photo-1449158743715-0a90ebb6d2d8?w=800&q=80',
    'https://images.unsplash.com/photo-1510798831971-661eb04b3739?w=800&q=80',
    'https://images.unsplash.com/photo-1587061949409-02df41d5e562?w=800&q=80',
    'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=800&q=80',
    'https://images.unsplash.com/photo-1502082553048-f009c37129b9?w=800&q=80',
  ]
  const guesthouseImages = [
    'https://images.unsplash.com/photo-1596394516093-501ba68a0ba6?w=800&q=80',
    'https://images.unsplash.com/photo-1555854877-bab0e564b8d5?w=800&q=80',
    'https://images.unsplash.com/photo-1518733057094-95b53143d2a7?w=800&q=80',
    'https://images.unsplash.com/photo-1545044846-351ba102b6d5?w=800&q=80',
    'https://images.unsplash.com/photo-1584132915807-fd1f5fbc078f?w=800&q=80',
  ]
  const campImages = [
    'https://images.unsplash.com/photo-1504280390367-361c6d9f38f4?w=800&q=80',
    'https://images.unsplash.com/photo-1533632359083-0185df1be85d?w=800&q=80',
    'https://images.unsplash.com/photo-1478827536114-da961b7f86d2?w=800&q=80',
    'https://images.unsplash.com/photo-1510312305653-8ed496efae75?w=800&q=80',
    'https://images.unsplash.com/photo-1504851149312-7a075b496cc7?w=800&q=80',
  ]

  // Function to get images based on accommodation type
  const getImagesForType = (type: string, index: number): string[] => {
    let images: string[]
    switch (type) {
      case AccommodationType.HOTEL:
        images = hotelImages
        break
      case AccommodationType.APARTMENT:
        images = apartmentImages
        break
      case AccommodationType.VILLA:
        images = villaImages
        break
      case AccommodationType.RESORT:
        images = resortImages
        break
      case AccommodationType.CHALET:
        images = chaletImages
        break
      case AccommodationType.GUESTHOUSE:
        images = guesthouseImages
        break
      case AccommodationType.CAMP:
        images = campImages
        break
      default:
        images = hotelImages
    }
    // Shuffle and return 3-4 images
    const shuffled = [...images].sort(() => Math.random() - 0.5)
    return shuffled.slice(0, 3 + (index % 2))
  }

  // Create Accommodations
  console.log('🏠 Creating accommodations...')
  const accommodations = []
  for (let i = 0; i < accommodationsData.length; i++) {
    const accData = accommodationsData[i]
    const host = hosts[i % hosts.length]
    const city = cities.find((c) => accData.addressAr?.includes(c.nameAr)) || cities[0]
    
    // Get images for this accommodation type
    const accImages = getImagesForType(accData.type, i)

    const accommodation = await prisma.accommodation.create({
      data: {
        titleAr: accData.titleAr,
        titleEn: accData.titleEn,
        descriptionAr: accData.descriptionAr,
        type: accData.type,
        status: AccommodationStatus.ACTIVE,
        addressAr: accData.addressAr,
        cityId: city.id,
        latitude: accData.latitude,
        longitude: accData.longitude,
        bedrooms: accData.bedrooms,
        bathrooms: accData.bathrooms,
        maxGuests: accData.maxGuests,
        beds: accData.beds,
        size: accData.size,
        basePrice: accData.basePrice,
        amenities: JSON.stringify(accData.amenities),
        rating: accData.rating,
        reviewCount: accData.reviewCount,
        viewCount: Math.floor(Math.random() * 500) + 100,
        bookingCount: Math.floor(Math.random() * 50) + 10,
        hostId: host.id,
        images: JSON.stringify(accImages),
        coverImage: accImages[0],
      },
    })
    accommodations.push(accommodation)
  }
  console.log(`✅ Created ${accommodations.length} accommodations`)

  // Create Bookings
  console.log('📅 Creating bookings...')
  const bookings = []
  const bookingStatuses = [BookingStatus.CONFIRMED, BookingStatus.PAID, BookingStatus.CHECKED_IN, BookingStatus.CHECKED_OUT]
  
  for (let i = 0; i < 25; i++) {
    const guest = guests[i % guests.length]
    const accommodation = accommodations[i % accommodations.length]
    const status = bookingStatuses[i % bookingStatuses.length]
    
    const checkInDate = new Date()
    checkInDate.setDate(checkInDate.getDate() - Math.floor(Math.random() * 30) - 1)
    const checkOutDate = new Date(checkInDate)
    checkOutDate.setDate(checkOutDate.getDate() + Math.floor(Math.random() * 7) + 2)
    
    const nightsCount = Math.ceil((checkOutDate.getTime() - checkInDate.getTime()) / (1000 * 60 * 60 * 24))
    const baseAmount = accommodation.basePrice * nightsCount
    const serviceFee = baseAmount * 0.1
    const totalAmount = baseAmount + serviceFee

    const booking = await prisma.booking.create({
      data: {
        status,
        checkIn: checkInDate,
        checkOut: checkOutDate,
        nightsCount,
        guestsCount: Math.floor(Math.random() * 3) + 1,
        baseAmount,
        serviceFee,
        totalAmount,
        currency: 'SYP',
        guestName: guest.nameAr || guest.name,
        guestPhone: guest.phone,
        specialRequests: i % 3 === 0 ? 'أحتاج سرير إضافي للأطفال' : null,
        guestId: guest.id,
        accommodationId: accommodation.id,
        confirmedAt: status !== BookingStatus.PENDING ? new Date() : null,
      },
    })
    bookings.push(booking)
  }
  console.log(`✅ Created ${bookings.length} bookings`)

  // Create Reviews
  console.log('⭐ Creating reviews...')
  const reviews = []
  for (let i = 0; i < 40; i++) {
    const booking = bookings[i % bookings.length]
    const guest = guests.find((g) => g.id === booking.guestId) || guests[0]
    
    // Check if review already exists for this booking
    const existingReview = await prisma.review.findUnique({
      where: { bookingId: booking.id },
    })
    
    if (!existingReview) {
      const rating = Math.floor(Math.random() * 2) + 4 // 4 or 5 stars
      const review = await prisma.review.create({
        data: {
          rating,
          commentAr: reviewComments[i % reviewComments.length],
          cleanliness: rating,
          location: rating,
          value: rating,
          communication: rating,
          checkIn: rating,
          isVerified: true,
          userId: guest.id,
          accommodationId: booking.accommodationId,
          bookingId: booking.id,
        },
      })
      reviews.push(review)
    }
  }
  console.log(`✅ Created ${reviews.length} reviews`)

  // Create Conversations and Messages
  console.log('💬 Creating conversations...')
  const conversations = []
  for (let i = 0; i < 15; i++) {
    const guest = guests[i % guests.length]
    const host = hosts.find((h) => {
      const acc = accommodations.find((a) => a.hostId === h.id)
      return acc !== undefined
    }) || hosts[0]
    
    const conversation = await prisma.conversation.create({
      data: {
        type: 'inquiry',
        status: 'active',
        guestId: guest.id,
        hostId: host.id,
        lastMessage: 'شكراً لتواصلكم!',
        lastMessageAt: new Date(),
      },
    })

    // Create messages
    await prisma.message.createMany({
      data: [
        {
          content: 'مرحباً، هل الإقامة متاحة في التواريخ المحددة؟',
          type: 'text',
          isFromGuest: true,
          isRead: true,
          readAt: new Date(),
          conversationId: conversation.id,
          senderId: guest.id,
        },
        {
          content: 'أهلاً وسهلاً! نعم الإقامة متاحة. يمكنكم الحجز مباشرة.',
          type: 'text',
          isFromGuest: false,
          isRead: true,
          readAt: new Date(),
          conversationId: conversation.id,
          senderId: host.id,
        },
        {
          content: 'ما هي وسائل الراحة المتوفرة؟',
          type: 'text',
          isFromGuest: true,
          isRead: i < 10,
          readAt: i < 10 ? new Date() : null,
          conversationId: conversation.id,
          senderId: guest.id,
        },
        {
          content: 'الإقامة مجهزة بكل ما تحتاجونه: واي فاي، تكييف، مطبخ مجهز، ومواقف سيارات.',
          type: 'text',
          isFromGuest: false,
          isRead: i < 10,
          readAt: i < 10 ? new Date() : null,
          conversationId: conversation.id,
          senderId: host.id,
        },
      ],
    })
    conversations.push(conversation)
  }
  console.log(`✅ Created ${conversations.length} conversations with messages`)

  // Create Community Categories
  console.log('📂 Creating community categories...')
  const categories = await Promise.all(
    categoriesData.map((cat) =>
      prisma.communityCategory.create({
        data: cat,
      })
    )
  )
  console.log(`✅ Created ${categories.length} categories`)

  // Create Community Posts
  console.log('📝 Creating community posts...')
  const posts = []
  for (let i = 0; i < postsData.length; i++) {
    const postData = postsData[i]
    const author = users[Math.floor(Math.random() * users.length)]
    const category = categories[i % categories.length]

    const post = await prisma.communityPost.create({
      data: {
        titleAr: postData.titleAr,
        titleEn: postData.titleEn,
        contentAr: postData.contentAr,
        type: postData.type,
        status: PostStatus.PUBLISHED,
        viewCount: Math.floor(Math.random() * 200) + 50,
        likeCount: Math.floor(Math.random() * 30) + 5,
        commentCount: Math.floor(Math.random() * 10) + 2,
        isFeatured: i < 2,
        isPinned: i === 0,
        tags: JSON.stringify(postData.tags),
        authorId: author.id,
        categoryId: category.id,
      },
    })
    posts.push(post)

    // Create comments for each post
    for (let j = 0; j < Math.floor(Math.random() * 5) + 2; j++) {
      const commenter = users[Math.floor(Math.random() * users.length)]
      await prisma.communityComment.create({
        data: {
          contentAr: [
            'مقالة مفيدة جداً، شكراً للمشاركة!',
            'أضفت هذا إلى قائمة أماكن الزيارة.',
            'هل يمكنك تقديم المزيد من التفاصيل؟',
            'تجربة رائعة، أنا أيضاً زرت هذا المكان.',
            'نصائح قيمة للمسافرين الجدد.',
          ][j % 5],
          postId: post.id,
          authorId: commenter.id,
        },
      })
    }
  }
  console.log(`✅ Created ${posts.length} posts with comments`)

  // Create Notifications
  console.log('🔔 Creating notifications...')
  for (let i = 0; i < 20; i++) {
    const user = users[Math.floor(Math.random() * users.length)]
    const types = ['booking', 'message', 'review', 'system']
    const type = types[i % types.length]
    
    await prisma.notification.create({
      data: {
        type,
        titleAr: type === 'booking' ? 'حجز جديد' : type === 'message' ? 'رسالة جديدة' : type === 'review' ? 'تقييم جديد' : 'تحديث النظام',
        bodyAr: type === 'booking' ? 'لديك طلب حجز جديد ينتظر المراجعة.' : type === 'message' ? 'لديك رسالة جديدة من ضيف.' : type === 'review' ? 'تم إضافة تقييم جديد لإقامتك.' : 'تم تحديث النظام بميزات جديدة.',
        isRead: i < 5,
        readAt: i < 5 ? new Date() : null,
        userId: user.id,
      },
    })
  }
  console.log('✅ Created notifications')

  // Create Payments
  console.log('💳 Creating payments...')
  for (let i = 0; i < 10; i++) {
    const booking = bookings[i % bookings.length]
    const guest = guests.find((g) => g.id === booking.guestId) || guests[0]
    
    await prisma.payment.create({
      data: {
        amount: booking.totalAmount,
        currency: 'SYP',
        status: PaymentStatus.COMPLETED,
        method: i % 2 === 0 ? PaymentMethod.SYRIATEL : PaymentMethod.MTN,
        transactionId: `TXN${Date.now()}${i}`,
        completedAt: new Date(),
        bookingId: booking.id,
        userId: guest.id,
      },
    })
  }
  console.log('✅ Created payments')

  // ==================== TRANSPORT DATA ====================
  console.log('🚗 Creating transports...')
  
  const transportImages = {
    car: [
      'https://images.unsplash.com/photo-1449965408869-ebd3fee6ba24?w=800&q=80',
      'https://images.unsplash.com/photo-1502877338535-67f0686c0b39?w=800&q=80',
    ],
    carWithDriver: [
      'https://images.unsplash.com/photo-1549317661-bd32c8ce0db2?w=800&q=80',
    ],
    bus: [
      'https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?w=800&q=80',
    ],
  }
  
  const transportsData = [
    { titleAr: 'سيارة تويوتا كامري', type: 'CAR', brand: 'تويوتا', model: 'كامري', year: 2022, seats: 4, hasDriver: false, basePrice: 50000, cityId: cities[0].id },
    { titleAr: 'سيارة هيونداي سوناتا مع سائق', type: 'CAR_WITH_DRIVER', brand: 'هيونداي', model: 'سوناتا', year: 2023, seats: 4, hasDriver: true, basePrice: 80000, cityId: cities[0].id },
    { titleAr: 'باص سياحي 25 راكب', type: 'BUS', brand: 'مرسيدس', model: 'بينت', year: 2020, seats: 25, hasDriver: true, basePrice: 200000, cityId: cities[1].id },
    { titleAr: 'سيارة Kia Rio', type: 'CAR', brand: 'كيا', model: 'ريو', year: 2021, seats: 4, hasDriver: false, basePrice: 40000, cityId: cities[2].id },
    { titleAr: 'حافلة صغيرة 14 راكب', type: 'MINIVAN', brand: 'تويوتا', model: 'هايس', year: 2021, seats: 14, hasDriver: true, basePrice: 120000, cityId: cities[3].id },
  ]
  
  const transports = []
  for (let i = 0; i < transportsData.length; i++) {
    const tData = transportsData[i]
    const host = hosts[i % hosts.length]
    const images = tData.type === 'CAR' ? transportImages.car : 
                   tData.type === 'CAR_WITH_DRIVER' ? transportImages.carWithDriver : 
                   transportImages.bus
    
    const transport = await prisma.transport.create({
      data: {
        titleAr: tData.titleAr,
        type: tData.type as any,
        status: 'ACTIVE',
        brand: tData.brand,
        model: tData.model,
        year: tData.year,
        seats: tData.seats,
        hasDriver: tData.hasDriver,
        hasAC: true,
        basePrice: tData.basePrice,
        cityId: tData.cityId,
        hostId: host.id,
        images: JSON.stringify(images),
        coverImage: images[0],
        rating: 4.5 + (Math.random() * 0.5),
        reviewCount: Math.floor(Math.random() * 30) + 5,
        viewCount: Math.floor(Math.random() * 300) + 50,
        bookingCount: Math.floor(Math.random() * 30) + 5,
      },
    })
    transports.push(transport)
  }
  console.log(`✅ Created ${transports.length} transports`)

  // ==================== TOURS DATA ====================
  console.log('🧭 Creating tours...')
  
  const tourImages = [
    'https://images.unsplash.com/photo-1539650116574-8efeb43e2750?w=800&q=80',
    'https://images.unsplash.com/photo-1569949381669-ecf31ae8f613?w=800&q=80',
    'https://images.unsplash.com/photo-1552832230-c0197dd311b5?w=800&q=80',
  ]
  
  const toursData = [
    { titleAr: 'جولة دمشق التاريخية', type: 'HISTORICAL', duration: 6, maxGroupSize: 12, basePrice: 75000, cityId: cities[0].id, description: 'جولة في أحياء دمشق القديمة والمسجد الأموي' },
    { titleAr: 'جولة تدمر الأثرية', type: 'HISTORICAL', duration: 8, maxGroupSize: 15, basePrice: 100000, cityId: cities[6].id, description: 'زيارة آثار تدمر والمتحف' },
    { titleAr: 'جولة سياحة دينية - معلولا', type: 'RELIGIOUS', duration: 5, maxGroupSize: 10, basePrice: 60000, cityId: cities[8].id, description: 'زيارة الأديرة والكنائس التاريخية' },
    { titleAr: 'جولة الساحل السوري', type: 'NATURE', duration: 10, maxGroupSize: 8, basePrice: 120000, cityId: cities[3].id, description: 'جولة على شاطئ اللاذقية وطرطوس' },
    { titleAr: 'جولة تسوق في أسواق دمشق', type: 'SHOPPING', duration: 4, maxGroupSize: 6, basePrice: 40000, cityId: cities[0].id, description: 'جولة في أسواق دمشق التقليدية' },
    { titleAr: 'سياحة الحرب - حلب', type: 'WAR_TOURISM', duration: 6, maxGroupSize: 10, basePrice: 80000, cityId: cities[1].id, description: 'جولة تعريفية في المناطق المتأثرة بالحرب' },
  ]
  
  const tours = []
  for (let i = 0; i < toursData.length; i++) {
    const tData = toursData[i]
    const guide = hosts[i % hosts.length]
    
    const tour = await prisma.tour.create({
      data: {
        titleAr: tData.titleAr,
        descriptionAr: tData.description,
        type: tData.type as any,
        status: 'ACTIVE',
        duration: tData.duration,
        maxGroupSize: tData.maxGroupSize,
        basePrice: tData.basePrice,
        cityId: tData.cityId,
        guideId: guide.id,
        images: JSON.stringify([tourImages[i % tourImages.length]]),
        coverImage: tourImages[i % tourImages.length],
        rating: 4.5 + (Math.random() * 0.5),
        reviewCount: Math.floor(Math.random() * 25) + 5,
        viewCount: Math.floor(Math.random() * 400) + 100,
        bookingCount: Math.floor(Math.random() * 40) + 10,
        languages: JSON.stringify(['ar', 'en']),
        highlights: JSON.stringify(['جولة مرشدة', 'نقل مجاني', 'وجبة خفيفة']),
        included: JSON.stringify(['دليل سياحي', 'مياه', 'تأمين']),
      },
    })
    tours.push(tour)
  }
  console.log(`✅ Created ${tours.length} tours`)

  // ==================== BUSINESS DATA ====================
  console.log('🏢 Creating business listings...')
  
  const businessImages = [
    'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=800&q=80',
    'https://images.unsplash.com/photo-1497366216548-37526070297c?w=800&q=80',
    'https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?w=800&q=80',
  ]
  
  const businessData = [
    { titleAr: 'فرصة استثمارية - مشروع سياحي في اللاذقية', type: 'INVESTMENT_OPPORTUNITY', sector: 'سياحة', investmentMin: 50000000, expectedReturn: 15, cityId: cities[3].id },
    { titleAr: 'عقار تجاري - مبنى مكاتب في دمشق', type: 'COMMERCIAL_PROPERTY', sector: 'عقارات', price: 200000000, cityId: cities[0].id },
    { titleAr: 'خدمات استشارية للأعمال', type: 'BUSINESS_SERVICE', sector: 'خدمات', price: 500000, cityId: cities[0].id },
    { titleAr: 'شراكة في مطعم سياحي', type: 'PARTNERSHIP', sector: 'مطاعم', investmentMin: 10000000, investmentMax: 30000000, cityId: cities[1].id },
    { titleAr: 'امتياز فندق اقتصادي', type: 'FRANCHISE', sector: 'ضيافة', price: 50000000, cityId: cities[2].id },
  ]
  
  const businessListings = []
  for (let i = 0; i < businessData.length; i++) {
    const bData = businessData[i]
    const owner = hosts[i % hosts.length]
    
    const listing = await prisma.businessListing.create({
      data: {
        titleAr: bData.titleAr,
        type: bData.type as any,
        status: 'ACTIVE',
        sector: bData.sector,
        investmentMin: bData.investmentMin || null,
        investmentMax: bData.investmentMax || null,
        expectedReturn: bData.expectedReturn || null,
        price: bData.price || null,
        cityId: bData.cityId,
        ownerId: owner.id,
        images: JSON.stringify([businessImages[i % businessImages.length]]),
        coverImage: businessImages[i % businessImages.length],
        viewCount: Math.floor(Math.random() * 200) + 50,
        inquiryCount: Math.floor(Math.random() * 15) + 3,
      },
    })
    businessListings.push(listing)
  }
  console.log(`✅ Created ${businessListings.length} business listings`)

  console.log('\n🎉 Seed completed successfully!')
  console.log('\n📊 Summary:')
  console.log(`   Cities: ${cities.length}`)
  console.log(`   Users: ${users.length} (${hosts.length} hosts, ${guests.length} guests)`)
  console.log(`   Accommodations: ${accommodations.length}`)
  console.log(`   Transports: ${transports.length}`)
  console.log(`   Tours: ${tours.length}`)
  console.log(`   Business Listings: ${businessListings.length}`)
  console.log(`   Bookings: ${bookings.length}`)
  console.log(`   Reviews: ${reviews.length}`)
  console.log(`   Conversations: ${conversations.length}`)
  console.log(`   Community Posts: ${posts.length}`)
}

main()
  .catch((e) => {
    console.error('❌ Seed failed:', e)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })
