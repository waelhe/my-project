# 🏗️ بنية مشروع "ضيف" - Architecture Documentation

## 📋 نظرة عامة | Overview

**ضيف (Dayf)** - منصة سياحية سورية متكاملة تتبع بنية **Modular Monolith** مع فصل واضح للاهتمامات.

---

## 🗂️ هيكل الطبقات | Layered Architecture

```
src/
├── core/                    # طبقة النواة - Core Layer
│   ├── domain/             # كيانات وقواعد العمل
│   │   ├── entities/       # الكيانات الأساسية
│   │   ├── value-objects/  # كائنات القيمة
│   │   └── events/         # أحداث النظام
│   ├── application/        # خدمات التطبيق
│   │   ├── services/       # الخدمات المشتركة
│   │   ├── use-cases/      # حالات الاستخدام
│   │   └── ports/          # منافذ الواجهات (Interfaces)
│   └── infrastructure/     # البنية التحتية
│       ├── database/       # الوصول للبيانات
│       ├── external/       # الخدمات الخارجية
│       └── config/         # الإعدادات
│
├── modules/                 # الوحدات المستقلة | Feature Modules
│   ├── ai/                 # وحدة الذكاء الاصطناعي
│   │   ├── api/            # نقاط API
│   │   ├── components/     # المكونات
│   │   ├── lib/            # المكتبات
│   │   └── index.ts        # التصدير الرئيسي
│   │
│   ├── tourism/            # وحدة السياحة والمعالم
│   │   ├── api/
│   │   ├── components/
│   │   ├── lib/
│   │   └── index.ts
│   │
│   ├── booking/            # وحدة الحجوزات والإقامات
│   │   ├── api/
│   │   ├── components/
│   │   ├── lib/
│   │   └── index.ts
│   │
│   ├── community/          # وحدة المجتمع
│   │   ├── api/
│   │   ├── components/
│   │   ├── lib/
│   │   └── index.ts
│   │
│   ├── transport/          # وحدة النقل والمواصلات
│   │   ├── api/
│   │   ├── components/
│   │   ├── lib/
│   │   └── index.ts
│   │
│   ├── tours/              # وحدة الجولات السياحية
│   │   ├── api/
│   │   ├── components/
│   │   ├── lib/
│   │   └── index.ts
│   │
│   └── business/           # وحدة الأعمال والاستثمار
│       ├── api/
│       ├── components/
│       ├── lib/
│       └── index.ts
│
├── lib/                     # مكتبات مشتركة
│   ├── db.ts               # عميل قاعدة البيانات
│   ├── utils.ts            # الأدوات المساعدة
│   ├── auth-middleware.ts  # وسيط المصادقة
│   ├── rate-limiter.ts     # محدد الطلبات
│   └── validations/        # قواعد التحقق
│
├── components/              # مكونات UI مشتركة
│   ├── ui/                 # مكونات shadcn/ui
│   ├── auth/               # مكونات المصادقة
│   ├── chat/               # مكونات المحادثة
│   └── tourism/            # مكونات السياحة
│
├── hooks/                   # React Hooks مشتركة
│   ├── use-mobile.ts
│   └── use-toast.ts
│
└── app/                     # Next.js App Router
    ├── api/                # نقاط API (تستدعي modules)
    ├── layout.tsx          # التخطيط الرئيسي
    └── page.tsx            # الصفحة الرئيسية
```

---

## 🔌 واجهات الاعتماد | Dependency Interfaces

### 1. واجهة قاعدة البيانات (Repository Pattern)
```typescript
// core/application/ports/IRepository.ts
interface IRepository<T> {
  findById(id: string): Promise<T | null>;
  findAll(filter?: FilterOptions): Promise<T[]>;
  create(data: Partial<T>): Promise<T>;
  update(id: string, data: Partial<T>): Promise<T>;
  delete(id: string): Promise<boolean>;
}
```

### 2. واجهة المصادقة
```typescript
// core/application/ports/IAuthService.ts
interface IAuthService {
  verifyPhone(phone: string): Promise<OTPResult>;
  verifyOTP(phone: string, code: string): Promise<AuthResult>;
  getCurrentUser(): Promise<User | null>;
  logout(): Promise<void>;
}
```

### 3. واجهة الذكاء الاصطناعي
```typescript
// core/application/ports/IAIService.ts
interface IAIProvider {
  chat(messages: Message[]): Promise<string>;
  analyzeImage(image: string): Promise<ImageAnalysis>;
  transcribe(audio: Buffer): Promise<string>;
  synthesize(text: string): Promise<Buffer>;
}
```

---

## 📦 الوحدات المستقلة | Feature Modules

كل وحدة تتبع نفس الهيكل:

```
module/
├── api/              # نقاط API
│   └── route.ts     # معالجات الطلبات
├── components/       # مكونات React
├── lib/
│   ├── types.ts     # أنواع TypeScript
│   ├── service.ts   # منطق الأعمال
│   └── utils.ts     # أدوات مساعدة
└── index.ts         # التصدير الرئيسي
```

### قواعد الوحدات:
1. ✅ كل وحدة مستقلة وقابلة للاختبار منفصلة
2. ✅ التواصل بين الوحدات عبر Events أو Services مشتركة
3. ✅ لا تبعيات مباشرة بين الوحدات
4. ✅ كل وحدة تصدر من index.ts خاص بها

---

## 🔄 أحداث النظام | Domain Events

```typescript
// core/domain/events/
const EVENTS = {
  BOOKING_CREATED: 'booking.created',
  BOOKING_CONFIRMED: 'booking.confirmed',
  PAYMENT_COMPLETED: 'payment.completed',
  REVIEW_ADDED: 'review.added',
  USER_REGISTERED: 'user.registered',
};
```

---

## 🚀 نقاط التوسع | Extension Points

### 1. إضافة وحدة جديدة
1. أنشئ مجلد في `src/modules/new-module/`
2. أضف الهيكل القياسي (api, components, lib)
3. صدر من `index.ts`
4. أضف في `src/modules/index.ts` الرئيسي

### 2. إضافة API جديد
1. أنشئ في `src/app/api/new-endpoint/route.ts`
2. استخدم الـ services من الوحدات
3. لا تكتب منطق أعمال في الـ route

### 3. إضافة خدمة AI جديدة
1. نفذ واجهة `IAIService`
3. سجل في الـ container
4. استخدم عبر Dependency Injection

---

## ⚠️ قواعد صارمة | Strict Rules

### ممنوع:
- ❌ منطق أعمال في `app/api/routes`
- ❌ استعلامات قاعدة بيانات مباشرة في المكونات
- ❌ تبعيات دائرية بين الوحدات
- ❌ استيراد مباشر من `node_modules` بدون تجريد

### واجب:
- ✅ كل منطق أعمال في services
- ✅ قاعدة البيانات عبر repository فقط
- ✅ التواصل بين الوحدات عبر interfaces
- ✅ إضافة اختبارات للـ services

---

## 📊 نموذج البيانات | Data Model

```
User ──┬── owns ──────► Accommodation
       │                    │
       ├── makes ──────► Booking
       │                    │
       ├── writes ─────► Review
       │
       ├── creates ────► Transport
       │
       ├── guides ─────► Tour
       │
       └── owns ───────► BusinessListing

City ──┬── has ────────► Accommodation[]
       │
       ├── has ────────► Transport[]
       │
       ├── has ────────► Tour[]
       │
       └── has ────────► BusinessListing[]
```

---

## 🔐 الأمان | Security

1. **المصادقة**: OTP عبر الهاتف
2. **التفويض**: Role-based (Guest, Host, Admin)
3. **API Protection**: Rate limiting, CSRF tokens
4. **Data Validation**: Zod schemas

---

## 📈 الأداء | Performance

1. **Caching**: في الذاكرة للبيانات المتكررة
2. **Pagination**: لجميع القوائم
3. **Lazy Loading**: للمكونات الثقيلة
4. **Image Optimization**: Next.js Image

---

## 🧪 الاختبارات | Testing

```
tests/
├── unit/           # اختبارات الوحدات
├── integration/    # اختبارات التكامل
└── e2e/           # اختبارات شاملة
```

---

## 📝 التحديثات المستقبلية | Future Updates

- [ ] إضافة نظام الإشعارات الفورية (WebSocket)
- [ ] إضافة نظام الدفع الإلكتروني المتكامل
- [ ] إضافة دعم تعدد اللغات الكامل
- [ ] إضافة نظام التقارير والإحصائيات المتقدم
- [ ] إضافة API للجهات الخارجية

---

*آخر تحديث: March 2024 | بنية Modular Monolith*
