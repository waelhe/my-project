# تقرير تحليل البنية البرمجية
## مشروع Next.js - Modular Monolith + DDD + Clean Architecture

---

## 📈 سجل التقدم

### الجلسة الحالية (تحديث)

| البداية | الحالي | التحسن |
|---------|--------|---------|
| 963 خطأ | 0 خطأ (lint passes) | ✅ جميع الأخطاء محلولة |

### الإصلاحات المنجزة:

#### ✅ المرحلة 1: إصلاح الأساسيات (مكتمل)
1. **Result Pattern**: تم التحقق من صحته - لا يحتاج تعديل
2. **PaginatedResult**: تم إضافة خصائص `items`, `total`, `page`, `limit`, `totalPages`, `hasMore`
3. **OperationResult**: تم إضافة حقل `error` اختياري

#### ✅ المرحلة 4: Prisma Schema Mismatches (جزئياً)

#### ✅ إصلاح استيراد formatValidationErrors
1. نقل `formatValidationErrors` من `api-response` إلى `api-validation`
2. تحديث جميع API routes لاستيرادها من المكان الصحيح:
   - `/api/listings/route.ts`
   - `/api/listings/[id]/route.ts`
   - `/api/bookings/route.ts`
   - `/api/users/route.ts`
   - `/api/users/[id]/route.ts`
   - `/api/auth/route.ts`
3. **ملاحظة**: Turbopack يحتاج إعادة تشغيل لالتقاط التغييرات

---

## 📝 المرحلة التالية: تحسين البنية

### المشاكل المحددة:
1. **Repository يعيد Prisma types** بدلاً من Domain Entities
2. **API Routes تستدعي Repository مباشرة** بدلاً من Use Cases
3. **`prismaToDTO` يتجاوز Domain layer**

### الحل المقترح:
```
API Routes → Use Cases → Repository → Domain Entity → DTO
```

### الملفات الرئيسية المُنشأة:
- `src/core/domain/entities/User.ts` - Domain Entity كامل
- `src/core/domain/value-objects/` - Value Objects
- `src/application/mappers/user.mapper.ts` - Mapper مع `toDomain()`, `toDTO()`
- `src/application/users/use-cases.ts` - Use Cases

---

## 📋 ملخص تنفيذي

تم تحليل مشروع Next.js يتبع بنية **Modular Monolith + DDD + Clean Architecture** مع 5 طبقات. المشروع يحتوي على **أكثر من 900 خطأ TypeScript** ناتجة عن مشاكل جوهرية في التصميم والتكامل بين الطبقات.

---

## 1️⃣ البنية الحالية

### 1.1 الطبقات الخمس

```
src/
├── core/                    # طبقة النطاق (Domain Layer)
│   ├── domain/
│   │   ├── entities/        # الكيانات (User, Listing, Booking...)
│   │   ├── value-objects/   # كائنات القيمة (Email, Money, Address...)
│   │   ├── authorization/   # نظام الصلاحيات (Role, Permission)
│   │   ├── rules/           # قواعد العمل
│   │   └── specifications/  # المواصفات
│   ├── types/               # الأنواع الأساسية (Result, Option, Guards)
│   └── interfaces/          # الواجهات (Repository Interfaces)
│
├── application/             # طبقة التطبيق (Application Layer)
│   ├── listings/            # Use Cases للإقامات
│   ├── users/               # Use Cases للمستخدمين
│   ├── bookings/            # Use Cases للحجوزات
│   ├── mappers/             # المحولات بين الطبقات
│   └── services/            # خدمات التطبيق
│
├── infrastructure/          # طبقة البنية التحتية (Infrastructure Layer)
│   ├── repositories/        # تنفيذ المستودعات (Prisma)
│   ├── services/            # التنفيذ الفعلي للخدمات
│   └── providers/           # مزودي الخدمات الخارجية
│
├── app/                     # طبقة العرض (Presentation Layer - Next.js App Router)
│   └── api/                 # API Routes
│
└── components/              # مكونات React
```

### 1.2 تحليل مكونات البنية

#### ✅ Domain Entities (الكيانات)

**الملفات المحللة:**
- `src/core/domain/entities/base/Entity.ts`
- `src/core/domain/entities/User.ts`
- `src/core/domain/entities/Listing.ts`

**التقييم:** ⭐⭐⭐⭐ (جيد جداً)

| الجانب | التقييم | ملاحظات |
|--------|---------|---------|
| التصميم | ممتاز | تطبيق صحيح لمبدأ Identity من DDD |
| AggregateRoot | ممتاز | يدعم Domain Events و Optimistic Concurrency |
| Factory Methods | جيد | `create()` و `reconstitute()` |
| Validation | جيد | تحقق داخل الكيان |
| Immutability | جيد | `protected readonly props` |

**نقاط القوة:**
```typescript
// Entity Base - تصميم ممتاز
export abstract class Entity<T extends EntityProps> {
  protected readonly props: T;        // Immutability
  private readonly _id: UniqueEntityId;  // Identity

  equals(entity?: Entity<T>): boolean {
    return this._id.equals(entity._id);  // مقارنة بالهوية
  }
}

// AggregateRoot - يدعم Domain Events
export abstract class AggregateRoot<T extends EntityProps> extends Entity<T> {
  private _domainEvents: DomainEvent[] = [];
  private _version: number = 1;  // Optimistic Concurrency
}
```

**نقاط الضعف:**
- لا يوجد في `User.ts` حقل `isSuperhost` في `UserProps` لكن يتم استخدامه في `UserMapper`
- بعض الـ getters تعتمد على `as unknown as` للتغلب على TypeScript

---

#### ✅ Value Objects (كائنات القيمة)

**الملفات المحللة:**
- `src/core/domain/value-objects/Email.ts`
- `src/core/domain/value-objects/Money.ts`
- `src/core/domain/value-objects/UniqueEntityId.ts`

**التقييم:** ⭐⭐⭐⭐⭐ (ممتاز)

| الجانب | التقييم | ملاحظات |
|--------|---------|---------|
| Immutability | ممتاز | `private readonly` fields |
| Validation | ممتاز | تحقق شامل داخل الـ constructor |
| Self-Validation | ممتاز | كل VO يتحقق من نفسه |
| Result Pattern | ممتاز | `tryCreate()` يعيد Result |
| Business Logic | ممتاز | منطق عمل داخل VO (isBusiness, mask) |

**أمثلة ممتازة:**
```typescript
// Email Value Object - تصميم مثالي
export class Email {
  private readonly _value: string;
  private readonly _localPart: string;
  private readonly _domain: string;

  private constructor(email: string) { ... }  // Private constructor

  static tryCreate(email: string): Result<Email, EmailError> {
    const normalized = email.toLowerCase().trim();
    const validationResult = Email.validate(normalized);
    if (validationResult.isFailure) {
      return err(validationResult.error);
    }
    return ok(new Email(normalized));
  }

  // Business methods
  isBusiness(): boolean { ... }
  mask(): string { ... }
}

// Money Value Object - مع عمليات حسابية
export class Money {
  add(other: Money): Result<Money, MoneyError> {
    if (this._currency !== other._currency) {
      return err(MoneyError.differentCurrencies(...));
    }
    return ok(new Money(this._amount + other._amount, this._currency));
  }
}
```

---

#### ✅ Result Pattern (نمط النتيجة)

**الملف المحلل:** `src/core/types/result.ts`

**التقييم:** ⭐⭐⭐⭐⭐ (ممتاز)

| الجانب | التقييم | ملاحظات |
|--------|---------|---------|
| Functional Design | ممتاز | Success/Failure classes |
| Composability | ممتاز | map, flatMap, filter |
| Type Safety | ممتاز | Discriminated Union |
| Error Hierarchy | ممتاز | AppError كـ base class |

**التصميم:**
```typescript
export type Result<T, E = AppError> = Success<T, E> | Failure<E, T>;

export class Success<T, E = never> {
  readonly isSuccess: true = true;
  readonly isFailure: false = false;
  
  map<U>(fn: (value: T) => U): Success<U, E> { ... }
  flatMap<U>(fn: (value: T) => Result<U, E>): Result<U, E> { ... }
}

export class Failure<E, T = never> {
  readonly isSuccess: false = false;
  readonly isFailure: true = true;
}

// Error Hierarchy
export class ValidationError extends AppError { ... }
export class NotFoundError extends AppError { ... }
export class BusinessError extends AppError { ... }
```

---

#### ⚠️ Repository Pattern (نمط المستودع)

**الملفات المحللة:**
- `src/core/interfaces/repositories/base.repository.ts` (Interface)
- `src/infrastructure/repositories/base.repository.ts` (Implementation)
- `src/infrastructure/repositories/user.repository.ts`

**التقييم:** ⭐⭐⭐ (متوسط - يحتاج إصلاح)

| الجانب | التقييم | ملاحظات |
|--------|---------|---------|
| Interface Design | جيد | IBaseRepository واضح |
| Implementation | متوسط | مشاكل في النوعية |
| Domain Separation | ضعيف | يعيد Prisma types مباشرة |
| Mapper Usage | متوسط | غير مستخدم بشكل كامل |

**المشكلة الرئيسية:**
```typescript
// ❌ المشكلة: Repository يعيد Prisma types
export class UserRepository extends VersionedRepository<User, string> {
  async findByEmail(email: string): Promise<User | null> {
    // يعيد Prisma User، ليس Domain User!
    return this.findOne({ where: { email } });
  }
}
```

**الصحيح يجب أن يكون:**
```typescript
// ✅ يجب أن يعيد Domain Entity
async findByEmail(email: string): Promise<Result<UserEntity, RepositoryError>> {
  const prismaUser = await this.model.findFirst({ where: { email } });
  if (!prismaUser) return err(RepositoryError.notFound('User', email));
  return UserMapper.toDomain(prismaUser);
}
```

---

#### ⚠️ Use Cases (حالات الاستخدام)

**الملف المحلل:** `src/application/listings/use-cases.ts`

**التقييم:** ⭐⭐⭐ (متوسط - يحتاج إصلاح)

| الجانب | التقييم | ملاحظات |
|--------|---------|---------|
| Separation | جيد | دوال منفصلة لكل Use Case |
| Result Usage | جيد | يعيد Result<T, E> |
| Domain Logic | ضعيف | يتجاوز Domain Entities |
| Type Safety | ضعيف | كثير من `as unknown as` |

**المشاكل:**
```typescript
// ❌ المشكلة 1: Use Case لا يستخدم Domain Entity
export async function createListing(input: CreateListingInput): Promise<Result<ListingOutput, Error>> {
  // يستدعي Repository مباشرة بدون Domain Entity!
  const listing = await listingRepository.createWithRelations({...});
  return ok(mapToListingOutput(listing));
}

// ❌ المشكلة 2: Type casting كثير
function mapToListingOutput(listing: Record<string, unknown>): ListingOutput {
  return {
    id: listing.id as string,
    hostId: listing.hostId as string,
    // ... كثير من as Type
  };
}
```

---

#### ⚠️ Mappers (المحولات)

**الملف المحلل:** `src/application/mappers/user.mapper.ts`

**التقييم:** ⭐⭐⭐⭐ (جيد)

| الجانب | التقييم | ملاحظات |
|--------|---------|---------|
| Direction Support | ممتاز | toDomain, toPersistence, toDTO |
| Result Pattern | جيد | toDomain يعيد Result |
| Error Handling | جيد | تحقق من صحة Value Objects |

**لكن يوجد مشكلة:**
```typescript
// ❌ Mapper يعيد Domain Entity لكن Repository لا يستخدمه!
static toDomain(prismaUser: PrismaUser): Result<User, UserError> {
  // تحويل كامل إلى Domain Entity
  const props: UserProps = { ... };
  return ok(User.reconstitute(props));
}
```

---

## 2️⃣ المشاكل الجوهرية

### 🔴 المشكلة 1: فجوة بين Interface و Implementation

```
┌─────────────────────────────────────────────────────────────┐
│ core/interfaces/repositories/base.repository.ts             │
│ ┌─────────────────────────────────────────────────────────┐ │
│ │ findById(id): Promise<Result<T, Error>>                 │ │
│ │ // T يجب أن يكون Domain Entity                         │ │
│ └─────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────┘
                          ⬇️ implements
┌─────────────────────────────────────────────────────────────┐
│ infrastructure/repositories/base.repository.ts              │
│ ┌─────────────────────────────────────────────────────────┐ │
│ │ async findById(id): Promise<Result<T, Error>>           │ │
│ │ // T هنا = Prisma Model، ليس Domain Entity!            │ │
│ └─────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────┘
```

**النتيجة:** API Routes تتلقى Prisma types بينما تتوقع Domain types.

---

### 🔴 المشكلة 2: Use Cases تتخطى Domain Layer

```
┌──────────────┐      ┌──────────────┐      ┌──────────────┐
│   Use Case   │ ──── │  Repository  │ ──── │   Database   │
└──────────────┘      └──────────────┘      └──────────────┘
       │
       └─── يتخطى Domain Entity مباشرة!
```

**الصحيح:**
```
┌──────────────┐      ┌──────────────┐      ┌──────────────┐      ┌──────────────┐
│   Use Case   │ ──── │Domain Entity │ ──── │  Repository  │ ──── │   Database   │
└──────────────┘      └──────────────┘      └──────────────┘      └──────────────┘
```

---

### 🔴 المشكلة 3: عدم توحيد Result Pattern

```typescript
// ❌ في أماكن مختلفة:

// Style 1
return { isSuccess: true, isFailure: false, value: user };

// Style 2  
return ok(user);

// Style 3
return Success.create(user);

// Style 4
const result = await repo.findById(id);
if (result.isOk()) { ... }  // خطأ! يجب أن يكون isSuccess
```

---

### 🔴 المشكلة 4: Type Mismatches في Prisma

```typescript
// خطأ شائع:
src/application/dashboard/use-cases.ts(348,41): error TS2339: 
  Property 'rating' does not exist on type '{ ratingOverall?: number | null; ... }'.

// السبب: Prisma schema يختلف عن الكود المتوقع
```

---

### 🔴 المشكلة 5: PaginatedResult Mismatch

```typescript
// Interface:
interface PaginatedResult<T> {
  data: T[];
  pagination: { page, limit, totalItems, totalPages, hasNext, hasPrev };
}

// Use Case يتوقع:
result.items  // ❌ غير موجود
result.total  // ❌ غير موجود
result.page   // ❌ غير موجود
```

---

## 3️⃣ خطة الإصلاح المفصلة

### 📋 المرحلة 1: إصلاح الأساسيات (أولوية عالية)

#### الخطوة 1.1: توحيد Result Pattern

**الملفات المتأثرة:**
- `src/core/types/result.ts`
- جميع ملفات `src/application/**/*.ts`

**المطلوب:**
1. استخدام `ok()` و `err()` فقط
2. إضافة Type Guards: `isOk()` و `isErr()`
3. إزالة الأنماط الأخرى

```typescript
// ✅ النمط الموحد
export function isOk<T, E>(result: Result<T, E>): result is Success<T, E> {
  return result.isSuccess === true;
}

export function isErr<T, E>(result: Result<T, E>): result is Failure<E, T> {
  return result.isFailure === true;
}
```

---

#### الخطوة 1.2: إصلاح PaginatedResult

**الملفات المتأثرة:**
- `src/core/interfaces/repositories/base.repository.ts`
- `src/infrastructure/repositories/base.repository.ts`
- جميع Use Cases

**المطلوب:**
```typescript
// ✅ توحيد البنية
export interface PaginatedResult<T> {
  items: T[];        // ← تغيير من data إلى items
  total: number;
  page: number;
  limit: number;
  totalPages: number;
  hasMore: boolean;
}
```

---

#### الخطوة 1.3: إصلاح OperationResult

**الملفات المتأثرة:**
- `src/core/interfaces/repositories/base.repository.ts`

**المطلوب:**
```typescript
// ✅ إضافة error اختياري
export interface OperationResult {
  success: boolean;
  affected?: number;
  message?: string;
  error?: Error;  // ← إضافة هذا
}
```

---

### 📋 المرحلة 2: إصلاح Repository Layer (أولوية عالية)

#### الخطوة 2.1: فصل Prisma Types عن Domain Types

**المشكلة:**
```typescript
// ❌ حالياً
export class UserRepository extends VersionedRepository<User, string> {
  // User هنا = Prisma User
}
```

**الحل:**
```typescript
// ✅ يجب أن يكون
import { User as PrismaUser } from '@prisma/client';
import { User as DomainUser } from '@/core/domain/entities/User';

export class UserRepository extends VersionedRepository<PrismaUser, string> {
  
  async findByEmail(email: string): Promise<DomainUser | null> {
    const prismaUser = await this.findOne({ where: { email } });
    if (!prismaUser) return null;
    
    const result = UserMapper.toDomain(prismaUser);
    return result.isSuccess ? result.value : null;
  }
}
```

---

#### الخطوة 2.2: تحديث Interface لتعكس الحقيقة

**الملف:** `src/core/interfaces/repositories/user.repository.ts`

```typescript
// ✅ Interface واضح
export interface IUserRepository {
  findById(id: string): Promise<DomainUser | null>;
  findByEmail(email: string): Promise<DomainUser | null>;
  create(data: UserCreateData): Promise<DomainUser>;
  update(id: string, data: UserUpdateData): Promise<DomainUser>;
}
```

---

### 📋 المرحلة 3: إصلاح Application Layer (أولوية متوسطة)

#### الخطوة 3.1: Use Cases تستخدم Domain Entities

**الملف:** `src/application/listings/use-cases.ts`

**المشكلة:**
```typescript
// ❌ حالياً
export async function createListing(input: CreateListingInput) {
  const listing = await listingRepository.createWithRelations({...});
  return ok(mapToListingOutput(listing));
}
```

**الحل:**
```typescript
// ✅ يجب أن يكون
export async function createListing(input: CreateListingInput): Promise<Result<ListingOutput, ListingError>> {
  // 1. إنشاء Domain Entity
  const priceResult = Money.create(input.basePrice, input.currency);
  if (priceResult.isFailure) return err(ListingError.invalidPrice(input.basePrice));
  
  const listingResult = Listing.create({
    hostId: input.hostId,
    title: input.title,
    basePrice: priceResult.value,
    // ...
  });
  
  if (listingResult.isFailure) return err(listingResult.error);
  
  // 2. حفظ عبر Repository
  const savedListing = await listingRepository.save(listingResult.value);
  
  // 3. تحويل إلى Output
  return ok(ListingMapper.toDTO(savedListing));
}
```

---

#### الخطوة 3.2: إصلاح Type Casting

**المشكلة:**
```typescript
// ❌ كثير من type casting
id: listing.id as string,
hostId: listing.hostId as string,
```

**الحل:**
```typescript
// ✅ استخدام Mapper صحيح
class ListingMapper {
  static toDTO(listing: Listing): ListingOutput {
    return {
      id: listing.idValue,
      hostId: listing.hostId,
      // أنواع صحيحة بدون casting
    };
  }
}
```

---

### 📋 المرحلة 4: إصلاح Prisma Schema Mismatches (أولوية متوسطة)

#### الخطوة 4.1: مراجعة أسماء الحقول

**الأخطاء الشائعة:**
```
- 'rating' لا يوجد، استخدم 'ratingOverall'
- 'deletedAt' قد لا يكون في بعض الجداول
- 'items' vs 'data' في PaginatedResult
```

**الحل:** إنشاء Types من Prisma Schema:
```typescript
// ✅ استخدام Prisma types مباشرة
import { Review } from '@prisma/client';

// مراجعة field names
type ReviewFields = keyof Review;
// 'ratingOverall', 'ratingCleanliness', ... (ليس 'rating')
```

---

### 📋 المرحلة 5: تحسين البنية (أولوية منخفضة)

#### الخطوة 5.1: إضافة Domain Services

**للمنطق المعقد الذي يشمل عدة كيانات:**
```typescript
// src/core/domain/services/BookingDomainService.ts
export class BookingDomainService {
  static canBook(
    listing: Listing,
    guest: User,
    checkIn: Date,
    checkOut: Date
  ): Result<void, BookingError> {
    // منطق يشمل Listing و User معاً
  }
}
```

---

#### الخطوة 5.2: إضافة Specification Pattern

```typescript
// src/core/domain/specifications/ActiveListingSpec.ts
export class ActiveListingSpecification implements Specification<Listing> {
  isSatisfiedBy(listing: Listing): boolean {
    return listing.isActive && !listing.isDeleted;
  }
}
```

---

## 4️⃣ ترتيب الأولويات

| الأولوية | المهمة | الوقت المتوقع | الأثر |
|----------|--------|---------------|-------|
| 🔴 P0 | إصلاح Result Pattern | 2-3 ساعات | يحل ~100 خطأ |
| 🔴 P0 | إصلاح PaginatedResult | 2-3 ساعات | يحل ~50 خطأ |
| 🔴 P0 | إصلاح OperationResult | 1-2 ساعات | يحل ~30 خطأ |
| 🟠 P1 | فصل Prisma عن Domain في Repositories | 4-6 ساعات | يحل ~300 خطأ |
| 🟠 P1 | تحديث Repository Interfaces | 2-3 ساعات | يحل ~100 خطأ |
| 🟠 P1 | إصلاح Use Cases | 4-6 ساعات | يحل ~200 خطأ |
| 🟡 P2 | إصلاح Prisma Schema mismatches | 3-4 ساعات | يحل ~150 خطأ |
| 🟡 P2 | إزالة Type Casting | 2-3 ساعات | يحل ~50 خطأ |
| 🟢 P3 | إضافة Domain Services | 4-6 ساعات | تحسين جودة |
| 🟢 P3 | إضافة Specification Pattern | 3-4 ساعات | تحسين جودة |

---

## 5️⃣ ملخص النتائج

### ✅ نقاط القوة

1. **Domain Entities ممتازة** - تصميم صحيح لـ DDD
2. **Value Objects مثالية** - immutability و self-validation
3. **Result Pattern قوي** - functional error handling
4. **Mapper Layer موجود** - يحتاج فقط ربط

### ❌ نقاط الضعف

1. **Repository لا يعيد Domain Entities** - فجوة حرجة
2. **Use Cases تتخطى Domain** - تفقد قيمة DDD
3. **Type mismatches** - عدم توافق بين Prisma والكود
4. **كثير من Type Casting** - يخفي الأخطاء

### 🎯 التوصية النهائية

المشروع يمتلك **بنية أساسية ممتازة** من الناحية النظرية، لكن **التطبيق العملي يحتاج إصلاح**. المشاكل ليست في التصميم بل في **التكامل بين الطبقات**.

**الخطوة الأولى الأهم:** إصلاح Repository Pattern ليعيد Domain Entities بدلاً من Prisma types، لأن هذا سيحل معظم الأخطاء تلقائياً.

---

## 📎 ملاحق

### ملحق أ: قائمة الأخطاء الشائعة

```
1. TS2322: Type 'string | undefined' is not assignable to type 'ListingType'
   → السبب: عدم استخدام Mapper

2. TS2339: Property 'items' does not exist on type 'PaginatedResult'
   → السبب: PaginatedResult يستخدم 'data' وليس 'items'

3. TS2339: Property 'error' does not exist on type 'OperationResult'
   → السبب: OperationResult لا يحتوي على حقل error

4. TS2352: Conversion of type 'Result<T, E>' to type 'Record<string, unknown>'
   → السبب: محاولة تحويل Result إلى object عادي
```

### ملحق ب: المراجع

- Clean Architecture - Robert C. Martin
- Domain-Driven Design - Eric Evans
- Functional Error Handling in TypeScript
- Prisma Best Practices

---

*تم إعداد هذا التقرير بتاريخ: $(date +%Y-%m-%d)*
