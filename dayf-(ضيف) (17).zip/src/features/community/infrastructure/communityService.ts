import { db } from '../../../firebase';
import { 
  collection, 
  getDocs, 
  getDoc, 
  doc, 
  addDoc, 
  updateDoc, 
  query, 
  where, 
  orderBy, 
  limit, 
  onSnapshot, 
  serverTimestamp, 
  increment,
  Timestamp
} from 'firebase/firestore';
import { CommunityTopic, Reply, MemberProfile } from '../types';

const TOPICS_COLLECTION = 'community_topics';
const REPLIES_COLLECTION = 'community_replies';
const USERS_COLLECTION = 'users';

export const communityService = {
  getMemberProfile: async (uid: string): Promise<MemberProfile | null> => {
    const docRef = doc(db, USERS_COLLECTION, uid);
    const docSnap = await getDoc(docRef);
    if (docSnap.exists()) {
      return { uid: docSnap.id, ...docSnap.data() } as MemberProfile;
    }
    return null;
  },
  getTopics: async (categoryId?: string, maxLimit: number = 20): Promise<CommunityTopic[]> => {
    const q = query(collection(db, TOPICS_COLLECTION));
    const snapshot = await getDocs(q);
    
    let topics = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as CommunityTopic));
    
    if (categoryId) {
      topics = topics.filter(t => t.categoryId === categoryId);
    }
    
    topics.sort((a, b) => {
      const dateA = a.createdAt?.toDate ? a.createdAt.toDate() : new Date(a.createdAt);
      const dateB = b.createdAt?.toDate ? b.createdAt.toDate() : new Date(b.createdAt);
      return dateB.getTime() - dateA.getTime();
    });
    
    return topics.slice(0, maxLimit);
  },

  subscribeToTopics: (callback: (topics: CommunityTopic[]) => void, categoryId?: string) => {
    const q = query(collection(db, TOPICS_COLLECTION));
    
    return onSnapshot(q, (snapshot) => {
      let topics = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as CommunityTopic));
      
      if (categoryId) {
        topics = topics.filter(t => t.categoryId === categoryId);
      }
      
      topics.sort((a, b) => {
        const dateA = a.createdAt?.toDate ? a.createdAt.toDate() : new Date(a.createdAt);
        const dateB = b.createdAt?.toDate ? b.createdAt.toDate() : new Date(b.createdAt);
        return dateB.getTime() - dateA.getTime();
      });
      
      callback(topics);
    });
  },

  getTopicById: async (id: string): Promise<CommunityTopic | null> => {
    const docRef = doc(db, TOPICS_COLLECTION, id);
    const docSnap = await getDoc(docRef);
    if (docSnap.exists()) {
      return { id: docSnap.id, ...docSnap.data() } as CommunityTopic;
    }
    return null;
  },

  createTopic: async (topic: Omit<CommunityTopic, 'id' | 'createdAt' | 'likesCount' | 'repliesCount'>): Promise<string> => {
    const docRef = await addDoc(collection(db, TOPICS_COLLECTION), {
      ...topic,
      likesCount: 0,
      repliesCount: 0,
      createdAt: serverTimestamp()
    });
    return docRef.id;
  },

  getReplies: async (topicId: string): Promise<Reply[]> => {
    const q = query(
      collection(db, REPLIES_COLLECTION), 
      where('topicId', '==', topicId), 
      orderBy('createdAt', 'asc')
    );
    const snapshot = await getDocs(q);
    return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Reply));
  },

  subscribeToReplies: (topicId: string, callback: (replies: Reply[]) => void) => {
    const q = query(
      collection(db, REPLIES_COLLECTION), 
      where('topicId', '==', topicId), 
      orderBy('createdAt', 'asc')
    );
    return onSnapshot(q, (snapshot) => {
      const replies = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Reply));
      callback(replies);
    });
  },

  createReply: async (reply: Omit<Reply, 'id' | 'createdAt' | 'likesCount'>): Promise<string> => {
    const docRef = await addDoc(collection(db, REPLIES_COLLECTION), {
      ...reply,
      likesCount: 0,
      createdAt: serverTimestamp()
    });

    // Increment replies count on topic
    const topicRef = doc(db, TOPICS_COLLECTION, reply.topicId);
    await updateDoc(topicRef, {
      repliesCount: increment(1)
    });

    return docRef.id;
  },

  updateTopic: async (topicId: string, content: string): Promise<void> => {
    const docRef = doc(db, TOPICS_COLLECTION, topicId);
    await updateDoc(docRef, {
      content,
      updatedAt: serverTimestamp()
    });
  },

  updateReply: async (replyId: string, content: string): Promise<void> => {
    const docRef = doc(db, REPLIES_COLLECTION, replyId);
    await updateDoc(docRef, {
      content,
      updatedAt: serverTimestamp()
    });
  },

  likeTopic: async (topicId: string, authorUid: string): Promise<void> => {
    const docRef = doc(db, TOPICS_COLLECTION, topicId);
    await updateDoc(docRef, {
      likesCount: increment(1)
    });
    // Add reputation points to author
    const userRef = doc(db, USERS_COLLECTION, authorUid);
    await updateDoc(userRef, {
      reputationPoints: increment(5)
    });
  },

  likeReply: async (replyId: string, authorUid: string): Promise<void> => {
    const docRef = doc(db, REPLIES_COLLECTION, replyId);
    await updateDoc(docRef, {
      likesCount: increment(1)
    });
    // Add reputation points to author
    const userRef = doc(db, USERS_COLLECTION, authorUid);
    await updateDoc(userRef, {
      reputationPoints: increment(2)
    });
  }
};
