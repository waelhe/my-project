import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { MemberProfile } from '../types';
import { communityService } from '../infrastructure/communityService';

export const MemberProfilePage = () => {
  const { userId } = useParams<{ userId: string }>();
  const [profile, setProfile] = useState<MemberProfile | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!userId) return;
    
    communityService.getMemberProfile(userId).then(p => {
      setProfile(p);
      setLoading(false);
    });
  }, [userId]);

  if (loading) return <div className="p-6 text-center">جاري تحميل الملف الشخصي...</div>;
  if (!profile) return <div className="p-6 text-center">لم يتم العثور على الملف الشخصي.</div>;

  return (
    <div className="max-w-4xl mx-auto p-6">
      <div className="bg-white rounded-2xl shadow-sm p-8 border border-gray-100">
        <div className="flex items-center gap-6">
          <img src={profile.photoURL || '/default-avatar.png'} alt={profile.displayName} className="w-24 h-24 rounded-full" />
          <div>
            <h1 className="text-3xl font-bold text-gray-900">{profile.displayName}</h1>
            <p className="text-gray-600 mt-1">{profile.bio || 'لا توجد نبذة شخصية.'}</p>
          </div>
        </div>
        <div className="grid grid-cols-3 gap-6 mt-8 border-t pt-8">
          <div className="text-center">
            <p className="text-2xl font-bold text-emerald-600">{profile.reputationPoints}</p>
            <p className="text-sm text-gray-500">نقاط السمعة</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold text-gray-900">{profile.topicsCount}</p>
            <p className="text-sm text-gray-500">المواضيع</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold text-gray-900">{profile.repliesCount}</p>
            <p className="text-sm text-gray-500">الردود</p>
          </div>
        </div>
      </div>
    </div>
  );
};
