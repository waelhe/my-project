import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { communityService } from '../infrastructure/communityService';
import { CommunityTopic } from '../types';

export const CategoryTopicsPage = () => {
  const { categoryId } = useParams<{ categoryId: string }>();
  const [topics, setTopics] = useState<CommunityTopic[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    const unsubscribe = communityService.subscribeToTopics((fetchedTopics) => {
      setTopics(fetchedTopics.filter(t => t.categoryId === categoryId));
      setLoading(false);
    }, categoryId);

    return () => unsubscribe();
  }, [categoryId]);

  if (loading) return <div className="p-6 text-center">جاري تحميل المواضيع...</div>;

  return (
    <div className="max-w-5xl mx-auto p-6">
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-3xl font-bold text-gray-900 capitalize">{categoryId?.replace('-', ' ')}</h1>
        <Link to="/community" className="text-emerald-600 hover:text-emerald-700 font-medium">العودة للأقسام</Link>
      </div>
      
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        {topics.length === 0 ? (
          <div className="p-12 text-center text-gray-500">لا توجد مواضيع في هذا القسم حالياً.</div>
        ) : (
          <div className="divide-y divide-gray-100">
            {topics.map(topic => (
              <Link key={topic.id} to={`/community/${categoryId}/${topic.id}`} className="block p-6 hover:bg-gray-50 transition-colors">
                <h2 className="text-xl font-bold text-gray-900 mb-2">{topic.title}</h2>
                <div className="flex items-center gap-4 text-sm text-gray-500">
                  <span>بواسطة {topic.authorName}</span>
                  <span>{new Date(topic.createdAt?.toDate ? topic.createdAt.toDate() : topic.createdAt).toLocaleDateString('ar-SA')}</span>
                  <span>{topic.repliesCount} ردود</span>
                </div>
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
