export interface CommunityTopic {
  id?: string;
  title: string;
  content: string;
  authorUid: string;
  authorName: string;
  authorAvatar?: string;
  categoryId: string;
  subCategoryId?: string; // Added for hierarchy
  createdAt: any;
  updatedAt?: any; // Added for editing
  likesCount: number;
  repliesCount: number;
  isOfficial?: boolean;
}

export interface Reply {
  id?: string;
  topicId: string;
  content: string;
  authorUid: string;
  authorName: string;
  authorAvatar?: string;
  createdAt: any;
  updatedAt?: any; // Added for editing
  likesCount: number;
}

export interface MemberProfile {
  uid: string;
  displayName: string;
  photoURL?: string;
  bio?: string;
  reputationPoints: number;
  joinedAt: any;
  topicsCount: number;
  repliesCount: number;
}
