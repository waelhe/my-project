import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../../../core/contexts/AuthContext';
import { useLanguage } from '../../../../core/contexts/LanguageContext';
import { createService } from '../../infrastructure/serviceRepository';
import { Service } from '../../domain/service';
import ServiceForm from '../components/ServiceForm';
import { ChevronLeft } from 'lucide-react';
import toast from 'react-hot-toast';

export default function AddServicePage() {
  const { user } = useAuth();
  const { language } = useLanguage();
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (data: Service) => {
    if (!user) return;
    setIsLoading(true);
    try {
      await createService({
        ...data,
        authorUid: user.uid,
      });
      toast.success(language === 'ar' ? 'تمت إضافة الخدمة بنجاح' : 'Service added successfully');
      navigate('/provider-dashboard');
    } catch (error) {
      console.error('Error adding service:', error);
      toast.error(language === 'ar' ? 'فشل في إضافة الخدمة' : 'Failed to add service');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="pt-24 pb-20 max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
      <button
        onClick={() => navigate(-1)}
        className="flex items-center gap-2 text-gray-500 hover:text-emerald-600 mb-6 font-bold transition-colors"
      >
        <ChevronLeft className="w-5 h-5 rotate-180" />
        {language === 'ar' ? 'العودة' : 'Back'}
      </button>

      <div className="bg-white border border-gray-200 rounded-3xl p-8 shadow-sm">
        <h1 className="text-2xl font-bold text-gray-900 mb-8">
          {language === 'ar' ? 'إضافة خدمة جديدة' : 'Add New Service'}
        </h1>
        
        <ServiceForm onSubmit={handleSubmit} isLoading={isLoading} />
      </div>
    </div>
  );
}
