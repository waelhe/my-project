import React, { useEffect, useState } from 'react';
import { useAuth } from '../../../core/contexts/AuthContext';
import { useLanguage } from '../../../core/contexts/LanguageContext';
import { getServicesByAuthor, deleteService } from '../../services/infrastructure/serviceRepository';
import { Service } from '../../services/domain/service';
import { getProviderBookings, Booking, updateBookingStatus } from '../infrastructure/bookingsService';
import { Plus, Edit, Trash2, Loader2, ExternalLink, Star, MapPin, Calendar, LayoutDashboard, ClipboardList, Check, X as XIcon } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import { motion, AnimatePresence } from 'motion/react';

export default function ProviderDashboard() {
  const { user } = useAuth();
  const { language } = useLanguage();
  const navigate = useNavigate();
  const [services, setServices] = useState<Service[]>([]);
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'services' | 'bookings'>('services');

  const fetchData = async () => {
    if (!user) return;
    setLoading(true);
    try {
      const [servicesData, bookingsData] = await Promise.all([
        getServicesByAuthor(user.uid),
        getProviderBookings(user.uid)
      ]);
      setServices(servicesData);
      setBookings(bookingsData);
    } catch (error) {
      console.error('Error fetching provider data:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [user]);

  const handleStatusUpdate = async (bookingId: string, status: Booking['status']) => {
    try {
      await updateBookingStatus(bookingId, status);
      toast.success(language === 'ar' ? 'تم تحديث حالة الحجز' : 'Booking status updated');
      // Refresh data
      const updatedBookings = await getProviderBookings(user!.uid);
      setBookings(updatedBookings);
    } catch (error) {
      toast.error(language === 'ar' ? 'فشل تحديث الحالة' : 'Failed to update status');
    }
  };

  const handleDelete = async (id: string) => {
    if (!window.confirm(language === 'ar' ? 'هل أنت متأكد من حذف هذه الخدمة؟' : 'Are you sure you want to delete this service?')) {
      return;
    }

    try {
      await deleteService(id);
      setServices(services.filter(s => s.id !== id));
      toast.success(language === 'ar' ? 'تم حذف الخدمة بنجاح' : 'Service deleted successfully');
    } catch (error) {
      toast.error(language === 'ar' ? 'فشل في حذف الخدمة' : 'Failed to delete service');
    }
  };

  const totalEarnings = bookings
    .filter(b => b.status === 'confirmed' || b.status === 'completed')
    .reduce((sum, b) => sum + b.totalPrice, 0);

  const totalViews = services.reduce((sum, s) => sum + (s.views || 0), 0);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-10 h-10 animate-spin text-emerald-600" />
      </div>
    );
  }

  return (
    <div className="pt-24 pb-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 min-h-screen">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">
            {language === 'ar' ? 'لوحة تحكم المزود' : 'Provider Dashboard'}
          </h1>
          <p className="text-gray-500 mt-1">
            {language === 'ar' ? 'إدارة خدماتك وعروضك' : 'Manage your services and offers'}
          </p>
        </div>
        <Link
          to="/provider/add-service"
          className="flex items-center justify-center gap-2 bg-emerald-600 text-white px-6 py-3 rounded-xl font-bold hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-200"
        >
          <Plus className="w-5 h-5" />
          {language === 'ar' ? 'إضافة خدمة جديدة' : 'Add New Service'}
        </Link>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
        <div className="bg-white border border-gray-200 rounded-2xl p-6 shadow-sm">
          <div className="text-gray-500 text-xs font-bold uppercase tracking-wider mb-1">
            {language === 'ar' ? 'إجمالي الأرباح' : 'Total Earnings'}
          </div>
          <div className="text-2xl font-black text-emerald-600">${totalEarnings}</div>
        </div>
        <div className="bg-white border border-gray-200 rounded-2xl p-6 shadow-sm">
          <div className="text-gray-500 text-xs font-bold uppercase tracking-wider mb-1">
            {language === 'ar' ? 'إجمالي المشاهدات' : 'Total Views'}
          </div>
          <div className="text-2xl font-black text-gray-900">{totalViews}</div>
        </div>
        <div className="bg-white border border-gray-200 rounded-2xl p-6 shadow-sm">
          <div className="text-gray-500 text-xs font-bold uppercase tracking-wider mb-1">
            {language === 'ar' ? 'الحجوزات النشطة' : 'Active Bookings'}
          </div>
          <div className="text-2xl font-black text-gray-900">
            {bookings.filter(b => b.status === 'confirmed').length}
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-4 mb-8 border-b border-gray-200">
        <button
          onClick={() => setActiveTab('services')}
          className={`pb-4 px-2 font-bold text-sm transition-all relative ${
            activeTab === 'services' ? 'text-emerald-600' : 'text-gray-500 hover:text-gray-700'
          }`}
        >
          <div className="flex items-center gap-2">
            <LayoutDashboard className="w-4 h-4" />
            {language === 'ar' ? 'خدماتي' : 'My Services'}
          </div>
          {activeTab === 'services' && (
            <motion.div layoutId="activeTab" className="absolute bottom-0 left-0 right-0 h-0.5 bg-emerald-600 rounded-full" />
          )}
        </button>
        <button
          onClick={() => setActiveTab('bookings')}
          className={`pb-4 px-2 font-bold text-sm transition-all relative ${
            activeTab === 'bookings' ? 'text-emerald-600' : 'text-gray-500 hover:text-gray-700'
          }`}
        >
          <div className="flex items-center gap-2">
            <ClipboardList className="w-4 h-4" />
            {language === 'ar' ? 'الحجوزات' : 'Bookings'}
            {bookings.length > 0 && (
              <span className="bg-emerald-100 text-emerald-700 px-1.5 py-0.5 rounded-full text-[10px]">
                {bookings.length}
              </span>
            )}
          </div>
          {activeTab === 'bookings' && (
            <motion.div layoutId="activeTab" className="absolute bottom-0 left-0 right-0 h-0.5 bg-emerald-600 rounded-full" />
          )}
        </button>
      </div>

      <AnimatePresence mode="wait">
        {activeTab === 'services' ? (
          <motion.div
            key="services"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 20 }}
          >
            {services.length === 0 ? (
              <div className="bg-white border border-gray-200 rounded-3xl p-12 text-center">
                <div className="w-20 h-20 bg-gray-50 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Plus className="w-10 h-10 text-gray-300" />
                </div>
                <h2 className="text-xl font-bold text-gray-900 mb-2">
                  {language === 'ar' ? 'لا توجد خدمات بعد' : 'No services yet'}
                </h2>
                <p className="text-gray-500 mb-6">
                  {language === 'ar' ? 'ابدأ بإضافة خدمتك الأولى لتظهر للعملاء' : 'Start by adding your first service to show to customers'}
                </p>
                <Link
                  to="/provider/add-service"
                  className="inline-flex items-center gap-2 text-emerald-600 font-bold hover:underline"
                >
                  {language === 'ar' ? 'إضافة خدمتك الأولى الآن' : 'Add your first service now'}
                </Link>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {services.map((service) => (
                  <motion.div
                    key={service.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="bg-white border border-gray-200 rounded-2xl overflow-hidden shadow-sm hover:shadow-md transition-shadow"
                  >
                    <div className="relative aspect-video">
                      <img
                        src={service.images?.[0] || 'https://images.unsplash.com/photo-1585076641394-6302f23b7b65?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'}
                        alt={service.title}
                        className="w-full h-full object-cover"
                        referrerPolicy="no-referrer"
                      />
                      <div className="absolute top-2 right-2 flex gap-2">
                        <span className="bg-white/90 backdrop-blur-sm px-2 py-1 rounded-lg text-[10px] font-bold text-gray-900 shadow-sm">
                          {service.mainCategoryId}
                        </span>
                      </div>
                    </div>

                    <div className="p-4">
                      <div className="flex justify-between items-start mb-2">
                        <h3 className="font-bold text-gray-900 truncate flex-1">{service.title}</h3>
                        <div className="flex items-center gap-1 text-xs font-bold">
                          <Star className="w-3 h-3 fill-emerald-500 text-emerald-500" />
                          <span>{service.rating}</span>
                        </div>
                      </div>

                      <div className="flex items-center gap-4 text-gray-500 text-xs mb-4">
                        <div className="flex items-center gap-1">
                          <MapPin className="w-3 h-3" />
                          <span>{service.location}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <ExternalLink className="w-3 h-3" />
                          <span>{service.views || 0} {language === 'ar' ? 'مشاهدة' : 'views'}</span>
                        </div>
                      </div>

                      <div className="flex items-center justify-between pt-4 border-t border-gray-100">
                        <div className="text-emerald-600 font-bold">${service.price}</div>
                        <div className="flex items-center gap-2">
                          <Link
                            to={`/listing/${service.id}`}
                            className="p-2 text-gray-400 hover:text-emerald-600 transition-colors"
                            title={language === 'ar' ? 'عرض' : 'View'}
                          >
                            <ExternalLink className="w-5 h-5" />
                          </Link>
                          <Link
                            to={`/provider/edit-service/${service.id}`}
                            className="p-2 text-gray-400 hover:text-blue-600 transition-colors"
                            title={language === 'ar' ? 'تعديل' : 'Edit'}
                          >
                            <Edit className="w-5 h-5" />
                          </Link>
                          <button
                            onClick={() => handleDelete(service.id!)}
                            className="p-2 text-gray-400 hover:text-red-600 transition-colors"
                            title={language === 'ar' ? 'حذف' : 'Delete'}
                          >
                            <Trash2 className="w-5 h-5" />
                          </button>
                        </div>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            )}
          </motion.div>
        ) : (
          <motion.div
            key="bookings"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
          >
            {bookings.length === 0 ? (
              <div className="bg-white border border-gray-200 rounded-3xl p-12 text-center">
                <div className="w-20 h-20 bg-gray-50 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Calendar className="w-10 h-10 text-gray-300" />
                </div>
                <h2 className="text-xl font-bold text-gray-900 mb-2">
                  {language === 'ar' ? 'لا توجد حجوزات بعد' : 'No bookings yet'}
                </h2>
                <p className="text-gray-500">
                  {language === 'ar' ? 'ستظهر هنا الحجوزات التي يقوم بها العملاء لخدماتك' : 'Bookings made by customers for your services will appear here'}
                </p>
              </div>
            ) : (
              <div className="bg-white border border-gray-200 rounded-3xl overflow-hidden shadow-sm">
                <div className="overflow-x-auto">
                  <table className="w-full text-right">
                    <thead className="bg-gray-50 border-b border-gray-200">
                      <tr>
                        <th className="px-6 py-4 text-sm font-bold text-gray-900">{language === 'ar' ? 'الخدمة' : 'Service'}</th>
                        <th className="px-6 py-4 text-sm font-bold text-gray-900">{language === 'ar' ? 'العميل' : 'Customer'}</th>
                        <th className="px-6 py-4 text-sm font-bold text-gray-900">{language === 'ar' ? 'التاريخ' : 'Dates'}</th>
                        <th className="px-6 py-4 text-sm font-bold text-gray-900">{language === 'ar' ? 'الإجمالي' : 'Total'}</th>
                        <th className="px-6 py-4 text-sm font-bold text-gray-900">{language === 'ar' ? 'الحالة' : 'Status'}</th>
                        <th className="px-6 py-4 text-sm font-bold text-gray-900">{language === 'ar' ? 'إجراءات' : 'Actions'}</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100">
                      {bookings.map((booking) => (
                        <tr key={booking.id} className="hover:bg-gray-50 transition-colors">
                          <td className="px-6 py-4">
                            <div className="font-bold text-gray-900">{booking.serviceTitle}</div>
                            <div className="text-xs text-gray-500">ID: {booking.serviceId.substring(0, 8)}...</div>
                          </td>
                          <td className="px-6 py-4 text-sm text-gray-600">
                            {booking.userEmail}
                          </td>
                          <td className="px-6 py-4 text-sm text-gray-600">
                            <div className="flex flex-col">
                              <span>{booking.checkIn}</span>
                              <span className="text-xs text-gray-400">{language === 'ar' ? 'إلى' : 'to'} {booking.checkOut}</span>
                            </div>
                          </td>
                          <td className="px-6 py-4 font-bold text-gray-900">
                            ${booking.totalPrice}
                          </td>
                          <td className="px-6 py-4">
                            <span className={`px-3 py-1 rounded-full text-xs font-bold ${
                              booking.status === 'confirmed' ? 'bg-emerald-100 text-emerald-700' :
                              booking.status === 'pending' ? 'bg-amber-100 text-amber-700' :
                              booking.status === 'completed' ? 'bg-blue-100 text-blue-700' :
                              'bg-gray-100 text-gray-700'
                            }`}>
                              {booking.status === 'confirmed' ? (language === 'ar' ? 'مؤكد' : 'Confirmed') :
                               booking.status === 'pending' ? (language === 'ar' ? 'قيد الانتظار' : 'Pending') :
                               booking.status === 'completed' ? (language === 'ar' ? 'مكتمل' : 'Completed') :
                               (language === 'ar' ? 'ملغي' : 'Cancelled')}
                            </span>
                          </td>
                          <td className="px-6 py-4">
                            <div className="flex gap-2">
                              {booking.status === 'pending' && (
                                <>
                                  <button
                                    onClick={() => handleStatusUpdate(booking.id!, 'confirmed')}
                                    className="p-1.5 bg-emerald-100 text-emerald-600 rounded-lg hover:bg-emerald-200 transition-colors"
                                    title={language === 'ar' ? 'تأكيد' : 'Confirm'}
                                  >
                                    <Check className="w-4 h-4" />
                                  </button>
                                  <button
                                    onClick={() => handleStatusUpdate(booking.id!, 'cancelled')}
                                    className="p-1.5 bg-red-100 text-red-600 rounded-lg hover:bg-red-200 transition-colors"
                                    title={language === 'ar' ? 'إلغاء' : 'Cancel'}
                                  >
                                    <XIcon className="w-4 h-4" />
                                  </button>
                                </>
                              )}
                              {booking.status === 'confirmed' && (
                                <button
                                  onClick={() => handleStatusUpdate(booking.id!, 'completed')}
                                  className="p-1.5 bg-blue-100 text-blue-600 rounded-lg hover:bg-blue-200 transition-colors"
                                  title={language === 'ar' ? 'إكمال' : 'Complete'}
                                >
                                  <Check className="w-4 h-4" />
                                </button>
                              )}
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
