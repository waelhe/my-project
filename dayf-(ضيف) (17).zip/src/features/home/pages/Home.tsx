import React, { useEffect, useState } from 'react';
import Hero from '../../../shared/components/ui/Hero';
import Categories from '../../../shared/components/ui/Categories';
import ServiceSection from '../../services/ui/components/ServiceSection';
import CommunityHighlights from '../../community/components/CommunityHighlights';
import MarketHighlights from '../../marketplace/components/MarketHighlights';
import RecentlyViewed from '../../../shared/components/ui/RecentlyViewed';
import WhyChooseUs from '../../../shared/components/ui/WhyChooseUs';
import { useLanguage } from '../../../core/contexts/LanguageContext';
import { seedServices } from '../../services/infrastructure/serviceRepository';
import { useAuth } from '../../../core/contexts/AuthContext';
import { Plus, Loader2 } from 'lucide-react';
import toast from 'react-hot-toast';

export default function Home() {
  const { language } = useLanguage();
  const { user, userProfile } = useAuth();
  const [isSeeding, setIsSeeding] = useState(false);
  const isAdmin = user?.email === 'wael.he88@gmail.com' || userProfile?.role === 'admin';

  const handleSeedServices = async () => {
    if (isSeeding) return;
    setIsSeeding(true);
    try {
      await seedServices('system-initial-seed', true);
      toast.success(language === 'ar' ? 'تمت إعادة إضافة الخدمات بنجاح' : 'Services re-seeded successfully');
      window.location.reload();
    } catch (error) {
      console.error('Error seeding services:', error);
      toast.error(language === 'ar' ? 'فشل في إضافة الخدمات' : 'Failed to seed services');
    } finally {
      setIsSeeding(false);
    }
  };

  return (
    <main>
      <Hero />
      <Categories />
      <RecentlyViewed />
      
      {isAdmin && (
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-center">
          <button
            onClick={handleSeedServices}
            disabled={isSeeding}
            className="flex items-center gap-2 bg-red-600 text-white px-6 py-2 rounded-full font-bold shadow-lg hover:bg-red-700 transition-all disabled:opacity-50"
          >
            {isSeeding ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />}
            {language === 'ar' ? 'إضافة الخدمات التجريبية (v2)' : 'Seed Services (v2)'}
          </button>
        </div>
      )}
      
      <div className="pb-12">
        <ServiceSection 
          title={language === 'ar' ? 'أماكن إقامة مميزة' : 'Featured Accommodations'}
          categoryId="tourism"
          filterPopular={true}
          viewAllPath="/category/tourism"
        />

        <ServiceSection 
          title={language === 'ar' ? 'فنادق ومنتجعات' : 'Hotels & Resorts'}
          subtitle={language === 'ar' ? 'مجموعة من الفنادق المستقلة والمختارة بعناية' : 'A curated collection of independent hotels'}
          categoryId="tourism"
          limit={8}
          viewAllPath="/category/tourism"
        />

        <ServiceSection 
          title={language === 'ar' ? 'تجارب فريدة' : 'Unique experiences'}
          categoryId="experiences"
          limit={8}
          viewAllPath="/category/experiences"
        />

        <ServiceSection 
          title={language === 'ar' ? 'خدمات طبية متميزة' : 'Top medical services'}
          subtitle={language === 'ar' ? 'أفضل المراكز الطبية والأطباء في سوريا' : 'The best medical centers and doctors in Syria'}
          categoryId="medical"
          limit={8}
          viewAllPath="/category/medical"
        />

        <ServiceSection 
          title={language === 'ar' ? 'فرص عقارية' : 'Real Estate Opportunities'}
          subtitle={language === 'ar' ? 'اكتشف أفضل العقارات المتاحة للبيع والإيجار' : 'Discover the best properties available for sale and rent'}
          categoryId="realestate"
          limit={8}
          viewAllPath="/category/realestate"
        />

        <ServiceSection 
          title={language === 'ar' ? 'خدمات الأعمال' : 'Business Services'}
          subtitle={language === 'ar' ? 'حلول احترافية لنمو أعمالك' : 'Professional solutions for your business growth'}
          categoryId="business"
          limit={8}
          viewAllPath="/category/business"
        />

        <ServiceSection 
          title={language === 'ar' ? 'تعليم وتدريب' : 'Education & Training'}
          subtitle={language === 'ar' ? 'طور مهاراتك مع أفضل الخبراء' : 'Develop your skills with the best experts'}
          categoryId="education"
          limit={8}
          viewAllPath="/category/education"
        />

        <ServiceSection 
          title={language === 'ar' ? 'مطاعم وكافيهات' : 'Dining & Cafes'}
          subtitle={language === 'ar' ? 'تذوق أشهى المأكولات السورية' : 'Taste the best Syrian cuisine'}
          categoryId="dining"
          limit={8}
          viewAllPath="/category/dining"
        />

        <ServiceSection 
          title={language === 'ar' ? 'نقل ومواصلات' : 'Transport & Rental'}
          subtitle={language === 'ar' ? 'تنقل بسهولة وأمان' : 'Travel easily and safely'}
          categoryId="transport"
          limit={8}
          viewAllPath="/category/transport"
        />

        <ServiceSection 
          title={language === 'ar' ? 'تسوق وهدايا' : 'Shopping & Souvenirs'}
          subtitle={language === 'ar' ? 'اكتشف الصناعات اليدوية المحلية' : 'Discover local handicrafts'}
          categoryId="shopping"
          limit={8}
          viewAllPath="/category/shopping"
        />

        <WhyChooseUs />
        <MarketHighlights />
        <CommunityHighlights />
      </div>
    </main>
  );
}
