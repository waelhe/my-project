/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BrowserRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import ScrollToTop from './shared/components/utils/ScrollToTop';
import AIAgent from './features/ai/components/AIAgent';
import Footer from './shared/components/layout/Footer';
import Header from './shared/components/layout/Header';
import BottomNav from './shared/components/layout/BottomNav';
import Home from './features/home/pages/Home';
import ListingDetails from './features/services/ui/pages/ListingDetails';
import CategoryPage from './features/services/ui/pages/CategoryPage';
import MyBookings from './features/bookings/pages/MyBookings';
import ProviderDashboard from './features/bookings/pages/ProviderDashboard';
import AddServicePage from './features/services/ui/pages/AddServicePage';
import EditServicePage from './features/services/ui/pages/EditServicePage';
import Profile from './features/user/pages/Profile';
import ProductDetailsPage from './features/marketplace/pages/ProductDetailsPage';
import VendorProfilePage from './features/provider/pages/VendorProfilePage';
import OrdersPage from './features/orders/pages/OrdersPage';
import CommunityPage from './features/community/pages/CommunityPage';
import { CategoryTopicsPage } from './features/community/pages/CategoryTopicsPage';
import TopicDetails from './features/community/pages/TopicDetails';
import GuideDetails from './features/community/pages/GuideDetails';
import { MemberProfilePage } from './features/community/pages/MemberProfilePage';
import MarketplacePage from './features/marketplace/pages/MarketplacePage';
import GuestServiceCenter from './features/ai/components/GuestServiceCenter';
import { AuthProvider } from './core/contexts/AuthContext';
import { LanguageProvider } from './core/contexts/LanguageContext';
import { CartProvider } from './features/marketplace/contexts/CartContext';
import CartDrawer from './features/marketplace/components/CartDrawer';

function AppContent() {
  const location = useLocation();
  const isHome = location.pathname === '/';

  return (
    <div className="min-h-screen font-sans bg-white flex flex-col">
      <Toaster position="top-center" toastOptions={{ duration: 3000, style: { fontFamily: 'Inter, sans-serif' } }} />
      <Header />
      <CartDrawer />
      <main className={`flex-grow ${isHome ? 'pt-20' : 'pt-16'} pb-16 md:pb-0`}>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/category/:categoryId" element={<CategoryPage />} />
          <Route path="/listing/:id" element={<ListingDetails />} />
          <Route path="/my-bookings" element={<MyBookings />} />
          <Route path="/provider-dashboard" element={<ProviderDashboard />} />
          <Route path="/provider/add-service" element={<AddServicePage />} />
          <Route path="/provider/edit-service/:id" element={<EditServicePage />} />
          <Route path="/profile" element={<Profile />} />
          <Route path="/community" element={<CommunityPage />} />
          <Route path="/community/:categoryId" element={<CategoryTopicsPage />} />
          <Route path="/community/:categoryId/:topicId" element={<TopicDetails />} />
          <Route path="/community/member/:userId" element={<MemberProfilePage />} />
          <Route path="/community/guide/:id" element={<GuideDetails />} />
          <Route path="/marketplace" element={<MarketplacePage />} />
          <Route path="/marketplace/product/:id" element={<ProductDetailsPage />} />
          <Route path="/marketplace/vendor/:vendorName" element={<VendorProfilePage />} />
          <Route path="/orders" element={<OrdersPage />} />
        </Routes>
      </main>
      <Footer />
      <BottomNav />
      <GuestServiceCenter />
      <AIAgent />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <LanguageProvider>
        <CartProvider>
          <Router>
            <ScrollToTop />
            <AppContent />
          </Router>
        </CartProvider>
      </LanguageProvider>
    </AuthProvider>
  );
}
