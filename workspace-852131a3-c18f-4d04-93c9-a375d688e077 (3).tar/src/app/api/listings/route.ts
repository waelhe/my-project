/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Listings API Endpoint
 *
 * نقطة نهاية API للإقامات والخدمات مع تحقق محسن
 *
 * @route GET /api/listings - قائمة الإقامات
 * @route POST /api/listings - إنشاء إقامة جديدة
 */

import { NextRequest } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { ListingRepository } from '@/infrastructure/repositories/listing.repository';
import { ListingMapper } from '@/application/mappers';
import {
  successResponse,
  createdResponse,
  errorResponse,
  paginatedResponse,
  validationErrorResponse,
  formatValidationErrors,
  getPaginationParams,
  getSortParams,
} from '@/lib/api-response';
import {
  createListingSchema,
  validate,
} from '@/lib/api-validation';

// Initialize repository
const listingRepository = new ListingRepository();
const listingMapper = new ListingMapper();

// ==================== GET - List Listings ====================

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);

    // Check for featured listings
    if (searchParams.get('featured') === 'true') {
      return handleGetFeatured(searchParams);
    }

    // Check for stats request
    if (searchParams.get('stats') === 'true') {
      return handleGetStats(searchParams);
    }

    // Check for search request
    const searchQuery = searchParams.get('search') || searchParams.get('q');
    if (searchQuery) {
      return handleSearch(searchQuery, searchParams);
    }

    // List listings with filters
    return handleList(searchParams);

  } catch (error) {
    console.error('Error fetching listings:', error);
    return errorResponse('INTERNAL_ERROR', 'حدث خطأ أثناء جلب الإقامات', 500);
  }
}

// ==================== POST - Create Listing ====================

export async function POST(request: NextRequest) {
  try {
    const user = await getCurrentUser();

    if (!user) {
      return errorResponse('UNAUTHORIZED', 'يجب تسجيل الدخول لإنشاء إقامة', 401);
    }

    // Only hosts and companies can create listings
    if (!['host', 'company', 'admin'].includes(user.role)) {
      return errorResponse('FORBIDDEN', 'يجب أن تكون مضيفاً لإنشاء إقامة', 403);
    }

    const body = await request.json();

    // Validate input
    const validation = validate(createListingSchema, body);
    if (!validation.success) {
      return validationErrorResponse(formatValidationErrors(validation.errors));
    }

    const data = validation.data;

    // Set hostId to current user if not specified
    const hostId = data.hostId || user.id;
    const companyId = data.companyId || (user.role === 'company' ? user.id : undefined);

    // Create listing
    const createData = {
      ...listingMapper.createDTOToPersistence({
        ...data,
        hostId,
        companyId,
      }),
      status: 'draft',
    };

    const listing = await listingRepository.create(createData);

    return createdResponse(listingMapper.toDTO(listing));

  } catch (error) {
    console.error('Error creating listing:', error);
    return errorResponse('INTERNAL_ERROR', 'حدث خطأ أثناء إنشاء الإقامة', 500);
  }
}

// ==================== Helper Functions ====================

async function handleGetFeatured(searchParams: URLSearchParams) {
  const limit = Math.min(20, parseInt(searchParams.get('limit') || '10', 10));
  const category = searchParams.get('category');

  const listings = await listingRepository.findFeatured(limit, category || undefined);

  return successResponse({
    items: listings.map(l => listingMapper.toSummaryDTO(l)),
    total: listings.length,
  });
}

async function handleGetStats(searchParams: URLSearchParams) {
  const hostId = searchParams.get('hostId');

  if (!hostId) {
    return errorResponse('INVALID_INPUT', 'معرف المضيف مطلوب للإحصائيات', 400);
  }

  const stats = await listingRepository.getHostStats(hostId);

  return successResponse(stats);
}

async function handleSearch(query: string, searchParams: URLSearchParams) {
  const { page, limit, skip } = getPaginationParams(searchParams as unknown as NextRequest);
  const category = searchParams.get('category');
  const type = searchParams.get('type');
  const city = searchParams.get('city');
  const country = searchParams.get('country');

  const result = await listingRepository.search(query, {
    skip,
    take: limit,
    category: category || undefined,
    type: type || undefined,
    city: city || undefined,
    country: country || undefined,
  });

  return paginatedResponse(
    result.items.map(l => listingMapper.toSummaryDTO(l)),
    {
      page,
      limit,
      total: result.total,
      totalPages: Math.ceil(result.total / limit),
      hasMore: page * limit < result.total,
    }
  );
}

async function handleList(searchParams: URLSearchParams) {
  const { page, limit, skip } = getPaginationParams(searchParams as unknown as NextRequest);
  const { sortBy, sortOrder } = getSortParams(searchParams as unknown as NextRequest);

  // Build filter
  const filter = {
    hostId: searchParams.get('hostId') || undefined,
    companyId: searchParams.get('companyId') || undefined,
    type: searchParams.get('type')?.split(',') || undefined,
    category: searchParams.get('category') || undefined,
    status: searchParams.get('status')?.split(',') || ['active'],
    city: searchParams.get('city') || undefined,
    country: searchParams.get('country') || undefined,
    minPrice: searchParams.get('minPrice') ? parseFloat(searchParams.get('minPrice')!) : undefined,
    maxPrice: searchParams.get('maxPrice') ? parseFloat(searchParams.get('maxPrice')!) : undefined,
    minCapacity: searchParams.get('guests') ? parseInt(searchParams.get('guests')!) : undefined,
    minBedrooms: searchParams.get('bedrooms') ? parseInt(searchParams.get('bedrooms')!) : undefined,
    minBathrooms: searchParams.get('bathrooms') ? parseInt(searchParams.get('bathrooms')!) : undefined,
    amenities: searchParams.get('amenities')?.split(',') || undefined,
    instantBook: searchParams.get('instantBook') === 'true' ? true : undefined,
    minRating: searchParams.get('minRating') ? parseFloat(searchParams.get('minRating')!) : undefined,
  };

  // Get listings and total count
  const [listings, total] = await Promise.all([
    listingRepository.findMany({
      filter,
      skip,
      take: limit,
      orderBy: { [sortBy]: sortOrder },
    }),
    listingRepository.count(filter),
  ]);

  return paginatedResponse(
    listings.map(l => listingMapper.toDTO(l)),
    {
      page,
      limit,
      total,
      totalPages: Math.ceil(total / limit),
      hasMore: page * limit < total,
    }
  );
}
