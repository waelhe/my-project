/**
 * @license
 * SPDX-Identifier: Apache-2.0
 */

/**
 * Header Component
 * 
 * شريط التنقل العلوي
 */

'use client';

import React, { useState, useEffect, useRef } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Search, Globe, User, Menu, LogIn, LogOut, ShoppingCart, X } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import { useAuth } from '@/contexts/AuthContext';
import { useCart } from '@/contexts/CartContext';

export default function Header() {
  const pathname = usePathname();
  const { language, setLanguage, t } = useLanguage();
  const { user, signOut } = useAuth();
  const { cartCount, setIsCartOpen } = useCart();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const [scrollDirection, setScrollDirection] = useState<'up' | 'down'>('up');
  const [lastScrollY, setLastScrollY] = useState(0);
  const menuRef = useRef<HTMLDivElement>(null);

  const isHome = pathname === '/';
  const isMinimized = scrollDirection === 'down' && isScrolled;

  useEffect(() => {
    const handleScroll = () => {
      const currentScrollY = window.scrollY;
      setIsScrolled(currentScrollY > 10);
      setScrollDirection(currentScrollY > lastScrollY ? 'down' : 'up');
      setLastScrollY(currentScrollY);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, [lastScrollY]);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setIsMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const toggleLanguage = () => {
    setLanguage(language === 'ar' ? 'en' : 'ar');
  };

  const headerHeight = isHome && !isMinimized ? '80px' : '64px';

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 ${
        isHome && !isScrolled 
          ? 'bg-white/50 backdrop-blur-sm border-transparent' 
          : 'bg-white/95 backdrop-blur-md border-b border-gray-200 shadow-sm'
      }`}
      style={{ 
        height: headerHeight,
        transform: isMinimized ? 'translateY(-100%)' : 'translateY(0)',
        transition: 'transform 0.2s ease-in-out, background-color 0.2s, height 0.2s'
      }}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-full flex items-center justify-between">
        {/* Logo */}
        <Link 
          href="/" 
          className="flex items-center gap-2 group"
        >
          <div className="w-8 h-8 bg-emerald-600 rounded-lg flex items-center justify-center shadow-lg shadow-emerald-900/20 group-hover:scale-110 transition-transform">
            <span className="text-white font-black text-lg">S</span>
          </div>
          <span className="text-xl font-black text-gray-900 tracking-tight hidden sm:block">
            SYRIA<span className="text-emerald-600">GUIDE</span>
          </span>
        </Link>
        
        {/* Search Bar - Desktop */}
        <div className="hidden md:flex items-center gap-0 bg-white border border-gray-200 rounded-full shadow-sm hover:shadow-md transition-all duration-300 overflow-hidden">
          <button className="px-5 font-semibold hover:bg-gray-50 transition-all py-2.5 text-sm">
            {t('header.anywhere')}
          </button>
          <div className="h-6 w-[1px] bg-gray-200" />
          <button className="px-5 font-semibold hover:bg-gray-50 transition-all py-2.5 text-sm">
            {t('header.any_week')}
          </button>
          <div className="h-6 w-[1px] bg-gray-200" />
          <button className="px-5 font-medium text-gray-500 hover:bg-gray-50 transition-all flex items-center gap-2 py-2.5 text-sm">
            {t('header.add_guests')}
            <div className="bg-emerald-600 text-white rounded-full p-1.5 w-7 h-7 flex items-center justify-center">
              <Search className="w-3.5 h-3.5" />
            </div>
          </button>
        </div>

        {/* Mobile Search Trigger */}
        <div className="md:hidden flex-1 mx-4 max-w-[200px]">
          <div className="flex items-center gap-2 bg-white border border-gray-200 rounded-full shadow-sm px-3 py-2">
            <Search className="w-4 h-4 text-emerald-600" />
            <span className="font-medium text-gray-500 truncate text-xs">{t('hero.placeholder')}</span>
          </div>
        </div>

        {/* Actions */}
        <div className="flex items-center gap-2 sm:gap-4">
          <Link 
            href="/provider-dashboard" 
            className="hidden sm:block text-sm font-semibold px-3 py-2 rounded-full hover:bg-black/5 transition-colors text-gray-700"
          >
            {t('header.host')}
          </Link>
          
          <button 
            onClick={() => setIsCartOpen(true)}
            className="relative p-2 rounded-full hover:bg-black/5 transition-colors text-gray-700"
            title={language === 'ar' ? 'السلة' : 'Cart'}
          >
            <ShoppingCart className="w-5 h-5" />
            {cartCount > 0 && (
              <span className="absolute top-0 right-0 bg-emerald-600 text-white text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center">
                {cartCount}
              </span>
            )}
          </button>

          <button 
            onClick={toggleLanguage}
            className="p-2 rounded-full hover:bg-black/5 transition-colors text-gray-700"
            title={language === 'ar' ? 'English' : 'العربية'}
          >
            <Globe className="w-5 h-5" />
          </button>

          <div className="relative" ref={menuRef}>
            <button 
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="flex items-center gap-2 border border-gray-200 rounded-full p-1.5 hover:shadow-md transition-all bg-white text-gray-700"
            >
              <Menu className="w-4 h-4" />
              <div className="w-7 h-7 rounded-full bg-gray-500 flex items-center justify-center overflow-hidden">
                {user?.avatar ? (
                  <img src={user.avatar} alt="Profile" className="w-full h-full object-cover" />
                ) : (
                  <User className="w-4 h-4 text-white" />
                )}
              </div>
            </button>

            {/* Dropdown Menu */}
            {isMenuOpen && (
              <div className={`absolute right-0 mt-2 w-64 bg-white rounded-xl shadow-xl border border-gray-100 py-2 z-[60] ${language === 'ar' ? 'text-right' : 'text-left'}`}>
                {!user ? (
                  <Link 
                    href="/auth/login"
                    onClick={() => setIsMenuOpen(false)}
                    className="w-full px-4 py-3 text-sm font-semibold hover:bg-gray-50 flex items-center gap-3"
                  >
                    <LogIn className="w-4 h-4" />
                    {language === 'ar' ? 'تسجيل الدخول' : 'Login'}
                  </Link>
                ) : (
                  <>
                    <div className="px-4 py-3 border-b border-gray-100">
                      <p className="text-sm font-bold text-gray-900 truncate">{user.displayName || `${user.firstName} ${user.lastName}`}</p>
                      <p className="text-xs text-gray-500 truncate">{user.email}</p>
                    </div>
                    <Link href="/profile" onClick={() => setIsMenuOpen(false)} className="block px-4 py-3 text-sm hover:bg-gray-50">
                      {language === 'ar' ? 'الملف الشخصي' : 'Profile'}
                    </Link>
                    <Link href="/provider-dashboard" onClick={() => setIsMenuOpen(false)} className="block px-4 py-3 text-sm hover:bg-gray-50 font-bold text-emerald-600">
                      {language === 'ar' ? 'لوحة تحكم المزود' : 'Provider Dashboard'}
                    </Link>
                    <Link href="/my-bookings" onClick={() => setIsMenuOpen(false)} className="block px-4 py-3 text-sm hover:bg-gray-50">
                      {language === 'ar' ? 'حجوزاتي' : 'My Bookings'}
                    </Link>
                    <Link href="/orders" onClick={() => setIsMenuOpen(false)} className="block px-4 py-3 text-sm hover:bg-gray-50">
                      {language === 'ar' ? 'طلباتي' : 'My Orders'}
                    </Link>
                    <div className="h-[1px] bg-gray-100 my-1" />
                  </>
                )}
                
                <Link href="/marketplace" onClick={() => setIsMenuOpen(false)} className="block px-4 py-3 text-sm hover:bg-gray-50 font-medium">
                  {language === 'ar' ? 'السوق المحلي' : 'Local Marketplace'}
                </Link>
                <Link href="/community" onClick={() => setIsMenuOpen(false)} className="block px-4 py-3 text-sm hover:bg-gray-50 font-medium">
                  {language === 'ar' ? 'المجتمع' : 'Community'}
                </Link>
                
                {user && (
                  <>
                    <div className="h-[1px] bg-gray-100 my-1" />
                    <button 
                      onClick={() => { signOut(); setIsMenuOpen(false); }}
                      className="w-full px-4 py-3 text-sm text-red-600 hover:bg-red-50 flex items-center gap-3"
                    >
                      <LogOut className="w-4 h-4" />
                      {language === 'ar' ? 'تسجيل الخروج' : 'Logout'}
                    </button>
                  </>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
}
