/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Bottom Navigation Component
 * 
 * شريط التنقل السفلي للموبايل
 */

'use client';

import React from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Home, ShoppingBag, Users, User, MessageSquare, LayoutGrid } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';

export default function BottomNav() {
  const pathname = usePathname();
  const { t } = useLanguage();

  const navItems = [
    { name: t('nav.home'), path: '/', icon: Home },
    { name: t('nav.marketplace'), path: '/marketplace', icon: ShoppingBag },
    { name: t('nav.services'), path: '/category/tourism', icon: LayoutGrid },
    { name: t('nav.community'), path: '/community', icon: Users },
    { name: t('nav.my_bookings'), path: '/my-bookings', icon: MessageSquare },
    { name: t('nav.profile'), path: '/profile', icon: User },
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white/95 backdrop-blur-md border-t border-gray-200 z-50 md:hidden pb-safe">
      <div className="flex justify-around items-center h-16 px-2">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = pathname === item.path;
          return (
            <Link
              key={item.path}
              href={item.path}
              className={`flex flex-col items-center justify-center w-full h-full gap-1 transition-all ${
                isActive ? 'text-emerald-600' : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              <div className="flex items-center justify-center h-6 w-6">
                <Icon className={`w-5 h-5 sm:w-6 sm:h-6 ${isActive ? 'stroke-[2.5]' : 'stroke-[2]'}`} />
              </div>
              <span className="font-bold whitespace-nowrap text-[9px] sm:text-[10px]">{item.name}</span>
            </Link>
          );
        })}
      </div>
    </div>
  );
}
