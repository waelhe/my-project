'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { Search, MapPin, Calendar, Users, Briefcase, Stethoscope, GraduationCap, Plane, Sparkles, ChevronRight, ChevronLeft } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useLanguage } from '@/contexts/LanguageContext';

export default function Hero() {
  const { t } = useLanguage();
  const [activeTab, setActiveTab] = useState('tourism');
  const [aiQuery, setAiQuery] = useState('');
  const [location, setLocation] = useState('');
  const [date, setDate] = useState('');
  const [guests, setGuests] = useState(1);
  const [currentRegionIndex, setCurrentRegionIndex] = useState(0);
  const router = useRouter();

  const TABS = [
    { id: 'tourism', label: t('hero.tab.tourism'), icon: Plane },
    { id: 'medical', label: t('hero.tab.medical'), icon: Stethoscope },
    { id: 'education', label: t('hero.tab.education'), icon: GraduationCap },
    { id: 'business', label: t('hero.tab.business'), icon: Briefcase },
    { id: 'ai', label: t('hero.tab.ai'), icon: Sparkles },
  ];

  const SYRIA_REGIONS = [
    {
      id: 'damascus',
      name: 'دمشق الياسمين',
      description: 'قلب الشام النابض، أقدم عاصمة في التاريخ وسحر الجامع الأموي',
      image: 'https://images.unsplash.com/photo-1545562083-a600704fa487?auto=format&fit=crop&w=2000&q=80'
    },
    {
      id: 'aleppo',
      name: 'قلعة حلب',
      description: 'جوهرة الشرق ورمز الصمود والتاريخ العريق',
      image: 'https://images.unsplash.com/photo-1615811361523-6bd03d7748e7?auto=format&fit=crop&w=2000&q=80'
    },
    {
      id: 'homs',
      name: 'حمص',
      description: 'مدينة ابن الوليد وقلب سوريا النابض بجمالها',
      image: 'https://images.unsplash.com/photo-1542013936-229001f1ee9a?auto=format&fit=crop&w=2000&q=80'
    },
    {
      id: 'palmyra',
      name: 'تدمر',
      description: 'عروس البادية ولؤلؤة الصحراء بآثارها الخالدة',
      image: 'https://images.unsplash.com/photo-1503917988258-f87a78e3c995?auto=format&fit=crop&w=2000&q=80'
    },
    {
      id: 'hama',
      name: 'حماة',
      description: 'مدينة النواعير التاريخية وصوت العاصي الخالد',
      image: 'https://images.unsplash.com/photo-1565674484010-47a339784945?auto=format&fit=crop&w=2000&q=80'
    },
    {
      id: 'tartus',
      name: 'طرطوس',
      description: 'لؤلؤة الساحل السوري وبوابة جزيرة أرواد الساحرة',
      image: 'https://images.unsplash.com/photo-1598335624134-490024f82661?auto=format&fit=crop&w=2000&q=80'
    }
  ];

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentRegionIndex((prev) => (prev + 1) % SYRIA_REGIONS.length);
    }, 6000);
    return () => clearInterval(timer);
  }, []);

  const handleAISearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!aiQuery.trim()) return;
    router.push(`/?search=${encodeURIComponent(aiQuery)}&type=ai`);
  };

  const handleSearch = () => {
    const params = new URLSearchParams();
    if (location) params.set('search', location);
    if (date) params.set('date', date);
    if (guests > 1) params.set('guests', guests.toString());
    params.set('category', activeTab);
    
    router.push(`/?${params.toString()}`);
  };

  const nextRegion = () => {
    setCurrentRegionIndex((prev) => (prev + 1) % SYRIA_REGIONS.length);
  };

  const prevRegion = () => {
    setCurrentRegionIndex((prev) => (prev - 1 + SYRIA_REGIONS.length) % SYRIA_REGIONS.length);
  };

  return (
    <div className="relative pb-12 lg:pb-20 overflow-hidden min-h-[70vh] flex items-center">
      {/* Background Image Slideshow */}
      <div className="absolute inset-0 z-0">
        <img
          key={SYRIA_REGIONS[currentRegionIndex].id}
          src={SYRIA_REGIONS[currentRegionIndex].image}
          alt={SYRIA_REGIONS[currentRegionIndex].name}
          className="w-full h-full object-cover transition-opacity duration-1000"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/70 via-black/40 to-white"></div>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center w-full">
        <div className="mb-8">
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2, duration: 0.5 }}
            className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/10 backdrop-blur-md border border-white/20 text-white text-xs md:text-sm font-medium mb-6 shadow-lg"
          >
            <Sparkles className="w-4 h-4 text-emerald-400" />
            <span>{t('hero.smart_travel')}</span>
          </motion.div>

          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-4xl md:text-7xl font-black text-white mb-6 tracking-tight drop-shadow-2xl leading-tight"
          >
            {t('hero.title').split('ضيف')[0]} <span className="text-emerald-400">ضيف</span>
          </motion.h1>
          
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="text-lg md:text-2xl text-white/90 mb-8 max-w-3xl mx-auto font-medium drop-shadow-md leading-relaxed"
          >
            {t('hero.subtitle')}
          </motion.p>

          {/* Region Indicator */}
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="inline-flex items-center gap-6 bg-black/30 backdrop-blur-xl border border-white/20 rounded-full px-6 py-2.5 text-white mb-6 shadow-xl"
          >
            <button onClick={prevRegion} className="hover:text-emerald-400 transition-colors p-1 hover:bg-white/10 rounded-full">
              <ChevronRight className="w-5 h-5 rtl:rotate-180" />
            </button>
            <div className="flex flex-col items-center min-w-[180px]">
              <AnimatePresence mode="wait">
                <motion.div
                  key={SYRIA_REGIONS[currentRegionIndex].id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className="text-center"
                >
                  <span className="block font-bold text-emerald-400 text-lg">{SYRIA_REGIONS[currentRegionIndex].name}</span>
                  <span className="block text-xs text-gray-300 mt-0.5">{SYRIA_REGIONS[currentRegionIndex].description}</span>
                </motion.div>
              </AnimatePresence>
            </div>
            <button onClick={nextRegion} className="hover:text-emerald-400 transition-colors p-1 hover:bg-white/10 rounded-full">
              <ChevronLeft className="w-5 h-5 rtl:rotate-180" />
            </button>
          </motion.div>
        </div>

        {/* Search Widget */}
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="max-w-4xl mx-auto relative z-20 mt-12"
        >
          <div className="bg-white/80 backdrop-blur-3xl rounded-3xl md:rounded-full shadow-[0_8px_30px_rgba(0,0,0,0.08)] border border-white/60 p-1.5 flex flex-col items-center gap-2 relative">
            
            {/* Elegant Tabs */}
            <div className="flex items-center gap-1 px-2 md:border-e border-gray-300/30 w-full md:w-auto overflow-x-auto hide-scrollbar pb-2 md:pb-0">
              {TABS.map((tab) => {
                const Icon = tab.icon;
                const isActive = activeTab === tab.id;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`flex items-center gap-1.5 px-4 py-2.5 rounded-full transition-all whitespace-nowrap ${
                      isActive 
                        ? 'bg-emerald-600 text-white shadow-md' 
                        : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100/50 font-medium'
                    }`}
                  >
                    <Icon className={`w-4 h-4 ${isActive ? 'stroke-[2]' : 'stroke-[1.5]'}`} />
                    <span className="text-sm font-bold">{tab.label}</span>
                  </button>
                );
              })}
            </div>

            {/* Dynamic Search Area */}
            <div className="flex-1 w-full relative">
              <AnimatePresence mode="wait">
                {activeTab === 'ai' ? (
                  <motion.form 
                    key="ai-search"
                    initial={{ opacity: 0, scale: 0.98 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.98 }}
                    onSubmit={handleAISearch}
                    className="flex items-center w-full bg-white/50 rounded-full border border-transparent focus-within:border-emerald-200 focus-within:bg-white transition-all px-2 shadow-inner group"
                  >
                    <div className="flex-1 flex items-center gap-3 px-4 py-3">
                      <Sparkles className="w-5 h-5 text-emerald-500 animate-pulse shrink-0" />
                      <input 
                        type="text" 
                        value={aiQuery}
                        onChange={(e) => setAiQuery(e.target.value)}
                        placeholder={t('hero.ai_placeholder')} 
                        className="w-full bg-transparent outline-none text-gray-900 font-medium placeholder-gray-400 text-sm transition-all duration-300 focus:text-base"
                      />
                    </div>
                    <button 
                      type="submit"
                      disabled={!aiQuery.trim()}
                      className="bg-emerald-600 text-white w-10 h-10 group-focus-within:w-24 rounded-full hover:bg-emerald-700 transition-all duration-300 flex items-center justify-center shrink-0 shadow-md disabled:opacity-50 overflow-hidden"
                    >
                      <Search className="w-4 h-4 shrink-0" />
                      <span className="text-sm font-bold mx-2 opacity-0 group-focus-within:opacity-100 whitespace-nowrap transition-opacity duration-300 hidden sm:block">{t('hero.search')}</span>
                    </button>
                  </motion.form>
                ) : (
                  <motion.div 
                    key="normal-search"
                    initial={{ opacity: 0, scale: 0.98 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.98 }}
                    className="flex flex-col md:flex-row items-center w-full bg-white/50 rounded-2xl md:rounded-full border border-transparent hover:border-gray-200 transition-all shadow-inner group focus-within:bg-white focus-within:border-emerald-200"
                  >
                    <div className="flex-1 flex items-center px-4 py-3 gap-3 md:border-e border-gray-300/30 transition-all duration-300 focus-within:flex-[1.5] w-full">
                      <MapPin className="w-4 h-4 text-emerald-600 shrink-0" />
                      <input 
                        type="text" 
                        value={location}
                        onChange={(e) => setLocation(e.target.value)}
                        placeholder={t('hero.destination')} 
                        className="w-full bg-transparent outline-none text-gray-900 font-bold text-sm placeholder-gray-400 transition-all duration-300 focus:text-base"
                      />
                    </div>
                    <div className="flex-1 flex items-center px-4 py-3 gap-3 md:border-e border-gray-300/30 hidden sm:flex transition-all duration-300 focus-within:flex-[1.5] w-full">
                      <Calendar className="w-4 h-4 text-emerald-600 shrink-0" />
                      <input 
                        type="date"
                        value={date}
                        onChange={(e) => setDate(e.target.value)}
                        className="w-full bg-transparent outline-none text-gray-900 font-bold text-sm cursor-pointer"
                      />
                    </div>
                    <div className="flex-1 flex items-center px-4 py-3 gap-3 hidden md:flex transition-all duration-300 focus-within:flex-[1.5] w-full">
                      <Users className="w-4 h-4 text-emerald-600 shrink-0" />
                      <select 
                        value={guests}
                        onChange={(e) => setGuests(Number(e.target.value))}
                        className="w-full bg-transparent outline-none text-gray-900 font-bold text-sm appearance-none cursor-pointer"
                      >
                        {[1, 2, 3, 4, 5, 6, 7, 8].map(n => (
                          <option key={n} value={n}>{n} {n === 1 ? t('hero.guest_unit') : t('hero.guests_unit')}</option>
                        ))}
                      </select>
                    </div>
                    <button 
                      onClick={handleSearch}
                      className="bg-emerald-600 text-white w-full md:w-12 h-12 md:group-focus-within:w-28 rounded-xl md:rounded-full hover:bg-emerald-700 transition-all duration-300 flex items-center justify-center shrink-0 shadow-md m-1 overflow-hidden"
                    >
                      <Search className="w-5 h-5 shrink-0" />
                      <span className="text-sm font-bold mx-2 opacity-0 md:group-focus-within:opacity-100 whitespace-nowrap transition-opacity duration-300 hidden sm:block">{t('hero.search')}</span>
                    </button>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
