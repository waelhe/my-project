'use client';

import React, { useState, useEffect, useRef } from 'react';
import Link from 'next/link';
import { ChevronLeft, ChevronRight, ArrowLeft, ArrowRight, Loader2 } from 'lucide-react';
import ServiceCard, { Listing } from './ServiceCard';
import { useLanguage } from '@/contexts/LanguageContext';
import { Skeleton } from '@/components/ui/skeleton';

interface ServiceSectionProps {
  title: string;
  subtitle?: string;
  categoryId?: string;
  filterPopular?: boolean;
  limit?: number;
}

export default function ServiceSection({ 
  title, 
  subtitle, 
  categoryId, 
  filterPopular = false, 
  limit = 8,
}: ServiceSectionProps) {
  const { language } = useLanguage();
  const [listings, setListings] = useState<Listing[]>([]);
  const [loading, setLoading] = useState(true);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const fetchListings = async () => {
      try {
        setLoading(true);
        
        const params = new URLSearchParams();
        params.append('limit', limit.toString());
        params.append('status', 'active');
        
        if (categoryId) {
          params.append('category', categoryId);
        }
        
        const response = await fetch(`/api/listings?${params.toString()}`);
        
        if (!response.ok) {
          throw new Error('Failed to fetch listings');
        }
        
        const data = await response.json();
        let fetchedListings = data.data || [];
        
        // Sort by rating if filterPopular is true
        if (filterPopular) {
          fetchedListings = fetchedListings.sort((a: Listing, b: Listing) => {
            const ratingA = a.ratingAverage || 0;
            const ratingB = b.ratingAverage || 0;
            return ratingB - ratingA;
          });
        }
        
        setListings(fetchedListings);
      } catch (error) {
        console.error('Error fetching listings for section:', error);
        setListings([]);
      } finally {
        setLoading(false);
      }
    };

    fetchListings();
  }, [categoryId, filterPopular, limit]);

  const scroll = (direction: 'left' | 'right') => {
    if (scrollRef.current) {
      const { scrollLeft, clientWidth } = scrollRef.current;
      const scrollTo = direction === 'left' 
        ? scrollLeft - clientWidth * 0.8 
        : scrollLeft + clientWidth * 0.8;
      
      scrollRef.current.scrollTo({ left: scrollTo, behavior: 'smooth' });
    }
  };

  if (!loading && listings.length === 0) return null;

  return (
    <section className="pt-0 pb-6 bg-white overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex justify-between items-end mb-4">
          <div className="flex-1">
            <h2 className="text-xl md:text-2xl font-bold text-gray-900 leading-tight">
              {title}
            </h2>
            {subtitle && <p className="text-sm text-gray-500 mt-1 max-w-2xl">{subtitle}</p>}
          </div>

          <div className="flex items-center gap-3">
            {categoryId && (
              <Link 
                href={`/?category=${categoryId}`} 
                className="p-2 hover:bg-gray-100 rounded-full transition-colors hidden sm:block"
              >
                {language === 'ar' ? <ArrowLeft className="w-5 h-5 text-gray-900" /> : <ArrowRight className="w-5 h-5 text-gray-900" />}
              </Link>
            )}
            <div className="flex items-center gap-1">
              <button 
                onClick={() => scroll('right')}
                className="p-2 rounded-full border border-gray-200 hover:bg-gray-50 transition-colors shadow-sm bg-white"
              >
                <ChevronRight className="w-4 h-4 text-gray-600" />
              </button>
              <button 
                onClick={() => scroll('left')}
                className="p-2 rounded-full border border-gray-200 hover:bg-gray-50 transition-colors shadow-sm bg-white"
              >
                <ChevronLeft className="w-4 h-4 text-gray-600" />
              </button>
            </div>
          </div>
        </div>

        {loading ? (
          <div className="flex gap-4 md:gap-6 overflow-hidden pb-4">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="min-w-[280px] md:min-w-[320px]">
                <div className="aspect-square rounded-xl bg-gray-100 mb-2">
                  <Skeleton className="w-full h-full" />
                </div>
                <div className="space-y-2">
                  <Skeleton className="h-4 w-3/4" />
                  <Skeleton className="h-3 w-1/2" />
                  <Skeleton className="h-4 w-1/3" />
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div 
            ref={scrollRef}
            className="flex gap-4 md:gap-6 overflow-x-auto pb-4 snap-x snap-mandatory hide-scrollbar"
          >
            {listings.map((listing) => (
              <div key={listing.id} className="snap-start">
                <ServiceCard 
                  listing={listing}
                  activeColorClass="bg-emerald-600 text-white"
                  activeTextClass="text-emerald-600"
                  activeBgLightClass="bg-emerald-50"
                />
              </div>
            ))}
          </div>
        )}
      </div>
    </section>
  );
}
